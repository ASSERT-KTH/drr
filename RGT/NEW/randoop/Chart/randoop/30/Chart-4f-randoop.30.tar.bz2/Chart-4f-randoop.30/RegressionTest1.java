import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 86400000L, Double.NaN);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        xYSeries4.addPropertyChangeListener(propertyChangeListener5);
        xYSeries4.add(0.05d, (double) 0);
        xYSeries4.fireSeriesChanged();
        xYSeriesCollection0.removeSeries(xYSeries4);
        try {
            org.jfree.data.xy.XYSeries xYSeries13 = xYSeriesCollection0.getSeries((java.lang.Comparable) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: -1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        java.awt.Font font9 = categoryAxis3D5.getTickLabelFont();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) font9, seriesChangeInfo10);
        barRenderer3D0.setLegendTextFont(0, font9);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        java.awt.Font font14 = categoryAxis3D10.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection19 = combinedRangeXYPlot15.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        combinedRangeXYPlot15.setDomainAxes(valueAxisArray21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot15.setDomainTickBandPaint((java.awt.Paint) color23);
        java.awt.Stroke stroke25 = combinedRangeXYPlot15.getRangeCrosshairStroke();
        categoryAxis3D10.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        jFreeChart27.setBorderVisible(true);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBasePaint();
        xYBarRenderer2.setShadowXOffset((double) 4);
        java.lang.Boolean boolean7 = xYBarRenderer2.getSeriesItemLabelsVisible((int) (byte) 100);
        double double8 = xYBarRenderer2.getShadowXOffset();
        xYBarRenderer2.setAutoPopulateSeriesFillPaint(false);
        double double11 = xYBarRenderer2.getShadowXOffset();
        boolean boolean12 = barRenderer0.equals((java.lang.Object) double11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        boolean boolean15 = barRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setLabelPaint(paint3);
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem2.setFillPaint(paint5);
        org.jfree.data.xy.XYDataItem xYDataItem9 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot10.clearDomainAxes();
        boolean boolean15 = xYDataItem9.equals((java.lang.Object) combinedRangeXYPlot10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot16.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        combinedRangeXYPlot16.setFixedRangeAxisSpace(axisSpace19, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot22.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = combinedRangeXYPlot22.getDomainMarkers(6, layer27);
        combinedRangeXYPlot22.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot16.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot22);
        java.awt.Image image32 = null;
        combinedRangeXYPlot16.setBackgroundImage(image32);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset35 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot16.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset35);
        int int37 = combinedRangeXYPlot10.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset35);
        legendItem2.setDataset((org.jfree.data.general.Dataset) defaultXYDataset35);
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset35, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(range40);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate22 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        java.lang.Object obj23 = intervalXYDelegate22.clone();
        try {
            intervalXYDelegate22.setIntervalPositionFactor((double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("SerialDate.weekInMonthToString(): invalid code.");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key SerialDate.weekInMonthToString(): invalid code.");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        defaultPieDataset0.validateObject();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getRangeCrosshairStroke();
        defaultPieDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedRangeXYPlot7.getRenderer();
        combinedRangeXYPlot7.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.String str1 = standardXYToolTipGenerator0.getFormatString();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}: ({1}, {2})" + "'", str1.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        categoryPlot5.setRangeCrosshairValue((double) 100.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot15.getRangeAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        java.lang.String str25 = categoryPlot24.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot24.getRangeAxisLocation(9999);
        combinedRangeXYPlot15.setDomainAxisLocation((int) ' ', axisLocation27);
        categoryPlot5.setDomainAxisLocation((int) (short) 1, axisLocation27);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Category Plot" + "'", str25.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        double double4 = dateRange1.constrain((double) '4');
        long long5 = dateRange1.getUpperMillis();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeZeroBaselinePaint();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        categoryPlot5.setDomainCrosshairColumnKey((java.lang.Comparable) '#');
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double3 = categoryAxis3D2.getCategoryMargin();
        categoryAxis3D2.setLabelAngle((double) (byte) 100);
        java.awt.Paint paint6 = categoryAxis3D2.getTickMarkPaint();
        boolean boolean7 = gradientPaintTransformType0.equals((java.lang.Object) categoryAxis3D2);
        categoryAxis3D2.setCategoryMargin(4.0d);
        java.awt.Paint paint11 = null;
        categoryAxis3D2.setTickLabelPaint((java.lang.Comparable) 900000.0d, paint11);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = xYAreaRenderer6.getGradientTransformer();
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = new org.jfree.chart.ChartRenderingInfo();
        try {
            java.awt.image.BufferedImage bufferedImage26 = jFreeChart20.createBufferedImage(0, 13, 255, chartRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 255");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer0.setSeriesStroke((int) (byte) 100, stroke5);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesOutlinePaint((int) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(itemLabelPosition10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        xYSeries3.add(0.05d, (double) 0);
        xYSeries3.fireSeriesChanged();
        xYSeries3.add((double) (-1L), 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        piePlot3D1.setAutoPopulateSectionPaint(false);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke2 = combinedRangeXYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getPlotArea();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = xYAreaRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            java.lang.Number number3 = timeSeriesCollection0.getX((int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        boolean boolean7 = ringPlot6.getSimpleLabels();
        double double8 = ringPlot6.getOuterSeparatorExtension();
        ringPlot6.setInnerSeparatorExtension((double) (-2208960000000L));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        java.awt.Paint paint14 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(true, true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer0.getItemLabelGenerator((-1), 0, true);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        java.lang.String str25 = categoryPlot24.getPlotType();
        org.jfree.chart.plot.Marker marker26 = null;
        boolean boolean27 = categoryPlot24.removeDomainMarker(marker26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot24.setRangeMinorGridlineStroke(stroke28);
        barRenderer0.setBaseOutlineStroke(stroke28);
        double double31 = barRenderer0.getShadowYOffset();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator33 = null;
        barRenderer0.setSeriesItemLabelGenerator(2019, categoryItemLabelGenerator33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Category Plot" + "'", str25.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        boolean boolean6 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        combinedRangeXYPlot0.panRangeAxes((double) 10L, plotRenderingInfo8, point2D9);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot3.clearDomainAxes();
        boolean boolean8 = xYDataItem2.equals((java.lang.Object) combinedRangeXYPlot3);
        org.jfree.chart.axis.ValueAxis valueAxis9 = combinedRangeXYPlot3.getRangeAxis();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(valueAxis9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        categoryAxis3D30.setLowerMargin(0.08d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        ringPlot1.setOuterSeparatorExtension(0.05d);
        ringPlot1.setShadowXOffset(0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        jFreeChart20.setBackgroundImageAlignment((int) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = jFreeChart20.getPadding();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer0.setSeriesStroke((int) (byte) 100, stroke5);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesOutlinePaint((int) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYBarRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Shape shape11 = xYBarRenderer0.lookupLegendShape((int) (byte) 1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot5.setDataset(categoryDataset9);
        java.awt.Paint paint11 = categoryPlot5.getNoDataMessagePaint();
        java.awt.Paint paint12 = categoryPlot5.getRangeMinorGridlinePaint();
        categoryPlot5.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = null;
        try {
            java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape28, rectangleAnchor29, (double) 0.5f, (double) 1964);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(shape28);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        try {
            org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset25, (java.lang.Comparable) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.lang.Object obj4 = xYBarRenderer0.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer6.setSeriesURLGenerator(6, xYURLGenerator8);
        java.lang.Object obj10 = xYBarRenderer6.clone();
        java.awt.Stroke stroke12 = xYBarRenderer6.getSeriesOutlineStroke((int) (short) 0);
        java.awt.Stroke stroke13 = xYBarRenderer6.getBaseStroke();
        xYBarRenderer0.setSeriesStroke(5, stroke13, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = xYBarRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(drawingSupplier16);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint8 = categoryPlot5.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        java.awt.Font font20 = categoryAxis3D16.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection25 = combinedRangeXYPlot21.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] { valueAxis26 };
        combinedRangeXYPlot21.setDomainAxes(valueAxisArray27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot21.setDomainTickBandPaint((java.awt.Paint) color29);
        java.awt.Stroke stroke31 = combinedRangeXYPlot21.getRangeCrosshairStroke();
        categoryAxis3D16.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot21);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot21);
        java.awt.Paint paint34 = jFreeChart33.getBorderPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint34);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer36 = intervalMarker35.getGradientPaintTransformer();
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot5.removeDomainMarker(128, (org.jfree.chart.plot.Marker) intervalMarker35, layer37);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(gradientPaintTransformer36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer15 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        xYBarRenderer15.setSeriesURLGenerator(6, xYURLGenerator17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer15.setSeriesNegativeItemLabelPosition(15, itemLabelPosition20);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition20);
        java.awt.Font font23 = barRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(font23);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("TextBlockAnchor.TOP_RIGHT");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator7);
        java.awt.Paint paint10 = xYBarRenderer0.getSeriesPaint(1);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 5);
        int int3 = dateTickUnit2.getMultiple();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double3 = categoryAxis3D2.getCategoryMargin();
        categoryAxis3D2.setLabelAngle((double) (byte) 100);
        java.awt.Paint paint6 = categoryAxis3D2.getTickMarkPaint();
        boolean boolean7 = gradientPaintTransformType0.equals((java.lang.Object) categoryAxis3D2);
        boolean boolean8 = categoryAxis3D2.isVisible();
        categoryAxis3D2.setCategoryLabelPositionOffset((int) ' ');
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        double double4 = dateRange0.constrain((double) 100.0f);
        long long5 = dateRange0.getLowerMillis();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer4.findRangeBounds(categoryDataset6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYBarRenderer9.setSeriesURLGenerator(6, xYURLGenerator11);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer9.setSeriesStroke((int) (byte) 100, stroke14);
        java.awt.Paint paint17 = xYBarRenderer9.lookupSeriesOutlinePaint((int) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYBarRenderer9.getBasePositiveItemLabelPosition();
        barRenderer4.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition18);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!", paint6);
        legendItem7.setShapeVisible(true);
        java.lang.Comparable comparable10 = legendItem7.getSeriesKey();
        legendItemCollection4.add(legendItem7);
        org.jfree.chart.LegendItem legendItem13 = legendItemCollection4.get(0);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertNotNull(legendItem13);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        boolean boolean7 = xYAreaRenderer6.getPlotShapes();
        boolean boolean9 = xYAreaRenderer6.isSeriesItemLabelsVisible((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("java.awt.Color[r=134,g=134,b=134]", "hi!", "SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        legendTitle2.setLegendItemGraphicPadding(rectangleInsets7);
        org.jfree.chart.block.BlockContainer blockContainer9 = legendTitle2.getItemContainer();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(blockContainer9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) font7, seriesChangeInfo8);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("{0}: ({1}, {2})", font7);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        piePlot3D1.setAutoPopulateSectionOutlinePaint(false);
        piePlot3D1.setShadowXOffset(0.5d);
        float float8 = piePlot3D1.getBackgroundAlpha();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        double double4 = piePlot3D1.getMinimumArcAngleToDraw();
        double double5 = piePlot3D1.getDepthFactor();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = null;
        try {
            piePlot3D1.setLabelLinkStyle(pieLabelLinkStyle6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-5d + "'", double4 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12d + "'", double5 == 0.12d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.text.NumberFormat numberFormat5 = logFormat4.getExponentFormat();
        try {
            java.lang.Object obj7 = numberFormat5.parseObject("NO_CHANGE");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 13, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot15.getRangeAxisLocation(0);
        java.awt.Paint paint18 = combinedRangeXYPlot15.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.util.List list21 = null;
        combinedRangeXYPlot15.drawDomainTickBands(graphics2D19, rectangle2D20, list21);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", paint27);
        legendItem28.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset31 = null;
        legendItem28.setDataset(dataset31);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer33 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = null;
        xYBarRenderer33.setSeriesURLGenerator(6, xYURLGenerator35);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer33.setSeriesStroke((int) (byte) 100, stroke38);
        legendItem28.setOutlineStroke(stroke38);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color25, stroke38);
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean44 = combinedRangeXYPlot15.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker41, layer42, true);
        boolean boolean45 = combinedRangeXYPlot6.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker41);
        org.jfree.chart.util.Layer layer46 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(128, (org.jfree.chart.plot.Marker) valueMarker41, layer46, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate26 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        double[] doubleArray32 = new double[] { 0.0f, 100, 9999, 0.0d };
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        try {
            defaultXYDataset19.addSeries((java.lang.Comparable) "Category Plot", doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'data' array must have length == 2.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, (double) 0.0f, (double) 13, (double) 3, (double) (short) 10, font10);
        legendTitle2.setItemFont(font10);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        java.awt.Font font20 = categoryAxis3D16.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection25 = combinedRangeXYPlot21.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] { valueAxis26 };
        combinedRangeXYPlot21.setDomainAxes(valueAxisArray27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot21.setDomainTickBandPaint((java.awt.Paint) color29);
        java.awt.Stroke stroke31 = combinedRangeXYPlot21.getRangeCrosshairStroke();
        categoryAxis3D16.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot21);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot21);
        java.awt.Paint paint34 = jFreeChart33.getBorderPaint();
        legendTitle2.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart33);
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = legendTitle2.getVerticalAlignment();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(verticalAlignment36);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = combinedRangeXYPlot0.getFixedLegendItems();
        combinedRangeXYPlot0.configureRangeAxes();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.axis.TickUnits tickUnits7 = new org.jfree.chart.axis.TickUnits();
        int int8 = tickUnits7.size();
        numberAxis6.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits7);
        org.jfree.data.Range range10 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.lang.String str7 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot6.removeDomainMarker(marker8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot6.getAxisOffset();
        boolean boolean11 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.setRangeMinorGridlinesVisible(true);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter7 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 1.0f, (double) 0.0f, (double) (short) -1);
        xYBarRenderer0.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter7);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYBarRenderer9.setSeriesURLGenerator(6, xYURLGenerator11);
        java.lang.Object obj13 = xYBarRenderer9.clone();
        xYBarRenderer9.setSeriesItemLabelsVisible(9999, true);
        boolean boolean17 = gradientXYBarPainter7.equals((java.lang.Object) xYBarRenderer9);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!", paint6);
        legendItem7.setShapeVisible(true);
        java.lang.Comparable comparable10 = legendItem7.getSeriesKey();
        legendItemCollection4.add(legendItem7);
        try {
            org.jfree.chart.LegendItem legendItem13 = legendItemCollection4.get(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        double double4 = dateRange0.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange6);
        java.lang.Class<?> wildcardClass8 = dateRange6.getClass();
        org.jfree.data.Range range9 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (double) ' ');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint11.toFixedHeight((double) 2019);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot12.getRangeAxisLocation(15);
        categoryPlot5.setRangeAxisLocation(axisLocation17, false);
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color21 = color20.darker();
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Paint paint23 = categoryPlot5.getRangeZeroBaselinePaint();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", paint28);
        legendItem29.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset32 = null;
        legendItem29.setDataset(dataset32);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator36 = null;
        xYBarRenderer34.setSeriesURLGenerator(6, xYURLGenerator36);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer34.setSeriesStroke((int) (byte) 100, stroke39);
        legendItem29.setOutlineStroke(stroke39);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color26, stroke39);
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = categoryPlot5.removeRangeMarker(2, (org.jfree.chart.plot.Marker) valueMarker42, layer43);
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = blockBorder49.getInsets();
        double double52 = rectangleInsets50.trimWidth(0.05d);
        valueMarker42.setLabelOffset(rectangleInsets50);
        java.lang.String str54 = rectangleInsets50.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + (-13.95d) + "'", double52 == (-13.95d));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "RectangleInsets[t=35.0,l=1.0,b=100.0,r=13.0]" + "'", str54.equals("RectangleInsets[t=35.0,l=1.0,b=100.0,r=13.0]"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (-2208960000000L), 10, 0.08d, 900000.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (-2208960000000L), 10, 0.08d, 900000.0d };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (-2208960000000L), 10, 0.08d, 900000.0d };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { (-2208960000000L), 10, 0.08d, 900000.0d };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { (-2208960000000L), 10, 0.08d, 900000.0d };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { (-2208960000000L), 10, 0.08d, 900000.0d };
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21, numberArray26, numberArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "RectangleInsets[t=35.0,l=1.0,b=100.0,r=13.0]", numberArray32);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        textTitle23.setText("item");
        java.awt.Paint paint26 = textTitle23.getBackgroundPaint();
        int int27 = textTitle23.getMaximumLinesToDisplay();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        piePlot3D1.setBackgroundImageAlignment((int) (byte) 10);
        piePlot3D1.setSectionOutlinesVisible(true);
        java.awt.Stroke stroke8 = piePlot3D1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot5.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            categoryPlot5.addDomainMarker((int) (short) 100, categoryMarker12, layer13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        java.util.List list2 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection0.removeSeries(timeSeries4);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape8, 0.0d, 100.0f, (float) 'a');
        boolean boolean13 = numberTickUnit7.equals((java.lang.Object) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries14 = timeSeriesCollection0.getSeries((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(timeSeries14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        barRenderer3D0.setBaseSeriesVisible(false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer3D0.setSeriesURLGenerator((int) ' ', categoryURLGenerator6, false);
        barRenderer3D0.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertNotNull(barPainter1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.zoomRange((-13.95d), (double) 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        double double2 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) (short) 10, (double) 1L);
        defaultKeyedValues0.setValue((java.lang.Comparable) (byte) -1, (java.lang.Number) 3);
        java.lang.Object obj7 = defaultKeyedValues0.clone();
        try {
            java.lang.Number number9 = defaultKeyedValues0.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = combinedRangeXYPlot6.getLegendItems();
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", paint18);
        legendItem19.setSeriesIndex((int) ' ');
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", paint23);
        legendItem24.setShapeVisible(true);
        java.lang.Comparable comparable27 = legendItem24.getSeriesKey();
        java.awt.Paint paint28 = legendItem24.getFillPaint();
        legendItem19.setOutlinePaint(paint28);
        legendItemCollection16.add(legendItem19);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(comparable27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        textBlock1.draw(graphics2D2, (float) '4', 10.0f, textBlockAnchor5, (float) 6, (float) (short) 1, (double) 2);
        java.util.List list10 = textBlock1.getLines();
        try {
            org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot8.getRangeMarkers(layer21);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot7.setRangeAxis((int) (byte) 100, valueAxis9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot7.setRangeAxis(valueAxis11);
        boolean boolean13 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot7.getDomainAxis();
        boolean boolean15 = blockBorder1.equals((java.lang.Object) categoryAxis14);
        java.lang.String str16 = categoryAxis14.getLabelToolTip();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categoryAxis14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator10 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        xYBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator13);
        java.awt.Shape shape16 = xYBarRenderer0.getSeriesShape((int) '#');
        org.junit.Assert.assertNull(shape16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int3 = java.awt.Color.HSBtoRGB((float) '4', (float) (-459), (float) 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-3680) + "'", int3 == (-3680));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        java.lang.Comparable comparable5 = legendItem2.getSeriesKey();
        java.awt.Paint paint6 = legendItem2.getFillPaint();
        java.awt.Paint paint7 = legendItem2.getLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        double double4 = dateRange0.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange6);
        java.lang.Class<?> wildcardClass8 = dateRange6.getClass();
        org.jfree.data.Range range9 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange6);
        double double10 = range9.getLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        defaultPieDataset0.clear();
        defaultPieDataset0.insertValue((int) (byte) 0, (java.lang.Comparable) 10.0f, 10.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int1 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot0.getRangeAxisIndex(valueAxis2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = combinedRangeXYPlot4.getDomainMarkers(6, layer9);
        combinedRangeXYPlot4.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot13.getRangeAxisLocation(0);
        java.awt.Paint paint16 = combinedRangeXYPlot13.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        combinedRangeXYPlot13.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", paint25);
        legendItem26.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset29 = null;
        legendItem26.setDataset(dataset29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = null;
        xYBarRenderer31.setSeriesURLGenerator(6, xYURLGenerator33);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer31.setSeriesStroke((int) (byte) 100, stroke36);
        legendItem26.setOutlineStroke(stroke36);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color23, stroke36);
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean42 = combinedRangeXYPlot13.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker39, layer40, true);
        boolean boolean43 = combinedRangeXYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker39);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot44.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection48 = combinedRangeXYPlot44.getLegendItems();
        boolean boolean49 = valueMarker39.equals((java.lang.Object) legendItemCollection48);
        org.jfree.chart.util.Layer layer50 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker39, layer50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(legendItemCollection48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.text.NumberFormat numberFormat11 = logFormat10.getExponentFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator("ThreadContext", (java.text.NumberFormat) logFormat5, numberFormat11);
        int int13 = logFormat5.getMaximumFractionDigits();
        boolean boolean14 = logFormat5.isGroupingUsed();
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean3 = tickUnits0.equals((java.lang.Object) shape2);
        java.lang.Object obj4 = tickUnits0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        boolean boolean16 = categoryPlot5.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        java.lang.String str10 = categoryPlot9.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot9.getRangeAxisLocation(9999);
        combinedRangeXYPlot0.setDomainAxisLocation((int) ' ', axisLocation12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = combinedRangeXYPlot0.getRangeAxisEdge((int) (short) 100);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        java.util.List list3 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        java.text.AttributedString attributedString5 = legendItem2.getAttributedLabel();
        java.awt.Paint paint6 = legendItem2.getLabelPaint();
        legendItem2.setToolTipText("");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        piePlot3D1.setLegendItemShape(shape4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot3D1.setLabelOutlineStroke(stroke6);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset8 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset8);
        int int11 = defaultPieDataset8.getIndex((java.lang.Comparable) "java.awt.Color[r=134,g=134,b=134]");
        piePlot3D1.setDataset((org.jfree.data.general.PieDataset) defaultPieDataset8);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        try {
            xYSeries3.update((java.lang.Number) 255, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 255");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        java.awt.Paint paint4 = combinedRangeXYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getRangeAxisLocation(0);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        combinedRangeXYPlot5.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", paint17);
        legendItem18.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset21 = null;
        legendItem18.setDataset(dataset21);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = null;
        xYBarRenderer23.setSeriesURLGenerator(6, xYURLGenerator25);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer23.setSeriesStroke((int) (byte) 100, stroke28);
        legendItem18.setOutlineStroke(stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color15, stroke28);
        org.jfree.chart.util.Layer layer32 = null;
        boolean boolean34 = combinedRangeXYPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32, true);
        java.awt.Stroke stroke35 = combinedRangeXYPlot5.getDomainMinorGridlineStroke();
        combinedRangeXYPlot0.setRangeCrosshairStroke(stroke35);
        boolean boolean37 = combinedRangeXYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesFilled();
        xYLineAndShapeRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setDrawOutlines(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorLeft(90.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.lang.Object obj4 = xYBarRenderer0.clone();
        java.awt.Stroke stroke6 = xYBarRenderer0.getSeriesOutlineStroke((int) (short) 0);
        java.awt.Stroke stroke7 = xYBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator9 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = xYBarRenderer0.getDrawingSupplier();
        java.util.Collection collection12 = xYBarRenderer0.getAnnotations();
        java.awt.Font font14 = xYBarRenderer0.lookupLegendTextFont(0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(drawingSupplier11);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNull(font14);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("{0}: ({1}, {2})");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection0.getSeries((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (35).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = categoryPlot5.getRangeMinorGridlineStroke();
        boolean boolean11 = categoryPlot5.isDomainPannable();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        double double13 = barRenderer12.getMinimumBarLength();
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", paint15);
        legendItem16.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset19 = null;
        legendItem16.setDataset(dataset19);
        java.awt.Paint paint21 = legendItem16.getOutlinePaint();
        barRenderer12.setShadowPaint(paint21);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = barRenderer12.getItemLabelGenerator(2, 9999, true);
        boolean boolean28 = barRenderer12.isSeriesItemLabelsVisible((int) (byte) 1);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12, true);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke33 = combinedRangeXYPlot32.getRangeCrosshairStroke();
        java.awt.Paint paint34 = combinedRangeXYPlot32.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = combinedRangeXYPlot32.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D39, valueAxis40, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer41);
        java.awt.Font font43 = categoryAxis3D39.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot44.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection48 = combinedRangeXYPlot44.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] { valueAxis49 };
        combinedRangeXYPlot44.setDomainAxes(valueAxisArray50);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot44.setDomainTickBandPaint((java.awt.Paint) color52);
        java.awt.Stroke stroke54 = combinedRangeXYPlot44.getRangeCrosshairStroke();
        categoryAxis3D39.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot44);
        org.jfree.chart.JFreeChart jFreeChart56 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot44);
        jFreeChart56.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle59 = jFreeChart56.getTitle();
        java.awt.Paint paint60 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle59.setPaint(paint60);
        java.awt.geom.Rectangle2D rectangle2D62 = textTitle59.getBounds();
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets35.createInsetRectangle(rectangle2D62, true, false);
        try {
            categoryPlot5.drawOutline(graphics2D31, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(legendItemCollection48);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(textTitle59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangle2D65);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorRight((double) 9999);
        double double3 = axisState0.getMax();
        axisState0.cursorLeft((double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot3.clearDomainAxes();
        boolean boolean8 = xYDataItem2.equals((java.lang.Object) combinedRangeXYPlot3);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot9.setFixedRangeAxisSpace(axisSpace12, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = combinedRangeXYPlot15.getDomainMarkers(6, layer20);
        combinedRangeXYPlot15.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot9.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        java.awt.Image image25 = null;
        combinedRangeXYPlot9.setBackgroundImage(image25);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset28 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot9.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset28);
        int int30 = combinedRangeXYPlot3.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset28);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        combinedRangeXYPlot3.setFixedRangeAxisSpace(axisSpace31, false);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        java.awt.Font font41 = categoryAxis3D37.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot42.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection46 = combinedRangeXYPlot42.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray48 = new org.jfree.chart.axis.ValueAxis[] { valueAxis47 };
        combinedRangeXYPlot42.setDomainAxes(valueAxisArray48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot42.setDomainTickBandPaint((java.awt.Paint) color50);
        java.awt.Stroke stroke52 = combinedRangeXYPlot42.getRangeCrosshairStroke();
        categoryAxis3D37.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot42);
        org.jfree.chart.JFreeChart jFreeChart54 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot42);
        jFreeChart54.setNotify(true);
        java.util.List list57 = jFreeChart54.getSubtitles();
        org.jfree.chart.axis.AxisState axisState58 = new org.jfree.chart.axis.AxisState();
        java.util.List list59 = axisState58.getTicks();
        jFreeChart54.setSubtitles(list59);
        jFreeChart54.removeLegend();
        combinedRangeXYPlot3.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart54);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(valueAxisArray48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(list59);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        xYSeries3.add((double) (byte) 1, (java.lang.Number) (-135.0d), false);
        double double10 = xYSeries3.getMinX();
        java.util.List list11 = xYSeries3.getItems();
        double double12 = xYSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-135.0d) + "'", double12 == (-135.0d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        boolean boolean16 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 1);
        barRenderer0.setDrawBarOutline(false);
        double double19 = barRenderer0.getShadowXOffset();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator20 = null;
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            int int7 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) defaultXYDataset0, 0, (double) (-61755710400001L), 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        java.util.List list8 = categoryPlot5.getCategories();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "VerticalAlignment.TOP", "hi!", "ItemLabelAnchor.OUTSIDE3", "");
        java.lang.String str6 = basicProjectInfo5.getCopyright();
        java.lang.String str7 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ItemLabelAnchor.OUTSIDE3" + "'", str6.equals("ItemLabelAnchor.OUTSIDE3"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ItemLabelAnchor.OUTSIDE3" + "'", str7.equals("ItemLabelAnchor.OUTSIDE3"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 15, "ThreadContext", textAnchor2, textAnchor3, (double) (short) 1);
        java.lang.Number number6 = numberTick5.getNumber();
        org.jfree.chart.axis.TickType tickType7 = numberTick5.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick5.getTextAnchor();
        java.lang.String str9 = numberTick5.getText();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 15 + "'", number6.equals(15));
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ThreadContext" + "'", str9.equals("ThreadContext"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        piePlot3D1.setMaximumLabelWidth((double) ' ');
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = combinedRangeXYPlot6.getLegendItems();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            combinedRangeXYPlot6.addRangeMarker(marker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(legendItemCollection16);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        int int25 = polarPlot24.getSeriesCount();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        double double27 = barRenderer26.getMinimumBarLength();
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("hi!", paint29);
        legendItem30.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset33 = null;
        legendItem30.setDataset(dataset33);
        java.awt.Paint paint35 = legendItem30.getOutlinePaint();
        barRenderer26.setShadowPaint(paint35);
        java.awt.Paint paint38 = barRenderer26.lookupSeriesPaint(5);
        polarPlot24.setRadiusGridlinePaint(paint38);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        java.awt.Paint paint4 = combinedRangeXYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getRangeAxisLocation(0);
        java.awt.Paint paint8 = combinedRangeXYPlot5.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        combinedRangeXYPlot5.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", paint17);
        legendItem18.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset21 = null;
        legendItem18.setDataset(dataset21);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer23 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator25 = null;
        xYBarRenderer23.setSeriesURLGenerator(6, xYURLGenerator25);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer23.setSeriesStroke((int) (byte) 100, stroke28);
        legendItem18.setOutlineStroke(stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color15, stroke28);
        org.jfree.chart.util.Layer layer32 = null;
        boolean boolean34 = combinedRangeXYPlot5.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32, true);
        java.awt.Stroke stroke35 = combinedRangeXYPlot5.getDomainMinorGridlineStroke();
        combinedRangeXYPlot0.setRangeCrosshairStroke(stroke35);
        java.awt.Paint paint38 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("hi!", paint38);
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem39.setLabelPaint(paint40);
        java.awt.Paint paint42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem39.setFillPaint(paint42);
        combinedRangeXYPlot0.setRangeMinorGridlinePaint(paint42);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        piePlot3D1.setAutoPopulateSectionOutlinePaint(false);
        piePlot3D1.setShadowXOffset(0.5d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = null;
        try {
            piePlot3D1.setLabelDistributor(abstractPieLabelDistributor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        double double4 = dateRange0.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange6);
        java.lang.Class<?> wildcardClass8 = dateRange6.getClass();
        org.jfree.data.Range range9 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange6);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange10, (org.jfree.data.Range) dateRange11);
        boolean boolean13 = dateRange6.intersects((org.jfree.data.Range) dateRange10);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange10);
        double double15 = dateRange14.getUpperBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getRangeCrosshairStroke();
        java.awt.Paint paint6 = combinedRangeXYPlot4.getRangeCrosshairPaint();
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) combinedRangeXYPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot4.getRangeAxisEdge();
        java.lang.Object obj9 = null;
        boolean boolean10 = rectangleEdge8.equals(obj9);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(date1);
        boolean boolean5 = segment2.contains(10L, (long) (short) 1);
        boolean boolean7 = segment2.contains((long) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline8.getSegment(date9);
        boolean boolean13 = segment10.contains(10L, (long) (short) 1);
        boolean boolean14 = segment2.before(segment10);
        segment10.moveIndexToStart();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.text.NumberFormat numberFormat11 = logFormat10.getExponentFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator("ThreadContext", (java.text.NumberFormat) logFormat5, numberFormat11);
        numberFormat11.setMinimumIntegerDigits(6);
        org.junit.Assert.assertNotNull(numberFormat11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        java.awt.Shape shape7 = xYAreaRenderer6.getLegendArea();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D(pieDataset12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D13);
        org.jfree.chart.event.TitleChangeListener titleChangeListener15 = null;
        legendTitle14.addChangeListener(titleChangeListener15);
        org.jfree.chart.entity.TitleEntity titleEntity19 = new org.jfree.chart.entity.TitleEntity(shape11, (org.jfree.chart.title.Title) legendTitle14, "Category Plot", "-0.0");
        java.lang.Number[] numberArray28 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray28, numberArray33 };
        org.jfree.data.category.CategoryDataset categoryDataset35 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray34);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity38 = new org.jfree.chart.entity.CategoryItemEntity(shape11, "HorizontalAlignment.CENTER", "January 13", categoryDataset35, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double41 = categoryAxis3D40.getCategoryMargin();
        boolean boolean42 = categoryAxis3D40.isTickLabelsVisible();
        float float43 = categoryAxis3D40.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D45 = new org.jfree.chart.plot.PiePlot3D(pieDataset44);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = null;
        piePlot3D45.datasetChanged(datasetChangeEvent46);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke49 = combinedRangeXYPlot48.getRangeCrosshairStroke();
        java.awt.Paint paint50 = combinedRangeXYPlot48.getRangeCrosshairPaint();
        boolean boolean51 = piePlot3D45.equals((java.lang.Object) combinedRangeXYPlot48);
        piePlot3D45.setLabelLinkMargin((double) 15);
        java.awt.Paint paint54 = piePlot3D45.getBaseSectionOutlinePaint();
        categoryAxis3D40.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D45);
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer60 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D58, valueAxis59, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer60);
        java.lang.String str62 = categoryPlot61.getPlotType();
        org.jfree.chart.plot.Marker marker63 = null;
        boolean boolean64 = categoryPlot61.removeDomainMarker(marker63);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = categoryPlot61.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot66 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot66.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection70 = combinedRangeXYPlot66.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] { valueAxis71 };
        combinedRangeXYPlot66.setDomainAxes(valueAxisArray72);
        java.awt.Color color74 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot66.setDomainTickBandPaint((java.awt.Paint) color74);
        java.awt.Stroke stroke76 = combinedRangeXYPlot66.getRangeCrosshairStroke();
        boolean boolean77 = rectangleInsets65.equals((java.lang.Object) stroke76);
        categoryAxis3D40.setLabelInsets(rectangleInsets65, false);
        org.jfree.chart.axis.NumberAxis numberAxis81 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D82 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D82.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis81, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D82);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity88 = new org.jfree.chart.entity.CategoryItemEntity(shape7, "RectangleAnchor.TOP", "", categoryDataset35, (java.lang.Comparable) "item", (java.lang.Comparable) "HorizontalAlignment.CENTER");
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.2d + "'", double41 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Category Plot" + "'", str62.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertNotNull(legendItemCollection70);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition6);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint9 = xYBarRenderer8.getBasePaint();
        xYBarRenderer8.setAutoPopulateSeriesShape(true);
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter15 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 1.0f, (double) 0.0f, (double) (short) -1);
        xYBarRenderer8.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter15);
        xYBarRenderer0.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter15);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.data.Range range18 = barRenderer15.findRangeBounds(categoryDataset17);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color20 = color19.darker();
        barRenderer15.setBaseItemLabelPaint((java.awt.Paint) color20, false);
        categoryPlot5.setRangeZeroBaselinePaint((java.awt.Paint) color20);
        categoryPlot5.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset19, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate26 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19);
        try {
            java.lang.Number number29 = intervalXYDelegate26.getEndX(2019, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range25);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.lang.String str7 = categoryPlot6.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot6.getRangeAxisLocation(9999);
        boolean boolean10 = booleanList0.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot6.setAxisOffset(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.NumberAxis numberAxis2 = null;
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedRangeXYPlot9.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        combinedRangeXYPlot9.setDomainAxes(valueAxisArray15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot9.setDomainTickBandPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", paint20);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem21.setLabelPaint(paint22);
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem21.setFillPaint(paint24);
        boolean boolean26 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color17, paint24);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("hi!", font7, (java.awt.Paint) color17);
        java.awt.geom.Rectangle2D rectangle2D28 = labelBlock27.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis29 = null;
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis29, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font34);
        labelBlock27.setFont(font34);
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("-0.0", font34);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo39);
        java.awt.geom.Rectangle2D rectangle2D41 = plotRenderingInfo40.getDataArea();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D44, valueAxis45, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer46);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot47.getDomainAxisEdge((int) (byte) 1);
        float float50 = categoryPlot47.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        categoryPlot47.setDataset(categoryDataset51);
        java.awt.Paint paint53 = categoryPlot47.getNoDataMessagePaint();
        java.awt.Paint paint54 = categoryPlot47.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer60 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D58, valueAxis59, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer60);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer63 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint64 = xYBarRenderer63.getBasePaint();
        barRenderer60.setSeriesFillPaint(3, paint64, true);
        categoryPlot47.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer60);
        try {
            java.lang.Object obj68 = labelBlock37.draw(graphics2D38, rectangle2D41, (java.lang.Object) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.5f + "'", float50 == 0.5f);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(paint64);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        xYSeries4.addPropertyChangeListener(propertyChangeListener5);
        xYSeries4.add(0.05d, (double) 0);
        xYSeries4.fireSeriesChanged();
        xYSeriesCollection0.removeSeries(xYSeries4);
        double double12 = xYSeries4.getMinY();
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getRangeCrosshairStroke();
        java.awt.Paint paint6 = combinedRangeXYPlot4.getRangeCrosshairPaint();
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) combinedRangeXYPlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot4.getRangeAxisEdge();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "VerticalAlignment.TOP", "hi!", "ItemLabelAnchor.OUTSIDE3", "");
        boolean boolean15 = rectangleEdge8.equals((java.lang.Object) "ItemLabelAnchor.OUTSIDE3");
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        piePlot3D1.setBackgroundImageAlignment((int) (byte) 10);
        piePlot3D1.setSectionOutlinesVisible(true);
        boolean boolean8 = piePlot3D1.isCircular();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        boolean boolean25 = polarPlot24.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace8, false);
        java.util.List list11 = combinedRangeXYPlot0.getSubplots();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart20.getLegend(0);
        java.awt.Image image24 = jFreeChart20.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D27, valueAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot30.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint33 = categoryPlot30.getRangeZeroBaselinePaint();
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot30.getColumnRenderingOrder();
        try {
            jFreeChart20.setTextAntiAlias((java.lang.Object) sortOrder34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SortOrder.ASCENDING incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(sortOrder34);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getRangeAxisLocation(0);
        java.awt.Paint paint5 = combinedRangeXYPlot2.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        combinedRangeXYPlot2.drawDomainTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedRangeXYPlot2, "DomainOrder.ASCENDING", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        java.awt.Font font20 = categoryAxis3D16.getTickLabelFont();
        boolean boolean21 = rectangleAnchor13.equals((java.lang.Object) categoryAxis3D16);
        categoryAxis3D16.setMaximumCategoryLabelLines(4);
        org.jfree.chart.entity.AxisEntity axisEntity25 = new org.jfree.chart.entity.AxisEntity(shape1, (org.jfree.chart.axis.Axis) categoryAxis3D16, "NO_CHANGE");
        boolean boolean27 = axisEntity25.equals((java.lang.Object) 3.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer0.getItemLabelGenerator((-1), 0, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", paint25);
        legendItem26.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset29 = null;
        legendItem26.setDataset(dataset29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = null;
        xYBarRenderer31.setSeriesURLGenerator(6, xYURLGenerator33);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer31.setSeriesStroke((int) (byte) 100, stroke36);
        legendItem26.setOutlineStroke(stroke36);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color23, stroke36);
        barRenderer0.setSeriesStroke(5, stroke36);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation41 = null;
        boolean boolean42 = barRenderer0.removeAnnotation(categoryAnnotation41);
        java.awt.Paint paint43 = barRenderer0.getBaseItemLabelPaint();
        double double44 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(5);
        boolean boolean15 = barRenderer0.getItemVisible(1964, (int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        java.awt.Font font9 = categoryAxis3D5.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = combinedRangeXYPlot10.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { valueAxis15 };
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot10.setDomainTickBandPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot10.getRangeCrosshairStroke();
        categoryAxis3D5.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot10);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot10);
        java.awt.Paint paint23 = jFreeChart22.getBorderPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint23);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = intervalMarker24.getGradientPaintTransformer();
        java.lang.Object obj26 = intervalMarker24.clone();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(gradientPaintTransformer25);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        java.text.AttributedString attributedString5 = legendItem2.getAttributedLabel();
        boolean boolean6 = legendItem2.isShapeFilled();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        boolean boolean15 = barRenderer0.isDrawBarOutline();
        boolean boolean19 = barRenderer0.isItemLabelVisible((int) (byte) -1, 0, true);
        org.jfree.chart.LegendItem legendItem22 = barRenderer0.getLegendItem(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(legendItem22);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        barRenderer0.setBaseOutlinePaint(paint11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot13.getRangeAxisLocation(15);
        boolean boolean19 = combinedRangeXYPlot13.isNotify();
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot13);
        combinedRangeXYPlot13.setWeight(255);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer28);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer35);
        java.lang.String str37 = categoryPlot36.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation39 = categoryPlot36.getRangeAxisLocation(9999);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot36.zoomRangeAxes((double) 100.0f, (double) 900000L, plotRenderingInfo43, point2D44);
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot29.zoomRangeAxes(15.0d, plotRenderingInfo43, point2D46, false);
        java.awt.geom.Point2D point2D49 = null;
        try {
            combinedRangeXYPlot13.zoomDomainAxes((double) (byte) 10, plotRenderingInfo43, point2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Category Plot" + "'", str37.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation39);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange2);
        double double5 = dateRange1.constrain((double) 100.0f);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange1, (double) 1964, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(1.0d, range8);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer4.findRangeBounds(categoryDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = barRenderer4.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        barRenderer4.setNegativeItemLabelPositionFallback(itemLabelPosition9);
        barRenderer4.setMinimumBarLength((double) (short) 100);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint8 = categoryPlot5.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = categoryPlot5.getDatasetRenderingOrder();
        java.lang.String str10 = categoryPlot5.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot5.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double3 = categoryAxis3D2.getCategoryMargin();
        categoryAxis3D2.setLabelAngle((double) (byte) 100);
        boolean boolean6 = lengthAdjustmentType0.equals((java.lang.Object) (byte) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean8 = lengthAdjustmentType0.equals((java.lang.Object) color7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getXFormat();
        boolean boolean2 = numberFormat1.isGroupingUsed();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        legendTitle2.setNotify(false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Pie 3D Plot");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        java.awt.Paint paint14 = categoryPlot5.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot5.getRangeAxisEdge();
        categoryPlot5.clearRangeMarkers(15);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot6.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { valueAxis11 };
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot6.setDomainTickBandPaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", paint17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem18.setLabelPaint(paint19);
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem18.setFillPaint(paint21);
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color14, paint21);
        boolean boolean24 = defaultPieDataset0.equals((java.lang.Object) paint21);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boolean24, true);
        boolean boolean27 = rendererChangeEvent26.getSeriesVisibilityChanged();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getPlotArea();
        java.awt.Paint paint2 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle23.setPaint(paint24);
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle23.getBounds();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = textTitle23.getTextAlignment();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(6, layer5);
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        boolean boolean3 = xYDataItem2.isSelected();
        xYDataItem2.setY(1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(date1);
        int int3 = segmentedTimeline0.getGroupSegmentCount();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        jFreeChart20.setBackgroundImageAlignment((int) (short) -1);
        try {
            org.jfree.chart.title.Title title27 = jFreeChart20.getSubtitle((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.lang.String str6 = logFormat4.format((double) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11);
        java.lang.String str13 = categoryPlot12.getPlotType();
        org.jfree.chart.plot.Marker marker14 = null;
        boolean boolean15 = categoryPlot12.removeDomainMarker(marker14);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        categoryPlot12.datasetChanged(datasetChangeEvent16);
        boolean boolean18 = logFormat4.equals((java.lang.Object) datasetChangeEvent16);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-0.0" + "'", str6.equals("-0.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            xYSeriesCollection0.removeSeries((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2, true);
        org.jfree.data.Range range5 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        org.jfree.chart.plot.Marker marker13 = null;
        boolean boolean14 = categoryPlot11.removeDomainMarker(marker13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot11.setRangeMinorGridlineStroke(stroke15);
        xYBarRenderer0.setBaseOutlineStroke(stroke15, true);
        xYBarRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYBarRenderer5.setSeriesURLGenerator(6, xYURLGenerator7);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer5.setSeriesStroke((int) (byte) 100, stroke10);
        combinedRangeXYPlot0.setRangeGridlineStroke(stroke10);
        combinedRangeXYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot5.getRangeAxisLocation(9999);
        int int9 = categoryPlot5.getRendererCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        combinedRangeXYPlot10.setFixedRangeAxisSpace(axisSpace13, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot16.getDomainMarkers(6, layer21);
        combinedRangeXYPlot16.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot10.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        combinedRangeXYPlot10.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        double double29 = barRenderer28.getMinimumBarLength();
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", paint31);
        legendItem32.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset35 = null;
        legendItem32.setDataset(dataset35);
        java.awt.Paint paint37 = legendItem32.getOutlinePaint();
        barRenderer28.setShadowPaint(paint37);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator42 = barRenderer28.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = barRenderer28.getItemLabelGenerator((-1), 0, true);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D49, valueAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer51);
        java.lang.String str53 = categoryPlot52.getPlotType();
        org.jfree.chart.plot.Marker marker54 = null;
        boolean boolean55 = categoryPlot52.removeDomainMarker(marker54);
        java.awt.Stroke stroke56 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot52.setRangeMinorGridlineStroke(stroke56);
        barRenderer28.setBaseOutlineStroke(stroke56);
        combinedRangeXYPlot10.setDomainMinorGridlineStroke(stroke56);
        categoryPlot5.setRangeCrosshairStroke(stroke56);
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = null;
        try {
            categoryPlot5.addDomainMarker(categoryMarker61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(categoryItemLabelGenerator42);
        org.junit.Assert.assertNull(categoryItemLabelGenerator46);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Category Plot" + "'", str53.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardPieToolTipGenerator0.getNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Object obj10 = titleEntity9.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        try {
            defaultKeyedValues0.insertValue((int) (short) -1, (java.lang.Comparable) serialDate3, (-13.95d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYBarRenderer1.setSeriesURLGenerator(6, xYURLGenerator3);
        java.lang.Object obj5 = xYBarRenderer1.clone();
        java.awt.Shape shape9 = xYBarRenderer1.getItemShape((int) (byte) 1, (-1), false);
        multiplePiePlot0.setLegendItemShape(shape9);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 5);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        xYSeries4.addPropertyChangeListener(propertyChangeListener5);
        xYSeries4.add(0.05d, (double) 0);
        xYSeries4.fireSeriesChanged();
        xYSeriesCollection0.removeSeries(xYSeries4);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        java.awt.Font font19 = categoryAxis3D15.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection24 = combinedRangeXYPlot20.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        combinedRangeXYPlot20.setDomainAxes(valueAxisArray26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot20.setDomainTickBandPaint((java.awt.Paint) color28);
        java.awt.Stroke stroke30 = combinedRangeXYPlot20.getRangeCrosshairStroke();
        categoryAxis3D15.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot20);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot20);
        java.awt.Paint paint33 = jFreeChart32.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle35 = jFreeChart32.getLegend(0);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent38 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) xYSeries4, jFreeChart32, 1964, (int) (short) 10);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(legendTitle35);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getXFormat();
        numberFormat1.setGroupingUsed(true);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis28 = null;
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis28, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font33);
        labelBlock26.setFont(font33);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint37 = xYBarRenderer36.getBasePaint();
        xYBarRenderer36.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator41 = xYBarRenderer36.getSeriesToolTipGenerator(10);
        java.awt.Paint paint42 = xYBarRenderer36.getBasePaint();
        boolean boolean43 = labelBlock26.equals((java.lang.Object) paint42);
        labelBlock26.setToolTipText("HorizontalAlignment.CENTER");
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.data.time.DateRange dateRange47 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange48 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange47, (org.jfree.data.Range) dateRange48);
        double double51 = dateRange47.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange52 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange53 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange52, (org.jfree.data.Range) dateRange53);
        java.lang.String str55 = dateRange53.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange47, (org.jfree.data.Range) dateRange53);
        try {
            org.jfree.chart.util.Size2D size2D57 = labelBlock26.arrange(graphics2D46, rectangleConstraint56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(xYToolTipGenerator41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str55.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle23.setPaint(paint24);
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle23.getBounds();
        java.lang.Object obj27 = textTitle23.clone();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = xYBarRenderer0.getGradientPaintTransformer();
        java.awt.Stroke stroke4 = null;
        xYBarRenderer0.setSeriesOutlineStroke(255, stroke4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double2 = xYSeriesCollection0.getRangeUpperBound(true);
        int int3 = xYSeriesCollection0.getSeriesCount();
        try {
            java.lang.Number number6 = xYSeriesCollection0.getEndX((int) 'a', 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 900000L, (float) '#', 1.0f);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("HorizontalAlignment.LEFT");
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        categoryAxis3D30.setAxisLineVisible(true);
        float float78 = categoryAxis3D30.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 0.0f + "'", float78 == 0.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer4.findRangeBounds(categoryDataset6);
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color9 = color8.darker();
        barRenderer4.setBaseItemLabelPaint((java.awt.Paint) color9, false);
        double double12 = barRenderer4.getMinimumBarLength();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        double double16 = barRenderer15.getMinimumBarLength();
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", paint18);
        legendItem19.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset22 = null;
        legendItem19.setDataset(dataset22);
        java.awt.Paint paint24 = legendItem19.getOutlinePaint();
        barRenderer15.setShadowPaint(paint24);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = barRenderer15.getItemLabelGenerator(2, 9999, true);
        boolean boolean31 = barRenderer15.isSeriesItemLabelsVisible((int) (byte) 1);
        barRenderer15.setDrawBarOutline(false);
        boolean boolean34 = layer14.equals((java.lang.Object) barRenderer15);
        try {
            barRenderer4.addAnnotation(categoryAnnotation13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryItemLabelGenerator29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) 10, (double) (-1L), plotRenderingInfo11, point2D12);
        categoryPlot5.configureRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = combinedRangeXYPlot15.getDomainMarkers(6, layer20);
        combinedRangeXYPlot15.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = combinedRangeXYPlot24.getRangeAxisLocation(0);
        java.awt.Paint paint27 = combinedRangeXYPlot24.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.util.List list30 = null;
        combinedRangeXYPlot24.drawDomainTickBands(graphics2D28, rectangle2D29, list30);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", paint36);
        legendItem37.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset40 = null;
        legendItem37.setDataset(dataset40);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator44 = null;
        xYBarRenderer42.setSeriesURLGenerator(6, xYURLGenerator44);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer42.setSeriesStroke((int) (byte) 100, stroke47);
        legendItem37.setOutlineStroke(stroke47);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color34, stroke47);
        org.jfree.chart.util.Layer layer51 = null;
        boolean boolean53 = combinedRangeXYPlot24.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker50, layer51, true);
        boolean boolean54 = combinedRangeXYPlot15.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker50);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot55 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot55.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection59 = combinedRangeXYPlot55.getLegendItems();
        boolean boolean60 = valueMarker50.equals((java.lang.Object) legendItemCollection59);
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.renderer.category.BarRenderer barRenderer62 = new org.jfree.chart.renderer.category.BarRenderer();
        double double63 = barRenderer62.getMinimumBarLength();
        java.awt.Paint paint65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem66 = new org.jfree.chart.LegendItem("hi!", paint65);
        legendItem66.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset69 = null;
        legendItem66.setDataset(dataset69);
        java.awt.Paint paint71 = legendItem66.getOutlinePaint();
        barRenderer62.setShadowPaint(paint71);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator76 = barRenderer62.getItemLabelGenerator(2, 9999, true);
        boolean boolean78 = barRenderer62.isSeriesItemLabelsVisible((int) (byte) 1);
        barRenderer62.setDrawBarOutline(false);
        boolean boolean81 = layer61.equals((java.lang.Object) barRenderer62);
        boolean boolean82 = categoryPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker50, layer61);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(legendItemCollection59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNull(categoryItemLabelGenerator76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot5.setDataset(categoryDataset9);
        java.awt.Paint paint11 = categoryPlot5.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            categoryPlot5.addDomainMarker((int) (short) 1, categoryMarker13, layer14, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(layer14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        java.util.List list2 = timeSeriesCollection0.getSeries();
        try {
            java.lang.Number number5 = timeSeriesCollection0.getY(15, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        piePlot3D7.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = piePlot3D7.getLegendLabelGenerator();
        double double11 = piePlot3D7.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = null;
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis14, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection25 = combinedRangeXYPlot21.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] { valueAxis26 };
        combinedRangeXYPlot21.setDomainAxes(valueAxisArray27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot21.setDomainTickBandPaint((java.awt.Paint) color29);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", paint32);
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem33.setLabelPaint(paint34);
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem33.setFillPaint(paint36);
        boolean boolean38 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color29, paint36);
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("hi!", font19, (java.awt.Paint) color29);
        java.awt.geom.Rectangle2D rectangle2D40 = labelBlock39.getBounds();
        piePlot3D7.drawBackgroundImage(graphics2D12, rectangle2D40);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset42 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean43 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset42);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke45 = combinedRangeXYPlot44.getRangeCrosshairStroke();
        java.awt.Paint paint46 = combinedRangeXYPlot44.getRangeCrosshairPaint();
        boolean boolean47 = defaultPieDataset42.hasListener((java.util.EventListener) combinedRangeXYPlot44);
        defaultPieDataset42.validateObject();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot49 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke50 = combinedRangeXYPlot49.getRangeCrosshairStroke();
        defaultPieDataset42.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = combinedRangeXYPlot49.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer57 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D55, valueAxis56, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer57);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D62 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D62, valueAxis63, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer64);
        java.lang.String str66 = categoryPlot65.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation68 = categoryPlot65.getRangeAxisLocation(9999);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo71);
        java.awt.geom.Point2D point2D73 = null;
        categoryPlot65.zoomRangeAxes((double) 100.0f, (double) 900000L, plotRenderingInfo72, point2D73);
        java.awt.geom.Point2D point2D75 = null;
        categoryPlot58.zoomRangeAxes(15.0d, plotRenderingInfo72, point2D75, false);
        try {
            org.jfree.chart.axis.AxisState axisState78 = numberAxis1.draw(graphics2D3, 10.0d, rectangle2D5, rectangle2D40, rectangleEdge52, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.14d + "'", double11 == 0.14d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Category Plot" + "'", str66.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation68);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeZeroBaselinePaint();
        categoryPlot5.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        piePlot3D2.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot5 = piePlot3D2.getRootPlot();
        java.awt.Paint paint6 = piePlot3D2.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D2.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = null;
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis10, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection21 = combinedRangeXYPlot17.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        combinedRangeXYPlot17.setDomainAxes(valueAxisArray23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot17.setDomainTickBandPaint((java.awt.Paint) color25);
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", paint28);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem29.setLabelPaint(paint30);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem29.setFillPaint(paint32);
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color25, paint32);
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("hi!", font15, (java.awt.Paint) color25);
        java.awt.geom.Rectangle2D rectangle2D36 = labelBlock35.getBounds();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D36);
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D39 = new org.jfree.chart.plot.PiePlot3D(pieDataset38);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = null;
        piePlot3D39.datasetChanged(datasetChangeEvent40);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke43 = combinedRangeXYPlot42.getRangeCrosshairStroke();
        java.awt.Paint paint44 = combinedRangeXYPlot42.getRangeCrosshairPaint();
        boolean boolean45 = piePlot3D39.equals((java.lang.Object) combinedRangeXYPlot42);
        piePlot3D39.setLabelLinkMargin((double) 15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo49);
        org.jfree.chart.plot.PiePlotState piePlotState51 = piePlot3D2.initialise(graphics2D8, rectangle2D36, (org.jfree.chart.plot.PiePlot) piePlot3D39, (java.lang.Integer) 0, plotRenderingInfo50);
        boolean boolean52 = rotation0.equals((java.lang.Object) piePlotState51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = piePlotState51.getInfo();
        java.awt.geom.Rectangle2D rectangle2D54 = plotRenderingInfo53.getPlotArea();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(piePlotState51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo53);
        org.junit.Assert.assertNull(rectangle2D54);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            xYSeriesCollection0.removeSeries(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint8 = categoryPlot5.getRangeZeroBaselinePaint();
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot5.getColumnRenderingOrder();
        categoryPlot5.setBackgroundAlpha((float) 2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(sortOrder9);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(1, 13);
        java.lang.String str5 = month4.toString();
        java.awt.Stroke stroke6 = strokeMap0.getStroke((java.lang.Comparable) month4);
        java.util.Calendar calendar7 = null;
        try {
            month4.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 13" + "'", str5.equals("January 13"));
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setUpperMargin((double) 5);
        categoryAxis3D1.setVisible(true);
        java.lang.String str7 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) (-61755710400001L));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getDrawOutlines();
        org.jfree.chart.LegendItem legendItem4 = xYLineAndShapeRenderer0.getLegendItem((-3680), 128);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        piePlot3D6.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot9 = piePlot3D6.getRootPlot();
        java.awt.Paint paint10 = piePlot3D6.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot3D6.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = null;
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis14, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection25 = combinedRangeXYPlot21.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] { valueAxis26 };
        combinedRangeXYPlot21.setDomainAxes(valueAxisArray27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot21.setDomainTickBandPaint((java.awt.Paint) color29);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", paint32);
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem33.setLabelPaint(paint34);
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem33.setFillPaint(paint36);
        boolean boolean38 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color29, paint36);
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("hi!", font19, (java.awt.Paint) color29);
        java.awt.geom.Rectangle2D rectangle2D40 = labelBlock39.getBounds();
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D40);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D43 = new org.jfree.chart.plot.PiePlot3D(pieDataset42);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        piePlot3D43.datasetChanged(datasetChangeEvent44);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot46 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke47 = combinedRangeXYPlot46.getRangeCrosshairStroke();
        java.awt.Paint paint48 = combinedRangeXYPlot46.getRangeCrosshairPaint();
        boolean boolean49 = piePlot3D43.equals((java.lang.Object) combinedRangeXYPlot46);
        piePlot3D43.setLabelLinkMargin((double) 15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo53);
        org.jfree.chart.plot.PiePlotState piePlotState55 = piePlot3D6.initialise(graphics2D12, rectangle2D40, (org.jfree.chart.plot.PiePlot) piePlot3D43, (java.lang.Integer) 0, plotRenderingInfo54);
        xYLineAndShapeRenderer0.setLegendLine((java.awt.Shape) rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(piePlotState55);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        java.lang.String str1 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.SECOND" + "'", str1.equals("DateTickUnitType.SECOND"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape1 = null;
        try {
            xYAreaRenderer0.setLegendArea(shape1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection0.clearSelection();
        try {
            java.lang.Number number4 = xYSeriesCollection0.getY((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator10 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        xYBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator13);
        boolean boolean15 = xYBarRenderer0.isDrawBarOutline();
        boolean boolean19 = xYBarRenderer0.getItemCreateEntity((int) ' ', 0, false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot5.getFixedLegendItems();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedRangeXYPlot9.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        combinedRangeXYPlot9.setDomainAxes(valueAxisArray15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot9.setDomainTickBandPaint((java.awt.Paint) color17);
        java.awt.Stroke stroke19 = combinedRangeXYPlot9.getRangeCrosshairStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", paint23);
        legendItem24.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset27 = null;
        legendItem24.setDataset(dataset27);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator31 = null;
        xYBarRenderer29.setSeriesURLGenerator(6, xYURLGenerator31);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer29.setSeriesStroke((int) (byte) 100, stroke34);
        legendItem24.setOutlineStroke(stroke34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color21, stroke34);
        combinedRangeXYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker37);
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean41 = categoryPlot5.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker37, layer39, true);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace42);
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot46 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation48 = combinedRangeXYPlot46.getRangeAxisLocation(0);
        java.awt.Paint paint49 = combinedRangeXYPlot46.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        java.util.List list52 = null;
        combinedRangeXYPlot46.drawDomainTickBands(graphics2D50, rectangle2D51, list52);
        org.jfree.chart.entity.PlotEntity plotEntity56 = new org.jfree.chart.entity.PlotEntity(shape45, (org.jfree.chart.plot.Plot) combinedRangeXYPlot46, "DomainOrder.ASCENDING", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D60 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer62 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D60, valueAxis61, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer62);
        java.awt.Font font64 = categoryAxis3D60.getTickLabelFont();
        boolean boolean65 = rectangleAnchor57.equals((java.lang.Object) categoryAxis3D60);
        categoryAxis3D60.setMaximumCategoryLabelLines(4);
        org.jfree.chart.entity.AxisEntity axisEntity69 = new org.jfree.chart.entity.AxisEntity(shape45, (org.jfree.chart.axis.Axis) categoryAxis3D60, "NO_CHANGE");
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D60);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean5 = numberAxis4.isInverted();
        numberAxis4.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.data.RangeType rangeType9 = org.jfree.data.RangeType.NEGATIVE;
        numberAxis4.setRangeType(rangeType9);
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rangeType9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        float float7 = ringPlot6.getForegroundAlpha();
        boolean boolean8 = ringPlot6.getSeparatorsVisible();
        java.awt.Paint paint9 = ringPlot6.getLabelLinkPaint();
        ringPlot6.setInnerSeparatorExtension((double) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        boolean boolean3 = categoryAxis3D1.isTickLabelsVisible();
        float float4 = categoryAxis3D1.getTickMarkInsideLength();
        categoryAxis3D1.setLabelURL("Category Plot");
        double double7 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = xYBarRenderer0.getSeriesToolTipGenerator(10);
        java.awt.Paint paint6 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setBarAlignmentFactor(0.05d);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = xYBarRenderer0.getItemLabelGenerator(12, 2019, true);
        xYBarRenderer0.setSeriesCreateEntities((int) (byte) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYToolTipGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(xYItemLabelGenerator12);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.text.NumberFormat numberFormat5 = logFormat4.getExponentFormat();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getDomainAxisEdge((int) (byte) 1);
        float float14 = categoryPlot11.getBackgroundImageAlpha();
        boolean boolean15 = logFormat4.equals((java.lang.Object) categoryPlot11);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot21.getOrientation();
        categoryPlot11.setOrientation(plotOrientation24);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(plotOrientation24);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo(entityCollection1);
        org.junit.Assert.assertNotNull(entityCollection1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        piePlot3D2.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3D2.getLegendLabelGenerator();
        double double6 = piePlot3D2.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = null;
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis9, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection20 = combinedRangeXYPlot16.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        combinedRangeXYPlot16.setDomainAxes(valueAxisArray22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot16.setDomainTickBandPaint((java.awt.Paint) color24);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", paint27);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem28.setLabelPaint(paint29);
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem28.setFillPaint(paint31);
        boolean boolean33 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color24, paint31);
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("hi!", font14, (java.awt.Paint) color24);
        java.awt.geom.Rectangle2D rectangle2D35 = labelBlock34.getBounds();
        piePlot3D2.drawBackgroundImage(graphics2D7, rectangle2D35);
        try {
            boolean boolean37 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection16 = combinedRangeXYPlot12.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] { valueAxis17 };
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot12.setDomainTickBandPaint((java.awt.Paint) color20);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", paint23);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem24.setLabelPaint(paint25);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem24.setFillPaint(paint27);
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color20, paint27);
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("hi!", font10, (java.awt.Paint) color20);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        labelBlock30.setContentAlignmentPoint(textBlockAnchor31);
        java.awt.Shape shape36 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) 6, textBlockAnchor31, (float) (short) 0, (float) 61200000L, (double) 0.5f);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("VerticalAlignment.TOP");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 10, "SeriesRenderingOrder.REVERSE");
        org.jfree.chart.axis.TickUnits tickUnits5 = new org.jfree.chart.axis.TickUnits();
        int int6 = tickUnits5.size();
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean8 = tickUnits5.equals((java.lang.Object) shape7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean10 = tickUnits5.equals((java.lang.Object) rectangleAnchor9);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getDrawOutlines();
        boolean boolean2 = xYLineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getUseFillPaint();
        boolean boolean2 = xYLineAndShapeRenderer0.getDrawSeriesLineAsPath();
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.getPlotArea();
        boolean boolean3 = xYAreaRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        boolean boolean4 = xYAreaRenderer0.isOutline();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis28 = null;
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis28, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font33);
        labelBlock26.setFont(font33);
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange37 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange36, (org.jfree.data.Range) dateRange37);
        double double40 = dateRange36.constrain((double) 100.0f);
        boolean boolean41 = labelBlock26.equals((java.lang.Object) double40);
        org.jfree.chart.axis.NumberAxis numberAxis42 = null;
        java.awt.Font font47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis42, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font47);
        labelBlock26.setFont(font47);
        java.lang.String str50 = labelBlock26.getToolTipText();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNull(str50);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        barRenderer3D72.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo0.getPlotInfo();
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        java.util.List list2 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection0.removeSeries(timeSeries4);
        timeSeriesCollection0.removeAllSeries();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getCeilingTickUnit((double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D4);
        org.jfree.chart.event.TitleChangeListener titleChangeListener6 = null;
        legendTitle5.addChangeListener(titleChangeListener6);
        org.jfree.chart.entity.TitleEntity titleEntity10 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle5, "Category Plot", "-0.0");
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, (double) 10, (float) 9999, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("NO_CHANGE");
        java.awt.Font font3 = textFragment2.getFont();
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        int int5 = color4.getAlpha();
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=134,g=134,b=134]", font3, (java.awt.Paint) color4, (float) 5, textMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = plotRenderingInfo1.getDataArea();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo1);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = state3.getSelectionState();
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNull(xYDatasetSelectionState4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        boolean boolean6 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYBarRenderer7.setSeriesURLGenerator(6, xYURLGenerator9);
        xYBarRenderer7.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        int int14 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        int int15 = combinedRangeXYPlot0.getWeight();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getRangeAxisLocation(0);
        java.awt.Paint paint5 = combinedRangeXYPlot2.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.util.List list8 = null;
        combinedRangeXYPlot2.drawDomainTickBands(graphics2D6, rectangle2D7, list8);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) combinedRangeXYPlot2, "DomainOrder.ASCENDING", "ItemLabelAnchor.OUTSIDE3");
        plotEntity12.setURLText("hi!");
        plotEntity12.setURLText("HorizontalAlignment.LEFT");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(date1);
        boolean boolean5 = segment2.contains(10L, (long) (short) 1);
        boolean boolean7 = segment2.contains((long) (byte) 1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline8.getSegment(date9);
        boolean boolean13 = segment10.contains(10L, (long) (short) 1);
        boolean boolean14 = segment2.before(segment10);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        java.awt.Font font22 = categoryAxis3D18.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot23.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection27 = combinedRangeXYPlot23.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        combinedRangeXYPlot23.setDomainAxes(valueAxisArray29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot23.setDomainTickBandPaint((java.awt.Paint) color31);
        java.awt.Stroke stroke33 = combinedRangeXYPlot23.getRangeCrosshairStroke();
        categoryAxis3D18.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot23);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot23);
        jFreeChart35.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle38 = jFreeChart35.getTitle();
        java.lang.String str39 = textTitle38.getURLText();
        textTitle38.setMaximumLinesToDisplay(0);
        textTitle38.setNotify(true);
        try {
            int int44 = segment2.compareTo((java.lang.Object) textTitle38);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.title.TextTitle cannot be cast to org.jfree.chart.axis.SegmentedTimeline$Segment");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(segment2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(textTitle38);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getRangeAxisLocation(0);
        java.awt.Paint paint10 = combinedRangeXYPlot7.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        combinedRangeXYPlot7.drawDomainTickBands(graphics2D11, rectangle2D12, list13);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) combinedRangeXYPlot7, "DomainOrder.ASCENDING", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        java.awt.Font font25 = categoryAxis3D21.getTickLabelFont();
        boolean boolean26 = rectangleAnchor18.equals((java.lang.Object) categoryAxis3D21);
        categoryAxis3D21.setMaximumCategoryLabelLines(4);
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) categoryAxis3D21, "NO_CHANGE");
        int int31 = numberTickUnit4.compareTo((java.lang.Object) categoryAxis3D21);
        numberAxis1.setTickUnit(numberTickUnit4, true, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Paint paint8 = combinedRangeXYPlot0.getRangeTickBandPaint();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        int int11 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis10);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.data.xy.XYDataItem xYDataItem10 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot11.clearDomainAxes();
        boolean boolean16 = xYDataItem10.equals((java.lang.Object) combinedRangeXYPlot11);
        double double17 = xYDataItem10.getXValue();
        boolean boolean18 = xYDataItem10.isSelected();
        xYDataItem10.setY((java.lang.Number) 1L);
        try {
            defaultPieDataset0.insertValue((int) (byte) 100, (java.lang.Comparable) 1L, (java.lang.Number) 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = combinedRangeXYPlot8.getDomainMarkers(6, layer13);
        combinedRangeXYPlot8.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot2.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        boolean boolean18 = tickUnits0.equals((java.lang.Object) combinedRangeXYPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        try {
            combinedRangeXYPlot2.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo21, point2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int1 = defaultKeyedValues0.getItemCount();
        defaultKeyedValues0.setValue((java.lang.Comparable) "{0}: ({1}, {2})", (java.lang.Number) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj1 = multiplePiePlot0.clone();
        org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) multiplePiePlot0);
        try {
            org.jfree.chart.title.Title title4 = jFreeChart2.getSubtitle(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        double double9 = rectangleInsets7.trimWidth(0.05d);
        double double11 = rectangleInsets7.trimHeight((double) 0.0f);
        org.jfree.chart.axis.NumberAxis numberAxis13 = null;
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis13, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font18);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection24 = combinedRangeXYPlot20.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        combinedRangeXYPlot20.setDomainAxes(valueAxisArray26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot20.setDomainTickBandPaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", paint31);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem32.setLabelPaint(paint33);
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem32.setFillPaint(paint35);
        boolean boolean37 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, paint35);
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("hi!", font18, (java.awt.Paint) color28);
        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock38.getBounds();
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets7.createInsetRectangle(rectangle2D39);
        boolean boolean41 = org.jfree.chart.util.ShapeUtilities.isPointInRect(0.05d, (double) 900000L, rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-13.95d) + "'", double9 == (-13.95d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-135.0d) + "'", double11 == (-135.0d));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange2);
        java.lang.Class<?> wildcardClass4 = dateRange2.getClass();
        java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ItemLabelAnchor.OUTSIDE3", (java.lang.Class) wildcardClass4);
        boolean boolean6 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        defaultPieDataset0.validateObject();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getRangeCrosshairStroke();
        defaultPieDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedRangeXYPlot7.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.data.Range range18 = barRenderer15.findRangeBounds(categoryDataset17);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color20 = color19.darker();
        barRenderer15.setBaseItemLabelPaint((java.awt.Paint) color20, false);
        double double23 = barRenderer15.getMinimumBarLength();
        java.awt.Paint paint25 = barRenderer15.lookupSeriesPaint(15);
        combinedRangeXYPlot7.setRangeTickBandPaint(paint25);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 13);
        int int3 = month2.getMonth();
        long long4 = month2.getMiddleMillisecond();
        java.lang.String str5 = month2.toString();
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61755710400001L) + "'", long4 == (-61755710400001L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "January 13" + "'", str5.equals("January 13"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = combinedRangeXYPlot0.getAxisOffset();
        boolean boolean4 = combinedRangeXYPlot0.canSelectByPoint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = xYSeries3.getKey();
        double double7 = xYSeries3.getMaxY();
        double double8 = xYSeries3.getMaxX();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem10 = xYSeries3.remove((java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (byte) 10 + "'", comparable6.equals((byte) 10));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection3 = waferMapPlot0.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        double double4 = range3.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range3, (-135.0d));
        java.lang.String str7 = rectangleConstraint6.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=-135.0]" + "'", str7.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=-135.0]"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        double double6 = xYBarRenderer0.getShadowXOffset();
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedRangeXYPlot9.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        combinedRangeXYPlot9.setDomainAxes(valueAxisArray15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot9.setDomainTickBandPaint((java.awt.Paint) color17);
        xYBarRenderer0.setBaseLegendTextPaint((java.awt.Paint) color17);
        xYBarRenderer0.removeAnnotations();
        boolean boolean21 = xYBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Shape shape22 = xYBarRenderer0.getBaseShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        int int25 = polarPlot24.getSeriesCount();
        org.jfree.chart.axis.TickUnit tickUnit26 = polarPlot24.getAngleTickUnit();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = polarPlot24.getLegendItems();
        int int28 = polarPlot24.getSeriesCount();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(tickUnit26);
        org.junit.Assert.assertNotNull(legendItemCollection27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getDomainAxisEdge((int) (byte) 1);
        java.awt.Paint paint16 = categoryPlot13.getRangeZeroBaselinePaint();
        org.jfree.chart.util.SortOrder sortOrder17 = categoryPlot13.getColumnRenderingOrder();
        categoryPlot5.setColumnRenderingOrder(sortOrder17);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(sortOrder17);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 15, "ThreadContext", textAnchor2, textAnchor3, (double) (short) 1);
        java.lang.Number number6 = numberTick5.getNumber();
        double double7 = numberTick5.getValue();
        java.lang.Number number8 = numberTick5.getNumber();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 15 + "'", number6.equals(15));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 15.0d + "'", double7 == 15.0d);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 15 + "'", number8.equals(15));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator3);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor5 = null;
        try {
            piePlot3D1.setLabelDistributor(abstractPieLabelDistributor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle2.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer0.getItemLabelGenerator((-1), 0, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", paint25);
        legendItem26.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset29 = null;
        legendItem26.setDataset(dataset29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = null;
        xYBarRenderer31.setSeriesURLGenerator(6, xYURLGenerator33);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer31.setSeriesStroke((int) (byte) 100, stroke36);
        legendItem26.setOutlineStroke(stroke36);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color23, stroke36);
        barRenderer0.setSeriesStroke(5, stroke36);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation41 = null;
        boolean boolean42 = barRenderer0.removeAnnotation(categoryAnnotation41);
        java.awt.Paint paint43 = barRenderer0.getBaseItemLabelPaint();
        boolean boolean44 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("ItemLabelAnchor.OUTSIDE3");
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        boolean boolean6 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYBarRenderer7.setSeriesURLGenerator(6, xYURLGenerator9);
        xYBarRenderer7.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        int int14 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke16 = combinedRangeXYPlot15.getRangeCrosshairStroke();
        java.awt.Paint paint17 = combinedRangeXYPlot15.getRangeCrosshairPaint();
        combinedRangeXYPlot0.setRangeMinorGridlinePaint(paint17);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset2 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getRangeCrosshairStroke();
        java.awt.Paint paint6 = combinedRangeXYPlot4.getRangeCrosshairPaint();
        boolean boolean7 = defaultPieDataset2.hasListener((java.util.EventListener) combinedRangeXYPlot4);
        defaultPieDataset2.validateObject();
        try {
            java.lang.String str10 = standardPieSectionLabelGenerator1.generateSectionLabel((org.jfree.data.general.PieDataset) defaultPieDataset2, (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 0.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        int int23 = defaultXYDataset19.indexOf((java.lang.Comparable) "null");
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, (double) 0.0f, (double) 13, (double) 3, (double) (short) 10, font10);
        legendTitle2.setItemFont(font10);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = titleChangeEvent13.getType();
        org.jfree.chart.util.LogFormat logFormat19 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("");
        boolean boolean22 = logFormat19.equals((java.lang.Object) "");
        boolean boolean23 = chartChangeEventType14.equals((java.lang.Object) logFormat19);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("null");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key null");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.util.Rotation rotation7 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        piePlot3D9.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot12 = piePlot3D9.getRootPlot();
        java.awt.Paint paint13 = piePlot3D9.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot3D9.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = null;
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis17, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font22);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot24.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection28 = combinedRangeXYPlot24.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        combinedRangeXYPlot24.setDomainAxes(valueAxisArray30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot24.setDomainTickBandPaint((java.awt.Paint) color32);
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("hi!", paint35);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem36.setLabelPaint(paint37);
        java.awt.Paint paint39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem36.setFillPaint(paint39);
        boolean boolean41 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color32, paint39);
        org.jfree.chart.block.LabelBlock labelBlock42 = new org.jfree.chart.block.LabelBlock("hi!", font22, (java.awt.Paint) color32);
        java.awt.geom.Rectangle2D rectangle2D43 = labelBlock42.getBounds();
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D43);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D46 = new org.jfree.chart.plot.PiePlot3D(pieDataset45);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
        piePlot3D46.datasetChanged(datasetChangeEvent47);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot49 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke50 = combinedRangeXYPlot49.getRangeCrosshairStroke();
        java.awt.Paint paint51 = combinedRangeXYPlot49.getRangeCrosshairPaint();
        boolean boolean52 = piePlot3D46.equals((java.lang.Object) combinedRangeXYPlot49);
        piePlot3D46.setLabelLinkMargin((double) 15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo56);
        org.jfree.chart.plot.PiePlotState piePlotState58 = piePlot3D9.initialise(graphics2D15, rectangle2D43, (org.jfree.chart.plot.PiePlot) piePlot3D46, (java.lang.Integer) 0, plotRenderingInfo57);
        boolean boolean59 = rotation7.equals((java.lang.Object) piePlotState58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = piePlotState58.getInfo();
        java.awt.geom.Point2D point2D61 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(0.12d, 12.0d, plotRenderingInfo60, point2D61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(rotation7);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(piePlotState58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo60);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean3 = standardXYSeriesLabelGenerator1.equals((java.lang.Object) itemLabelAnchor2);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double2 = xYSeriesCollection0.getRangeUpperBound(true);
        int int3 = xYSeriesCollection0.getSeriesCount();
        boolean boolean4 = xYSeriesCollection0.isAutoWidth();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        java.util.List list23 = jFreeChart20.getSubtitles();
        org.jfree.chart.title.Title title25 = jFreeChart20.getSubtitle(0);
        java.awt.Paint paint26 = null;
        jFreeChart20.setBorderPaint(paint26);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(title25);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(5);
        java.awt.Paint paint16 = barRenderer0.getItemPaint(0, (int) (short) -1, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(15, itemLabelPosition5);
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean8 = itemLabelPosition5.equals((java.lang.Object) date7);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        boolean boolean8 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        java.awt.Paint paint9 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        combinedRangeXYPlot0.setDomainZeroBaselinePaint(paint9);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 2);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        jFreeChart20.clearSubtitles();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        boolean boolean8 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        combinedRangeXYPlot0.setDomainCrosshairValue(12.0d, false);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace12, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        combinedRangeXYPlot0.setRenderer(0, xYItemRenderer16, false);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        xYSeries3.add(0.05d, (double) 0);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset9 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset9, true);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset9, true);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset9);
        xYSeries3.removeChangeListener((org.jfree.data.general.SeriesChangeListener) defaultXYDataset9);
        org.jfree.data.DomainOrder domainOrder16 = defaultXYDataset9.getDomainOrder();
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(domainOrder16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot5.getFixedLegendItems();
        boolean boolean8 = categoryPlot5.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.axis.TickUnits tickUnits6 = new org.jfree.chart.axis.TickUnits();
        int int7 = tickUnits6.size();
        numberAxis5.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits6);
        java.awt.Shape shape9 = numberAxis5.getDownArrow();
        numberAxis5.setPositiveArrowVisible(false);
        combinedRangeXYPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) '#');
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.lang.String str7 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot6.removeDomainMarker(marker8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot6.getAxisOffset();
        boolean boolean11 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        categoryPlot6.setRangePannable(false);
        boolean boolean16 = categoryPlot6.getDrawSharedDomainAxis();
        int int17 = categoryPlot6.getDomainAxisCount();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Paint paint8 = combinedRangeXYPlot0.getRangeTickBandPaint();
        combinedRangeXYPlot0.mapDatasetToDomainAxis((int) (short) 1, 15);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        piePlot3D1.setLegendItemShape(shape4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getDomainAxisEdge((int) (byte) 1);
        float float14 = categoryPlot11.getBackgroundImageAlpha();
        categoryPlot11.setNoDataMessage("item");
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot11);
        java.awt.Shape shape18 = plotEntity17.getArea();
        java.lang.Number[] numberArray27 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray27, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray33);
        org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset34, false);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity39 = new org.jfree.chart.entity.CategoryItemEntity(shape18, "null", "", categoryDataset34, (java.lang.Comparable) "TitleEntity: tooltip = January 13", (java.lang.Comparable) 0.5d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer0.setSeriesStroke((int) (byte) 100, stroke5);
        boolean boolean8 = xYBarRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis28 = null;
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis28, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font33);
        labelBlock26.setFont(font33);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint37 = xYBarRenderer36.getBasePaint();
        xYBarRenderer36.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator41 = xYBarRenderer36.getSeriesToolTipGenerator(10);
        java.awt.Paint paint42 = xYBarRenderer36.getBasePaint();
        boolean boolean43 = labelBlock26.equals((java.lang.Object) paint42);
        labelBlock26.setToolTipText("HorizontalAlignment.CENTER");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = labelBlock26.getTextAnchor();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(xYToolTipGenerator41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!", paint12);
        legendItem13.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset16 = null;
        legendItem13.setDataset(dataset16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYBarRenderer18.setSeriesURLGenerator(6, xYURLGenerator20);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer18.setSeriesStroke((int) (byte) 100, stroke23);
        legendItem13.setOutlineStroke(stroke23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke23);
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = combinedRangeXYPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27, true);
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange30, (org.jfree.data.Range) dateRange31);
        java.lang.Class<?> wildcardClass33 = dateRange31.getClass();
        try {
            java.util.EventListener[] eventListenerArray34 = valueMarker26.getListeners((java.lang.Class) wildcardClass33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.DateRange; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        piePlot3D1.setBackgroundImageAlignment((int) (byte) 10);
        piePlot3D1.setSectionOutlinesVisible(true);
        org.jfree.chart.util.Rotation rotation8 = piePlot3D1.getDirection();
        org.junit.Assert.assertNotNull(rotation8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("NO_CHANGE");
        java.awt.Paint paint2 = textFragment1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.awt.Font font6 = categoryAxis3D2.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot7.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        combinedRangeXYPlot7.setFixedRangeAxisSpace(axisSpace10, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = combinedRangeXYPlot13.getDomainMarkers(6, layer18);
        combinedRangeXYPlot13.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot7.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        java.awt.Image image23 = null;
        combinedRangeXYPlot7.setBackgroundImage(image23);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset26 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot7.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset26);
        int int28 = defaultXYDataset26.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer30 = null;
        org.jfree.chart.plot.PolarPlot polarPlot31 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset26, valueAxis29, polarItemRenderer30);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot32.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection36 = combinedRangeXYPlot32.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { valueAxis37 };
        combinedRangeXYPlot32.setDomainAxes(valueAxisArray38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot32.setDomainTickBandPaint((java.awt.Paint) color40);
        java.awt.Stroke stroke42 = combinedRangeXYPlot32.getRangeCrosshairStroke();
        java.awt.Stroke stroke43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedRangeXYPlot32.setRangeCrosshairStroke(stroke43);
        polarPlot31.setRadiusGridlineStroke(stroke43);
        categoryAxis3D2.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot31);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot5.setDataset(categoryDataset9);
        float float11 = categoryPlot5.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        java.awt.Paint paint76 = categoryAxis3D30.getLabelPaint();
        categoryAxis3D30.setMaximumCategoryLabelWidthRatio((float) (short) 100);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(paint76);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-3680), 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        boolean boolean6 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = combinedRangeXYPlot0.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer21);
        java.lang.String str23 = categoryPlot22.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot22.getRangeAxisLocation(9999);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot22.zoomRangeAxes((double) 100.0f, (double) 900000L, plotRenderingInfo29, point2D30);
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot15.zoomRangeAxes(15.0d, plotRenderingInfo29, point2D32, false);
        java.awt.geom.Point2D point2D35 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 1964, (double) (-459), plotRenderingInfo29, point2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        boolean boolean21 = combinedRangeXYPlot0.isDomainMinorGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = combinedRangeXYPlot0.getAxisOffset();
        boolean boolean23 = combinedRangeXYPlot0.isSubplot();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot5.getDataset((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setBaseItemLabelsVisible(true);
        xYBarRenderer0.clearSeriesStrokes(false);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2147483647, year3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        java.lang.String str29 = categoryItemEntity28.toString();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        try {
            categoryItemEntity28.setDataset(categoryDataset30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        java.lang.String str2 = projectInfo0.getLicenceText();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesFilled();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke4 = combinedRangeXYPlot3.getRangeCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = combinedRangeXYPlot5.getRangeAxisLocation(0);
        combinedRangeXYPlot3.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        piePlot3D11.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot3D11.getLegendLabelGenerator();
        double double15 = piePlot3D11.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = null;
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis18, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font23);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection29 = combinedRangeXYPlot25.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { valueAxis30 };
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot25.setDomainTickBandPaint((java.awt.Paint) color33);
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", paint36);
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem37.setLabelPaint(paint38);
        java.awt.Paint paint40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem37.setFillPaint(paint40);
        boolean boolean42 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color33, paint40);
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("hi!", font23, (java.awt.Paint) color33);
        java.awt.geom.Rectangle2D rectangle2D44 = labelBlock43.getBounds();
        piePlot3D11.drawBackgroundImage(graphics2D16, rectangle2D44);
        try {
            xYLineAndShapeRenderer0.fillDomainGridBand(graphics2D2, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, valueAxis9, rectangle2D44, 0.05d, (double) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.14d + "'", double15 == 0.14d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangle2D44);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = combinedRangeXYPlot0.getFixedLegendItems();
        combinedRangeXYPlot0.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.awt.Font font12 = categoryAxis3D8.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection17 = combinedRangeXYPlot13.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { valueAxis18 };
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot13.setDomainTickBandPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot13.getRangeCrosshairStroke();
        categoryAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot13);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        java.awt.Paint paint26 = jFreeChart25.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle28 = jFreeChart25.getLegend(0);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent31 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart25, 0, 1);
        boolean boolean32 = jFreeChart25.isBorderVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(legendTitle28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("ItemLabelAnchor.OUTSIDE3");
        java.lang.String str3 = basicProjectInfo0.getCopyright();
        basicProjectInfo0.setCopyright("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        double double19 = rectangleInsets17.trimWidth(0.05d);
        double double21 = rectangleInsets17.trimHeight((double) 0.0f);
        categoryAxis3D9.setLabelInsets(rectangleInsets17);
        double double23 = categoryAxis3D9.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-13.95d) + "'", double19 == (-13.95d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-135.0d) + "'", double21 == (-135.0d));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = barRenderer3D0.getBarPainter();
        barRenderer3D0.setBaseSeriesVisible(false, false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        org.jfree.chart.plot.Marker marker13 = null;
        boolean boolean14 = categoryPlot11.removeDomainMarker(marker13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot11.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer21);
        java.lang.String str23 = categoryPlot22.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot22.getRangeAxisLocation(9999);
        categoryPlot11.setRangeAxisLocation(10, axisLocation25, false);
        categoryPlot11.setCrosshairDatasetIndex((int) (byte) 100, false);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean33 = numberAxis32.isInverted();
        numberAxis32.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot37 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Object obj38 = multiplePiePlot37.clone();
        multiplePiePlot37.setAggregatedItemsKey((java.lang.Comparable) 1.0E-8d);
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D42 = new org.jfree.chart.plot.PiePlot3D(pieDataset41);
        piePlot3D42.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot45 = piePlot3D42.getRootPlot();
        java.awt.Paint paint46 = piePlot3D42.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = piePlot3D42.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.axis.NumberAxis numberAxis50 = null;
        java.awt.Font font55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand56 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis50, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font55);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot57.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection61 = combinedRangeXYPlot57.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray63 = new org.jfree.chart.axis.ValueAxis[] { valueAxis62 };
        combinedRangeXYPlot57.setDomainAxes(valueAxisArray63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot57.setDomainTickBandPaint((java.awt.Paint) color65);
        java.awt.Paint paint68 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("hi!", paint68);
        java.awt.Paint paint70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem69.setLabelPaint(paint70);
        java.awt.Paint paint72 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem69.setFillPaint(paint72);
        boolean boolean74 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color65, paint72);
        org.jfree.chart.block.LabelBlock labelBlock75 = new org.jfree.chart.block.LabelBlock("hi!", font55, (java.awt.Paint) color65);
        java.awt.geom.Rectangle2D rectangle2D76 = labelBlock75.getBounds();
        java.awt.Shape shape77 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D76);
        org.jfree.data.general.PieDataset pieDataset78 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D79 = new org.jfree.chart.plot.PiePlot3D(pieDataset78);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent80 = null;
        piePlot3D79.datasetChanged(datasetChangeEvent80);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot82 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke83 = combinedRangeXYPlot82.getRangeCrosshairStroke();
        java.awt.Paint paint84 = combinedRangeXYPlot82.getRangeCrosshairPaint();
        boolean boolean85 = piePlot3D79.equals((java.lang.Object) combinedRangeXYPlot82);
        piePlot3D79.setLabelLinkMargin((double) 15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo89 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo90 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo89);
        org.jfree.chart.plot.PiePlotState piePlotState91 = piePlot3D42.initialise(graphics2D48, rectangle2D76, (org.jfree.chart.plot.PiePlot) piePlot3D79, (java.lang.Integer) 0, plotRenderingInfo90);
        multiplePiePlot37.setLegendItemShape((java.awt.Shape) rectangle2D76);
        barRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis32, rectangle2D76, (double) (byte) 100);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Category Plot" + "'", str23.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(plot45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator47);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(legendItemCollection61);
        org.junit.Assert.assertNotNull(valueAxisArray63);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(piePlotState91);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(15, itemLabelPosition5);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = combinedRangeXYPlot8.getDomainMarkers(6, layer13);
        combinedRangeXYPlot8.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke17 = combinedRangeXYPlot8.getOutlineStroke();
        xYBarRenderer0.setSeriesOutlineStroke(2019, stroke17, true);
        org.jfree.chart.LegendItem legendItem22 = xYBarRenderer0.getLegendItem(8, 0);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(legendItem22);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        boolean boolean6 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYBarRenderer7.setSeriesURLGenerator(6, xYURLGenerator9);
        xYBarRenderer7.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        int int14 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        boolean boolean15 = combinedRangeXYPlot0.isRangePannable();
        java.awt.Paint paint16 = combinedRangeXYPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator10 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        xYBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYBarRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator12);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot9.setFixedRangeAxisSpace(axisSpace12, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = combinedRangeXYPlot15.getDomainMarkers(6, layer20);
        combinedRangeXYPlot15.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot9.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        combinedRangeXYPlot9.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        double double28 = barRenderer27.getMinimumBarLength();
        java.awt.Paint paint30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", paint30);
        legendItem31.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset34 = null;
        legendItem31.setDataset(dataset34);
        java.awt.Paint paint36 = legendItem31.getOutlinePaint();
        barRenderer27.setShadowPaint(paint36);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = barRenderer27.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator45 = barRenderer27.getItemLabelGenerator((-1), 0, true);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot51.setRangeMinorGridlineStroke(stroke55);
        barRenderer27.setBaseOutlineStroke(stroke55);
        combinedRangeXYPlot9.setDomainMinorGridlineStroke(stroke55);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke55);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryItemLabelGenerator41);
        org.junit.Assert.assertNull(categoryItemLabelGenerator45);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getRangeCrosshairStroke();
        java.awt.Paint paint6 = combinedRangeXYPlot4.getRangeCrosshairPaint();
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) combinedRangeXYPlot4);
        java.awt.Paint paint8 = null;
        try {
            combinedRangeXYPlot4.setRangeGridlinePaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int1 = defaultKeyedValues0.getItemCount();
        defaultKeyedValues0.addValue((java.lang.Comparable) (short) 0, (java.lang.Number) 1);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, 13);
        java.lang.String str8 = month7.toString();
        defaultKeyedValues0.setValue((java.lang.Comparable) str8, 0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "January 13" + "'", str8.equals("January 13"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        legendTitle3.addChangeListener(titleChangeListener4);
        org.jfree.chart.entity.TitleEntity titleEntity6 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle3);
        titleEntity6.setURLText("item");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        barRenderer0.setBaseOutlinePaint(paint11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot13.getRangeAxisLocation(15);
        boolean boolean19 = combinedRangeXYPlot13.isNotify();
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = null;
        combinedRangeXYPlot13.setDrawingSupplier(drawingSupplier21, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.Comparable comparable6 = null;
        try {
            categoryAxis3D2.removeCategoryLabelToolTip(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("DomainOrder.ASCENDING", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot12.getRangeAxisLocation(15);
        categoryPlot5.setRangeAxisLocation(axisLocation17, false);
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color21 = color20.darker();
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Paint paint23 = categoryPlot5.getRangeZeroBaselinePaint();
        java.awt.Paint paint24 = categoryPlot5.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font5);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        java.awt.Font font16 = categoryAxis3D12.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection21 = combinedRangeXYPlot17.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        combinedRangeXYPlot17.setDomainAxes(valueAxisArray23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot17.setDomainTickBandPaint((java.awt.Paint) color25);
        java.awt.Stroke stroke27 = combinedRangeXYPlot17.getRangeCrosshairStroke();
        categoryAxis3D12.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot17);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot17);
        java.awt.Paint paint30 = jFreeChart29.getBorderPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint30);
        markerAxisBand6.addMarker(intervalMarker31);
        double double33 = intervalMarker31.getStartValue();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        boolean boolean76 = numberAxis71.isPositiveArrowVisible();
        org.jfree.data.time.DateRange dateRange77 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange78 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange77, (org.jfree.data.Range) dateRange78);
        org.jfree.data.Range range80 = rectangleConstraint79.getHeightRange();
        numberAxis71.setDefaultAutoRange(range80);
        float float82 = numberAxis71.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertTrue("'" + float82 + "' != '" + 2.0f + "'", float82 == 2.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean2 = barRenderer3D0.equals((java.lang.Object) 10.0f);
        java.awt.Paint paint3 = barRenderer3D0.getBaseFillPaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer3D0.setSeriesItemLabelPaint(0, paint5, false);
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint5, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        categoryPlot5.setNoDataMessage("item");
        boolean boolean11 = categoryPlot5.isDomainCrosshairVisible();
        java.awt.Color color12 = java.awt.Color.PINK;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        boolean boolean11 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = combinedRangeXYPlot0.removeDomainMarker(15, marker7, layer8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot13.getRangeAxisLocation(0);
        combinedRangeXYPlot11.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = combinedRangeXYPlot18.getRangeAxisLocation(0);
        java.awt.Paint paint21 = combinedRangeXYPlot18.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.util.List list24 = null;
        combinedRangeXYPlot18.drawDomainTickBands(graphics2D22, rectangle2D23, list24);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", paint30);
        legendItem31.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset34 = null;
        legendItem31.setDataset(dataset34);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = null;
        xYBarRenderer36.setSeriesURLGenerator(6, xYURLGenerator38);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer36.setSeriesStroke((int) (byte) 100, stroke41);
        legendItem31.setOutlineStroke(stroke41);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color28, stroke41);
        org.jfree.chart.util.Layer layer45 = null;
        boolean boolean47 = combinedRangeXYPlot18.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker44, layer45, true);
        java.lang.String str48 = valueMarker44.getLabel();
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.BACKGROUND;
        combinedRangeXYPlot11.addRangeMarker(128, (org.jfree.chart.plot.Marker) valueMarker44, layer49, false);
        java.util.Collection collection52 = combinedRangeXYPlot0.getDomainMarkers((int) 'a', layer49);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.TOP");
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getRangeAxisLocation(0);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        combinedRangeXYPlot4.drawDomainTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", paint16);
        legendItem17.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset20 = null;
        legendItem17.setDataset(dataset20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        xYBarRenderer22.setSeriesURLGenerator(6, xYURLGenerator24);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer22.setSeriesStroke((int) (byte) 100, stroke27);
        legendItem17.setOutlineStroke(stroke27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color14, stroke27);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = combinedRangeXYPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker30, layer31, true);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = combinedRangeXYPlot0.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker30, layer34, false);
        org.jfree.chart.axis.ValueAxis valueAxis37 = combinedRangeXYPlot0.getDomainAxis();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot38.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection42 = combinedRangeXYPlot38.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] { valueAxis43 };
        combinedRangeXYPlot38.setDomainAxes(valueAxisArray44);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot38.setDomainTickBandPaint((java.awt.Paint) color46);
        java.awt.Stroke stroke48 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Stroke stroke49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedRangeXYPlot38.setRangeCrosshairStroke(stroke49);
        org.jfree.chart.axis.AxisSpace axisSpace51 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot38.setFixedRangeAxisSpace(axisSpace51);
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace51, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(valueAxis37);
        org.junit.Assert.assertNotNull(legendItemCollection42);
        org.junit.Assert.assertNotNull(valueAxisArray44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 13, false);
        org.jfree.chart.axis.AxisSpace axisSpace5 = combinedRangeXYPlot0.getFixedRangeAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.lang.String str12 = categoryPlot11.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = categoryPlot11.getDatasetRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = categoryPlot11.getDatasetRenderingOrder();
        combinedRangeXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.lang.String str7 = categoryPlot6.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot6.getRangeAxisLocation(9999);
        boolean boolean10 = booleanList0.equals((java.lang.Object) categoryPlot6);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot6.setRangeZeroBaselineStroke(stroke11);
        java.lang.Comparable comparable13 = categoryPlot6.getDomainCrosshairRowKey();
        boolean boolean14 = categoryPlot6.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(comparable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardPieToolTipGenerator0.getPercentFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        piePlot3D1.setLegendItemShape(shape4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot3D1.setLabelOutlineStroke(stroke6);
        double double8 = piePlot3D1.getInteriorGap();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        categoryPlot19.setRangeAxis((int) (byte) 100, valueAxis21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot19.getDomainAxisEdge((int) '#');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = combinedRangeXYPlot25.getRangeAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D31, valueAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer33);
        java.lang.String str35 = categoryPlot34.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot34.getRangeAxisLocation(9999);
        combinedRangeXYPlot25.setDomainAxisLocation((int) ' ', axisLocation37);
        categoryPlot19.setDomainAxisLocation(axisLocation37, true);
        boolean boolean41 = categoryPlot5.equals((java.lang.Object) categoryPlot19);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Category Plot" + "'", str35.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart20.getLegend(0);
        org.jfree.chart.plot.XYPlot xYPlot24 = jFreeChart20.getXYPlot();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNotNull(xYPlot24);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) ' ');
        boolean boolean4 = categoryAxis3D1.isAxisLineVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = combinedRangeXYPlot5.getDomainMarkers(6, layer10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot5.setFixedDomainAxisSpace(axisSpace12, true);
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        java.lang.String str17 = categoryPlot16.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot16.getRangeAxisLocation(9999);
        categoryPlot5.setRangeAxisLocation(10, axisLocation19, false);
        categoryPlot5.setCrosshairDatasetIndex((int) (byte) 100, false);
        double double25 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset26 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean27 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset26);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke29 = combinedRangeXYPlot28.getRangeCrosshairStroke();
        java.awt.Paint paint30 = combinedRangeXYPlot28.getRangeCrosshairPaint();
        boolean boolean31 = defaultPieDataset26.hasListener((java.util.EventListener) combinedRangeXYPlot28);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot32.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection36 = combinedRangeXYPlot32.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { valueAxis37 };
        combinedRangeXYPlot32.setDomainAxes(valueAxisArray38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot32.setDomainTickBandPaint((java.awt.Paint) color40);
        java.awt.Paint paint43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", paint43);
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem44.setLabelPaint(paint45);
        java.awt.Paint paint47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem44.setFillPaint(paint47);
        boolean boolean49 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color40, paint47);
        boolean boolean50 = defaultPieDataset26.equals((java.lang.Object) paint47);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boolean50, true);
        boolean boolean53 = categoryPlot5.equals((java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = categoryPlot5.getRangeMinorGridlineStroke();
        boolean boolean11 = categoryPlot5.isDomainPannable();
        categoryPlot5.clearAnnotations();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D17);
        org.jfree.chart.event.TitleChangeListener titleChangeListener19 = null;
        legendTitle18.addChangeListener(titleChangeListener19);
        org.jfree.chart.entity.TitleEntity titleEntity23 = new org.jfree.chart.entity.TitleEntity(shape15, (org.jfree.chart.title.Title) legendTitle18, "Category Plot", "-0.0");
        java.lang.Number[] numberArray32 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray32, numberArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray38);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity42 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "HorizontalAlignment.CENTER", "January 13", categoryDataset39, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double45 = categoryAxis3D44.getCategoryMargin();
        boolean boolean46 = categoryAxis3D44.isTickLabelsVisible();
        float float47 = categoryAxis3D44.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset48 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D49 = new org.jfree.chart.plot.PiePlot3D(pieDataset48);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = null;
        piePlot3D49.datasetChanged(datasetChangeEvent50);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke53 = combinedRangeXYPlot52.getRangeCrosshairStroke();
        java.awt.Paint paint54 = combinedRangeXYPlot52.getRangeCrosshairPaint();
        boolean boolean55 = piePlot3D49.equals((java.lang.Object) combinedRangeXYPlot52);
        piePlot3D49.setLabelLinkMargin((double) 15);
        java.awt.Paint paint58 = piePlot3D49.getBaseSectionOutlinePaint();
        categoryAxis3D44.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D49);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D62 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D62, valueAxis63, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer64);
        java.lang.String str66 = categoryPlot65.getPlotType();
        org.jfree.chart.plot.Marker marker67 = null;
        boolean boolean68 = categoryPlot65.removeDomainMarker(marker67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = categoryPlot65.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot70 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot70.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection74 = combinedRangeXYPlot70.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray76 = new org.jfree.chart.axis.ValueAxis[] { valueAxis75 };
        combinedRangeXYPlot70.setDomainAxes(valueAxisArray76);
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot70.setDomainTickBandPaint((java.awt.Paint) color78);
        java.awt.Stroke stroke80 = combinedRangeXYPlot70.getRangeCrosshairStroke();
        boolean boolean81 = rectangleInsets69.equals((java.lang.Object) stroke80);
        categoryAxis3D44.setLabelInsets(rectangleInsets69, false);
        org.jfree.chart.axis.NumberAxis numberAxis85 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D86 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D86.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot89 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D44, (org.jfree.chart.axis.ValueAxis) numberAxis85, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D86);
        boolean boolean90 = numberAxis85.isPositiveArrowVisible();
        try {
            categoryPlot5.setRangeAxis(2147483647, (org.jfree.chart.axis.ValueAxis) numberAxis85, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.2d + "'", double45 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Category Plot" + "'", str66.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(legendItemCollection74);
        org.junit.Assert.assertNotNull(valueAxisArray76);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        int int1 = booleanList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = plotRenderingInfo1.getDataArea();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        java.awt.Font font10 = categoryAxis3D6.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection15 = combinedRangeXYPlot11.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { valueAxis16 };
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot11.setDomainTickBandPaint((java.awt.Paint) color19);
        java.awt.Stroke stroke21 = combinedRangeXYPlot11.getRangeCrosshairStroke();
        categoryAxis3D6.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        jFreeChart23.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle26 = jFreeChart23.getTitle();
        java.awt.Paint paint27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle26.setPaint(paint27);
        org.jfree.chart.entity.TitleEntity titleEntity29 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape) rectangle2D2, (org.jfree.chart.title.Title) textTitle26);
        org.jfree.data.time.DateRange dateRange30 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange31 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange30, (org.jfree.data.Range) dateRange31);
        double double34 = dateRange30.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange35 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange35, (org.jfree.data.Range) dateRange36);
        java.lang.Class<?> wildcardClass38 = dateRange36.getClass();
        org.jfree.data.Range range39 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange30, (org.jfree.data.Range) dateRange36);
        org.jfree.data.time.DateRange dateRange40 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange41 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange40, (org.jfree.data.Range) dateRange41);
        double double44 = dateRange40.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange46 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange45, (org.jfree.data.Range) dateRange46);
        java.lang.Class<?> wildcardClass48 = dateRange46.getClass();
        org.jfree.data.Range range49 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange40, (org.jfree.data.Range) dateRange46);
        org.jfree.data.Range range50 = org.jfree.data.Range.combine(range39, range49);
        boolean boolean51 = titleEntity29.equals((java.lang.Object) range49);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator52 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator53 = null;
        java.lang.String str54 = titleEntity29.getImageMapAreaTag(toolTipTagFragmentGenerator52, uRLTagFragmentGenerator53);
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(textTitle26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        float float7 = ringPlot6.getForegroundAlpha();
        java.awt.Paint paint8 = ringPlot6.getSeparatorPaint();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange9, (org.jfree.data.Range) dateRange10);
        double double13 = dateRange9.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange14, (org.jfree.data.Range) dateRange15);
        java.lang.Class<?> wildcardClass17 = dateRange15.getClass();
        org.jfree.data.Range range18 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange9, (org.jfree.data.Range) dateRange15);
        java.lang.String str19 = dateRange15.toString();
        boolean boolean20 = ringPlot6.equals((java.lang.Object) dateRange15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str19.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ItemLabelAnchor.OUTSIDE3", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "DateTickUnitType.SECOND", "RectangleInsets[t=35.0,l=1.0,b=100.0,r=13.0]");
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D(pieDataset28);
        piePlot3D29.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot32 = piePlot3D29.getRootPlot();
        boolean boolean33 = labelBlock26.equals((java.lang.Object) piePlot3D29);
        piePlot3D29.setIgnoreNullValues(false);
        try {
            piePlot3D29.setInteriorGap(0.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (0.5) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(plot32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getRangeAxisLocation(0);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        combinedRangeXYPlot4.drawDomainTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", paint16);
        legendItem17.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset20 = null;
        legendItem17.setDataset(dataset20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        xYBarRenderer22.setSeriesURLGenerator(6, xYURLGenerator24);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer22.setSeriesStroke((int) (byte) 100, stroke27);
        legendItem17.setOutlineStroke(stroke27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color14, stroke27);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = combinedRangeXYPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker30, layer31, true);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = combinedRangeXYPlot0.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker30, layer34, false);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, valueAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer43);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot44.getDomainMarkers(layer45);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot44.zoomRangeAxes(0.0d, plotRenderingInfo49, point2D50, true);
        combinedRangeXYPlot0.handleClick(2019, (int) '#', plotRenderingInfo49);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        java.lang.String str2 = projectInfo0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str2.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean2 = barRenderer3D0.equals((java.lang.Object) 10.0f);
        int int3 = barRenderer3D0.getRowCount();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYBarRenderer5.setSeriesURLGenerator(6, xYURLGenerator7);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer5.setSeriesStroke((int) (byte) 100, stroke10);
        java.awt.Paint paint13 = xYBarRenderer5.lookupSeriesOutlinePaint((int) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYBarRenderer5.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = itemLabelPosition14.getItemLabelAnchor();
        barRenderer3D0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition14, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, 0.0d, 100.0f, (float) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, valueAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer32);
        java.awt.Font font34 = categoryAxis3D30.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot35.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection39 = combinedRangeXYPlot35.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        combinedRangeXYPlot35.setDomainAxes(valueAxisArray41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot35.setDomainTickBandPaint((java.awt.Paint) color43);
        java.awt.Stroke stroke45 = combinedRangeXYPlot35.getRangeCrosshairStroke();
        categoryAxis3D30.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot35);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot35);
        jFreeChart47.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle50 = jFreeChart47.getTitle();
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle50.setPaint(paint51);
        org.jfree.chart.entity.TitleEntity titleEntity54 = new org.jfree.chart.entity.TitleEntity(shape22, (org.jfree.chart.title.Title) textTitle50, "January 13");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = textTitle50.getTextAlignment();
        try {
            jFreeChart20.addSubtitle(7, (org.jfree.chart.title.Title) textTitle50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(legendItemCollection39);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(textTitle50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        boolean boolean3 = jFreeChartResources0.containsKey("{0}: ({1}, {2})");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = null;
        textBlock0.draw(graphics2D2, (float) (byte) 10, (float) (short) 100, textBlockAnchor5, (-1.0f), (float) 13, (double) (short) 10);
        org.junit.Assert.assertNull(textLine1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        double double2 = xYSeriesCollection0.getRangeUpperBound(true);
        int int3 = xYSeriesCollection0.getSeriesCount();
        xYSeriesCollection0.setIntervalWidth(0.08d);
        try {
            java.lang.Number number8 = xYSeriesCollection0.getEndX((int) (short) 100, 1964);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = combinedRangeXYPlot0.getAxisOffset();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.data.Range range6 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot4.getRangeAxisLocation(0);
        java.awt.Paint paint7 = combinedRangeXYPlot4.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        combinedRangeXYPlot4.drawDomainTickBands(graphics2D8, rectangle2D9, list10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", paint16);
        legendItem17.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset20 = null;
        legendItem17.setDataset(dataset20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        xYBarRenderer22.setSeriesURLGenerator(6, xYURLGenerator24);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer22.setSeriesStroke((int) (byte) 100, stroke27);
        legendItem17.setOutlineStroke(stroke27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color14, stroke27);
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = combinedRangeXYPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker30, layer31, true);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = combinedRangeXYPlot0.removeRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker30, layer34, false);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        double double39 = barRenderer38.getMinimumBarLength();
        java.awt.Paint paint41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", paint41);
        legendItem42.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset45 = null;
        legendItem42.setDataset(dataset45);
        java.awt.Paint paint47 = legendItem42.getOutlinePaint();
        barRenderer38.setShadowPaint(paint47);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator52 = barRenderer38.getItemLabelGenerator(2, 9999, true);
        boolean boolean54 = barRenderer38.isSeriesItemLabelsVisible((int) (byte) 1);
        barRenderer38.setDrawBarOutline(false);
        boolean boolean57 = layer37.equals((java.lang.Object) barRenderer38);
        java.util.Collection collection58 = combinedRangeXYPlot0.getRangeMarkers(layer37);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(categoryItemLabelGenerator52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getRangeAxisLocation(0);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot2);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean9 = numberAxis8.isInverted();
        numberAxis8.setAutoTickUnitSelection(false);
        java.awt.Shape shape12 = numberAxis8.getLeftArrow();
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("NO_CHANGE");
        org.jfree.data.time.DateRange dateRange15 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange15, (org.jfree.data.Range) dateRange16);
        org.jfree.data.Range range18 = rectangleConstraint17.getHeightRange();
        boolean boolean19 = textFragment14.equals((java.lang.Object) range18);
        numberAxis8.setRangeWithMargins(range18, false, false);
        try {
            combinedRangeXYPlot2.setRangeAxis((-459), (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!", paint12);
        legendItem13.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset16 = null;
        legendItem13.setDataset(dataset16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYBarRenderer18.setSeriesURLGenerator(6, xYURLGenerator20);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer18.setSeriesStroke((int) (byte) 100, stroke23);
        legendItem13.setOutlineStroke(stroke23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke23);
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26, layer27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker26.setLabelAnchor(rectangleAnchor29);
        java.awt.Paint paint31 = valueMarker26.getLabelPaint();
        java.lang.String str32 = valueMarker26.getLabel();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (-2208960000000L), 12.0d);
        size2D2.setWidth((double) (-2208960000000L));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        java.lang.Comparable comparable2 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, dataset1, comparable2);
        legendItemBlockContainer3.setURLText("{0}: ({1}, {2})");
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.data.general.Dataset dataset1 = null;
        java.lang.Comparable comparable2 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer3 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, dataset1, comparable2);
        java.lang.String str4 = legendItemBlockContainer3.getToolTipText();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate3 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0, false);
        int int4 = timeSeriesCollection0.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer4.findRangeBounds(categoryDataset6);
        try {
            java.awt.Paint paint11 = barRenderer4.getItemPaint((int) (short) -1, 7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        textTitle23.setText("item");
        java.awt.Paint paint26 = textTitle23.getBackgroundPaint();
        java.lang.Object obj27 = null;
        boolean boolean28 = textTitle23.equals(obj27);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange6);
        java.lang.String str8 = dateRange6.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint2.toRangeHeight((org.jfree.data.Range) dateRange6);
        java.lang.String str10 = dateRange6.toString();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str8.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str10.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot5.setDataset(1, categoryDataset11);
        boolean boolean13 = categoryPlot5.isRangeGridlinesVisible();
        categoryPlot5.setDomainCrosshairColumnKey((java.lang.Comparable) 128, false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot5.setRangeAxis(valueAxis9);
        boolean boolean11 = categoryPlot5.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot5.getRenderer(12);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer13);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection2.getSeries((java.lang.Comparable) 100.0f);
        try {
            timeSeriesCollection2.setSelected(15, (int) (short) 0, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (15).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeries4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(6, layer5);
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Paint paint9 = combinedRangeXYPlot0.getOutlinePaint();
        java.util.List list10 = combinedRangeXYPlot0.getAnnotations();
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.setAutoTickUnitSelection(false);
        java.awt.Shape shape5 = numberAxis1.getLeftArrow();
        java.awt.Paint paint6 = numberAxis1.getLabelPaint();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (org.jfree.data.Range) dateRange8);
        java.lang.Class<?> wildcardClass10 = dateRange8.getClass();
        numberAxis1.setRange((org.jfree.data.Range) dateRange8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem2.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer1 = xYAreaRenderer0.getGradientTransformer();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean4 = xYLineAndShapeRenderer3.getUseFillPaint();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer3.setBaseStroke(stroke5);
        xYAreaRenderer0.setSeriesOutlineStroke(9999, stroke5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        int int14 = categoryPlot5.getCrosshairDatasetIndex();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace15);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double6 = rectangleInsets5.getLeft();
        double double7 = rectangleInsets5.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 13.0d + "'", double7 == 13.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getDataArea();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        java.awt.Font font19 = categoryAxis3D15.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection24 = combinedRangeXYPlot20.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        combinedRangeXYPlot20.setDomainAxes(valueAxisArray26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot20.setDomainTickBandPaint((java.awt.Paint) color28);
        java.awt.Stroke stroke30 = combinedRangeXYPlot20.getRangeCrosshairStroke();
        categoryAxis3D15.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot20);
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot20);
        jFreeChart32.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle35 = jFreeChart32.getTitle();
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle35.setPaint(paint36);
        org.jfree.chart.entity.TitleEntity titleEntity38 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape) rectangle2D11, (org.jfree.chart.title.Title) textTitle35);
        try {
            categoryPlot5.drawBackground(graphics2D8, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(textTitle35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.lang.Object obj4 = xYBarRenderer0.clone();
        java.awt.Stroke stroke6 = xYBarRenderer0.getSeriesOutlineStroke((int) (short) 0);
        java.awt.Stroke stroke7 = xYBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator9 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator9);
        java.awt.Paint paint11 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        boolean boolean12 = standardXYSeriesLabelGenerator9.equals((java.lang.Object) paint11);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer0.getItemLabelGenerator((-1), 0, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        double double25 = barRenderer0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace5, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = combinedRangeXYPlot8.getDomainMarkers(6, layer13);
        combinedRangeXYPlot8.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot2.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        boolean boolean18 = tickUnits0.equals((java.lang.Object) combinedRangeXYPlot2);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot25.getDomainAxisEdge((int) (byte) 1);
        float float28 = categoryPlot25.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot25.setDataset(categoryDataset29);
        java.awt.Paint paint31 = categoryPlot25.getNoDataMessagePaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot25.panDomainAxes((double) (byte) 100, plotRenderingInfo34, point2D35);
        java.awt.geom.Point2D point2D37 = null;
        try {
            combinedRangeXYPlot2.zoomDomainAxes((double) (-2208960000000L), plotRenderingInfo34, point2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.5f + "'", float28 == 0.5f);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        defaultXYDataset19.removeSeries((java.lang.Comparable) "ThreadContext");
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = labelBlock26.getTextAnchor();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange2);
        double double5 = dateRange1.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (org.jfree.data.Range) dateRange7);
        java.lang.Class<?> wildcardClass9 = dateRange7.getClass();
        org.jfree.data.Range range10 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange7);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange11, (org.jfree.data.Range) dateRange12);
        double double15 = dateRange11.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange16, (org.jfree.data.Range) dateRange17);
        java.lang.Class<?> wildcardClass19 = dateRange17.getClass();
        org.jfree.data.Range range20 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange11, (org.jfree.data.Range) dateRange17);
        org.jfree.data.Range range21 = org.jfree.data.Range.combine(range10, range20);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) 15, range20);
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange23, (org.jfree.data.Range) dateRange24);
        java.lang.Class<?> wildcardClass26 = dateRange24.getClass();
        org.jfree.data.Range range27 = org.jfree.data.Range.combine(range20, (org.jfree.data.Range) dateRange24);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        barRenderer0.setBaseOutlinePaint(paint11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot13.getRangeAxisLocation(15);
        boolean boolean19 = combinedRangeXYPlot13.isNotify();
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot13);
        combinedRangeXYPlot13.setWeight(255);
        java.awt.Stroke stroke23 = combinedRangeXYPlot13.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieToolTipGenerator.DEFAULT_TOOLTIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 15, "ThreadContext", textAnchor2, textAnchor3, (double) (short) 1);
        java.lang.Number number6 = numberTick5.getNumber();
        org.jfree.chart.axis.TickType tickType7 = numberTick5.getTickType();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor11 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick(tickType7, (double) 1560458003853L, "TitleEntity: tooltip = January 13", textAnchor10, textAnchor11, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 15 + "'", number6.equals(15));
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(10.0d, plotRenderingInfo7, point2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        java.lang.Object obj9 = categoryPlot5.clone();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis1);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer6.setSeriesURLGenerator(6, xYURLGenerator8);
        xYBarRenderer6.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator13 = null;
        xYBarRenderer6.setBaseItemLabelGenerator(xYItemLabelGenerator13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYBarRenderer6.setBasePaint((java.awt.Paint) color15, false);
        int int18 = color15.getGreen();
        java.awt.color.ColorSpace colorSpace19 = color15.getColorSpace();
        numberAxis1.setLabelPaint((java.awt.Paint) color15);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(colorSpace19);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) (short) 10, (double) 1L);
        defaultKeyedValues0.addValue((java.lang.Comparable) 1964, (java.lang.Number) 100.0d);
        int int8 = defaultKeyedValues0.getIndex((java.lang.Comparable) "RectangleAnchor.TOP");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getRangeAxisLocation(0);
        boolean boolean12 = defaultKeyedValues0.equals((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getRangeAxisLocation(0);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        combinedRangeXYPlot8.drawDomainTickBands(graphics2D12, rectangle2D13, list14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", paint20);
        legendItem21.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset24 = null;
        legendItem21.setDataset(dataset24);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer26 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = null;
        xYBarRenderer26.setSeriesURLGenerator(6, xYURLGenerator28);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer26.setSeriesStroke((int) (byte) 100, stroke31);
        legendItem21.setOutlineStroke(stroke31);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color18, stroke31);
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean37 = combinedRangeXYPlot8.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker34, layer35, true);
        java.lang.String str38 = valueMarker34.getLabel();
        boolean boolean39 = combinedRangeXYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator10 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        xYBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYBarRenderer0.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator13);
        xYBarRenderer0.removeAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis17 = null;
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis17, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font22);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot24.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection28 = combinedRangeXYPlot24.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray30 = new org.jfree.chart.axis.ValueAxis[] { valueAxis29 };
        combinedRangeXYPlot24.setDomainAxes(valueAxisArray30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot24.setDomainTickBandPaint((java.awt.Paint) color32);
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("hi!", paint35);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem36.setLabelPaint(paint37);
        java.awt.Paint paint39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem36.setFillPaint(paint39);
        boolean boolean41 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color32, paint39);
        org.jfree.chart.block.LabelBlock labelBlock42 = new org.jfree.chart.block.LabelBlock("hi!", font22, (java.awt.Paint) color32);
        java.awt.geom.Rectangle2D rectangle2D43 = labelBlock42.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis44 = null;
        java.awt.Font font49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis44, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font49);
        labelBlock42.setFont(font49);
        xYBarRenderer0.setBaseLegendTextFont(font49);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(valueAxisArray30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(font49);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.Object obj1 = null;
        boolean boolean2 = unitType0.equals(obj1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        piePlot3D1.setAutoPopulateSectionOutlinePaint(false);
        double double6 = piePlot3D1.getDepthFactor();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.12d + "'", double6 == 0.12d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        float float7 = ringPlot6.getForegroundAlpha();
        boolean boolean8 = ringPlot6.getSeparatorsVisible();
        double double9 = ringPlot6.getLabelGap();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot6.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { valueAxis11 };
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot6.setDomainTickBandPaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = combinedRangeXYPlot6.getRangeCrosshairStroke();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedRangeXYPlot6.setRangeCrosshairStroke(stroke17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot6.setFixedRangeAxisSpace(axisSpace19);
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace19, true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("VerticalAlignment.TOP");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        double double4 = xYSeriesCollection2.getRangeUpperBound(true);
        int int5 = xYSeriesCollection2.getSeriesCount();
        xYSeriesCollection2.setIntervalWidth(0.08d);
        boolean boolean8 = standardChartTheme1.equals((java.lang.Object) xYSeriesCollection2);
        try {
            java.lang.Number number11 = xYSeriesCollection2.getEndY(2019, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot0.setDomainTickBandPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedRangeXYPlot0.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace13);
        combinedRangeXYPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        serialDate3.setDescription("TitleEntity: tooltip = January 13");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(3, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) (byte) 1, serialDate3);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(6, layer5);
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke9 = combinedRangeXYPlot0.getOutlineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        combinedRangeXYPlot10.setFixedRangeAxisSpace(axisSpace13, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot16.getDomainMarkers(6, layer21);
        combinedRangeXYPlot16.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot10.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = combinedRangeXYPlot16.getLegendItems();
        combinedRangeXYPlot0.setFixedLegendItems(legendItemCollection26);
        combinedRangeXYPlot0.mapDatasetToRangeAxis(1, 7);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(legendItemCollection26);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.String str1 = standardXYToolTipGenerator0.getNullYString();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer3 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator0, xYURLGenerator2);
        java.lang.String str4 = standardXYToolTipGenerator0.getNullYString();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null" + "'", str1.equals("null"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "null" + "'", str4.equals("null"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getUseFillPaint();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = xYLineAndShapeRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator7 = null;
        xYBarRenderer5.setSeriesURLGenerator(6, xYURLGenerator7);
        java.lang.Object obj9 = xYBarRenderer5.clone();
        java.awt.Shape shape13 = xYBarRenderer5.getItemShape((int) (byte) 1, (-1), false);
        multiplePiePlot4.setLegendItemShape(shape13);
        xYLineAndShapeRenderer0.setLegendShape(255, shape13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator2);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot3D1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.lang.Object obj6 = defaultDrawingSupplier4.clone();
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 90.0d, (java.lang.Number) (short) 10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("VerticalAlignment.TOP");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        double double4 = xYSeriesCollection2.getRangeUpperBound(true);
        int int5 = xYSeriesCollection2.getSeriesCount();
        xYSeriesCollection2.setIntervalWidth(0.08d);
        boolean boolean8 = standardChartTheme1.equals((java.lang.Object) xYSeriesCollection2);
        try {
            java.lang.Number number11 = xYSeriesCollection2.getEndY((int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot3.clearDomainAxes();
        boolean boolean8 = xYDataItem2.equals((java.lang.Object) combinedRangeXYPlot3);
        java.lang.Object obj9 = xYDataItem2.clone();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart20.getLegend(0);
        java.awt.Image image24 = jFreeChart20.getBackgroundImage();
        org.jfree.chart.plot.XYPlot xYPlot25 = jFreeChart20.getXYPlot();
        boolean boolean26 = jFreeChart20.isBorderVisible();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNull(image24);
        org.junit.Assert.assertNotNull(xYPlot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.setAutoTickUnitSelection(false);
        java.awt.Shape shape5 = numberAxis1.getLeftArrow();
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot0.setDomainTickBandPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedRangeXYPlot0.setRangeCrosshairStroke(stroke11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace13);
        java.awt.Paint paint15 = combinedRangeXYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot4 = piePlot3D1.getRootPlot();
        java.awt.Paint paint5 = piePlot3D1.getBaseSectionPaint();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean8 = barRenderer3D6.equals((java.lang.Object) 10.0f);
        java.awt.Paint paint9 = barRenderer3D6.getBaseFillPaint();
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer3D6.setSeriesItemLabelPaint(0, paint11, false);
        piePlot3D1.setLabelBackgroundPaint(paint11);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getDataArea();
        boolean boolean5 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) 96, (double) (byte) 10, rectangle2D4);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        java.lang.String str17 = categoryPlot16.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot16.getRangeAxisLocation(9999);
        categoryPlot5.setRangeAxisLocation(10, axisLocation19, false);
        categoryPlot5.setCrosshairDatasetIndex((int) (byte) 100, false);
        java.util.List list25 = categoryPlot5.getCategories();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot5.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo30.getDataArea();
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot5.zoomRangeAxes((double) 0.5f, plotRenderingInfo30, point2D32);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(list25);
        org.junit.Assert.assertNotNull(categoryAxis27);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        double double6 = xYBarRenderer0.getShadowXOffset();
        double double7 = xYBarRenderer0.getBase();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot13.removeDomainMarker(marker15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot13.setRangeMinorGridlineStroke(stroke17);
        xYBarRenderer0.setBaseStroke(stroke17, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator24 = xYBarRenderer0.getItemLabelGenerator((int) '#', 9999, true);
        xYBarRenderer0.setSeriesItemLabelsVisible(6, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(xYItemLabelGenerator24);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!", paint12);
        legendItem13.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset16 = null;
        legendItem13.setDataset(dataset16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYBarRenderer18.setSeriesURLGenerator(6, xYURLGenerator20);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer18.setSeriesStroke((int) (byte) 100, stroke23);
        legendItem13.setOutlineStroke(stroke23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke23);
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = combinedRangeXYPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27, true);
        java.lang.String str30 = valueMarker26.getLabel();
        org.jfree.chart.text.TextAnchor textAnchor31 = valueMarker26.getLabelTextAnchor();
        org.jfree.chart.util.ShapeList shapeList32 = new org.jfree.chart.util.ShapeList();
        org.jfree.data.xy.XYDataItem xYDataItem35 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        boolean boolean36 = shapeList32.equals((java.lang.Object) 0.0d);
        java.awt.Shape shape38 = shapeList32.getShape(3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.lang.String str40 = rectangleAnchor39.toString();
        boolean boolean41 = shapeList32.equals((java.lang.Object) rectangleAnchor39);
        valueMarker26.setLabelAnchor(rectangleAnchor39);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleAnchor.TOP" + "'", str40.equals("RectangleAnchor.TOP"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis1);
        org.jfree.data.RangeType rangeType6 = org.jfree.data.RangeType.NEGATIVE;
        numberAxis1.setRangeType(rangeType6);
        numberAxis1.setLowerBound((double) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rangeType6);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot6.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { valueAxis11 };
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot6.setDomainTickBandPaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", paint17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem18.setLabelPaint(paint19);
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem18.setFillPaint(paint21);
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color14, paint21);
        boolean boolean24 = defaultPieDataset0.equals((java.lang.Object) paint21);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boolean24, true);
        java.lang.String str27 = rendererChangeEvent26.toString();
        java.lang.Object obj28 = rendererChangeEvent26.getSource();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=false]" + "'", str27.equals("org.jfree.chart.event.RendererChangeEvent[source=false]"));
        org.junit.Assert.assertTrue("'" + obj28 + "' != '" + false + "'", obj28.equals(false));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        org.jfree.chart.util.LogFormat logFormat10 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.text.NumberFormat numberFormat11 = logFormat10.getExponentFormat();
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator12 = new org.jfree.chart.labels.StandardPieToolTipGenerator("ThreadContext", (java.text.NumberFormat) logFormat5, numberFormat11);
        int int13 = logFormat5.getMaximumFractionDigits();
        logFormat5.setMinimumFractionDigits((-459));
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean5 = piePlot3D1.equals((java.lang.Object) rectangleInsets4);
        piePlot3D1.setDepthFactor((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        legendTitle2.setLegendItemGraphicPadding(rectangleInsets7);
        java.awt.geom.Rectangle2D rectangle2D9 = legendTitle2.getBounds();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        piePlot3D1.setBackgroundImageAlignment((int) (byte) 10);
        piePlot3D1.setSectionOutlinesVisible(true);
        java.awt.Font font8 = piePlot3D1.getNoDataMessageFont();
        piePlot3D1.clearSectionOutlinePaints(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot3D1.getSimpleLabelOffset();
        double double12 = rectangleInsets11.getTop();
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.18d + "'", double12 == 0.18d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        java.util.List list2 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection0.removeSeries(timeSeries4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        java.util.List list8 = timeSeries7.getItems();
        int int9 = timeSeriesCollection0.indexOf(timeSeries7);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        java.awt.Stroke stroke6 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = combinedRangeXYPlot0.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer9);
        java.awt.Font font11 = categoryAxis3D7.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection16 = combinedRangeXYPlot12.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] { valueAxis17 };
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot12.setDomainTickBandPaint((java.awt.Paint) color20);
        java.awt.Stroke stroke22 = combinedRangeXYPlot12.getRangeCrosshairStroke();
        categoryAxis3D7.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot12);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot12);
        jFreeChart24.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle27 = jFreeChart24.getTitle();
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle27.setPaint(paint28);
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle27.getBounds();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets3.createInsetRectangle(rectangle2D30, true, false);
        double double34 = rectangleInsets3.getTop();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(textTitle27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot5.setRangeAxis(valueAxis9);
        boolean boolean11 = categoryPlot5.isRangeCrosshairVisible();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", paint16);
        legendItem17.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset20 = null;
        legendItem17.setDataset(dataset20);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer22 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator24 = null;
        xYBarRenderer22.setSeriesURLGenerator(6, xYURLGenerator24);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer22.setSeriesStroke((int) (byte) 100, stroke27);
        legendItem17.setOutlineStroke(stroke27);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color14, stroke27);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        double double33 = barRenderer32.getMinimumBarLength();
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("hi!", paint35);
        legendItem36.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset39 = null;
        legendItem36.setDataset(dataset39);
        java.awt.Paint paint41 = legendItem36.getOutlinePaint();
        barRenderer32.setShadowPaint(paint41);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = barRenderer32.getItemLabelGenerator(2, 9999, true);
        boolean boolean48 = barRenderer32.isSeriesItemLabelsVisible((int) (byte) 1);
        barRenderer32.setDrawBarOutline(false);
        boolean boolean51 = layer31.equals((java.lang.Object) barRenderer32);
        categoryPlot5.addRangeMarker((-459), (org.jfree.chart.plot.Marker) valueMarker30, layer31);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(categoryItemLabelGenerator46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("NO_CHANGE");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange2, (org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range5 = rectangleConstraint4.getHeightRange();
        boolean boolean6 = textFragment1.equals((java.lang.Object) range5);
        java.lang.String str7 = textFragment1.getText();
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "NO_CHANGE" + "'", str7.equals("NO_CHANGE"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        combinedRangeXYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean2 = barRenderer3D0.equals((java.lang.Object) 10.0f);
        java.awt.Paint paint3 = barRenderer3D0.getBaseFillPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D0.setSeriesURLGenerator(3, categoryURLGenerator5, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        boolean boolean10 = itemLabelAnchor8.equals((java.lang.Object) 1.0d);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 15, "ThreadContext", textAnchor13, textAnchor14, (double) (short) 1);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor8, textAnchor13, textAnchor17, 15.0d);
        barRenderer3D0.setBasePositiveItemLabelPosition(itemLabelPosition19);
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D(pieDataset23);
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D24);
        org.jfree.chart.event.TitleChangeListener titleChangeListener26 = null;
        legendTitle25.addChangeListener(titleChangeListener26);
        org.jfree.chart.entity.TitleEntity titleEntity30 = new org.jfree.chart.entity.TitleEntity(shape22, (org.jfree.chart.title.Title) legendTitle25, "Category Plot", "-0.0");
        java.lang.Number[] numberArray39 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray44 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] { numberArray39, numberArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray45);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity49 = new org.jfree.chart.entity.CategoryItemEntity(shape22, "HorizontalAlignment.CENTER", "January 13", categoryDataset46, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.data.Range range51 = barRenderer3D0.findRangeBounds(categoryDataset46, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range51);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("-0.0");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key -0.0");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.lang.String str11 = chartEntity10.getToolTipText();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        java.lang.String str29 = categoryItemEntity28.toString();
        java.lang.String str30 = categoryItemEntity28.getShapeType();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "poly" + "'", str30.equals("poly"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        int int3 = year2.getYear();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        boolean boolean6 = year2.equals((java.lang.Object) rectangleEdge5);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year2, (java.lang.Number) 0.14d);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year9.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator3);
        double double5 = piePlot3D1.getShadowYOffset();
        boolean boolean6 = piePlot3D1.isCircular();
        piePlot3D1.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(1, 13);
        int int6 = month5.getMonth();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.TOP;
        int int8 = month5.compareTo((java.lang.Object) rectangleEdge7);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double12 = categoryAxis3D11.getCategoryMargin();
        categoryAxis3D11.setLabelAngle((double) (byte) 100);
        java.awt.Paint paint15 = categoryAxis3D11.getTickMarkPaint();
        boolean boolean16 = gradientPaintTransformType9.equals((java.lang.Object) categoryAxis3D11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = categoryAxis3D11.getCategoryLabelPositions();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = year18.getYear();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        boolean boolean22 = year18.equals((java.lang.Object) rectangleEdge21);
        categoryAxis3D11.addCategoryLabelToolTip((java.lang.Comparable) year18, "hi!");
        long long25 = year18.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month5, (org.jfree.data.time.RegularTimePeriod) year18);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = combinedRangeXYPlot0.getFixedLegendItems();
        combinedRangeXYPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(legendItemCollection3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        java.text.NumberFormat numberFormat1 = logAxis0.getNumberFormatOverride();
        try {
            logAxis0.setBase((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'base' > 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        java.awt.Font font9 = categoryAxis3D5.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = combinedRangeXYPlot10.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { valueAxis15 };
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot10.setDomainTickBandPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot10.getRangeCrosshairStroke();
        categoryAxis3D5.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot10);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot10);
        java.awt.Paint paint23 = jFreeChart22.getBorderPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint23);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker24);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.addBaseTimelineExclusions(0L, (long) 15);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline0.addException(date4);
        java.util.List list6 = segmentedTimeline0.getExceptionSegments();
        segmentedTimeline0.addException((long) 6);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelAngle((double) (byte) 100);
        java.awt.Paint paint5 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.setCategoryLabelPositionOffset(1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        barRenderer0.setBaseOutlinePaint(paint11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot13.getRangeAxisLocation(0);
        java.awt.Paint paint16 = combinedRangeXYPlot13.getRangeGridlinePaint();
        barRenderer0.setBaseOutlinePaint(paint16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer0.getNegativeItemLabelPositionFallback();
        double double19 = barRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(itemLabelPosition18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        numberAxis1.setAutoTickUnitSelection(false);
        java.awt.Shape shape5 = numberAxis1.getLeftArrow();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("NO_CHANGE");
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange8, (org.jfree.data.Range) dateRange9);
        org.jfree.data.Range range11 = rectangleConstraint10.getHeightRange();
        boolean boolean12 = textFragment7.equals((java.lang.Object) range11);
        numberAxis1.setRangeWithMargins(range11, false, false);
        boolean boolean17 = range11.contains((double) 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        boolean boolean7 = rectangleInsets5.equals((java.lang.Object) "VerticalAlignment.TOP");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo9.getDataArea();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.awt.Font font18 = categoryAxis3D14.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot19.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection23 = combinedRangeXYPlot19.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] { valueAxis24 };
        combinedRangeXYPlot19.setDomainAxes(valueAxisArray25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot19.setDomainTickBandPaint((java.awt.Paint) color27);
        java.awt.Stroke stroke29 = combinedRangeXYPlot19.getRangeCrosshairStroke();
        categoryAxis3D14.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot19);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot19);
        jFreeChart31.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle34 = jFreeChart31.getTitle();
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle34.setPaint(paint35);
        org.jfree.chart.entity.TitleEntity titleEntity37 = new org.jfree.chart.entity.TitleEntity((java.awt.Shape) rectangle2D10, (org.jfree.chart.title.Title) textTitle34);
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets5.createOutsetRectangle(rectangle2D10, false, false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(valueAxisArray25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(textTitle34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = year3.getYear();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge5);
        boolean boolean7 = year3.equals((java.lang.Object) rectangleEdge6);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year3, (java.lang.Number) 0.14d);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(1, 13);
        java.lang.String str13 = month12.toString();
        org.jfree.data.time.Year year14 = month12.getYear();
        java.util.TimeZone timeZone15 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale16 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) month12, timeZone15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "January 13" + "'", str13.equals("January 13"));
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot5.setDomainAxis(categoryAxis13);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        piePlot3D1.setBackgroundImageAlignment((int) (byte) 10);
        piePlot3D1.setSectionOutlinesVisible(true);
        java.awt.Font font8 = piePlot3D1.getNoDataMessageFont();
        java.awt.Font font9 = piePlot3D1.getLabelFont();
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        java.text.AttributedString attributedString5 = legendItem2.getAttributedLabel();
        legendItem2.setDescription("ItemLabelAnchor.OUTSIDE3");
        boolean boolean8 = legendItem2.isShapeOutlineVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        legendItem2.setOutlinePaint((java.awt.Paint) color9);
        java.lang.String str11 = legendItem2.getLabel();
        boolean boolean12 = legendItem2.isShapeFilled();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator7 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator3, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator7);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 'a');
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(date3);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segment4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.lang.Object obj4 = xYBarRenderer0.clone();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer6 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = null;
        xYBarRenderer6.setSeriesURLGenerator(6, xYURLGenerator8);
        java.lang.Object obj10 = xYBarRenderer6.clone();
        java.awt.Stroke stroke12 = xYBarRenderer6.getSeriesOutlineStroke((int) (short) 0);
        java.awt.Stroke stroke13 = xYBarRenderer6.getBaseStroke();
        xYBarRenderer0.setSeriesStroke(5, stroke13, false);
        org.jfree.chart.LegendItem legendItem18 = xYBarRenderer0.getLegendItem(15, 100);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(legendItem18);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("VerticalAlignment.TOP");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        standardChartTheme1.setLegendItemPaint(paint3);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            xYSeriesCollection0.setSelected(2147483647, (int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.data.general.DatasetGroup datasetGroup4 = piePlot3D1.getDatasetGroup();
        org.junit.Assert.assertNull(datasetGroup4);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = combinedRangeXYPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot4 = piePlot3D1.getRootPlot();
        piePlot3D1.setAutoPopulateSectionPaint(false);
        java.lang.Object obj7 = piePlot3D1.clone();
        piePlot3D1.setStartAngle((double) (-61755710400001L));
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 5);
        java.lang.String str3 = dateTickUnitType0.toString();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnitType.MILLISECOND" + "'", str3.equals("DateTickUnitType.MILLISECOND"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str2 = verticalAlignment1.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 2958465, 0.025d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.TOP" + "'", str2.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = combinedRangeXYPlot0.getRangeAxisEdge();
        org.jfree.chart.util.BooleanList booleanList9 = new org.jfree.chart.util.BooleanList();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        java.lang.String str16 = categoryPlot15.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot15.getRangeAxisLocation(9999);
        boolean boolean19 = booleanList9.equals((java.lang.Object) categoryPlot15);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot15.setRangeZeroBaselineStroke(stroke20);
        combinedRangeXYPlot0.setRangeMinorGridlineStroke(stroke20);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Category Plot" + "'", str16.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 12.0d, "", textAnchor2, textAnchor3, (double) 2147483647);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset19, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate26 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19);
        java.lang.Object obj27 = intervalXYDelegate26.clone();
        try {
            java.lang.Number number30 = intervalXYDelegate26.getStartX(13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            java.lang.Number number3 = xYSeriesCollection0.getX((int) (short) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.addBaseTimelineExclusions(0L, (long) 15);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline0.addException(date4);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline0.getSegment(1560458003853L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(segment7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        java.awt.Stroke stroke10 = categoryPlot5.getRangeMinorGridlineStroke();
        double double11 = categoryPlot5.getRangeCrosshairValue();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedRangeXYPlot12.getRangeAxisLocation(0);
        java.awt.Paint paint15 = combinedRangeXYPlot12.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.util.List list18 = null;
        combinedRangeXYPlot12.drawDomainTickBands(graphics2D16, rectangle2D17, list18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!", paint24);
        legendItem25.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset28 = null;
        legendItem25.setDataset(dataset28);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer30 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator32 = null;
        xYBarRenderer30.setSeriesURLGenerator(6, xYURLGenerator32);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer30.setSeriesStroke((int) (byte) 100, stroke35);
        legendItem25.setOutlineStroke(stroke35);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color22, stroke35);
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean41 = combinedRangeXYPlot12.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39, true);
        java.lang.String str42 = valueMarker38.getLabel();
        org.jfree.chart.text.TextAnchor textAnchor43 = valueMarker38.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        org.jfree.chart.renderer.category.BarRenderer barRenderer45 = new org.jfree.chart.renderer.category.BarRenderer();
        double double46 = barRenderer45.getMinimumBarLength();
        java.awt.Paint paint48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("hi!", paint48);
        legendItem49.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset52 = null;
        legendItem49.setDataset(dataset52);
        java.awt.Paint paint54 = legendItem49.getOutlinePaint();
        barRenderer45.setShadowPaint(paint54);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator59 = barRenderer45.getItemLabelGenerator(2, 9999, true);
        boolean boolean61 = barRenderer45.isSeriesItemLabelsVisible((int) (byte) 1);
        barRenderer45.setDrawBarOutline(false);
        boolean boolean64 = layer44.equals((java.lang.Object) barRenderer45);
        boolean boolean65 = categoryPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker38, layer44);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(categoryItemLabelGenerator59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean2 = barRenderer3D0.equals((java.lang.Object) 10.0f);
        java.awt.Paint paint3 = barRenderer3D0.getBaseFillPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot9.getDomainAxisEdge((int) (byte) 1);
        float float12 = categoryPlot9.getBackgroundImageAlpha();
        categoryPlot9.setNoDataMessage("item");
        java.awt.Paint paint15 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        categoryPlot9.setRangeCrosshairPaint(paint15);
        barRenderer3D0.setBasePaint(paint15, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.awt.Stroke stroke7 = legendItem2.getOutlineStroke();
        java.lang.Object obj8 = legendItem2.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj8);
    }
}

