import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE3" + "'", str1.equals("ItemLabelAnchor.OUTSIDE3"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("hi!", regularTimePeriod1, regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("hi!", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity2 = new org.jfree.chart.entity.PlotEntity(shape0, plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color3 = color2.darker();
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("ItemLabelAnchor.OUTSIDE3", font1, (java.awt.Paint) color2, (float) (byte) 10, textMeasurer5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        boolean boolean5 = legendItem2.isLineVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = null;
        try {
            combinedRangeXYPlot0.setDatasetRenderingOrder(datasetRenderingOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity7 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3", categoryDataset4, (java.lang.Comparable) 10.0f, (java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.Marker marker2 = null;
        org.jfree.chart.util.Layer layer3 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker((int) (byte) -1, marker2, layer3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            defaultKeyedValues0.sortByKeys(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("hi!", paint2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!", paint6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem7.setLabelPaint(paint8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem7.setFillPaint(paint10);
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color13 = color12.darker();
        boolean boolean14 = org.jfree.chart.util.PaintUtilities.equal(paint10, (java.awt.Paint) color13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1, paint2, stroke4, paint10, stroke15, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            piePlot3D1.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        java.awt.Paint paint5 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) '#');
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '#', (float) (byte) 100);
        try {
            shapeList0.setShape((int) (byte) -1, shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str1.equals("TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator4 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        boolean boolean5 = gradientPaintTransformType0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (short) 10, (double) (short) 0, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        try {
            combinedRangeXYPlot0.setRangeAxis((int) (short) -1, valueAxis2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, (double) (short) 100, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (short) 100, 0.0f, textAnchor4, (double) (byte) 100, textAnchor6);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            defaultPieDataset0.insertValue(3, (java.lang.Comparable) (byte) 0, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, (-1.0d), (float) 2, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            defaultPieDataset0.insertValue(3, (java.lang.Comparable) "", (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setDefaultEntityRadius(4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(9999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1964 + "'", int1 == 1964);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 2, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextBlockAnchor.TOP_RIGHT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ThreadContext");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D9.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            barRenderer0.drawDomainMarker(graphics2D1, categoryPlot7, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D9, categoryMarker12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot5.addDomainMarker((int) (byte) 10, categoryMarker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            combinedRangeXYPlot0.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = null;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 6, dateTickUnitType2, (int) (byte) 10, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        java.util.List list12 = null;
        try {
            categoryPlot5.mapDatasetToDomainAxes((int) (byte) 1, list12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = null;
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis9, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection20 = combinedRangeXYPlot16.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        combinedRangeXYPlot16.setDomainAxes(valueAxisArray22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot16.setDomainTickBandPaint((java.awt.Paint) color24);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", paint27);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem28.setLabelPaint(paint29);
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem28.setFillPaint(paint31);
        boolean boolean33 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color24, paint31);
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("hi!", font14, (java.awt.Paint) color24);
        java.awt.geom.Rectangle2D rectangle2D35 = labelBlock34.getBounds();
        org.jfree.data.general.DefaultPieDataset defaultPieDataset36 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = defaultPieDataset36.hasListener((java.util.EventListener) combinedRangeXYPlot38);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset44 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            xYBarRenderer0.drawItem(graphics2D6, xYItemRendererState7, rectangle2D35, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot38, valueAxis42, valueAxis43, (org.jfree.data.xy.XYDataset) defaultXYDataset44, 3, (int) (short) 1, true, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.xy.DefaultXYDataset cannot be cast to org.jfree.data.xy.IntervalXYDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        boolean boolean5 = logFormat4.isParseIntegerOnly();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.util.List list5 = null;
        try {
            combinedRangeXYPlot0.mapDatasetToDomainAxes((int) '#', list5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("VerticalAlignment.TOP", "ItemLabelAnchor.OUTSIDE3", "ThreadContext", "VerticalAlignment.TOP", "VerticalAlignment.TOP");
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("Category Plot", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = null;
        try {
            categoryPlot5.setDomainGridlinePosition(categoryAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100, (-135.0d), (double) 'a', (double) 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        java.text.AttributedString attributedString5 = legendItem2.getAttributedLabel();
        int int6 = legendItem2.getSeriesIndex();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        java.lang.Comparable comparable1 = null;
        try {
            int int2 = defaultKeyedValues0.getIndex(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        double double6 = xYBarRenderer0.getShadowXOffset();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot8.clearDomainAxes();
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = combinedRangeXYPlot8.removeDomainMarker(marker13, layer14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = null;
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis18, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font23);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection29 = combinedRangeXYPlot25.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { valueAxis30 };
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot25.setDomainTickBandPaint((java.awt.Paint) color33);
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("hi!", paint36);
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem37.setLabelPaint(paint38);
        java.awt.Paint paint40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem37.setFillPaint(paint40);
        boolean boolean42 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color33, paint40);
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("hi!", font23, (java.awt.Paint) color33);
        java.awt.geom.Rectangle2D rectangle2D44 = labelBlock43.getBounds();
        java.awt.Color color46 = java.awt.Color.LIGHT_GRAY;
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D49, valueAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer51);
        java.lang.String str53 = categoryPlot52.getPlotType();
        org.jfree.chart.plot.Marker marker54 = null;
        boolean boolean55 = categoryPlot52.removeDomainMarker(marker54);
        java.awt.Stroke stroke56 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot52.setRangeMinorGridlineStroke(stroke56);
        try {
            xYBarRenderer0.drawRangeLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8, valueAxis16, rectangle2D44, 4.0d, (java.awt.Paint) color46, stroke56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Category Plot" + "'", str53.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = null;
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis10, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font15);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection21 = combinedRangeXYPlot17.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        combinedRangeXYPlot17.setDomainAxes(valueAxisArray23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot17.setDomainTickBandPaint((java.awt.Paint) color25);
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", paint28);
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem29.setLabelPaint(paint30);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem29.setFillPaint(paint32);
        boolean boolean34 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color25, paint32);
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("hi!", font15, (java.awt.Paint) color25);
        java.awt.geom.Rectangle2D rectangle2D36 = labelBlock35.getBounds();
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D8, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot5.setRangeAxis(valueAxis9);
        java.util.List list12 = null;
        try {
            categoryPlot5.mapDatasetToRangeAxes((int) (short) 100, list12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) (short) 10, (double) 1L);
        try {
            defaultKeyedValues0.insertValue(6, (java.lang.Comparable) (short) 100, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, (double) (byte) 0, (double) 'a', (int) '4', (java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) (short) 10, (double) 1L);
        try {
            defaultKeyedValues0.insertValue((int) (short) -1, (java.lang.Comparable) 2, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        boolean boolean6 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYBarRenderer7.setSeriesURLGenerator(6, xYURLGenerator9);
        xYBarRenderer7.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        int int14 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYBarRenderer7);
        xYBarRenderer7.setBaseCreateEntities(false, true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        double double21 = rectangleInsets19.trimWidth(0.05d);
        double double23 = rectangleInsets19.trimHeight((double) 0.0f);
        org.jfree.chart.axis.NumberAxis numberAxis25 = null;
        java.awt.Font font30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis25, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font30);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot32.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection36 = combinedRangeXYPlot32.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { valueAxis37 };
        combinedRangeXYPlot32.setDomainAxes(valueAxisArray38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot32.setDomainTickBandPaint((java.awt.Paint) color40);
        java.awt.Paint paint43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", paint43);
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem44.setLabelPaint(paint45);
        java.awt.Paint paint47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem44.setFillPaint(paint47);
        boolean boolean49 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color40, paint47);
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("hi!", font30, (java.awt.Paint) color40);
        java.awt.geom.Rectangle2D rectangle2D51 = labelBlock50.getBounds();
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets19.createInsetRectangle(rectangle2D51);
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot54.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection58 = combinedRangeXYPlot54.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray60 = new org.jfree.chart.axis.ValueAxis[] { valueAxis59 };
        combinedRangeXYPlot54.setDomainAxes(valueAxisArray60);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = combinedRangeXYPlot54.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        try {
            org.jfree.chart.axis.AxisState axisState64 = categoryAxis3D9.draw(graphics2D12, (double) 100L, rectangle2D51, rectangle2D53, rectangleEdge62, plotRenderingInfo63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-13.95d) + "'", double21 == (-13.95d));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-135.0d) + "'", double23 == (-135.0d));
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertNotNull(valueAxisArray60);
        org.junit.Assert.assertNotNull(rectangleEdge62);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getRangeAxisLocation(0);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 0.0f, (-13.95d), plotRenderingInfo8, point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, 0.0d, (double) 4, (int) (byte) -1, (java.lang.Comparable) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = (short) 100;
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(6, layer5);
        combinedRangeXYPlot0.setDomainCrosshairLockedOnData(false);
        java.awt.Stroke stroke9 = combinedRangeXYPlot0.getOutlineStroke();
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot0.getDomainMarkers(0, layer11);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBasePaint();
        xYBarRenderer2.setShadowXOffset((double) 4);
        java.lang.Boolean boolean7 = xYBarRenderer2.getSeriesItemLabelsVisible((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer2.setPositiveItemLabelPositionFallback(itemLabelPosition8);
        xYBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            int int2 = defaultXYDataset0.getItemCount(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle2.removeChangeListener(titleChangeListener5);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        java.lang.String str1 = domainOrder0.toString();
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DomainOrder.ASCENDING" + "'", str1.equals("DomainOrder.ASCENDING"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        piePlot3D1.setAutoPopulateSectionOutlinePaint(false);
        java.awt.Font font6 = null;
        try {
            piePlot3D1.setNoDataMessageFont(font6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = null;
        xYBarRenderer0.setSeriesItemLabelGenerator(4, xYItemLabelGenerator5, false);
        org.jfree.chart.plot.XYPlot xYPlot8 = xYBarRenderer0.getPlot();
        org.junit.Assert.assertNull(xYPlot8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        double double6 = xYBarRenderer0.getShadowXOffset();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '#', (float) (byte) 100);
        try {
            xYBarRenderer0.setSeriesShape((-1), shape10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot0.setDomainTickBandPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list12 = null;
        try {
            combinedRangeXYPlot0.mapDatasetToDomainAxes(2, list12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getRangeAxisLocation(15);
        boolean boolean6 = combinedRangeXYPlot0.isNotify();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(0.0d, 0.0d, plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        piePlot3D1.setAutoPopulateSectionOutlinePaint(false);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle6 = null;
        try {
            piePlot3D1.setLabelLinkStyle(pieLabelLinkStyle6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'style' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot0.getRangeAxisIndex(valueAxis2);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot4 = piePlot3D1.getRootPlot();
        org.jfree.chart.util.UnitType unitType5 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean6 = piePlot3D1.equals((java.lang.Object) unitType5);
        double double7 = piePlot3D1.getShadowYOffset();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint10 = xYBarRenderer9.getBasePaint();
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) 2, paint10);
        piePlot3D1.setAutoPopulateSectionOutlineStroke(false);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation5, plotOrientation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition6);
        xYBarRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        java.awt.Shape shape7 = xYAreaRenderer6.getLegendArea();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        combinedRangeXYPlot11.setFixedRangeAxisSpace(axisSpace14, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = combinedRangeXYPlot17.getDomainMarkers(6, layer22);
        combinedRangeXYPlot17.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot11.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot17);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        try {
            xYAreaRenderer6.drawItem(graphics2D8, xYItemRendererState9, rectangle2D10, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, valueAxis27, valueAxis28, xYDataset29, 1964, 100, false, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean11 = categoryPlot5.removeAnnotation(categoryAnnotation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.text.NumberFormat numberFormat5 = logFormat4.getExponentFormat();
        numberFormat5.setMinimumIntegerDigits((int) 'a');
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        categoryAxis3D2.setVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getRangeAxisLocation(0);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getRangeGridlinePaint();
        boolean boolean12 = categoryAxis3D2.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        try {
            combinedRangeXYPlot8.zoomDomainAxes((double) 1964, (double) 'a', plotRenderingInfo15, point2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        combinedRangeXYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis18 = null;
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis18, (double) 0.0f, (double) 13, (double) 3, (double) (short) 10, font23);
        boolean boolean25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) true, (java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        categoryPlot5.clearRangeAxes();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            categoryPlot5.drawBackground(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = null;
        try {
            combinedRangeXYPlot0.setOrientation(plotOrientation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("DomainOrder.ASCENDING");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name DomainOrder.ASCENDING, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.RenderingHints renderingHints21 = null;
        try {
            jFreeChart20.setRenderingHints(renderingHints21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange28, (org.jfree.data.Range) dateRange29);
        org.jfree.data.Range range31 = rectangleConstraint30.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D32 = labelBlock26.arrange(graphics2D27, rectangleConstraint30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        int int4 = combinedRangeXYPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        java.awt.Paint paint6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!", paint6);
        legendItem7.setShapeVisible(true);
        java.lang.Comparable comparable10 = legendItem7.getSeriesKey();
        legendItemCollection4.add(legendItem7);
        java.lang.Object obj12 = legendItemCollection4.clone();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(comparable10);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "ThreadContext", "", "hi!");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        try {
            java.lang.Number number23 = defaultXYDataset19.getX(100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYBarRenderer2.setSeriesURLGenerator(6, xYURLGenerator4);
        java.lang.Object obj6 = xYBarRenderer2.clone();
        java.awt.Stroke stroke8 = xYBarRenderer2.getSeriesOutlineStroke((int) (short) 0);
        boolean boolean9 = standardGradientPaintTransformer1.equals((java.lang.Object) xYBarRenderer2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot10.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        combinedRangeXYPlot10.setFixedRangeAxisSpace(axisSpace13, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot16.getDomainMarkers(6, layer21);
        combinedRangeXYPlot16.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot10.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        java.awt.Image image26 = null;
        combinedRangeXYPlot10.setBackgroundImage(image26);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset29 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot10.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset29);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate32 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset29, true);
        org.jfree.data.Range range33 = xYBarRenderer2.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset29);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        int int21 = jFreeChart20.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        double double4 = dateRange0.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange5, (org.jfree.data.Range) dateRange6);
        java.lang.Class<?> wildcardClass8 = dateRange6.getClass();
        org.jfree.data.Range range9 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange6);
        boolean boolean11 = dateRange0.contains((-13.95d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        double double6 = xYBarRenderer0.getShadowXOffset();
        xYBarRenderer0.setAutoPopulateSeriesFillPaint(false);
        double double9 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer0.getSeriesItemLabelGenerator(10);
        double double12 = xYBarRenderer0.getShadowXOffset();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D4);
        org.jfree.chart.event.TitleChangeListener titleChangeListener6 = null;
        legendTitle5.addChangeListener(titleChangeListener6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle5.setLegendItemGraphicLocation(rectangleAnchor8);
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 12.0d, (double) 60000L, rectangleAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisible((int) (byte) 0);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        boolean boolean4 = piePlot3D1.getSimpleLabels();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Point2D point2D4 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 0.5f, plotRenderingInfo3, point2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean2 = barRenderer3D0.equals((java.lang.Object) 10.0f);
        java.awt.Paint paint3 = barRenderer3D0.getBaseFillPaint();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer9);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot10.getDomainMarkers(layer11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = null;
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis14, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font19);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection25 = combinedRangeXYPlot21.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] { valueAxis26 };
        combinedRangeXYPlot21.setDomainAxes(valueAxisArray27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot21.setDomainTickBandPaint((java.awt.Paint) color29);
        java.awt.Paint paint32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!", paint32);
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem33.setLabelPaint(paint34);
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem33.setFillPaint(paint36);
        boolean boolean38 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color29, paint36);
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("hi!", font19, (java.awt.Paint) color29);
        java.awt.geom.Rectangle2D rectangle2D40 = labelBlock39.getBounds();
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D40);
        try {
            barRenderer3D0.drawOutline(graphics2D4, categoryPlot10, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(shape41);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke5 = combinedRangeXYPlot4.getRangeCrosshairStroke();
        java.awt.Paint paint6 = combinedRangeXYPlot4.getRangeCrosshairPaint();
        boolean boolean7 = piePlot3D1.equals((java.lang.Object) combinedRangeXYPlot4);
        piePlot3D1.setLabelLinkMargin((double) 15);
        java.awt.Paint paint10 = piePlot3D1.getBaseSectionOutlinePaint();
        double double11 = piePlot3D1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.14d + "'", double11 == 0.14d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        java.awt.Shape shape7 = xYAreaRenderer6.getLegendArea();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity13 = new org.jfree.chart.entity.CategoryItemEntity(shape7, "", "TextBlockAnchor.TOP_RIGHT", categoryDataset10, (java.lang.Comparable) "hi!", (java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        try {
            piePlot3D1.setBackgroundImageAlpha((float) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 13);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = xYSeries3.getKey();
        java.lang.Comparable comparable7 = null;
        try {
            xYSeries3.setKey(comparable7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (byte) 10 + "'", comparable6.equals((byte) 10));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("TextBlockAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key TextBlockAnchor.TOP_RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 15, "ThreadContext", textAnchor2, textAnchor3, (double) (short) 1);
        double double6 = numberTick5.getValue();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 15.0d + "'", double6 == 15.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        boolean boolean3 = combinedRangeXYPlot0.isDomainPannable();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart20.getLegend(15);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(legendTitle23);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) 10, (double) (-1L), plotRenderingInfo11, point2D12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot5.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = null;
        try {
            barRenderer0.setBarPainter(barPainter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = xYSeries3.getKey();
        try {
            xYSeries3.update((java.lang.Number) 1964, (java.lang.Number) 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 1964");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (byte) 10 + "'", comparable6.equals((byte) 10));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot4 = piePlot3D1.getRootPlot();
        org.jfree.chart.util.UnitType unitType5 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean6 = piePlot3D1.equals((java.lang.Object) unitType5);
        double double7 = piePlot3D1.getShadowYOffset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getURLGenerator();
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        jFreeChart20.fireChartChanged();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot12.getRangeAxisLocation(15);
        categoryPlot5.setRangeAxisLocation(axisLocation17, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '#', (float) (byte) 100);
        java.awt.Color color7 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color8 = color7.darker();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot9.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        combinedRangeXYPlot9.setFixedRangeAxisSpace(axisSpace12, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = combinedRangeXYPlot15.getDomainMarkers(6, layer20);
        combinedRangeXYPlot15.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot9.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot15);
        java.awt.Stroke stroke25 = combinedRangeXYPlot9.getOutlineStroke();
        java.awt.Paint paint26 = null;
        try {
            org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem(attributedString0, "Category Plot", "DomainOrder.ASCENDING", "DomainOrder.ASCENDING", shape6, (java.awt.Paint) color7, stroke25, paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        java.lang.String str3 = legendItem2.getURLText();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) 10, (double) (-1L), plotRenderingInfo11, point2D12);
        categoryPlot5.setDrawSharedDomainAxis(false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        categoryAxis3D2.setVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedRangeXYPlot9.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        combinedRangeXYPlot9.setDomainAxes(valueAxisArray15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot9.setDomainTickBandPaint((java.awt.Paint) color17);
        java.awt.Stroke stroke19 = combinedRangeXYPlot9.getRangeCrosshairStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", paint23);
        legendItem24.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset27 = null;
        legendItem24.setDataset(dataset27);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator31 = null;
        xYBarRenderer29.setSeriesURLGenerator(6, xYURLGenerator31);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer29.setSeriesStroke((int) (byte) 100, stroke34);
        legendItem24.setOutlineStroke(stroke34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color21, stroke34);
        combinedRangeXYPlot9.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker37);
        java.util.List list39 = combinedRangeXYPlot9.getAnnotations();
        org.jfree.chart.block.BlockBorder blockBorder44 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = blockBorder44.getInsets();
        double double47 = rectangleInsets45.trimWidth(0.05d);
        double double49 = rectangleInsets45.trimHeight((double) 0.0f);
        org.jfree.chart.axis.NumberAxis numberAxis51 = null;
        java.awt.Font font56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis51, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font56);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot58 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot58.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection62 = combinedRangeXYPlot58.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray64 = new org.jfree.chart.axis.ValueAxis[] { valueAxis63 };
        combinedRangeXYPlot58.setDomainAxes(valueAxisArray64);
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot58.setDomainTickBandPaint((java.awt.Paint) color66);
        java.awt.Paint paint69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem70 = new org.jfree.chart.LegendItem("hi!", paint69);
        java.awt.Paint paint71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem70.setLabelPaint(paint71);
        java.awt.Paint paint73 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem70.setFillPaint(paint73);
        boolean boolean75 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color66, paint73);
        org.jfree.chart.block.LabelBlock labelBlock76 = new org.jfree.chart.block.LabelBlock("hi!", font56, (java.awt.Paint) color66);
        java.awt.geom.Rectangle2D rectangle2D77 = labelBlock76.getBounds();
        java.awt.geom.Rectangle2D rectangle2D78 = rectangleInsets45.createInsetRectangle(rectangle2D77);
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge79);
        try {
            double double81 = categoryAxis3D2.getCategoryMiddle((java.lang.Comparable) (-1.0f), list39, rectangle2D78, rectangleEdge80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + (-13.95d) + "'", double47 == (-13.95d));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-135.0d) + "'", double49 == (-135.0d));
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(legendItemCollection62);
        org.junit.Assert.assertNotNull(valueAxisArray64);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(rectangleEdge79);
        org.junit.Assert.assertNotNull(rectangleEdge80);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries3.remove((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        boolean boolean15 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        try {
            barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYBarRenderer1.setSeriesURLGenerator(6, xYURLGenerator3);
        xYBarRenderer1.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = xYBarRenderer1.getSeriesURLGenerator((int) 'a');
        boolean boolean10 = itemLabelAnchor0.equals((java.lang.Object) xYBarRenderer1);
        xYBarRenderer1.setUseYInterval(false);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(xYURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        double double12 = categoryAxis3D9.getLowerMargin();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot14.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection18 = combinedRangeXYPlot14.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { valueAxis19 };
        combinedRangeXYPlot14.setDomainAxes(valueAxisArray20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot14.setDomainTickBandPaint((java.awt.Paint) color22);
        java.awt.Stroke stroke24 = combinedRangeXYPlot14.getRangeCrosshairStroke();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!", paint28);
        legendItem29.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset32 = null;
        legendItem29.setDataset(dataset32);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer34 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator36 = null;
        xYBarRenderer34.setSeriesURLGenerator(6, xYURLGenerator36);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer34.setSeriesStroke((int) (byte) 100, stroke39);
        legendItem29.setOutlineStroke(stroke39);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color26, stroke39);
        combinedRangeXYPlot14.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker42);
        java.util.List list44 = combinedRangeXYPlot14.getAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis46 = null;
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand52 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis46, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font51);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot53.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection57 = combinedRangeXYPlot53.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray59 = new org.jfree.chart.axis.ValueAxis[] { valueAxis58 };
        combinedRangeXYPlot53.setDomainAxes(valueAxisArray59);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot53.setDomainTickBandPaint((java.awt.Paint) color61);
        java.awt.Paint paint64 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem("hi!", paint64);
        java.awt.Paint paint66 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem65.setLabelPaint(paint66);
        java.awt.Paint paint68 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem65.setFillPaint(paint68);
        boolean boolean70 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color61, paint68);
        org.jfree.chart.block.LabelBlock labelBlock71 = new org.jfree.chart.block.LabelBlock("hi!", font51, (java.awt.Paint) color61);
        java.awt.geom.Rectangle2D rectangle2D72 = labelBlock71.getBounds();
        java.awt.Shape shape73 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D72);
        org.jfree.data.category.CategoryDataset categoryDataset74 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D76 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer78 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset74, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D76, valueAxis77, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer78);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = categoryPlot79.getDomainAxisEdge((int) (byte) 1);
        try {
            double double82 = categoryAxis3D9.getCategoryMiddle((java.lang.Comparable) 10.0d, list44, rectangle2D72, rectangleEdge81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(valueAxisArray59);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(rectangleEdge81);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setBackgroundImageAlignment(15);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelAngle((double) (byte) 100);
        categoryAxis3D1.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot5.setDataset(categoryDataset9);
        java.awt.Paint paint11 = categoryPlot5.getNoDataMessagePaint();
        categoryPlot5.setRangePannable(false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot3.clearDomainAxes();
        boolean boolean8 = xYDataItem2.equals((java.lang.Object) combinedRangeXYPlot3);
        combinedRangeXYPlot3.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot1.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection5 = combinedRangeXYPlot1.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] { valueAxis6 };
        combinedRangeXYPlot1.setDomainAxes(valueAxisArray7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot1.setDomainTickBandPaint((java.awt.Paint) color9);
        java.awt.Stroke stroke11 = combinedRangeXYPlot1.getRangeCrosshairStroke();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", paint15);
        legendItem16.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset19 = null;
        legendItem16.setDataset(dataset19);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        xYBarRenderer21.setSeriesURLGenerator(6, xYURLGenerator23);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer21.setSeriesStroke((int) (byte) 100, stroke26);
        legendItem16.setOutlineStroke(stroke26);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color13, stroke26);
        combinedRangeXYPlot1.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker29);
        java.util.List list31 = combinedRangeXYPlot1.getAnnotations();
        try {
            org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer0.setSeriesStroke((int) (byte) 100, stroke5);
        xYBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint10 = xYBarRenderer0.lookupLegendTextPaint((int) (byte) 10);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart20.getLegend(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = legendTitle23.getPosition();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator10 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        xYBarRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
        java.lang.Boolean boolean13 = xYBarRenderer0.getSeriesCreateEntities(0);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.data.Range range18 = barRenderer15.findRangeBounds(categoryDataset17);
        java.awt.Color color19 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color20 = color19.darker();
        barRenderer15.setBaseItemLabelPaint((java.awt.Paint) color20, false);
        categoryPlot5.setRangeZeroBaselinePaint((java.awt.Paint) color20);
        java.lang.String str24 = color20.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=134,g=134,b=134]" + "'", str24.equals("java.awt.Color[r=134,g=134,b=134]"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot12.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot12.getDomainAxisLocation();
        categoryPlot5.setRangeAxisLocation(axisLocation17);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot5.setDataset(categoryDataset9);
        java.awt.Paint paint11 = categoryPlot5.getNoDataMessagePaint();
        java.awt.Paint paint12 = categoryPlot5.getRangeMinorGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot5.getDomainAxis();
        categoryPlot5.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(categoryAxis13);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        piePlot3D3.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke7 = combinedRangeXYPlot6.getRangeCrosshairStroke();
        java.awt.Paint paint8 = combinedRangeXYPlot6.getRangeCrosshairPaint();
        boolean boolean9 = piePlot3D3.equals((java.lang.Object) combinedRangeXYPlot6);
        piePlot3D3.setLabelLinkMargin((double) 15);
        java.awt.Paint paint12 = piePlot3D3.getBaseSectionOutlinePaint();
        boolean boolean13 = org.jfree.chart.util.PaintUtilities.equal(paint1, paint12);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getRangeAxisLocation(0);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot2);
        combinedRangeXYPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint3 = xYBarRenderer2.getBasePaint();
        xYBarRenderer2.setShadowXOffset((double) 4);
        java.lang.Boolean boolean7 = xYBarRenderer2.getSeriesItemLabelsVisible((int) (byte) 100);
        java.awt.Paint paint11 = xYBarRenderer2.getItemOutlinePaint(100, (int) (short) 0, false);
        try {
            org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("ItemLabelAnchor.OUTSIDE3", font1, paint11, (float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ThreadContext", "hi!");
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            java.lang.Number number2 = defaultKeyedValues0.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot4 = piePlot3D1.getRootPlot();
        java.awt.Paint paint5 = piePlot3D1.getBaseSectionPaint();
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("hi!", paint8);
        legendItem9.setShapeVisible(true);
        java.text.AttributedString attributedString12 = legendItem9.getAttributedLabel();
        legendItem9.setDescription("ItemLabelAnchor.OUTSIDE3");
        boolean boolean15 = legendItem9.isShapeOutlineVisible();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        legendItem9.setOutlinePaint((java.awt.Paint) color16);
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) "ItemLabelAnchor.OUTSIDE3", (java.awt.Paint) color16);
        java.awt.color.ColorSpace colorSpace19 = null;
        float[] floatArray24 = new float[] { 15, 1, (byte) -1, (short) -1 };
        try {
            float[] floatArray25 = color16.getColorComponents(colorSpace19, floatArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(attributedString12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot5.setRangeAxis(valueAxis9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot5.getRangeAxisLocation();
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate22 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        try {
            double double25 = intervalXYDelegate22.getStartXValue(12, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, (double) 0.0f, (double) 13, (double) 3, (double) (short) 10, font6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D10 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        java.lang.String str14 = categoryPlot13.getPlotType();
        org.jfree.chart.plot.Marker marker15 = null;
        boolean boolean16 = categoryPlot13.removeDomainMarker(marker15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot13.setRangeMinorGridlineStroke(stroke17);
        categoryPlot13.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedRangeXYPlot20.getRangeAxisLocation(15);
        categoryPlot13.setRangeAxisLocation(axisLocation25, false);
        java.awt.Color color28 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color29 = color28.darker();
        categoryPlot13.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D32 = new org.jfree.chart.plot.PiePlot3D(pieDataset31);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent33 = null;
        piePlot3D32.datasetChanged(datasetChangeEvent33);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot35 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke36 = combinedRangeXYPlot35.getRangeCrosshairStroke();
        java.awt.Paint paint37 = combinedRangeXYPlot35.getRangeCrosshairPaint();
        boolean boolean38 = piePlot3D32.equals((java.lang.Object) combinedRangeXYPlot35);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = combinedRangeXYPlot35.getRangeAxisEdge();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = null;
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D44, valueAxis45, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer46);
        java.lang.String str48 = categoryPlot47.getPlotType();
        org.jfree.chart.plot.Marker marker49 = null;
        boolean boolean50 = categoryPlot47.removeDomainMarker(marker49);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryPlot47.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot52.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection56 = combinedRangeXYPlot52.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] { valueAxis57 };
        combinedRangeXYPlot52.setDomainAxes(valueAxisArray58);
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot52.setDomainTickBandPaint((java.awt.Paint) color60);
        java.awt.Stroke stroke62 = combinedRangeXYPlot52.getRangeCrosshairStroke();
        boolean boolean63 = rectangleInsets51.equals((java.lang.Object) stroke62);
        try {
            org.jfree.chart.title.TextTitle textTitle64 = new org.jfree.chart.title.TextTitle("-0.0", font6, (java.awt.Paint) color29, rectangleEdge39, horizontalAlignment40, verticalAlignment41, rectangleInsets51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Category Plot" + "'", str48.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertNotNull(legendItemCollection56);
        org.junit.Assert.assertNotNull(valueAxisArray58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = null;
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis4, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font9);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection15 = combinedRangeXYPlot11.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] { valueAxis16 };
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot11.setDomainTickBandPaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!", paint22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem23.setLabelPaint(paint24);
        java.awt.Paint paint26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem23.setFillPaint(paint26);
        boolean boolean28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color19, paint26);
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("hi!", font9, (java.awt.Paint) color19);
        java.awt.geom.Rectangle2D rectangle2D30 = labelBlock29.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot36.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = categoryPlot36.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D43 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer45 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D43, valueAxis44, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer45);
        org.jfree.chart.util.Layer layer47 = null;
        java.util.Collection collection48 = categoryPlot46.getDomainMarkers(layer47);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo50);
        java.awt.geom.Point2D point2D52 = null;
        categoryPlot46.zoomRangeAxes(0.0d, plotRenderingInfo51, point2D52, true);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState55 = barRenderer0.initialise(graphics2D2, rectangle2D30, categoryPlot36, 13, plotRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNull(collection48);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        java.text.AttributedString attributedString7 = legendItem4.getAttributedLabel();
        legendItem4.setDescription("ItemLabelAnchor.OUTSIDE3");
        boolean boolean10 = gradientPaintTransformType0.equals((java.lang.Object) "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot11.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        combinedRangeXYPlot11.setFixedRangeAxisSpace(axisSpace14, false);
        boolean boolean17 = gradientPaintTransformType0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(attributedString7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        piePlot3D4.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot7 = piePlot3D4.getRootPlot();
        java.awt.Paint paint8 = piePlot3D4.getBaseSectionPaint();
        legendItem2.setLinePaint(paint8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesShapesVisible(1, false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot4 = piePlot3D1.getRootPlot();
        org.jfree.chart.util.UnitType unitType5 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean6 = piePlot3D1.equals((java.lang.Object) unitType5);
        double double7 = piePlot3D1.getShadowYOffset();
        java.awt.Color color8 = java.awt.Color.GRAY;
        piePlot3D1.setLabelLinkPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot5.setRangeAxis(100, valueAxis10, false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        categoryAxis3D6.setVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedRangeXYPlot12.getRangeAxisLocation(0);
        java.awt.Paint paint15 = combinedRangeXYPlot12.getRangeGridlinePaint();
        boolean boolean16 = categoryAxis3D6.hasListener((java.util.EventListener) combinedRangeXYPlot12);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D(pieDataset17);
        piePlot3D18.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot21 = piePlot3D18.getRootPlot();
        java.awt.Paint paint22 = piePlot3D18.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot3D18.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = null;
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis26, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font31);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot33.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection37 = combinedRangeXYPlot33.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray39 = new org.jfree.chart.axis.ValueAxis[] { valueAxis38 };
        combinedRangeXYPlot33.setDomainAxes(valueAxisArray39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot33.setDomainTickBandPaint((java.awt.Paint) color41);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("hi!", paint44);
        java.awt.Paint paint46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem45.setLabelPaint(paint46);
        java.awt.Paint paint48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem45.setFillPaint(paint48);
        boolean boolean50 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color41, paint48);
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("hi!", font31, (java.awt.Paint) color41);
        java.awt.geom.Rectangle2D rectangle2D52 = labelBlock51.getBounds();
        java.awt.Shape shape53 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D52);
        org.jfree.data.general.PieDataset pieDataset54 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D55 = new org.jfree.chart.plot.PiePlot3D(pieDataset54);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent56 = null;
        piePlot3D55.datasetChanged(datasetChangeEvent56);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot58 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke59 = combinedRangeXYPlot58.getRangeCrosshairStroke();
        java.awt.Paint paint60 = combinedRangeXYPlot58.getRangeCrosshairPaint();
        boolean boolean61 = piePlot3D55.equals((java.lang.Object) combinedRangeXYPlot58);
        piePlot3D55.setLabelLinkMargin((double) 15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo65 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo65);
        org.jfree.chart.plot.PiePlotState piePlotState67 = piePlot3D18.initialise(graphics2D24, rectangle2D52, (org.jfree.chart.plot.PiePlot) piePlot3D55, (java.lang.Integer) 0, plotRenderingInfo66);
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D70 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer72 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset68, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D70, valueAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer72);
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = categoryPlot73.getDomainAxisEdge((int) (byte) 1);
        try {
            double double76 = barRenderer3D0.getItemMiddle((java.lang.Comparable) 9999, (java.lang.Comparable) Double.NaN, categoryDataset3, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D6, rectangle2D52, rectangleEdge75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(legendItemCollection37);
        org.junit.Assert.assertNotNull(valueAxisArray39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(piePlotState67);
        org.junit.Assert.assertNotNull(rectangleEdge75);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        defaultPieDataset0.validateObject();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke8 = combinedRangeXYPlot7.getRangeCrosshairStroke();
        defaultPieDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot7);
        java.awt.geom.Point2D point2D10 = null;
        try {
            combinedRangeXYPlot7.setQuadrantOrigin(point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        org.jfree.chart.LegendItem legendItem4 = xYBarRenderer0.getLegendItem((int) (byte) 100, 0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(legendItem4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getLowerClip();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot5.getRangeAxis((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = null;
        piePlot3D1.datasetChanged(datasetChangeEvent2);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        piePlot3D1.setLegendItemShape(shape4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getDomainAxisEdge((int) (byte) 1);
        float float14 = categoryPlot11.getBackgroundImageAlpha();
        categoryPlot11.setNoDataMessage("item");
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot11);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = null;
        try {
            categoryPlot11.addDomainMarker(categoryMarker18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.awt.Font font12 = categoryAxis3D8.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection17 = combinedRangeXYPlot13.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { valueAxis18 };
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot13.setDomainTickBandPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot13.getRangeCrosshairStroke();
        categoryAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot13);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        java.awt.Paint paint26 = jFreeChart25.getBorderPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator29 = null;
        xYBarRenderer27.setSeriesURLGenerator(6, xYURLGenerator29);
        java.lang.Object obj31 = xYBarRenderer27.clone();
        java.awt.Stroke stroke33 = xYBarRenderer27.getSeriesOutlineStroke((int) (short) 0);
        java.awt.Stroke stroke34 = xYBarRenderer27.getBaseStroke();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, valueAxis38, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer39);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer42 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint43 = xYBarRenderer42.getBasePaint();
        barRenderer39.setSeriesFillPaint(3, paint43, true);
        try {
            org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem(attributedString0, "Category Plot", "ItemLabelAnchor.OUTSIDE3", "java.awt.Color[r=134,g=134,b=134]", shape4, paint26, stroke34, paint43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNull(stroke33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = null;
        try {
            timeSeriesCollection0.setXPosition(timePeriodAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart20.getTitle();
        java.lang.String str24 = textTitle23.getURLText();
        textTitle23.visible = true;
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot3.clearDomainAxes();
        boolean boolean8 = xYDataItem2.equals((java.lang.Object) combinedRangeXYPlot3);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            combinedRangeXYPlot3.addAnnotation(xYAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        boolean boolean2 = rotation0.equals((java.lang.Object) xYBarRenderer1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        boolean boolean5 = rotation0.equals((java.lang.Object) 0.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection10 = combinedRangeXYPlot6.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] { valueAxis11 };
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot6.setDomainTickBandPaint((java.awt.Paint) color14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!", paint17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem18.setLabelPaint(paint19);
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem18.setFillPaint(paint21);
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color14, paint21);
        boolean boolean24 = rotation0.equals((java.lang.Object) color14);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.DateRange dateRange0 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, (org.jfree.data.Range) dateRange1);
        double double4 = dateRange0.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', (int) ' ', 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        java.lang.Comparable comparable6 = null;
        try {
            int int7 = defaultPieDataset0.getIndex(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer0.setSeriesNegativeItemLabelPosition(15, itemLabelPosition5);
        xYBarRenderer0.setSeriesItemLabelsVisible((int) ' ', (java.lang.Boolean) false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.axis.NumberAxis numberAxis2 = null;
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis2, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedRangeXYPlot9.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        combinedRangeXYPlot9.setDomainAxes(valueAxisArray15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot9.setDomainTickBandPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", paint20);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem21.setLabelPaint(paint22);
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem21.setFillPaint(paint24);
        boolean boolean26 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color17, paint24);
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("hi!", font7, (java.awt.Paint) color17);
        boolean boolean28 = org.jfree.chart.util.PaintUtilities.equal(paint0, (java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 13, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = combinedRangeXYPlot0.getDataRange(valueAxis18);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = combinedRangeXYPlot21.getDomainMarkers(6, layer26);
        combinedRangeXYPlot21.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation32 = combinedRangeXYPlot30.getRangeAxisLocation(0);
        java.awt.Paint paint33 = combinedRangeXYPlot30.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.util.List list36 = null;
        combinedRangeXYPlot30.drawDomainTickBands(graphics2D34, rectangle2D35, list36);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("hi!", paint42);
        legendItem43.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset46 = null;
        legendItem43.setDataset(dataset46);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer48 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = null;
        xYBarRenderer48.setSeriesURLGenerator(6, xYURLGenerator50);
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer48.setSeriesStroke((int) (byte) 100, stroke53);
        legendItem43.setOutlineStroke(stroke53);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color40, stroke53);
        org.jfree.chart.util.Layer layer57 = null;
        boolean boolean59 = combinedRangeXYPlot30.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker56, layer57, true);
        boolean boolean60 = combinedRangeXYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker56);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot61 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot61.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection65 = combinedRangeXYPlot61.getLegendItems();
        boolean boolean66 = valueMarker56.equals((java.lang.Object) legendItemCollection65);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent67 = null;
        valueMarker56.notifyListeners(markerChangeEvent67);
        org.jfree.chart.util.Layer layer69 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(6, (org.jfree.chart.plot.Marker) valueMarker56, layer69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(legendItemCollection65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 15, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        java.text.AttributedString attributedString5 = legendItem2.getAttributedLabel();
        legendItem2.setDescription("ItemLabelAnchor.OUTSIDE3");
        boolean boolean8 = legendItem2.isShapeOutlineVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        legendItem2.setOutlinePaint((java.awt.Paint) color9);
        java.lang.String str11 = legendItem2.getLabel();
        java.awt.Paint paint12 = null;
        try {
            legendItem2.setOutlinePaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = null;
        java.util.Date date2 = null;
        try {
            boolean boolean3 = segmentedTimeline0.containsDomainRange(date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange2);
        double double5 = dateRange1.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange6, (org.jfree.data.Range) dateRange7);
        java.lang.Class<?> wildcardClass9 = dateRange7.getClass();
        org.jfree.data.Range range10 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange13, (org.jfree.data.Range) dateRange14);
        double double17 = dateRange13.constrain((double) 100.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) 13, (org.jfree.data.Range) dateRange1, lengthConstraintType11, (double) 0L, (org.jfree.data.Range) dateRange13, lengthConstraintType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'heightType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) 10, (double) (-1L), plotRenderingInfo11, point2D12);
        categoryPlot5.configureRangeAxes();
        boolean boolean15 = categoryPlot5.isRangePannable();
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        combinedRangeXYPlot0.clearRangeMarkers((int) '4');
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        boolean boolean7 = xYAreaRenderer6.getPlotShapes();
        xYAreaRenderer6.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint8 = xYBarRenderer7.getBasePaint();
        barRenderer4.setSeriesFillPaint(3, paint8, true);
        barRenderer4.setShadowVisible(false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState();
        java.util.List list2 = axisState1.getTicks();
        java.util.Collection collection3 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list2);
        try {
            org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds(xYDataset0, list2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(collection3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '#', (float) (byte) 100);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, (double) 86400000L, (float) (short) 100, (float) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) (byte) 10, 0.08d, (-135.0d), (double) 10, font5);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot12.getRangeAxisLocation(15);
        categoryPlot5.setRangeAxisLocation(axisLocation17, false);
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color21 = color20.darker();
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Paint paint23 = categoryPlot5.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot5.getDomainAxisLocation((int) '#');
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Shape shape1 = xYAreaRenderer0.getLegendArea();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        java.awt.Paint paint4 = combinedRangeXYPlot0.getDomainGridlinePaint();
        java.util.List list5 = combinedRangeXYPlot0.getSubplots();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        blockContainer1.clear();
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot0.clearDomainAxes();
        combinedRangeXYPlot0.setDomainMinorGridlinesVisible(false);
        combinedRangeXYPlot0.setRangeZeroBaselineVisible(true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        xYSeries3.setMaximumItemCount(9999);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = combinedRangeXYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(legendItemCollection8);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("ItemLabelAnchor.OUTSIDE3");
        basicProjectInfo0.setLicenceName("hi!");
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer0.setSeriesStroke((int) (byte) 100, stroke5);
        java.awt.Paint paint8 = xYBarRenderer0.lookupSeriesOutlinePaint((int) (byte) 1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = xYBarRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot3.clearDomainAxes();
        boolean boolean8 = xYDataItem2.equals((java.lang.Object) combinedRangeXYPlot3);
        double double9 = xYDataItem2.getXValue();
        boolean boolean10 = xYDataItem2.isSelected();
        double double11 = xYDataItem2.getYValue();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = combinedRangeXYPlot0.getAxisOffset();
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection16 = combinedRangeXYPlot12.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] { valueAxis17 };
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot12.setDomainTickBandPaint((java.awt.Paint) color20);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!", paint23);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem24.setLabelPaint(paint25);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem24.setFillPaint(paint27);
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color20, paint27);
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("hi!", font10, (java.awt.Paint) color20);
        java.awt.geom.Rectangle2D rectangle2D31 = labelBlock30.getBounds();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D31);
        rectangleInsets3.trim(rectangle2D31);
        double double35 = rectangleInsets3.trimWidth((double) 2);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-6.0d) + "'", double35 == (-6.0d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        java.awt.Paint paint7 = legendItem2.getOutlinePaint();
        java.awt.Shape shape8 = legendItem2.getLine();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot14.getDomainAxisEdge((int) (byte) 1);
        float float17 = categoryPlot14.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot14.setDataset(categoryDataset18);
        java.awt.Paint paint20 = categoryPlot14.getNoDataMessagePaint();
        legendItem2.setOutlinePaint(paint20);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int1 = defaultKeyedValues0.getItemCount();
        defaultKeyedValues0.addValue((java.lang.Comparable) (short) 0, (java.lang.Number) 1);
        java.lang.Number number7 = null;
        try {
            defaultKeyedValues0.insertValue(100, (java.lang.Comparable) 10L, number7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        java.lang.String str2 = basicProjectInfo0.getVersion();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        java.awt.Paint paint21 = jFreeChart20.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle23 = jFreeChart20.getLegend(0);
        java.awt.Font font24 = legendTitle23.getItemFont();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(legendTitle23);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange2);
        org.jfree.data.Range range4 = rectangleConstraint3.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint3.getHeightConstraintType();
        boolean boolean6 = gradientPaintTransformType0.equals((java.lang.Object) lengthConstraintType5);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, (double) 0.0f, (double) 13, (double) 3, (double) (short) 10, font10);
        legendTitle2.setItemFont(font10);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        legendTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder17);
        java.lang.String str19 = legendTitle2.getID();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.chart.plot.Plot plot12 = categoryPlot5.getRootPlot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        try {
            defaultPieDataset0.remove((java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (100.0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setVersion("VerticalAlignment.TOP");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot5.getFixedLegendItems();
        categoryPlot5.setRangeCrosshairValue(1.0E-8d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNull(legendItemCollection7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate22 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        try {
            double double25 = intervalXYDelegate22.getStartXValue((int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        java.awt.Font font8 = categoryAxis3D4.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedRangeXYPlot9.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        combinedRangeXYPlot9.setDomainAxes(valueAxisArray15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot9.setDomainTickBandPaint((java.awt.Paint) color17);
        java.awt.Stroke stroke19 = combinedRangeXYPlot9.getRangeCrosshairStroke();
        categoryAxis3D4.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot9);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        jFreeChart21.setNotify(true);
        java.util.List list24 = jFreeChart21.getSubtitles();
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState();
        java.util.List list26 = axisState25.getTicks();
        jFreeChart21.setSubtitles(list26);
        try {
            org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list26, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        java.lang.Comparable comparable5 = legendItem2.getSeriesKey();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        java.awt.Font font15 = categoryAxis3D11.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection20 = combinedRangeXYPlot16.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        combinedRangeXYPlot16.setDomainAxes(valueAxisArray22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot16.setDomainTickBandPaint((java.awt.Paint) color24);
        java.awt.Stroke stroke26 = combinedRangeXYPlot16.getRangeCrosshairStroke();
        categoryAxis3D11.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot16);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot16);
        java.awt.Paint paint29 = jFreeChart28.getBorderPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) (short) 1, 0.0d, paint29);
        legendItem2.setLinePaint(paint29);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        int int14 = categoryPlot5.getCrosshairDatasetIndex();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D(pieDataset16);
        piePlot3D17.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot20 = piePlot3D17.getRootPlot();
        java.awt.Paint paint21 = piePlot3D17.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator22 = piePlot3D17.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = null;
        java.awt.Font font30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis25, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font30);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot32.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection36 = combinedRangeXYPlot32.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { valueAxis37 };
        combinedRangeXYPlot32.setDomainAxes(valueAxisArray38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot32.setDomainTickBandPaint((java.awt.Paint) color40);
        java.awt.Paint paint43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", paint43);
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem44.setLabelPaint(paint45);
        java.awt.Paint paint47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem44.setFillPaint(paint47);
        boolean boolean49 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color40, paint47);
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("hi!", font30, (java.awt.Paint) color40);
        java.awt.geom.Rectangle2D rectangle2D51 = labelBlock50.getBounds();
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D51);
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D54 = new org.jfree.chart.plot.PiePlot3D(pieDataset53);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent55 = null;
        piePlot3D54.datasetChanged(datasetChangeEvent55);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot57 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke58 = combinedRangeXYPlot57.getRangeCrosshairStroke();
        java.awt.Paint paint59 = combinedRangeXYPlot57.getRangeCrosshairPaint();
        boolean boolean60 = piePlot3D54.equals((java.lang.Object) combinedRangeXYPlot57);
        piePlot3D54.setLabelLinkMargin((double) 15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo64);
        org.jfree.chart.plot.PiePlotState piePlotState66 = piePlot3D17.initialise(graphics2D23, rectangle2D51, (org.jfree.chart.plot.PiePlot) piePlot3D54, (java.lang.Integer) 0, plotRenderingInfo65);
        try {
            categoryPlot5.drawBackground(graphics2D15, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator22);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(legendItemCollection36);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(piePlotState66);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        xYAreaRenderer0.setSeriesItemLabelPaint((int) '4', (java.awt.Paint) color2, false);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double7 = rectangleInsets5.trimWidth(0.05d);
        double double9 = rectangleInsets5.trimHeight((double) 0.0f);
        double double11 = rectangleInsets5.calculateBottomInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-13.95d) + "'", double7 == (-13.95d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-135.0d) + "'", double9 == (-135.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.lang.Boolean boolean3 = barRenderer0.getSeriesVisible((int) (short) 0);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesCreateEntities(128);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            boolean boolean3 = timeSeriesCollection0.isSelected(100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle2.addChangeListener(titleChangeListener3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, (double) 0.0f, (double) 13, (double) 3, (double) (short) 10, font10);
        legendTitle2.setItemFont(font10);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        legendTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder17);
        double double19 = legendTitle2.getWidth();
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(6, layer5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace7, true);
        int int10 = combinedRangeXYPlot0.getSeriesCount();
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot2.getRangeAxisLocation(0);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot2);
        java.util.List list6 = combinedRangeXYPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        boolean boolean8 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        combinedRangeXYPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        boolean boolean8 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        combinedRangeXYPlot0.setDomainCrosshairValue(12.0d, false);
        java.awt.Paint paint12 = combinedRangeXYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        java.awt.Paint paint12 = barRenderer0.lookupSeriesPaint(5);
        barRenderer0.setShadowVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot5.setRangeAxis(valueAxis9);
        boolean boolean11 = categoryPlot5.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot5.getDomainAxis();
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categoryAxis12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator3);
        piePlot3D1.setPieIndex(1);
        java.lang.String str7 = piePlot3D1.getPlotType();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie 3D Plot" + "'", str7.equals("Pie 3D Plot"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Font font1 = null;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        java.text.AttributedString attributedString7 = legendItem4.getAttributedLabel();
        legendItem4.setDescription("ItemLabelAnchor.OUTSIDE3");
        boolean boolean10 = legendItem4.isShapeOutlineVisible();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        legendItem4.setOutlinePaint((java.awt.Paint) color11);
        try {
            org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("VerticalAlignment.TOP", font1, (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(attributedString7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double3 = categoryAxis3D2.getCategoryMargin();
        categoryAxis3D2.setLabelAngle((double) (byte) 100);
        java.awt.Paint paint6 = categoryAxis3D2.getTickMarkPaint();
        boolean boolean7 = gradientPaintTransformType0.equals((java.lang.Object) categoryAxis3D2);
        boolean boolean8 = categoryAxis3D2.isVisible();
        int int9 = categoryAxis3D2.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        int int3 = combinedRangeXYPlot0.getRangeAxisIndex(valueAxis2);
        boolean boolean4 = combinedRangeXYPlot0.isDomainZeroBaselineVisible();
        boolean boolean5 = combinedRangeXYPlot0.canSelectByPoint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getCeilingTickUnit((double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            xYBarRenderer0.addAnnotation(xYAnnotation4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = xYBarRenderer0.getSeriesToolTipGenerator(10);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D(pieDataset7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot3D8.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke12 = combinedRangeXYPlot11.getRangeCrosshairStroke();
        java.awt.Paint paint13 = combinedRangeXYPlot11.getRangeCrosshairPaint();
        boolean boolean14 = piePlot3D8.equals((java.lang.Object) combinedRangeXYPlot11);
        piePlot3D8.setLabelLinkMargin((double) 15);
        java.awt.Paint paint17 = piePlot3D8.getBaseSectionOutlinePaint();
        xYBarRenderer0.setLegendTextPaint((int) (short) 10, paint17);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYToolTipGenerator5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = ' ';
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        java.lang.Boolean boolean5 = xYBarRenderer0.getSeriesItemLabelsVisible((int) (byte) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYBarRenderer0.getLegendItems();
        xYBarRenderer0.setShadowYOffset(0.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart20.createBufferedImage((-1), 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (9999) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Pie 3D Plot");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        try {
            numberAxis1.setRangeAboutValue((double) 15, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (15.5) <= upper (14.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        try {
            timeSeriesCollection0.addSeries(timeSeries1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        categoryAxis3D9.setMinorTickMarkInsideLength((float) (short) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Pie 3D Plot");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection4 = combinedRangeXYPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] { valueAxis5 };
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot0.setDomainTickBandPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke10 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        boolean boolean11 = combinedRangeXYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedRangeXYPlot12.getRangeAxisLocation(0);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        java.lang.String str22 = categoryPlot21.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot21.getRangeAxisLocation(9999);
        combinedRangeXYPlot12.setDomainAxisLocation((int) ' ', axisLocation24);
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation24, false);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = xYBarRenderer0.getSeriesToolTipGenerator(10);
        java.awt.Paint paint6 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setUseYInterval(false);
        xYBarRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYToolTipGenerator5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate22 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        java.lang.Comparable comparable23 = null;
        int int24 = defaultXYDataset19.indexOf(comparable23);
        try {
            java.lang.Number number27 = defaultXYDataset19.getX(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D1.getLegendLabelGenerator();
        double double5 = piePlot3D1.getMaximumLabelWidth();
        java.awt.Paint paint7 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) "item");
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.14d + "'", double5 == 0.14d);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D(pieDataset3);
        piePlot3D4.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot7 = piePlot3D4.getRootPlot();
        java.awt.Paint paint8 = piePlot3D4.getBaseSectionPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot3D4.getLegendLabelGenerator();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = null;
        java.awt.Font font17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis12, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot19.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection23 = combinedRangeXYPlot19.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] { valueAxis24 };
        combinedRangeXYPlot19.setDomainAxes(valueAxisArray25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot19.setDomainTickBandPaint((java.awt.Paint) color27);
        java.awt.Paint paint30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", paint30);
        java.awt.Paint paint32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem31.setLabelPaint(paint32);
        java.awt.Paint paint34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem31.setFillPaint(paint34);
        boolean boolean36 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color27, paint34);
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("hi!", font17, (java.awt.Paint) color27);
        java.awt.geom.Rectangle2D rectangle2D38 = labelBlock37.getBounds();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D38);
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D41 = new org.jfree.chart.plot.PiePlot3D(pieDataset40);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent42 = null;
        piePlot3D41.datasetChanged(datasetChangeEvent42);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot44 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke45 = combinedRangeXYPlot44.getRangeCrosshairStroke();
        java.awt.Paint paint46 = combinedRangeXYPlot44.getRangeCrosshairPaint();
        boolean boolean47 = piePlot3D41.equals((java.lang.Object) combinedRangeXYPlot44);
        piePlot3D41.setLabelLinkMargin((double) 15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo51);
        org.jfree.chart.plot.PiePlotState piePlotState53 = piePlot3D4.initialise(graphics2D10, rectangle2D38, (org.jfree.chart.plot.PiePlot) piePlot3D41, (java.lang.Integer) 0, plotRenderingInfo52);
        org.jfree.data.time.DateRange dateRange54 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange55 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange54, (org.jfree.data.Range) dateRange55);
        double double58 = dateRange54.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange59 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange60 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange59, (org.jfree.data.Range) dateRange60);
        java.lang.Class<?> wildcardClass62 = dateRange60.getClass();
        org.jfree.data.Range range63 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange54, (org.jfree.data.Range) dateRange60);
        try {
            java.lang.Object obj64 = labelBlock1.draw(graphics2D2, rectangle2D38, (java.lang.Object) dateRange60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plot7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(valueAxisArray25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(piePlotState53);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(range63);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace4, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedRangeXYPlot7.getDomainMarkers(6, layer12);
        combinedRangeXYPlot7.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot1.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        java.awt.Image image17 = null;
        combinedRangeXYPlot1.setBackgroundImage(image17);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset20);
        boolean boolean22 = lengthAdjustmentType0.equals((java.lang.Object) (byte) 1);
        java.lang.String str23 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "NO_CHANGE" + "'", str23.equals("NO_CHANGE"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("VerticalAlignment.TOP", "-0.0");
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot9.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation14 = combinedRangeXYPlot9.getRangeAxisLocation();
        combinedRangeXYPlot0.setDomainAxisLocation(5, axisLocation14);
        java.lang.Object obj16 = combinedRangeXYPlot0.clone();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot4 = piePlot3D1.getRootPlot();
        org.jfree.chart.util.UnitType unitType5 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean6 = piePlot3D1.equals((java.lang.Object) unitType5);
        double double7 = piePlot3D1.getShadowYOffset();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint10 = xYBarRenderer9.getBasePaint();
        piePlot3D1.setSectionOutlinePaint((java.lang.Comparable) 2, paint10);
        piePlot3D1.setShadowXOffset((-6.0d));
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "VerticalAlignment.TOP", "hi!", "ItemLabelAnchor.OUTSIDE3", "");
        java.lang.String str6 = basicProjectInfo5.getName();
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo5.getLibraries();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ThreadContext" + "'", str6.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setLabelPaint(paint3);
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem2.setFillPaint(paint5);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D7 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = barRenderer3D7.getGradientPaintTransformer();
        legendItem2.setFillPaintTransformer(gradientPaintTransformer8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Paint paint3 = combinedRangeXYPlot0.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.util.List list6 = null;
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D4, rectangle2D5, list6);
        java.awt.Paint paint8 = null;
        try {
            combinedRangeXYPlot0.setRangeGridlinePaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.awt.Paint paint2 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = combinedRangeXYPlot0.getAxisOffset();
        java.awt.Paint paint4 = combinedRangeXYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        piePlot3D1.setLabelLinksVisible(false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        combinedRangeXYPlot3.setFixedRangeAxisSpace(axisSpace6, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = combinedRangeXYPlot9.getDomainMarkers(6, layer14);
        combinedRangeXYPlot9.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot3.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        java.awt.Image image19 = null;
        combinedRangeXYPlot3.setBackgroundImage(image19);
        int int21 = xYDataItem2.compareTo((java.lang.Object) image19);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator5 = new org.jfree.chart.urls.StandardXYURLGenerator("hi!", "ItemLabelAnchor.OUTSIDE3", "ItemLabelAnchor.OUTSIDE3");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator5);
        xYAreaRenderer6.setAutoPopulateSeriesPaint(false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            boolean boolean9 = categoryPlot5.removeAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        boolean boolean15 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke3 = combinedRangeXYPlot2.getRangeCrosshairStroke();
        java.awt.Paint paint4 = combinedRangeXYPlot2.getRangeCrosshairPaint();
        boolean boolean5 = defaultPieDataset0.hasListener((java.util.EventListener) combinedRangeXYPlot2);
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot((org.jfree.data.general.PieDataset) defaultPieDataset0);
        float float7 = ringPlot6.getForegroundAlpha();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint10 = xYBarRenderer9.getBasePaint();
        xYBarRenderer9.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = xYBarRenderer9.getSeriesToolTipGenerator(10);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D16 = new org.jfree.chart.plot.PiePlot3D(pieDataset15);
        piePlot3D16.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = piePlot3D16.getLegendLabelGenerator();
        double double20 = piePlot3D16.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = null;
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis23, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font28);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection34 = combinedRangeXYPlot30.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { valueAxis35 };
        combinedRangeXYPlot30.setDomainAxes(valueAxisArray36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot30.setDomainTickBandPaint((java.awt.Paint) color38);
        java.awt.Paint paint41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", paint41);
        java.awt.Paint paint43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem42.setLabelPaint(paint43);
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem42.setFillPaint(paint45);
        boolean boolean47 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color38, paint45);
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("hi!", font28, (java.awt.Paint) color38);
        java.awt.geom.Rectangle2D rectangle2D49 = labelBlock48.getBounds();
        piePlot3D16.drawBackgroundImage(graphics2D21, rectangle2D49);
        xYBarRenderer9.setBaseShape((java.awt.Shape) rectangle2D49, false);
        org.jfree.data.general.PieDataset pieDataset53 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D54 = new org.jfree.chart.plot.PiePlot3D(pieDataset53);
        org.jfree.chart.title.LegendTitle legendTitle55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D54);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator56 = null;
        piePlot3D54.setLegendLabelURLGenerator(pieURLGenerator56);
        piePlot3D54.setPieIndex(1);
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D63 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer65 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D63, valueAxis64, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer65);
        java.lang.String str67 = categoryPlot66.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation69 = categoryPlot66.getRangeAxisLocation(9999);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo72 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo72);
        java.awt.geom.Point2D point2D74 = null;
        categoryPlot66.zoomRangeAxes((double) 100.0f, (double) 900000L, plotRenderingInfo73, point2D74);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState76 = ringPlot6.initialise(graphics2D8, rectangle2D49, (org.jfree.chart.plot.PiePlot) piePlot3D54, (java.lang.Integer) 0, plotRenderingInfo73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(xYToolTipGenerator14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.14d + "'", double20 == 0.14d);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Category Plot" + "'", str67.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation69);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("SerialDate.weekInMonthToString(): invalid code.");
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            double double8 = defaultXYDataset0.getYValue((int) (byte) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator4 = null;
        xYBarRenderer2.setSeriesURLGenerator(6, xYURLGenerator4);
        java.lang.Object obj6 = xYBarRenderer2.clone();
        java.awt.Stroke stroke8 = xYBarRenderer2.getSeriesOutlineStroke((int) (short) 0);
        boolean boolean9 = standardGradientPaintTransformer1.equals((java.lang.Object) xYBarRenderer2);
        xYBarRenderer2.setBaseSeriesVisibleInLegend(false, false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!", paint19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem20.setLabelPaint(paint21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem20.setFillPaint(paint23);
        boolean boolean25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color16, paint23);
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("hi!", font6, (java.awt.Paint) color16);
        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D29 = new org.jfree.chart.plot.PiePlot3D(pieDataset28);
        piePlot3D29.setDarkerSides(true);
        org.jfree.chart.plot.Plot plot32 = piePlot3D29.getRootPlot();
        boolean boolean33 = labelBlock26.equals((java.lang.Object) piePlot3D29);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer35 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint36 = xYBarRenderer35.getBasePaint();
        xYBarRenderer35.setShadowXOffset((double) 4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator40 = xYBarRenderer35.getSeriesToolTipGenerator(10);
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D42 = new org.jfree.chart.plot.PiePlot3D(pieDataset41);
        piePlot3D42.setDarkerSides(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator45 = piePlot3D42.getLegendLabelGenerator();
        double double46 = piePlot3D42.getMaximumLabelWidth();
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.axis.NumberAxis numberAxis49 = null;
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand55 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis49, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font54);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Paint paint67 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("hi!", paint67);
        java.awt.Paint paint69 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem68.setLabelPaint(paint69);
        java.awt.Paint paint71 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem68.setFillPaint(paint71);
        boolean boolean73 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color64, paint71);
        org.jfree.chart.block.LabelBlock labelBlock74 = new org.jfree.chart.block.LabelBlock("hi!", font54, (java.awt.Paint) color64);
        java.awt.geom.Rectangle2D rectangle2D75 = labelBlock74.getBounds();
        piePlot3D42.drawBackgroundImage(graphics2D47, rectangle2D75);
        xYBarRenderer35.setBaseShape((java.awt.Shape) rectangle2D75, false);
        try {
            labelBlock26.draw(graphics2D34, rectangle2D75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(plot32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(xYToolTipGenerator40);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.14d + "'", double46 == 0.14d);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(rectangle2D75);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        timeSeriesCollection0.removeAllSeries();
        try {
            int[] intArray4 = timeSeriesCollection0.getSurroundingItems((int) (byte) 100, (long) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.lang.String str7 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot6.removeDomainMarker(marker8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot6.getAxisOffset();
        boolean boolean11 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot6.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray6, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray12);
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset13);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 900000.0d + "'", number14.equals(900000.0d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot0.clearDomainAxes();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker(marker5, layer6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace8, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = combinedRangeXYPlot0.getSeriesRenderingOrder();
        java.lang.String str12 = seriesRenderingOrder11.toString();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(seriesRenderingOrder11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str12.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            java.lang.Number number3 = timeSeriesCollection0.getStartX(3, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        boolean boolean3 = categoryAxis3D1.isTickLabelsVisible();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        piePlot3D5.setDarkerSides(true);
        piePlot3D5.setBackgroundImageAlignment((int) (byte) 10);
        piePlot3D5.setSectionOutlinesVisible(true);
        java.awt.Font font12 = piePlot3D5.getNoDataMessageFont();
        categoryAxis3D1.setTickLabelFont(font12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.awt.Font font7 = categoryAxis3D3.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection12 = combinedRangeXYPlot8.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { valueAxis13 };
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot8.setDomainTickBandPaint((java.awt.Paint) color16);
        java.awt.Stroke stroke18 = combinedRangeXYPlot8.getRangeCrosshairStroke();
        categoryAxis3D3.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot8);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot8);
        jFreeChart20.setNotify(true);
        java.util.List list23 = jFreeChart20.getSubtitles();
        org.jfree.chart.event.ChartChangeListener chartChangeListener24 = null;
        try {
            jFreeChart20.addChangeListener(chartChangeListener24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        java.lang.Object obj76 = categoryAxis3D30.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(obj76);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = xYSeries3.getKey();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem8 = xYSeries3.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (byte) 10 + "'", comparable6.equals((byte) 10));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        java.awt.Stroke stroke79 = barRenderer3D72.getItemStroke((int) (short) 100, 15, true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(stroke79);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat(0.0d, "TextBlockAnchor.TOP_RIGHT", "ItemLabelAnchor.OUTSIDE3", false);
        java.text.NumberFormat numberFormat5 = logFormat4.getExponentFormat();
        numberFormat5.setMinimumIntegerDigits(15);
        numberFormat5.setParseIntegerOnly(false);
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D13 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        java.lang.String str17 = categoryPlot16.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot16.getRangeAxisLocation(9999);
        categoryPlot5.setRangeAxisLocation(10, axisLocation19, false);
        categoryPlot5.setCrosshairDatasetIndex((int) (byte) 100, false);
        java.util.List list25 = categoryPlot5.getCategories();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryPlot5.getAxisOffset();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Category Plot" + "'", str17.equals("Category Plot"));
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(list25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 15, "ThreadContext", textAnchor2, textAnchor3, (double) (short) 1);
        java.lang.Number number6 = numberTick5.getNumber();
        org.jfree.chart.axis.TickType tickType7 = numberTick5.getTickType();
        java.lang.Object obj8 = numberTick5.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 15 + "'", number6.equals(15));
        org.junit.Assert.assertNotNull(tickType7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.renderer.RendererUtilities rendererUtilities1 = new org.jfree.chart.renderer.RendererUtilities();
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) rendererUtilities1);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        java.awt.Stroke stroke3 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Object obj1 = strokeMap0.clone();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = combinedRangeXYPlot3.getRangeAxisLocation(0);
        java.awt.Paint paint6 = combinedRangeXYPlot3.getRangeGridlinePaint();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.util.List list9 = null;
        combinedRangeXYPlot3.drawDomainTickBands(graphics2D7, rectangle2D8, list9);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!", paint15);
        legendItem16.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset19 = null;
        legendItem16.setDataset(dataset19);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer21 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = null;
        xYBarRenderer21.setSeriesURLGenerator(6, xYURLGenerator23);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer21.setSeriesStroke((int) (byte) 100, stroke26);
        legendItem16.setOutlineStroke(stroke26);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color13, stroke26);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean32 = combinedRangeXYPlot3.removeRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker29, layer30, true);
        java.awt.Stroke stroke33 = combinedRangeXYPlot3.getDomainMinorGridlineStroke();
        strokeMap0.put((java.lang.Comparable) true, stroke33);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot5.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot5.setDataset(categoryDataset11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot5.getRenderer();
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(categoryItemRenderer13);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset0 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0, true);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) defaultXYDataset0);
        try {
            double double8 = defaultXYDataset0.getYValue(3, 1964);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 0L, (float) '4', (double) (byte) 100, (float) 100L, 0.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState();
        java.util.List list10 = axisState9.getTicks();
        java.util.Collection collection11 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list10);
        try {
            categoryPlot5.mapDatasetToRangeAxes((int) (byte) 1, list10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        java.awt.Paint paint9 = categoryPlot5.getRangeZeroBaselinePaint();
        int int10 = categoryPlot5.getDomainAxisCount();
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1, (double) 100.0f, (double) 13);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        double double19 = rectangleInsets17.trimWidth(0.05d);
        double double21 = rectangleInsets17.trimHeight((double) 0.0f);
        categoryAxis3D9.setLabelInsets(rectangleInsets17);
        java.lang.String str23 = categoryAxis3D9.getLabel();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-13.95d) + "'", double19 == (-13.95d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-135.0d) + "'", double21 == (-135.0d));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.lang.Object obj1 = timeSeriesCollection0.clone();
        try {
            java.lang.Number number4 = timeSeriesCollection0.getStartX((int) (byte) 0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot5.getAxisOffset();
        double double10 = rectangleInsets9.getTop();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        boolean boolean3 = categoryAxis3D1.isTickLabelsVisible();
        java.lang.String str4 = categoryAxis3D1.getLabelToolTip();
        java.awt.Font font5 = categoryAxis3D1.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.Marker marker7 = null;
        boolean boolean8 = categoryPlot5.removeDomainMarker(marker7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot5.setRangeMinorGridlineStroke(stroke9);
        categoryPlot5.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot12.getRangeAxisLocation(15);
        categoryPlot5.setRangeAxisLocation(axisLocation17, false);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace20, false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate22 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        java.lang.Comparable comparable23 = null;
        int int24 = defaultXYDataset19.indexOf(comparable23);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        boolean boolean3 = categoryAxis3D1.isTickLabelsVisible();
        float float4 = categoryAxis3D1.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot3D6.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getRangeCrosshairStroke();
        java.awt.Paint paint11 = combinedRangeXYPlot9.getRangeCrosshairPaint();
        boolean boolean12 = piePlot3D6.equals((java.lang.Object) combinedRangeXYPlot9);
        piePlot3D6.setLabelLinkMargin((double) 15);
        java.awt.Paint paint15 = piePlot3D6.getBaseSectionOutlinePaint();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D6);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator17 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        boolean boolean18 = piePlot3D6.equals((java.lang.Object) standardPieToolTipGenerator17);
        java.lang.String str19 = standardPieToolTipGenerator17.getLabelFormat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{0}: ({1}, {2})" + "'", str19.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        double double11 = barRenderer0.getShadowYOffset();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D15 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        java.lang.String str19 = categoryPlot18.getPlotType();
        org.jfree.chart.plot.Marker marker20 = null;
        boolean boolean21 = categoryPlot18.removeDomainMarker(marker20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot18.setRangeMinorGridlineStroke(stroke22);
        categoryPlot18.clearRangeAxes();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation30 = combinedRangeXYPlot25.getRangeAxisLocation(15);
        categoryPlot18.setRangeAxisLocation(axisLocation30, false);
        java.awt.Color color33 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color34 = color33.darker();
        categoryPlot18.setBackgroundPaint((java.awt.Paint) color34);
        java.awt.Paint paint36 = categoryPlot18.getRangeZeroBaselinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer42 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer42);
        java.awt.Font font44 = categoryAxis3D40.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot45.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection49 = combinedRangeXYPlot45.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray51 = new org.jfree.chart.axis.ValueAxis[] { valueAxis50 };
        combinedRangeXYPlot45.setDomainAxes(valueAxisArray51);
        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot45.setDomainTickBandPaint((java.awt.Paint) color53);
        java.awt.Stroke stroke55 = combinedRangeXYPlot45.getRangeCrosshairStroke();
        categoryAxis3D40.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot45);
        org.jfree.chart.JFreeChart jFreeChart57 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot45);
        jFreeChart57.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle60 = jFreeChart57.getTitle();
        java.awt.Paint paint61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle60.setPaint(paint61);
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle60.getBounds();
        try {
            barRenderer0.drawBackground(graphics2D12, categoryPlot18, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Category Plot" + "'", str19.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(legendItemCollection49);
        org.junit.Assert.assertNotNull(valueAxisArray51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(textTitle60);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(rectangle2D63);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = combinedRangeXYPlot0.getDataRange(valueAxis18);
        java.awt.Paint paint20 = combinedRangeXYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!", paint1);
        legendItem2.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset5 = null;
        legendItem2.setDataset(dataset5);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer7 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = null;
        xYBarRenderer7.setSeriesURLGenerator(6, xYURLGenerator9);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer7.setSeriesStroke((int) (byte) 100, stroke12);
        legendItem2.setOutlineStroke(stroke12);
        java.io.ObjectOutputStream objectOutputStream15 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke12, objectOutputStream15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, true);
        java.awt.Paint paint14 = categoryPlot5.getRangeGridlinePaint();
        categoryPlot5.setRangeCrosshairValue((double) (byte) 0, true);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace9, true);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.data.Range range7 = barRenderer4.findRangeBounds(categoryDataset6);
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color9 = color8.darker();
        barRenderer4.setBaseItemLabelPaint((java.awt.Paint) color9, false);
        double double12 = barRenderer4.getMinimumBarLength();
        barRenderer4.setSeriesItemLabelsVisible((int) '4', true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) (byte) 10, false, true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = xYSeries3.getKey();
        double double7 = xYSeries3.getMaxY();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (byte) 10 + "'", comparable6.equals((byte) 10));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.awt.Font font6 = categoryAxis3D2.getTickLabelFont();
        categoryAxis3D2.setMaximumCategoryLabelLines((int) (byte) 100);
        double double9 = categoryAxis3D2.getLabelAngle();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(false);
        blockParams0.setTranslateY((double) 0.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "VerticalAlignment.TOP", "hi!", "ItemLabelAnchor.OUTSIDE3", "");
        java.lang.String str6 = basicProjectInfo5.getName();
        java.lang.String str7 = basicProjectInfo5.getInfo();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ThreadContext" + "'", str6.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange1, (org.jfree.data.Range) dateRange2);
        org.jfree.data.Range range4 = rectangleConstraint3.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint3.getHeightConstraintType();
        boolean boolean6 = strokeMap0.equals((java.lang.Object) rectangleConstraint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.axis.TickUnits tickUnits1 = new org.jfree.chart.axis.TickUnits();
        int int2 = tickUnits1.size();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        boolean boolean4 = tickUnits1.equals((java.lang.Object) shape3);
        boolean boolean5 = defaultDrawingSupplier0.equals((java.lang.Object) boolean4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = combinedRangeXYPlot1.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        combinedRangeXYPlot1.setFixedRangeAxisSpace(axisSpace4, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedRangeXYPlot7.getDomainMarkers(6, layer12);
        combinedRangeXYPlot7.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot1.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot7);
        java.awt.Image image17 = null;
        combinedRangeXYPlot1.setBackgroundImage(image17);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot1.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset20);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate23 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset20, true);
        java.lang.Comparable comparable24 = null;
        int int25 = defaultXYDataset20.indexOf(comparable24);
        try {
            java.lang.String str28 = standardXYToolTipGenerator0.generateToolTip((org.jfree.data.xy.XYDataset) defaultXYDataset20, 2, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        java.lang.Object obj4 = xYBarRenderer0.clone();
        java.awt.Stroke stroke6 = xYBarRenderer0.getSeriesOutlineStroke((int) (short) 0);
        java.awt.Stroke stroke7 = xYBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator9 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
        xYBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator9);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange12 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange11, (org.jfree.data.Range) dateRange12);
        double double15 = dateRange11.constrain((double) 100.0f);
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange16, (org.jfree.data.Range) dateRange17);
        java.lang.Class<?> wildcardClass19 = dateRange17.getClass();
        org.jfree.data.Range range20 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange11, (org.jfree.data.Range) dateRange17);
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange();
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange21, (org.jfree.data.Range) dateRange22);
        boolean boolean24 = dateRange17.intersects((org.jfree.data.Range) dateRange21);
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange21);
        boolean boolean26 = standardXYSeriesLabelGenerator9.equals((java.lang.Object) dateRange21);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        java.awt.Paint paint3 = categoryAxis3D1.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        boolean boolean2 = numberAxis1.isInverted();
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D1);
        double double3 = piePlot3D1.getInteriorGap();
        double double5 = piePlot3D1.getExplodePercent((java.lang.Comparable) 10);
        java.awt.Font font6 = null;
        try {
            piePlot3D1.setLabelFont(font6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        java.lang.String str7 = categoryPlot6.getPlotType();
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = categoryPlot6.removeDomainMarker(marker8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot6.getAxisOffset();
        boolean boolean11 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot6);
        try {
            categoryPlot6.zoom((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        boolean boolean15 = barRenderer0.isDrawBarOutline();
        boolean boolean19 = barRenderer0.isItemLabelVisible((int) (byte) -1, 0, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D4 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getDomainAxisEdge((int) (byte) 1);
        float float10 = categoryPlot7.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot7.setDataset(categoryDataset11);
        java.awt.Paint paint13 = categoryPlot7.getNoDataMessagePaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot7.panDomainAxes((double) (byte) 100, plotRenderingInfo16, point2D17);
        int int19 = objectList1.indexOf((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer0.getItemLabelGenerator((-1), 0, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = barRenderer0.getSeriesToolTipGenerator((int) (byte) 100);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!", paint25);
        legendItem26.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset29 = null;
        legendItem26.setDataset(dataset29);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator33 = null;
        xYBarRenderer31.setSeriesURLGenerator(6, xYURLGenerator33);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer31.setSeriesStroke((int) (byte) 100, stroke36);
        legendItem26.setOutlineStroke(stroke36);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color23, stroke36);
        barRenderer0.setSeriesStroke(5, stroke36);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation41 = null;
        boolean boolean42 = barRenderer0.removeAnnotation(categoryAnnotation41);
        int int43 = barRenderer0.getRowCount();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator44 = barRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNull(categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator44);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.LEFT" + "'", str1.equals("HorizontalAlignment.LEFT"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        boolean boolean15 = barRenderer0.isDrawBarOutline();
        boolean boolean19 = barRenderer0.isItemLabelVisible((int) (byte) -1, 0, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = barRenderer0.getSeriesToolTipGenerator(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        int int25 = polarPlot24.getSeriesCount();
        try {
            polarPlot24.zoom((double) 86400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.NumberAxis numberAxis3 = null;
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis3, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection14 = combinedRangeXYPlot10.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { valueAxis15 };
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot10.setDomainTickBandPaint((java.awt.Paint) color18);
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", paint21);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem22.setLabelPaint(paint23);
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem22.setFillPaint(paint25);
        boolean boolean27 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color18, paint25);
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("hi!", font8, (java.awt.Paint) color18);
        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock28.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis30 = null;
        java.awt.Font font35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis30, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font35);
        labelBlock28.setFont(font35);
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("-0.0", font35);
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("", font35);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection29 = combinedRangeXYPlot25.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { valueAxis30 };
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot25.setDomainTickBandPaint((java.awt.Paint) color33);
        java.awt.Stroke stroke35 = combinedRangeXYPlot25.getRangeCrosshairStroke();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        combinedRangeXYPlot25.setRangeCrosshairStroke(stroke36);
        polarPlot24.setRadiusGridlineStroke(stroke36);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        polarPlot24.setRenderer(polarItemRenderer39);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot5.getDomainMarkers(layer6);
        boolean boolean8 = categoryPlot5.isSubplot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        categoryPlot5.notifyListeners(plotChangeEvent9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot5.getRangeAxis();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            java.lang.Comparable comparable2 = timeSeriesCollection0.getSeriesKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter7 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 1.0f, (double) 0.0f, (double) (short) -1);
        xYBarRenderer0.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = xYBarRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(drawingSupplier9);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, plot2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = null;
        waferMapPlot0.rendererChanged(rendererChangeEvent1);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset3 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset3);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke6 = combinedRangeXYPlot5.getRangeCrosshairStroke();
        java.awt.Paint paint7 = combinedRangeXYPlot5.getRangeCrosshairPaint();
        boolean boolean8 = defaultPieDataset3.hasListener((java.util.EventListener) combinedRangeXYPlot5);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection13 = combinedRangeXYPlot9.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] { valueAxis14 };
        combinedRangeXYPlot9.setDomainAxes(valueAxisArray15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot9.setDomainTickBandPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", paint20);
        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem21.setLabelPaint(paint22);
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem21.setFillPaint(paint24);
        boolean boolean26 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color17, paint24);
        boolean boolean27 = defaultPieDataset3.equals((java.lang.Object) paint24);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boolean27, true);
        java.lang.String str30 = rendererChangeEvent29.toString();
        waferMapPlot0.rendererChanged(rendererChangeEvent29);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=false]" + "'", str30.equals("org.jfree.chart.event.RendererChangeEvent[source=false]"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, 13);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "January 13" + "'", str3.equals("January 13"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61755710400001L) + "'", long5 == (-61755710400001L));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate22 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset19, true);
        java.lang.Object obj23 = intervalXYDelegate22.clone();
        java.lang.Object obj24 = intervalXYDelegate22.clone();
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) 1);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D3);
        org.jfree.chart.event.TitleChangeListener titleChangeListener5 = null;
        legendTitle4.addChangeListener(titleChangeListener5);
        org.jfree.chart.entity.TitleEntity titleEntity9 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle4, "Category Plot", "-0.0");
        java.lang.Number[] numberArray18 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (byte) 10, 900000L, (short) 10, 10L };
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] { numberArray18, numberArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Category Plot", "", numberArray24);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "HorizontalAlignment.CENTER", "January 13", categoryDataset25, (java.lang.Comparable) 6, (java.lang.Comparable) 100.0f);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double31 = categoryAxis3D30.getCategoryMargin();
        boolean boolean32 = categoryAxis3D30.isTickLabelsVisible();
        float float33 = categoryAxis3D30.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D35 = new org.jfree.chart.plot.PiePlot3D(pieDataset34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        piePlot3D35.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot38 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke39 = combinedRangeXYPlot38.getRangeCrosshairStroke();
        java.awt.Paint paint40 = combinedRangeXYPlot38.getRangeCrosshairPaint();
        boolean boolean41 = piePlot3D35.equals((java.lang.Object) combinedRangeXYPlot38);
        piePlot3D35.setLabelLinkMargin((double) 15);
        java.awt.Paint paint44 = piePlot3D35.getBaseSectionOutlinePaint();
        categoryAxis3D30.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D35);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        java.lang.String str52 = categoryPlot51.getPlotType();
        org.jfree.chart.plot.Marker marker53 = null;
        boolean boolean54 = categoryPlot51.removeDomainMarker(marker53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = categoryPlot51.getAxisOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection60 = combinedRangeXYPlot56.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { valueAxis61 };
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot56.setDomainTickBandPaint((java.awt.Paint) color64);
        java.awt.Stroke stroke66 = combinedRangeXYPlot56.getRangeCrosshairStroke();
        boolean boolean67 = rectangleInsets55.equals((java.lang.Object) stroke66);
        categoryAxis3D30.setLabelInsets(rectangleInsets55, false);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("Category Plot");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D72 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D72.setIncludeBaseInRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis71, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D72);
        boolean boolean76 = numberAxis71.isPositiveArrowVisible();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit77 = numberAxis71.getTickUnit();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Category Plot" + "'", str52.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertNotNull(legendItemCollection60);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(numberTickUnit77);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!", paint12);
        legendItem13.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset16 = null;
        legendItem13.setDataset(dataset16);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator20 = null;
        xYBarRenderer18.setSeriesURLGenerator(6, xYURLGenerator20);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYBarRenderer18.setSeriesStroke((int) (byte) 100, stroke23);
        legendItem13.setOutlineStroke(stroke23);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 100.0f, (java.awt.Paint) color10, stroke23);
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26, layer27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.LEFT;
        valueMarker26.setLabelAnchor(rectangleAnchor29);
        java.awt.Paint paint31 = valueMarker26.getPaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int33 = combinedRangeXYPlot32.getBackgroundImageAlignment();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        int int35 = combinedRangeXYPlot32.getRangeAxisIndex(valueAxis34);
        valueMarker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) combinedRangeXYPlot32);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 15 + "'", int33 == 15);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot5.setRangeAxis((int) (byte) 100, valueAxis7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot5.zoomDomainAxes((double) 10, (double) (-1L), plotRenderingInfo11, point2D12);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            categoryPlot5.addAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        categoryAxis3D2.setVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot8.getRangeAxisLocation(0);
        java.awt.Paint paint11 = combinedRangeXYPlot8.getRangeGridlinePaint();
        boolean boolean12 = categoryAxis3D2.hasListener((java.util.EventListener) combinedRangeXYPlot8);
        categoryAxis3D2.setTickMarksVisible(true);
        categoryAxis3D2.setFixedDimension((double) (byte) 10);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean((int) (short) 10);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getDomainAxisEdge((int) (byte) 1);
        float float8 = categoryPlot5.getBackgroundImageAlpha();
        categoryPlot5.setNoDataMessage("item");
        boolean boolean11 = categoryPlot5.isDomainCrosshairVisible();
        boolean boolean12 = categoryPlot5.isDomainPannable();
        java.awt.Paint paint13 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot5.setOutlinePaint(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) (-135.0d), (java.lang.Number) 100.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke1 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        java.util.List list2 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = combinedRangeXYPlot0.getFixedLegendItems();
        combinedRangeXYPlot0.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.awt.Font font12 = categoryAxis3D8.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection17 = combinedRangeXYPlot13.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { valueAxis18 };
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot13.setDomainTickBandPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot13.getRangeCrosshairStroke();
        categoryAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot13);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        java.awt.Paint paint26 = jFreeChart25.getBorderPaint();
        org.jfree.chart.title.LegendTitle legendTitle28 = jFreeChart25.getLegend(0);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent31 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) combinedRangeXYPlot0, jFreeChart25, 0, 1);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D(pieDataset32);
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3D33);
        org.jfree.chart.event.TitleChangeListener titleChangeListener35 = null;
        legendTitle34.addChangeListener(titleChangeListener35);
        org.jfree.chart.axis.NumberAxis numberAxis37 = null;
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand43 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis37, (double) 0.0f, (double) 13, (double) 3, (double) (short) 10, font42);
        legendTitle34.setItemFont(font42);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent45 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle34);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = titleChangeEvent45.getType();
        jFreeChart25.titleChanged(titleChangeEvent45);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(legendTitle28);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        java.awt.Paint paint1 = xYBarRenderer0.getBasePaint();
        xYBarRenderer0.setAutoPopulateSeriesShape(true);
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter7 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((double) 1.0f, (double) 0.0f, (double) (short) -1);
        xYBarRenderer0.setBarPainter((org.jfree.chart.renderer.xy.XYBarPainter) gradientXYBarPainter7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        xYBarRenderer10.setSeriesURLGenerator(6, xYURLGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        xYBarRenderer10.setSeriesNegativeItemLabelPosition(15, itemLabelPosition15);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYBarRenderer10.setBaseToolTipGenerator(xYToolTipGenerator17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke23 = combinedRangeXYPlot22.getRangeCrosshairStroke();
        java.awt.Paint paint24 = combinedRangeXYPlot22.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = combinedRangeXYPlot22.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer31);
        java.awt.Font font33 = categoryAxis3D29.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot34 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot34.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection38 = combinedRangeXYPlot34.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { valueAxis39 };
        combinedRangeXYPlot34.setDomainAxes(valueAxisArray40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot34.setDomainTickBandPaint((java.awt.Paint) color42);
        java.awt.Stroke stroke44 = combinedRangeXYPlot34.getRangeCrosshairStroke();
        categoryAxis3D29.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot34);
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot34);
        jFreeChart46.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle49 = jFreeChart46.getTitle();
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle49.setPaint(paint50);
        java.awt.geom.Rectangle2D rectangle2D52 = textTitle49.getBounds();
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets25.createInsetRectangle(rectangle2D52, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge56);
        try {
            gradientXYBarPainter7.paintBar(graphics2D9, xYBarRenderer10, (int) (short) 0, 2, true, (java.awt.geom.RectangularShape) rectangle2D52, rectangleEdge56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(legendItemCollection38);
        org.junit.Assert.assertNotNull(valueAxisArray40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(textTitle49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        xYBarRenderer0.setSeriesURLGenerator(6, xYURLGenerator2);
        xYBarRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        org.jfree.data.xy.XYDataItem xYDataItem9 = new org.jfree.data.xy.XYDataItem((double) (short) 1, 0.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        combinedRangeXYPlot10.clearDomainAxes();
        boolean boolean15 = xYDataItem9.equals((java.lang.Object) combinedRangeXYPlot10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = combinedRangeXYPlot16.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        combinedRangeXYPlot16.setFixedRangeAxisSpace(axisSpace19, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot22.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = combinedRangeXYPlot22.getDomainMarkers(6, layer27);
        combinedRangeXYPlot22.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot16.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot22);
        java.awt.Image image32 = null;
        combinedRangeXYPlot16.setBackgroundImage(image32);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset35 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot16.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset35);
        int int37 = combinedRangeXYPlot10.indexOf((org.jfree.data.xy.XYDataset) defaultXYDataset35);
        xYBarRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean2 = barRenderer3D0.equals((java.lang.Object) 10.0f);
        java.awt.Paint paint3 = barRenderer3D0.getBaseFillPaint();
        java.awt.Paint paint5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        barRenderer3D0.setSeriesItemLabelPaint(0, paint5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer3D0.getSeriesNegativeItemLabelPosition(12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        java.lang.String str2 = serialDate1.getDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, 0.0d, 100.0f, (float) 'a');
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        java.awt.Font font12 = categoryAxis3D8.getTickLabelFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection17 = combinedRangeXYPlot13.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] { valueAxis18 };
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot13.setDomainTickBandPaint((java.awt.Paint) color21);
        java.awt.Stroke stroke23 = combinedRangeXYPlot13.getRangeCrosshairStroke();
        categoryAxis3D8.addChangeListener((org.jfree.chart.event.AxisChangeListener) combinedRangeXYPlot13);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("DomainOrder.ASCENDING", (org.jfree.chart.plot.Plot) combinedRangeXYPlot13);
        jFreeChart25.setNotify(true);
        org.jfree.chart.title.TextTitle textTitle28 = jFreeChart25.getTitle();
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        textTitle28.setPaint(paint29);
        org.jfree.chart.entity.TitleEntity titleEntity32 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) textTitle28, "January 13");
        java.lang.String str33 = titleEntity32.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(textTitle28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TitleEntity: tooltip = January 13" + "'", str33.equals("TitleEntity: tooltip = January 13"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((-6.0d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        java.lang.String str6 = categoryPlot5.getPlotType();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double10 = categoryAxis3D9.getCategoryMargin();
        categoryPlot5.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.jfree.chart.axis.NumberAxis numberAxis13 = null;
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis13, 0.0d, (double) 10L, (double) 100.0f, (double) 100, font18);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection24 = combinedRangeXYPlot20.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        combinedRangeXYPlot20.setDomainAxes(valueAxisArray26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        combinedRangeXYPlot20.setDomainTickBandPaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", paint31);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem32.setLabelPaint(paint33);
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        legendItem32.setFillPaint(paint35);
        boolean boolean37 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color28, paint35);
        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("hi!", font18, (java.awt.Paint) color28);
        categoryAxis3D9.setAxisLinePaint((java.awt.Paint) color28);
        java.awt.Stroke stroke40 = categoryAxis3D9.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        boolean boolean3 = categoryAxis3D1.isTickLabelsVisible();
        float float4 = categoryAxis3D1.getTickMarkInsideLength();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D(pieDataset5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        piePlot3D6.datasetChanged(datasetChangeEvent7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Stroke stroke10 = combinedRangeXYPlot9.getRangeCrosshairStroke();
        java.awt.Paint paint11 = combinedRangeXYPlot9.getRangeCrosshairPaint();
        boolean boolean12 = piePlot3D6.equals((java.lang.Object) combinedRangeXYPlot9);
        piePlot3D6.setLabelLinkMargin((double) 15);
        java.awt.Paint paint15 = piePlot3D6.getBaseSectionOutlinePaint();
        categoryAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) piePlot3D6);
        categoryAxis3D1.addCategoryLabelToolTip((java.lang.Comparable) ' ', "");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment2 = segmentedTimeline0.getSegment(date1);
//        boolean boolean5 = segment2.contains(10L, (long) (short) 1);
//        long long6 = segment2.getSegmentEnd();
//        segment2.dec();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(segment2);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560458699999L + "'", long6 == 1560458699999L);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        java.awt.Paint paint25 = polarPlot24.getAngleGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        polarPlot24.zoomDomainAxes((double) 12, (double) 0, plotRenderingInfo28, point2D29);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Paint paint3 = piePlot3D1.getSectionOutlinePaint((java.lang.Comparable) 100.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        java.awt.Paint paint8 = combinedRangeXYPlot4.getDomainGridlinePaint();
        piePlot3D1.setNoDataMessagePaint(paint8);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        boolean boolean2 = piePlot3D1.getAutoPopulateSectionPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMinimumBarLength();
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!", paint3);
        legendItem4.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset7 = null;
        legendItem4.setDataset(dataset7);
        java.awt.Paint paint9 = legendItem4.getOutlinePaint();
        barRenderer0.setShadowPaint(paint9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getItemLabelGenerator(2, 9999, true);
        java.lang.Boolean boolean16 = barRenderer0.getSeriesItemLabelsVisible((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDarkerSides(true);
        piePlot3D1.setBackgroundImageAlignment((int) (byte) 10);
        piePlot3D1.setSectionOutlinesVisible(true);
        java.awt.Paint paint8 = piePlot3D1.getLabelLinkPaint();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        piePlot3D1.setBaseSectionPaint(paint9);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = combinedRangeXYPlot0.getRangeAxisLocation(0);
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace3, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.mapDatasetToRangeAxis((int) (short) 1, (int) '4');
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = combinedRangeXYPlot6.getDomainMarkers(6, layer11);
        combinedRangeXYPlot6.setDomainCrosshairLockedOnData(false);
        combinedRangeXYPlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot6);
        java.awt.Image image16 = null;
        combinedRangeXYPlot0.setBackgroundImage(image16);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset19 = new org.jfree.data.xy.DefaultXYDataset();
        combinedRangeXYPlot0.setDataset((int) (byte) 1, (org.jfree.data.xy.XYDataset) defaultXYDataset19);
        int int21 = defaultXYDataset19.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset19, valueAxis22, polarItemRenderer23);
        java.awt.Paint paint25 = polarPlot24.getAngleGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer30);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.data.Range range33 = barRenderer30.findRangeBounds(categoryDataset32);
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color35 = color34.darker();
        barRenderer30.setBaseItemLabelPaint((java.awt.Paint) color35, false);
        polarPlot24.setRadiusGridlinePaint((java.awt.Paint) color35);
        org.junit.Assert.assertNotNull(axisLocation2);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        double double2 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setLabelAngle((double) (byte) 100);
        double double5 = categoryAxis3D1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }
}

