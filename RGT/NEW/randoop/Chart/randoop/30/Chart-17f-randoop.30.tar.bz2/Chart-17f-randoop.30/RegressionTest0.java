import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 1, (java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 10.0d + "'", obj2.equals(10.0d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "First" + "'", str1.equals("First"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate10 = null;
        try {
            boolean boolean11 = spreadsheetDate4.isOnOrBefore(serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate1.getFollowingDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate2.getPreviousDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, (int) 'a', 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate5.getFollowingDayOfWeek((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(3, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "March" + "'", str2.equals("March"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        java.util.Calendar calendar9 = null;
        try {
            day3.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate8 = null;
        try {
            org.jfree.data.time.SerialDate serialDate9 = serialDate5.getEndOfCurrentMonth(serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate5);
        java.lang.String str8 = spreadsheetDate2.getDescription();
        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) false, (java.lang.Object) str8);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("March");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date10 = day9.getEnd();
        boolean boolean11 = spreadsheetDate2.equals((java.lang.Object) date10);
        java.util.TimeZone timeZone12 = null;
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.Class<?> wildcardClass4 = day3.getClass();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Calendar calendar4 = null;
        try {
            day3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long23 = fixedMillisecond22.getMiddleMillisecond();
        try {
            timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 1560442536792L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int6 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate2.getFollowingDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate5 = null;
        try {
            int int6 = spreadsheetDate1.compare(serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        timeSeriesDataItem8.setValue((java.lang.Number) 10.0d);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date6 = fixedMillisecond5.getTime();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone7);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date6, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0, 2019, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = null;
//        try {
//            timeSeries1.add(timeSeriesDataItem24, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442538981L + "'", long4 == 1560442538981L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, 6);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day17.getLastMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100, (int) (byte) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        int int6 = day3.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, 6);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(35L);
        try {
            int int20 = spreadsheetDate8.compareTo((java.lang.Object) 35L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        try {
            org.jfree.data.time.SerialDate serialDate16 = serialDate14.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries20.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0, 100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        try {
//            timeSeries1.delete((int) (byte) 10, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442541501L + "'", long4 == 1560442541501L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        try {
            timeSeries20.update(2, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        timeSeries20.clear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date25 = spreadsheetDate24.toDate();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.next();
        try {
            timeSeries20.update(regularTimePeriod27, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass33 = seriesChangeEvent32.getClass();
        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date37 = spreadsheetDate36.toDate();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        java.util.Date date39 = day38.getEnd();
        java.util.TimeZone timeZone40 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod27, "hi!", "", (java.lang.Class) wildcardClass33);
        try {
            org.jfree.data.time.TimeSeries timeSeries43 = timeSeries20.createCopy(regularTimePeriod21, regularTimePeriod27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNull(uRL34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        java.lang.Object obj9 = null;
        boolean boolean10 = day3.equals(obj9);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(8, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "August" + "'", str2.equals("August"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getFollowingDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        long long8 = year6.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1900L + "'", long8 == 1900L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        timeSeries20.setRangeDescription("First");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries20.getDataItem(regularTimePeriod25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        long long10 = month7.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 22801L + "'", long10 == 22801L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries1.setKey((java.lang.Comparable) 100.0f);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries1.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getTimePeriod(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442543109L + "'", long4 == 1560442543109L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.util.Date date11 = day10.getEnd();
        boolean boolean12 = spreadsheetDate3.equals((java.lang.Object) date11);
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Saturday" + "'", str1.equals("Saturday"));
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setNotify(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries1.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date30 = spreadsheetDate29.toDate();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
//        long long34 = day31.getSerialIndex();
//        long long35 = day31.getSerialIndex();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 0, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 9-January-1900 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442543768L + "'", long4 == 1560442543768L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int4 = day3.getDayOfMonth();
        int int6 = day3.compareTo((java.lang.Object) 22801L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries1.setKey((java.lang.Comparable) 100.0f);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        java.util.Collection collection28 = timeSeries1.getTimePeriods();
//        try {
//            java.util.Collection collection29 = org.jfree.chart.util.ObjectUtilities.deepClone(collection28);
//            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
//        } catch (java.lang.CloneNotSupportedException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442544035L + "'", long6 == 1560442544035L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(collection28);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        timeSeries20.clear();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond25.getEnd();
//        int int29 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        try {
//            timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1560442537682L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560442544071L + "'", long27 == 1560442544071L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
//        try {
//            timeSeries1.add(regularTimePeriod28, (double) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442544615L + "'", long6 == 1560442544615L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        timeSeries20.clear();
        try {
            timeSeries20.setMaximumItemCount((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999, 13, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date9);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries10.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int6 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SerialDate serialDate7 = null;
        try {
            boolean boolean8 = spreadsheetDate2.isOn(serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.next();
//        java.lang.String str7 = regularTimePeriod6.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442546125L + "'", long2 == 1560442546125L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442546125L + "'", long5 == 1560442546125L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Thu Jun 13 09:15:46 PDT 2019" + "'", str7.equals("Thu Jun 13 09:15:46 PDT 2019"));
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setNotify(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries1.addChangeListener(seriesChangeListener26);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = null;
//        try {
//            timeSeries1.add(regularTimePeriod30, (double) (-1L));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442546219L + "'", long4 == 1560442546219L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int4 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-2208182400001L) + "'", long5 == (-2208182400001L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        java.util.Calendar calendar11 = null;
        try {
            month10.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date9 = day8.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass15 = seriesChangeEvent14.getClass();
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date19 = spreadsheetDate18.toDate();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.util.Date date21 = day20.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date9, timeZone22);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month24.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '#', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
        try {
            int int26 = timeSeries20.getIndex(regularTimePeriod25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        int int15 = spreadsheetDate1.compareTo((java.lang.Object) serialDate14);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-90) + "'", int15 == (-90));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        java.lang.Class class23 = timeSeries20.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(class23);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        timeSeries20.setRangeDescription("First");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date27 = spreadsheetDate26.toDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
        long long31 = day28.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeriesDataItem33.getPeriod();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean37 = timeSeriesDataItem33.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date40 = spreadsheetDate39.toDate();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.lang.String str42 = spreadsheetDate39.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date47 = spreadsheetDate46.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean52 = spreadsheetDate46.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean54 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate44, (org.jfree.data.time.SerialDate) spreadsheetDate46, 6);
        int int55 = timeSeriesDataItem33.compareTo((java.lang.Object) 6);
        try {
            timeSeries20.add(timeSeriesDataItem33, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str5 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, 6);
        try {
            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((-457), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(4);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        try {
//            org.jfree.data.time.SerialDate serialDate6 = serialDate4.getPreviousDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442547939L + "'", long2 == 1560442547939L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date14 = spreadsheetDate13.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate9.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        spreadsheetDate1.setDescription("");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        java.util.Calendar calendar8 = null;
        try {
            year6.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean23 = timeSeries20.equals((java.lang.Object) 1560442537682L);
        timeSeries20.clear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date27 = spreadsheetDate26.toDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        int int29 = day28.getDayOfMonth();
        try {
            timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day28, (double) 1560442547147L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) -1, year6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(11);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date10 = day9.getEnd();
        boolean boolean11 = spreadsheetDate2.equals((java.lang.Object) date10);
        int int12 = spreadsheetDate2.getDayOfMonth();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        long long9 = day3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean8 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNull(uRL6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (-459), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        timeSeries20.clear();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries20.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate5);
        int int8 = spreadsheetDate2.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) 'a', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate8);
//        boolean boolean10 = spreadsheetDate5.equals((java.lang.Object) spreadsheetDate8);
//        spreadsheetDate8.setDescription("");
//        java.util.Date date13 = spreadsheetDate8.toDate();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) serialDate14);
//        long long16 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442550673L + "'", long2 == 1560442550673L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560442550673L + "'", long16 == 1560442550673L);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        boolean boolean24 = timeSeries1.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, 0.0d);
//        try {
//            timeSeries1.add(timeSeriesDataItem28);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442550727L + "'", long4 == 1560442550727L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date26);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        java.util.Date date28 = day27.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 1, year29);
        long long31 = year29.getSerialIndex();
        int int32 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date36 = spreadsheetDate35.toDate();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        java.util.Date date38 = day37.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month((int) (short) 1, year39);
        int int41 = year39.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year39.previous();
        try {
            timeSeries20.add(regularTimePeriod42, (double) 1560442537573L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1900L + "'", long31 == 1900L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1900 + "'", int41 == 1900);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
        timeSeries20.setDescription("January 1900");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries24);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond25.getFirstMillisecond(calendar29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond25.getFirstMillisecond(calendar31);
//        java.lang.Number number33 = null;
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number33);
//        java.lang.Class class35 = timeSeries1.getTimePeriodClass();
//        boolean boolean36 = timeSeries1.isEmpty();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442551367L + "'", long4 == 1560442551367L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        int int6 = day3.getDayOfMonth();
        java.lang.String str7 = day3.toString();
        int int8 = day3.getDayOfMonth();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day3.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        long long6 = day3.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getEnd();
//        int int15 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date20 = spreadsheetDate19.toDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
//        long long24 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean30 = timeSeriesDataItem26.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem26.getPeriod();
//        timeSeries10.add(timeSeriesDataItem26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long35 = fixedMillisecond34.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond34.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.previous();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond34.getFirstMillisecond(calendar38);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond34.getFirstMillisecond(calendar40);
//        java.lang.Number number42 = null;
//        timeSeries10.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, number42);
//        int int44 = timeSeriesDataItem8.compareTo((java.lang.Object) number42);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442552171L + "'", long13 == 1560442552171L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setNotify(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries1.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries1.getNextTimePeriod();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442552496L + "'", long4 == 1560442552496L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Thu Jun 13 09:15:46 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getFirstMillisecond();
        java.lang.String[] strArray8 = org.jfree.data.time.SerialDate.getMonths(true);
        boolean boolean9 = year5.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208960000000L) + "'", long6 == (-2208960000000L));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        timeSeriesDataItem8.setValue((java.lang.Number) 1560442536737L);
        java.lang.Number number12 = timeSeriesDataItem8.getValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1560442536737L + "'", number12.equals(1560442536737L));
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442553692L + "'", long3 == 1560442553692L);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        java.lang.String str22 = timeSeries20.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond23.getEnd();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond23.getLastMillisecond(calendar27);
//        long long29 = fixedMillisecond23.getSerialIndex();
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        long long31 = timeSeries20.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442554532L + "'", long25 == 1560442554532L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560442554532L + "'", long28 == 1560442554532L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560442554532L + "'", long29 == 1560442554532L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.util.Date date11 = day10.getEnd();
        boolean boolean12 = spreadsheetDate3.equals((java.lang.Object) date11);
        try {
            org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-90), (org.jfree.data.time.SerialDate) spreadsheetDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int2 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        int int21 = timeSeries20.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries22 = null;
        try {
            java.util.Collection collection23 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setNotify(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries1.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date29 = fixedMillisecond28.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, 0.0d);
//        try {
//            timeSeries1.add(timeSeriesDataItem31, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442554774L + "'", long4 == 1560442554774L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date29);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries20.createCopy((int) (short) 10, 2019);
        timeSeries20.setMaximumItemAge((long) (short) 100);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, 6);
        int int17 = spreadsheetDate6.getDayOfMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        long long4 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442555404L + "'", long3 == 1560442555404L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442555404L + "'", long4 == 1560442555404L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day3.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getFirstMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442556194L + "'", long3 == 1560442556194L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442556194L + "'", long5 == 1560442556194L);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date10 = day9.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(inputStream5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(uRL13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("January 1900");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.lang.String str9 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date14 = spreadsheetDate13.toDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(0, serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate19.equals((java.lang.Object) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date27 = spreadsheetDate26.toDate();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean29 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate30 = serialDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean31 = spreadsheetDate4.isOn(serialDate17);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "9-January-1900" + "'", str9.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getLastMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond2.getEnd();
//        java.lang.Class<?> wildcardClass8 = fixedMillisecond2.getClass();
//        java.io.InputStream inputStream9 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("First", (java.lang.Class) wildcardClass8);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', (java.lang.Class) wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442556715L + "'", long4 == 1560442556715L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442556715L + "'", long6 == 1560442556715L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNull(inputStream9);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate5);
        spreadsheetDate5.setDescription("");
        java.util.Date date10 = spreadsheetDate5.toDate();
        boolean boolean11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1560442551367L, (java.lang.Object) spreadsheetDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.lang.Object obj7 = timeSeries1.clone();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener8);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442558371L + "'", long4 == 1560442558371L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(obj7);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("Last", (java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNull(uRL6);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        java.lang.String str22 = timeSeries20.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond23.getEnd();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond23.getLastMillisecond(calendar27);
//        long long29 = fixedMillisecond23.getSerialIndex();
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries20.getTimePeriod((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442558670L + "'", long25 == 1560442558670L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560442558670L + "'", long28 == 1560442558670L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560442558670L + "'", long29 == 1560442558670L);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SerialDate serialDate2 = null;
        try {
            boolean boolean3 = spreadsheetDate1.isOn(serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.next();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Thu Jun 13 09:15:58 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date11 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate6.equals((java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate1.isInRange(serialDate18, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        try {
            org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate20.getNearestDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = timeSeriesDataItem8.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem8.getPeriod();
        java.lang.String str15 = regularTimePeriod14.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-January-1900" + "'", str15.equals("9-January-1900"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        timeSeriesDataItem8.setValue((java.lang.Number) 1560442536737L);
        java.lang.Class<?> wildcardClass12 = timeSeriesDataItem8.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem8.getPeriod();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        java.util.Date date43 = fixedMillisecond35.getEnd();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442559496L + "'", long4 == 1560442559496L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442559515L + "'", long37 == 1560442559515L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442559515L + "'", long40 == 1560442559515L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertNotNull(date43);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        long long7 = day3.getSerialIndex();
        long long8 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208182400001L) + "'", long8 == (-2208182400001L));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Calendar calendar8 = null;
        try {
            year5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
        org.junit.Assert.assertNull(regularTimePeriod7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=10.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=10.0]"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getNearestDayOfWeek((int) (short) 1);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '4', serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("March");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        long long11 = month10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month10.next();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month10.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2206281600001L) + "'", long11 == (-2206281600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean23 = timeSeries20.equals((java.lang.Object) 1560442537682L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.getDataItem(regularTimePeriod28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        java.util.Date date35 = day34.getEnd();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month((int) (short) 1, year36);
        org.jfree.data.time.Year year38 = month37.getYear();
        long long39 = month37.getFirstMillisecond();
        org.jfree.data.time.Year year40 = month37.getYear();
        try {
            timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) 1560442534034L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(year38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208960000000L) + "'", long39 == (-2208960000000L));
        org.junit.Assert.assertNotNull(year40);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.setDomainDescription("hi!");
//        timeSeries1.removeAgedItems(true);
//        int int47 = timeSeries1.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442561155L + "'", long4 == 1560442561155L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442561161L + "'", long37 == 1560442561161L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442561161L + "'", long40 == 1560442561161L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2147483647 + "'", int47 == 2147483647);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        boolean boolean24 = timeSeries1.isEmpty();
//        timeSeries1.setMaximumItemAge(0L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date29 = spreadsheetDate28.toDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.next();
//        long long33 = day30.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) (byte) 100);
//        int int36 = day30.getMonth();
//        int int37 = day30.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day30);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442561726L + "'", long4 == 1560442561726L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem38);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        boolean boolean25 = timeSeries1.equals((java.lang.Object) 1560442548077L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442565180L + "'", long4 == 1560442565180L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2177424000001L) + "'", long7 == (-2177424000001L));
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        boolean boolean28 = timeSeries1.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date32 = spreadsheetDate31.toDate();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        java.util.Date date34 = day33.getEnd();
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date34);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month((int) (short) 1, year35);
//        org.jfree.data.time.Year year37 = month36.getYear();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year37, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442565295L + "'", long6 == 1560442565295L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(year37);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        int int2 = day0.getYear();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate4.equals((java.lang.Object) spreadsheetDate8);
        boolean boolean16 = day0.equals((java.lang.Object) spreadsheetDate8);
        int int17 = day0.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        int int10 = spreadsheetDate4.toSerial();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Thu Jun 13 09:15:46 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        int int8 = year6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        long long10 = year6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208960000000L) + "'", long10 == (-2208960000000L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.equals((java.lang.Object) spreadsheetDate8);
        spreadsheetDate8.setDescription("");
        java.util.Date date13 = spreadsheetDate8.toDate();
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date17 = spreadsheetDate16.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean22 = spreadsheetDate16.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, serialDate26);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        try {
//            java.lang.Number number10 = timeSeries1.getValue((-90));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442569247L + "'", long4 == 1560442569247L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
        try {
            org.jfree.data.time.TimeSeries timeSeries27 = timeSeries20.createCopy((int) (short) -1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        timeSeriesDataItem8.setValue((java.lang.Number) 1560442536737L);
        java.lang.Class<?> wildcardClass12 = timeSeriesDataItem8.getClass();
        java.lang.Number number13 = timeSeriesDataItem8.getValue();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        java.lang.String str18 = spreadsheetDate15.getDescription();
        int int19 = spreadsheetDate15.getDayOfWeek();
        boolean boolean20 = timeSeriesDataItem8.equals((java.lang.Object) spreadsheetDate15);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1560442536737L + "'", number13.equals(1560442536737L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        int int8 = year6.getYear();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate9.equals((java.lang.Object) spreadsheetDate12);
        spreadsheetDate12.setDescription("");
        java.util.Date date17 = spreadsheetDate12.toDate();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        boolean boolean19 = month7.equals((java.lang.Object) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month7.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        long long9 = day3.getSerialIndex();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day3.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries28.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.next();
//        long long42 = day39.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean48 = timeSeriesDataItem44.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem44.getPeriod();
//        timeSeries28.add(timeSeriesDataItem44);
//        timeSeries26.add(timeSeriesDataItem44, false);
//        java.util.Collection collection53 = timeSeries26.getTimePeriods();
//        boolean boolean54 = timeSeries26.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date57 = spreadsheetDate56.toDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
//        java.net.URL uRL67 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        java.util.Date date72 = day71.getEnd();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod60, "hi!", "", (java.lang.Class) wildcardClass66);
//        java.lang.String str76 = timeSeries75.getDomainDescription();
//        java.lang.String str77 = timeSeries75.getRangeDescription();
//        boolean boolean78 = timeSeries26.equals((java.lang.Object) timeSeries75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries24.addAndOrUpdate(timeSeries75);
//        try {
//            timeSeries75.removeAgedItems(0L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442574254L + "'", long31 == 1560442574254L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(uRL67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
        timeSeries1.setKey((java.lang.Comparable) 100.0f);
        try {
            java.lang.Number number5 = timeSeries1.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        boolean boolean28 = timeSeries1.isEmpty();
//        java.lang.String str29 = timeSeries1.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442574369L + "'", long6 == 1560442574369L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Value" + "'", str29.equals("Value"));
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        java.lang.Object obj7 = null;
        boolean boolean8 = spreadsheetDate4.equals(obj7);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        boolean boolean11 = spreadsheetDate4.equals((java.lang.Object) 1560442549638L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date6 = spreadsheetDate5.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean11 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        boolean boolean12 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean28 = spreadsheetDate23.equals((java.lang.Object) spreadsheetDate26);
        java.lang.String str29 = spreadsheetDate23.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date37 = spreadsheetDate36.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean43 = spreadsheetDate32.equals((java.lang.Object) spreadsheetDate36);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date47 = spreadsheetDate46.toDate();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
        boolean boolean49 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, serialDate48);
        boolean boolean50 = spreadsheetDate18.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        java.util.Date date51 = spreadsheetDate18.toDate();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "March" + "'", str1.equals("March"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.util.Date date14 = day13.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date26 = day25.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date14, timeZone27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date4, timeZone27);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = month30.getLastMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(inputStream21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setNotify(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries1.addChangeListener(seriesChangeListener26);
//        timeSeries1.setMaximumItemAge(1560442569575L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442575356L + "'", long4 == 1560442575356L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date13 = spreadsheetDate12.toDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day3.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(inputStream10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        long long9 = month7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month7.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208960000000L) + "'", long9 == (-2208960000000L));
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setNotify(true);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries1.addChangeListener(seriesChangeListener26);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener28);
//        java.lang.String str30 = timeSeries1.getDomainDescription();
//        timeSeries1.setDomainDescription("hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
//        try {
//            timeSeries1.add(regularTimePeriod33, (java.lang.Number) 1560442550616L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442575765L + "'", long4 == 1560442575765L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        try {
            org.jfree.data.time.SerialDate serialDate12 = serialDate10.getPreviousDayOfWeek(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, 6);
        int int17 = spreadsheetDate1.getDayOfMonth();
        java.lang.Object obj18 = null;
        boolean boolean19 = spreadsheetDate1.equals(obj18);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9 + "'", int17 == 9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        long long9 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208182400001L) + "'", long9 == (-2208182400001L));
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond27.getEnd();
//        int int31 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long34 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.next();
//        int int36 = timeSeries26.getIndex(regularTimePeriod35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date39 = spreadsheetDate38.toDate();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day40.next();
//        long long43 = day40.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long46 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond45.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond45.previous();
//        int int49 = day40.compareTo((java.lang.Object) regularTimePeriod48);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date52 = spreadsheetDate51.toDate();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day53.next();
//        long long56 = day53.getSerialIndex();
//        long long57 = day53.getSerialIndex();
//        java.lang.String str58 = day53.toString();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries26.createCopy(regularTimePeriod48, (org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond60.getMiddleMillisecond(calendar61);
//        java.util.Date date63 = fixedMillisecond60.getEnd();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond60.getLastMillisecond(calendar64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond60.next();
//        java.lang.Number number67 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        java.util.Calendar calendar68 = null;
//        fixedMillisecond60.peg(calendar68);
//        long long70 = fixedMillisecond60.getFirstMillisecond();
//        int int71 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate76);
//        boolean boolean78 = spreadsheetDate73.equals((java.lang.Object) spreadsheetDate76);
//        spreadsheetDate76.setDescription("");
//        java.util.Date date81 = spreadsheetDate76.toDate();
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month(date81);
//        long long83 = month82.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = month82.next();
//        try {
//            timeSeries20.add((org.jfree.data.time.RegularTimePeriod) month82, (double) 2019, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560442576327L + "'", long29 == 1560442576327L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 35L + "'", long46 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-January-1900" + "'", str58.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560442576336L + "'", long62 == 1560442576336L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560442576336L + "'", long65 == 1560442576336L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNull(number67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560442576336L + "'", long70 == 1560442576336L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-2206281600001L) + "'", long83 == (-2206281600001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((-459), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener45);
//        timeSeries1.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442577020L + "'", long4 == 1560442577020L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442577039L + "'", long37 == 1560442577039L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442577039L + "'", long40 == 1560442577039L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        long long10 = month7.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2206281600001L) + "'", long10 == (-2206281600001L));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            day3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond0);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442577408L + "'", long3 == 1560442577408L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Saturday");
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean23 = timeSeries20.equals((java.lang.Object) 1560442537682L);
        java.lang.String str24 = timeSeries20.getRangeDescription();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate5);
        java.lang.String str8 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean22 = spreadsheetDate11.equals((java.lang.Object) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        boolean boolean28 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, serialDate27);
        try {
            org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long8 = fixedMillisecond7.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.next();
//        java.util.Date date10 = regularTimePeriod9.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass14 = seriesChangeEvent13.getClass();
//        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date18 = spreadsheetDate17.toDate();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        java.util.Date date20 = day19.getEnd();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date20, timeZone21);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass26 = seriesChangeEvent25.getClass();
//        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass26);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date30 = spreadsheetDate29.toDate();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        java.util.Date date32 = day31.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date20, timeZone33);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date10, timeZone33);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date5, timeZone33);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442578164L + "'", long2 == 1560442578164L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442578164L + "'", long4 == 1560442578164L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNull(uRL15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(inputStream27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        java.lang.Class<?> wildcardClass6 = fixedMillisecond0.getClass();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = fixedMillisecond0.equals(obj7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442578681L + "'", long2 == 1560442578681L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442578681L + "'", long4 == 1560442578681L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) 10);
        int int3 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.util.Date date14 = day13.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date26 = day25.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date14, timeZone27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date4, timeZone27);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = month30.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(inputStream21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        int int5 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate7.equals((java.lang.Object) spreadsheetDate10);
        spreadsheetDate10.setDescription("");
        java.lang.String str15 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date20 = spreadsheetDate19.toDate();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate23.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate19.equals((java.lang.Object) spreadsheetDate23);
        java.lang.String str31 = spreadsheetDate23.getDescription();
        boolean boolean32 = spreadsheetDate17.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean33 = spreadsheetDate10.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean34 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate10);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "9-January-1900" + "'", str15.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date9 = day8.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass15 = seriesChangeEvent14.getClass();
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date19 = spreadsheetDate18.toDate();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.util.Date date21 = day20.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date9, timeZone22);
        long long25 = month24.getLastMillisecond();
        long long26 = month24.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2206281600001L) + "'", long25 == (-2206281600001L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 22801L + "'", long26 == 22801L);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        long long6 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getEnd();
//        int int15 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date20 = spreadsheetDate19.toDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
//        long long24 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean30 = timeSeriesDataItem26.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem26.getPeriod();
//        timeSeries10.add(timeSeriesDataItem26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long35 = fixedMillisecond34.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond34.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond34.previous();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond34.getFirstMillisecond(calendar38);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond34.getFirstMillisecond(calendar40);
//        java.lang.Number number42 = null;
//        timeSeries10.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, number42);
//        java.lang.Class class44 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "9-January-1900", "", class44);
//        boolean boolean46 = timeSeries45.getNotify();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442579049L + "'", long2 == 1560442579049L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442579049L + "'", long5 == 1560442579049L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442579049L + "'", long6 == 1560442579049L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442579050L + "'", long13 == 1560442579050L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond27.getEnd();
//        int int31 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long34 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.next();
//        int int36 = timeSeries26.getIndex(regularTimePeriod35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date39 = spreadsheetDate38.toDate();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day40.next();
//        long long43 = day40.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long46 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond45.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond45.previous();
//        int int49 = day40.compareTo((java.lang.Object) regularTimePeriod48);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date52 = spreadsheetDate51.toDate();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day53.next();
//        long long56 = day53.getSerialIndex();
//        long long57 = day53.getSerialIndex();
//        java.lang.String str58 = day53.toString();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries26.createCopy(regularTimePeriod48, (org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond60.getMiddleMillisecond(calendar61);
//        java.util.Date date63 = fixedMillisecond60.getEnd();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond60.getLastMillisecond(calendar64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond60.next();
//        java.lang.Number number67 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        java.util.Calendar calendar68 = null;
//        fixedMillisecond60.peg(calendar68);
//        long long70 = fixedMillisecond60.getFirstMillisecond();
//        int int71 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        java.lang.Object obj72 = timeSeries20.clone();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560442579600L + "'", long29 == 1560442579600L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 35L + "'", long46 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-January-1900" + "'", str58.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560442579606L + "'", long62 == 1560442579606L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560442579606L + "'", long65 == 1560442579606L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNull(number67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560442579606L + "'", long70 == 1560442579606L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(obj72);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ThreadContext");
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.equals((java.lang.Object) spreadsheetDate8);
        spreadsheetDate8.setDescription("");
        java.util.Date date13 = spreadsheetDate8.toDate();
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int15 = spreadsheetDate2.toSerial();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.next();
        long long13 = day10.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (double) (byte) 100);
        int int16 = day10.getMonth();
        try {
            int int17 = spreadsheetDate1.compareTo((java.lang.Object) int16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        java.util.Calendar calendar9 = null;
        try {
            month7.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate4.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        java.lang.Class<?> wildcardClass10 = spreadsheetDate8.getClass();
        boolean boolean12 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, (org.jfree.data.time.SerialDate) spreadsheetDate8, (int) (byte) 10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, 11);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(5, (int) (byte) 10, (-90));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        java.util.Date date28 = day27.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 1, year29);
        long long31 = year29.getSerialIndex();
        int int32 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        java.util.Calendar calendar33 = null;
        try {
            long long34 = year29.getLastMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1900L + "'", long31 == 1900L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        java.lang.String str35 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond36.getMiddleMillisecond(calendar39);
//        java.util.Date date41 = fixedMillisecond36.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (short) 10);
//        java.lang.Number number44 = timeSeriesDataItem43.getValue();
//        try {
//            timeSeries1.add(timeSeriesDataItem43, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442581832L + "'", long4 == 1560442581832L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Value" + "'", str35.equals("Value"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560442581850L + "'", long38 == 1560442581850L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442581850L + "'", long40 == 1560442581850L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + number44 + "' != '" + (short) 10 + "'", number44.equals((short) 10));
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Value");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate4);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2147483647, 6, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("March");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date50 = spreadsheetDate49.toDate();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        java.util.Date date52 = day51.getEnd();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (short) 1, year53);
//        long long55 = year53.getSerialIndex();
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 1560442577427L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442582133L + "'", long4 == 1560442582133L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442582152L + "'", long37 == 1560442582152L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442582152L + "'", long40 == 1560442582152L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1900L + "'", long55 == 1900L);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str6 = spreadsheetDate3.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date11 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean18 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10, 6);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate10);
        try {
            org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays((-458), serialDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate19);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, (-458), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        int int8 = year5.compareTo((java.lang.Object) 1560442570677L);
        long long9 = year5.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2177424000001L) + "'", long9 == (-2177424000001L));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.equals((java.lang.Object) spreadsheetDate8);
        spreadsheetDate8.setDescription("");
        java.util.Date date13 = spreadsheetDate8.toDate();
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int15 = spreadsheetDate8.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = timeSeriesDataItem8.equals((java.lang.Object) (byte) 10);
        boolean boolean14 = timeSeriesDataItem8.equals((java.lang.Object) 1560442548071L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date37 = spreadsheetDate36.toDate();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day38.next();
//        long long41 = day38.getSerialIndex();
//        long long42 = day38.getSerialIndex();
//        java.lang.String str43 = day38.toString();
//        long long44 = day38.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day38.next();
//        java.lang.Number number46 = timeSeries1.getValue(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442585649L + "'", long4 == 1560442585649L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "9-January-1900" + "'", str43.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-2208268800000L) + "'", long44 == (-2208268800000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNull(number46);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        timeSeries20.clear();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond25.getEnd();
//        int int29 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        timeSeries24.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date34 = spreadsheetDate33.toDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day35.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day35.next();
//        long long38 = day35.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem40.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean44 = timeSeriesDataItem40.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem40.getPeriod();
//        timeSeries24.add(timeSeriesDataItem40);
//        boolean boolean47 = timeSeries24.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long50 = fixedMillisecond49.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond49.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond49.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries24.addOrUpdate(regularTimePeriod52, 0.0d);
//        try {
//            timeSeries20.add(timeSeriesDataItem54, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560442586130L + "'", long27 == 1560442586130L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 35L + "'", long50 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem54);
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries28.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.next();
//        long long42 = day39.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean48 = timeSeriesDataItem44.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem44.getPeriod();
//        timeSeries28.add(timeSeriesDataItem44);
//        timeSeries26.add(timeSeriesDataItem44, false);
//        java.util.Collection collection53 = timeSeries26.getTimePeriods();
//        boolean boolean54 = timeSeries26.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date57 = spreadsheetDate56.toDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
//        java.net.URL uRL67 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        java.util.Date date72 = day71.getEnd();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod60, "hi!", "", (java.lang.Class) wildcardClass66);
//        java.lang.String str76 = timeSeries75.getDomainDescription();
//        java.lang.String str77 = timeSeries75.getRangeDescription();
//        boolean boolean78 = timeSeries26.equals((java.lang.Object) timeSeries75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries24.addAndOrUpdate(timeSeries75);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar81 = null;
//        long long82 = fixedMillisecond80.getMiddleMillisecond(calendar81);
//        java.util.Date date83 = fixedMillisecond80.getEnd();
//        java.util.Calendar calendar84 = null;
//        long long85 = fixedMillisecond80.getLastMillisecond(calendar84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = fixedMillisecond80.next();
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80);
//        timeSeries24.setMaximumItemAge((long) 2147483647);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442586174L + "'", long31 == 1560442586174L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(uRL67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560442586184L + "'", long82 == 1560442586184L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560442586184L + "'", long85 == 1560442586184L);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond25.getFirstMillisecond(calendar29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond25.getFirstMillisecond(calendar31);
//        java.lang.Number number33 = null;
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number33);
//        java.util.Date date35 = fixedMillisecond25.getTime();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442587778L + "'", long4 == 1560442587778L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
//        org.junit.Assert.assertNotNull(date35);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date14 = spreadsheetDate13.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate9.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean28 = spreadsheetDate23.equals((java.lang.Object) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date31 = spreadsheetDate30.toDate();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean34 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SerialDate serialDate35 = null;
        try {
            boolean boolean36 = spreadsheetDate23.isOnOrBefore(serialDate35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass3);
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader5);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNotNull(classLoader5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Fourth" + "'", str1.equals("Fourth"));
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        long long6 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond2.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond11.getLastMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond11.getEnd();
//        java.lang.Class<?> wildcardClass17 = fixedMillisecond11.getClass();
//        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("First", (java.lang.Class) wildcardClass17);
//        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass17);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod7, (java.lang.Class) wildcardClass17);
//        int int23 = day0.compareTo((java.lang.Object) regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442588191L + "'", long4 == 1560442588191L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442588191L + "'", long6 == 1560442588191L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442588192L + "'", long13 == 1560442588192L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560442588192L + "'", long15 == 1560442588192L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNull(inputStream18);
//        org.junit.Assert.assertNotNull(inputStream19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(uRL21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date11 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate6.equals((java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean23 = spreadsheetDate1.isInRange(serialDate18, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
        boolean boolean28 = spreadsheetDate20.equals((java.lang.Object) timeSeriesDataItem27);
        java.lang.Number number29 = timeSeriesDataItem27.getValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0d + "'", number29.equals(0.0d));
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        java.lang.Class<?> wildcardClass6 = fixedMillisecond0.getClass();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getEnd();
//        int int15 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date20 = spreadsheetDate19.toDate();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
//        long long24 = day21.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean30 = timeSeriesDataItem26.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeriesDataItem26.getPeriod();
//        timeSeries10.add(timeSeriesDataItem26);
//        timeSeries8.add(timeSeriesDataItem26, false);
//        boolean boolean35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) wildcardClass6, (java.lang.Object) timeSeries8);
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timeSeries8.addPropertyChangeListener(propertyChangeListener36);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442588628L + "'", long2 == 1560442588628L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442588628L + "'", long4 == 1560442588628L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560442588629L + "'", long13 == 1560442588629L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        int int7 = day3.getMonth();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day3.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        int int2 = day0.getYear();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean23 = timeSeries20.equals((java.lang.Object) 1560442537682L);
        java.util.List list24 = timeSeries20.getItems();
        try {
            java.lang.Number number26 = timeSeries20.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.String str5 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate9.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean17 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9, 6);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) ' ', (org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int19 = spreadsheetDate9.getYYYY();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond1.getEnd();
//        java.lang.Class<?> wildcardClass7 = fixedMillisecond1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getEnd();
//        int int16 = timeSeries11.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        timeSeries11.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date21 = spreadsheetDate20.toDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day22.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeriesDataItem27.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean31 = timeSeriesDataItem27.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeriesDataItem27.getPeriod();
//        timeSeries11.add(timeSeriesDataItem27);
//        timeSeries9.add(timeSeriesDataItem27, false);
//        boolean boolean36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) wildcardClass7, (java.lang.Object) timeSeries9);
//        java.io.InputStream inputStream37 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Fourth", (java.lang.Class) wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560442589510L + "'", long3 == 1560442589510L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442589510L + "'", long5 == 1560442589510L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560442589515L + "'", long14 == 1560442589515L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNull(inputStream37);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.util.Date date14 = day13.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date26 = day25.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date14, timeZone27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date4, timeZone27);
        long long31 = month30.getFirstMillisecond();
        long long32 = month30.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(inputStream21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2649600000L) + "'", long31 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2649600000L) + "'", long32 == (-2649600000L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day3.previous();
        java.lang.String str8 = day3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442540821L);
        timeSeries1.setDomainDescription("ERROR : Relative To String");
        timeSeries1.removeAgedItems(false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        timeSeries20.removeAgedItems(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries20.removeChangeListener(seriesChangeListener23);
        timeSeries20.setNotify(true);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date13 = spreadsheetDate12.toDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, (java.lang.Class) wildcardClass15);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(inputStream10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442540821L);
        timeSeries1.setDomainDescription("ERROR : Relative To String");
        timeSeries1.setRangeDescription("9-January-1900");
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Thu Jun 13 09:15:58 PDT 2019");
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass5 = seriesChangeEvent4.getClass();
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.Class<?> wildcardClass11 = day10.getClass();
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass22 = seriesChangeEvent21.getClass();
        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        java.lang.Class<?> wildcardClass28 = day27.getClass();
        java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass22, (java.lang.Class) wildcardClass28);
        java.net.URL uRL30 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Last", (java.lang.Class) wildcardClass28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass34 = seriesChangeEvent33.getClass();
        java.net.URL uRL35 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date38 = spreadsheetDate37.toDate();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
        java.util.Date date40 = day39.getEnd();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date40, timeZone41);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass46 = seriesChangeEvent45.getClass();
        java.io.InputStream inputStream47 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date50 = spreadsheetDate49.toDate();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate49);
        java.util.Date date52 = day51.getEnd();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date52, timeZone53);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date40, timeZone53);
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date40, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar61 = null;
        long long62 = fixedMillisecond60.getMiddleMillisecond(calendar61);
        java.util.Date date63 = fixedMillisecond60.getStart();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date63);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass68 = seriesChangeEvent67.getClass();
        java.net.URL uRL69 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass68);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date72 = spreadsheetDate71.toDate();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate71);
        java.util.Date date74 = day73.getEnd();
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date74, timeZone75);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent79 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass80 = seriesChangeEvent79.getClass();
        java.io.InputStream inputStream81 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass80);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date84 = spreadsheetDate83.toDate();
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate83);
        java.util.Date date86 = day85.getEnd();
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass80, date86, timeZone87);
        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month(date74, timeZone87);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date63, timeZone87);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.createInstance(date63);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(inputStream6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(inputStream23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNull(uRL30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNull(uRL35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(inputStream47);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 35L + "'", long62 == 35L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertNull(uRL69);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(inputStream81);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(serialDate91);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        java.util.Collection collection28 = timeSeries1.getTimePeriods();
//        boolean boolean29 = timeSeries1.isEmpty();
//        java.lang.Class<?> wildcardClass30 = timeSeries1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) 100);
//        long long33 = fixedMillisecond32.getFirstMillisecond();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 1560442569855L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442593674L + "'", long6 == 1560442593674L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 100L + "'", long33 == 100L);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) (-1.0f));
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560442593705L + "'", long1 == 1560442593705L);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate9.equals((java.lang.Object) spreadsheetDate12);
        spreadsheetDate12.setDescription("");
        java.util.Date date17 = spreadsheetDate12.toDate();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        boolean boolean19 = month7.equals((java.lang.Object) month18);
        long long20 = month18.getSerialIndex();
        int int21 = month18.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 22801L + "'", long20 == 22801L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1900 + "'", int21 == 1900);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        int int8 = year6.getYear();
        long long9 = year6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208960000000L) + "'", long9 == (-2208960000000L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-459));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        boolean boolean24 = timeSeries1.isEmpty();
//        timeSeries1.setMaximumItemAge(0L);
//        timeSeries1.removeAgedItems(1560442556773L, false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442593853L + "'", long4 == 1560442593853L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int4 = spreadsheetDate1.getMonth();
        int int5 = spreadsheetDate1.getMonth();
        java.util.Date date6 = spreadsheetDate1.toDate();
        java.lang.String str7 = spreadsheetDate1.toString();
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getFollowingDayOfWeek(1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (-2208225600001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.removeAgedItems(1560442555647L, false);
//        timeSeries1.setMaximumItemCount(8);
//        timeSeries1.clear();
//        timeSeries1.setRangeDescription("");
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442593978L + "'", long4 == 1560442593978L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442593996L + "'", long37 == 1560442593996L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442593996L + "'", long40 == 1560442593996L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond25.getFirstMillisecond(calendar29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond25.getFirstMillisecond(calendar31);
//        java.lang.Number number33 = null;
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number33);
//        java.lang.Class class35 = timeSeries1.getTimePeriodClass();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries1.getDataItem((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442594297L + "'", long4 == 1560442594297L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
//        org.junit.Assert.assertNotNull(class35);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("Last", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, "", "December 1969", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        long long16 = day13.getSerialIndex();
        int int17 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        try {
            timeSeries9.update((-459), (java.lang.Number) 1560442589510L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(uRL8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond3.getEnd();
//        int int7 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        timeSeries2.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date12 = spreadsheetDate11.toDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
//        long long16 = day13.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem18.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean22 = timeSeriesDataItem18.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem18.getPeriod();
//        timeSeries2.add(timeSeriesDataItem18);
//        boolean boolean25 = timeSeries2.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long28 = fixedMillisecond27.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond27.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond27.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries2.addOrUpdate(regularTimePeriod30, 0.0d);
//        int int33 = year0.compareTo((java.lang.Object) timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442594340L + "'", long5 == 1560442594340L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        long long9 = month7.getFirstMillisecond();
        org.jfree.data.time.Year year10 = month7.getYear();
        long long11 = year10.getLastMillisecond();
        long long12 = year10.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208960000000L) + "'", long9 == (-2208960000000L));
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2177424000001L) + "'", long11 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1900L + "'", long12 == 1900L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        long long7 = day3.getSerialIndex();
        java.lang.String str8 = day3.toString();
        long long9 = day3.getFirstMillisecond();
        boolean boolean11 = day3.equals((java.lang.Object) 1900L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208268800000L) + "'", long9 == (-2208268800000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        long long7 = day3.getSerialIndex();
        java.lang.String str8 = day3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate7 = serialDate5.getPreviousDayOfWeek(4);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
        timeSeriesDataItem3.setValue((java.lang.Number) (-459));
        java.lang.Object obj6 = timeSeriesDataItem3.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
//        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
//        spreadsheetDate4.setDescription("");
//        java.util.Date date9 = spreadsheetDate4.toDate();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date9);
//        int int11 = timeSeries10.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
//        java.lang.String str15 = fixedMillisecond12.toString();
//        try {
//            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1560442584990L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560442594787L + "'", long14 == 1560442594787L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Thu Jun 13 09:16:34 PDT 2019" + "'", str15.equals("Thu Jun 13 09:16:34 PDT 2019"));
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        long long10 = month7.getFirstMillisecond();
        long long11 = month7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208960000000L) + "'", long10 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2208960000000L) + "'", long11 == (-2208960000000L));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Date date5 = fixedMillisecond1.getTime();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getMiddleMillisecond();
        int int7 = day3.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2208225600001L) + "'", long6 == (-2208225600001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        long long11 = month10.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 22801L + "'", long11 == 22801L);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date7 = spreadsheetDate6.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        boolean boolean12 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        boolean boolean13 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond16.getLastMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond16.getEnd();
//        java.lang.Class<?> wildcardClass22 = fixedMillisecond16.getClass();
//        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("First", (java.lang.Class) wildcardClass22);
//        java.io.InputStream inputStream24 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass22);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate2, (java.lang.Class) wildcardClass22);
//        java.lang.Object obj26 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Last", (java.lang.Class) wildcardClass22);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560442594931L + "'", long18 == 1560442594931L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560442594931L + "'", long20 == 1560442594931L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(inputStream23);
//        org.junit.Assert.assertNotNull(inputStream24);
//        org.junit.Assert.assertNull(obj26);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("Last", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, "", "December 1969", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.next();
        long long16 = day13.getSerialIndex();
        int int17 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(uRL8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Saturday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.lang.Object obj6 = null;
        int int7 = year5.compareTo(obj6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int4 = spreadsheetDate1.getMonth();
        int int5 = spreadsheetDate1.getMonth();
        java.util.Date date6 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate9 = null;
        try {
            org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth(serialDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, year7);
        long long9 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, year7);
        long long12 = year7.getLastMillisecond();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1900L + "'", long9 == 1900L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2177424000001L) + "'", long12 == (-2177424000001L));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        long long9 = month7.getFirstMillisecond();
        long long10 = month7.getFirstMillisecond();
        long long11 = month7.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208960000000L) + "'", long9 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208960000000L) + "'", long10 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 22801L + "'", long11 == 22801L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass9 = seriesChangeEvent8.getClass();
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date13 = spreadsheetDate12.toDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.Class<?> wildcardClass15 = day14.getClass();
        java.lang.Object obj16 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date20 = spreadsheetDate19.toDate();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day21.next();
        long long24 = day21.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
        timeSeriesDataItem26.setValue((java.lang.Number) 1560442536737L);
        java.lang.Class<?> wildcardClass30 = timeSeriesDataItem26.getClass();
        timeSeries17.add(timeSeriesDataItem26, false);
        int int34 = timeSeriesDataItem26.compareTo((java.lang.Object) 9);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(inputStream10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate9.equals((java.lang.Object) spreadsheetDate12);
        spreadsheetDate12.setDescription("");
        java.util.Date date17 = spreadsheetDate12.toDate();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date17);
        boolean boolean19 = month7.equals((java.lang.Object) month18);
        long long20 = month18.getFirstMillisecond();
        long long21 = month18.getLastMillisecond();
        int int22 = month18.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208960000000L) + "'", long20 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2206281600001L) + "'", long21 == (-2206281600001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442595898L + "'", long2 == 1560442595898L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int4 = day3.getDayOfMonth();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442540821L);
        timeSeries1.removeAgedItems(true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date11 = spreadsheetDate10.toDate();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.Class<?> wildcardClass13 = day12.getClass();
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass7, (java.lang.Class) wildcardClass13);
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Last", (java.lang.Class) wildcardClass13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass21 = seriesChangeEvent20.getClass();
        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date25 = spreadsheetDate24.toDate();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        java.lang.Class<?> wildcardClass27 = day26.getClass();
        java.lang.Object obj28 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass21, (java.lang.Class) wildcardClass27);
        java.net.URL uRL29 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", (java.lang.Class) wildcardClass27);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize(class30);
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass13, class30);
        java.net.URL uRL33 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("March", class30);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(inputStream8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(inputStream22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(uRL29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNull(uRL33);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate5);
        java.lang.String str8 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean22 = spreadsheetDate11.equals((java.lang.Object) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        boolean boolean28 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, serialDate27);
        try {
            org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.util.Date date14 = day13.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date26 = day25.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date14, timeZone27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date4, timeZone27);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(inputStream21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        long long7 = day3.getSerialIndex();
        int int8 = day3.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date14 = spreadsheetDate13.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate9.equals((java.lang.Object) spreadsheetDate13);
        boolean boolean21 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.lang.String str26 = spreadsheetDate23.getDescription();
        int int27 = spreadsheetDate23.getDayOfMonth();
        int int28 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        spreadsheetDate23.setDescription("Thu Jun 13 09:15:46 PDT 2019");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setNotify(true);
//        timeSeries1.setDomainDescription("Time");
//        int int28 = timeSeries1.getItemCount();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener29);
//        int int31 = timeSeries1.getItemCount();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442597038L + "'", long4 == 1560442597038L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        java.util.Date date28 = day27.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 1, year29);
        long long31 = year29.getSerialIndex();
        int int32 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeries20.getTimePeriod(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1900L + "'", long31 == 1900L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date3 = spreadsheetDate2.toDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
//        int int8 = year6.getYear();
//        java.lang.String str9 = year6.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond10.getLastMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond10.getEnd();
//        java.lang.Class<?> wildcardClass16 = fixedMillisecond10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond21.getMiddleMillisecond(calendar22);
//        java.util.Date date24 = fixedMillisecond21.getEnd();
//        int int25 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        timeSeries20.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date30 = spreadsheetDate29.toDate();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
//        long long34 = day31.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem36.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean40 = timeSeriesDataItem36.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem36.getPeriod();
//        timeSeries20.add(timeSeriesDataItem36);
//        timeSeries18.add(timeSeriesDataItem36, false);
//        boolean boolean45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) wildcardClass16, (java.lang.Object) timeSeries18);
//        int int46 = year6.compareTo((java.lang.Object) boolean45);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1900" + "'", str9.equals("1900"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560442597252L + "'", long12 == 1560442597252L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560442597252L + "'", long14 == 1560442597252L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560442597253L + "'", long23 == 1560442597253L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries1.addChangeListener(seriesChangeListener9);
//        java.lang.Comparable comparable11 = timeSeries1.getKey();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442597561L + "'", long4 == 1560442597561L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 100L + "'", comparable11.equals(100L));
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 100);
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean15 = spreadsheetDate4.equals((java.lang.Object) spreadsheetDate8);
        java.lang.String str16 = spreadsheetDate8.getDescription();
        boolean boolean17 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        try {
            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((int) (short) -1, (org.jfree.data.time.SerialDate) spreadsheetDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        long long9 = month7.getFirstMillisecond();
        org.jfree.data.time.Year year10 = month7.getYear();
        java.lang.String str11 = year10.toString();
        try {
            java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) str11);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208960000000L) + "'", long9 == (-2208960000000L));
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1900" + "'", str11.equals("1900"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        int int5 = spreadsheetDate1.getDayOfWeek();
        int int6 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass5 = seriesChangeEvent4.getClass();
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.Class<?> wildcardClass11 = day10.getClass();
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass17 = seriesChangeEvent16.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = day22.getEnd();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23);
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date23, timeZone27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date23);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(inputStream6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass4 = seriesChangeEvent3.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("Last", (java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=10.0]", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNull(uRL6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.lang.Object obj4 = null;
        boolean boolean5 = fixedMillisecond1.equals(obj4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        java.lang.Number number24 = timeSeriesDataItem17.getValue();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442597877L + "'", long4 == 1560442597877L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 100.0d + "'", number24.equals(100.0d));
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener45);
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener47);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442597988L + "'", long4 == 1560442597988L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442598000L + "'", long37 == 1560442598000L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442598000L + "'", long40 == 1560442598000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond27.getEnd();
//        int int31 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long34 = fixedMillisecond33.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond33.next();
//        int int36 = timeSeries26.getIndex(regularTimePeriod35);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date39 = spreadsheetDate38.toDate();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day40.next();
//        long long43 = day40.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long46 = fixedMillisecond45.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond45.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = fixedMillisecond45.previous();
//        int int49 = day40.compareTo((java.lang.Object) regularTimePeriod48);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date52 = spreadsheetDate51.toDate();
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day53.next();
//        long long56 = day53.getSerialIndex();
//        long long57 = day53.getSerialIndex();
//        java.lang.String str58 = day53.toString();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries26.createCopy(regularTimePeriod48, (org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond60.getMiddleMillisecond(calendar61);
//        java.util.Date date63 = fixedMillisecond60.getEnd();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond60.getLastMillisecond(calendar64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond60.next();
//        java.lang.Number number67 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        java.util.Calendar calendar68 = null;
//        fixedMillisecond60.peg(calendar68);
//        long long70 = fixedMillisecond60.getFirstMillisecond();
//        int int71 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        java.util.Date date72 = fixedMillisecond60.getTime();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560442598302L + "'", long29 == 1560442598302L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 35L + "'", long46 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 10L + "'", long56 == 10L);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 10L + "'", long57 == 10L);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "9-January-1900" + "'", str58.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560442598312L + "'", long62 == 1560442598312L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560442598312L + "'", long65 == 1560442598312L);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNull(number67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560442598312L + "'", long70 == 1560442598312L);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
//        org.junit.Assert.assertNotNull(date72);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date9 = day8.getEnd();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass15 = seriesChangeEvent14.getClass();
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date19 = spreadsheetDate18.toDate();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.util.Date date21 = day20.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date9, timeZone22);
        java.lang.String str25 = month24.toString();
        java.lang.String str26 = month24.toString();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(uRL4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(inputStream16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "January 1900" + "'", str25.equals("January 1900"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "January 1900" + "'", str26.equals("January 1900"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) (short) 1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month7.previous();
        long long10 = month7.getFirstMillisecond();
        int int11 = month7.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208960000000L) + "'", long10 == (-2208960000000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        long long6 = day3.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
//        timeSeriesDataItem8.setValue((java.lang.Number) 1560442536737L);
//        java.lang.Object obj12 = timeSeriesDataItem8.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond13.getMiddleMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond13.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) (short) 10);
//        int int21 = timeSeriesDataItem8.compareTo((java.lang.Object) fixedMillisecond13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate26);
//        boolean boolean28 = spreadsheetDate23.equals((java.lang.Object) spreadsheetDate26);
//        java.lang.String str29 = spreadsheetDate23.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date33 = spreadsheetDate32.toDate();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date37 = spreadsheetDate36.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean42 = spreadsheetDate36.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        boolean boolean43 = spreadsheetDate32.equals((java.lang.Object) spreadsheetDate36);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate36);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date47 = spreadsheetDate46.toDate();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
//        boolean boolean49 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, serialDate48);
//        boolean boolean50 = timeSeriesDataItem8.equals((java.lang.Object) serialDate48);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560442599626L + "'", long15 == 1560442599626L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560442599626L + "'", long17 == 1560442599626L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNull(str29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date49 = spreadsheetDate48.toDate();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
//        long long53 = day50.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long56 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond55.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond55.previous();
//        int int59 = day50.compareTo((java.lang.Object) regularTimePeriod58);
//        timeSeries1.delete(regularTimePeriod58);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeries1.getTimePeriod(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442600720L + "'", long4 == 1560442600720L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442600732L + "'", long37 == 1560442600732L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442600732L + "'", long40 == 1560442600732L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 35L + "'", long56 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries28.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.next();
//        long long42 = day39.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean48 = timeSeriesDataItem44.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem44.getPeriod();
//        timeSeries28.add(timeSeriesDataItem44);
//        timeSeries26.add(timeSeriesDataItem44, false);
//        java.util.Collection collection53 = timeSeries26.getTimePeriods();
//        boolean boolean54 = timeSeries26.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date57 = spreadsheetDate56.toDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
//        java.net.URL uRL67 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        java.util.Date date72 = day71.getEnd();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod60, "hi!", "", (java.lang.Class) wildcardClass66);
//        java.lang.String str76 = timeSeries75.getDomainDescription();
//        java.lang.String str77 = timeSeries75.getRangeDescription();
//        boolean boolean78 = timeSeries26.equals((java.lang.Object) timeSeries75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries24.addAndOrUpdate(timeSeries75);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = null;
//        try {
//            timeSeries24.add(timeSeriesDataItem80);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442600761L + "'", long31 == 1560442600761L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(uRL67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond3.getEnd();
//        int int7 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond3.getLastMillisecond(calendar8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date12 = spreadsheetDate11.toDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        int int14 = spreadsheetDate11.getMonth();
//        int int15 = spreadsheetDate11.toSerial();
//        boolean boolean16 = fixedMillisecond3.equals((java.lang.Object) spreadsheetDate11);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(7, (org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442600797L + "'", long5 == 1560442600797L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442600797L + "'", long9 == 1560442600797L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("August");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        java.lang.String str22 = timeSeries20.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond23.getEnd();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond23.getLastMillisecond(calendar27);
//        long long29 = fixedMillisecond23.getSerialIndex();
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries20.setRangeDescription("hi!");
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560442600887L + "'", long25 == 1560442600887L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560442600887L + "'", long28 == 1560442600887L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560442600887L + "'", long29 == 1560442600887L);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        timeSeries20.setRangeDescription("First");
        java.lang.String str25 = timeSeries20.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries20.addChangeListener(seriesChangeListener26);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "First" + "'", str25.equals("First"));
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        boolean boolean23 = timeSeries20.equals((java.lang.Object) 1560442537682L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date26 = spreadsheetDate25.toDate();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries20.getDataItem(regularTimePeriod28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond30.getLastMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond30.getEnd();
//        java.lang.Class<?> wildcardClass36 = fixedMillisecond30.getClass();
//        try {
//            timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 100L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560442601138L + "'", long32 == 1560442601138L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560442601138L + "'", long34 == 1560442601138L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.removeAgedItems(1560442555647L, false);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries1.getDataItem((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442601185L + "'", long4 == 1560442601185L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442601199L + "'", long37 == 1560442601199L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442601199L + "'", long40 == 1560442601199L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=10.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener45);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date49 = spreadsheetDate48.toDate();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
//        long long53 = day50.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long56 = fixedMillisecond55.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond55.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond55.previous();
//        int int59 = day50.compareTo((java.lang.Object) regularTimePeriod58);
//        timeSeries1.delete(regularTimePeriod58);
//        try {
//            timeSeries1.setMaximumItemCount((-457));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442601231L + "'", long4 == 1560442601231L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442601238L + "'", long37 == 1560442601238L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442601238L + "'", long40 == 1560442601238L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 35L + "'", long56 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        java.lang.String str22 = timeSeries20.getDomainDescription();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date7 = spreadsheetDate6.toDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate14);
//        boolean boolean16 = spreadsheetDate10.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        boolean boolean17 = spreadsheetDate6.equals((java.lang.Object) spreadsheetDate10);
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date21 = spreadsheetDate20.toDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
//        boolean boolean23 = spreadsheetDate1.isInRange(serialDate18, (org.jfree.data.time.SerialDate) spreadsheetDate20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        boolean boolean28 = spreadsheetDate20.equals((java.lang.Object) timeSeriesDataItem27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond29.getLastMillisecond(calendar33);
//        long long35 = fixedMillisecond29.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        java.util.Date date43 = fixedMillisecond40.getEnd();
//        int int44 = timeSeries39.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
//        timeSeries39.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date49 = spreadsheetDate48.toDate();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
//        long long53 = day50.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeriesDataItem55.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean59 = timeSeriesDataItem55.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = timeSeriesDataItem55.getPeriod();
//        timeSeries39.add(timeSeriesDataItem55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long64 = fixedMillisecond63.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = fixedMillisecond63.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond63.previous();
//        java.util.Calendar calendar67 = null;
//        long long68 = fixedMillisecond63.getFirstMillisecond(calendar67);
//        java.util.Calendar calendar69 = null;
//        long long70 = fixedMillisecond63.getFirstMillisecond(calendar69);
//        java.lang.Number number71 = null;
//        timeSeries39.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, number71);
//        java.lang.Class class73 = timeSeries39.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond29, "9-January-1900", "", class73);
//        try {
//            int int75 = spreadsheetDate20.compareTo((java.lang.Object) timeSeries74);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442601403L + "'", long31 == 1560442601403L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560442601403L + "'", long34 == 1560442601403L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560442601403L + "'", long35 == 1560442601403L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560442601406L + "'", long42 == 1560442601406L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 10L + "'", long53 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 35L + "'", long64 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 35L + "'", long68 == 35L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 35L + "'", long70 == 35L);
//        org.junit.Assert.assertNotNull(class73);
//    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        java.util.Collection collection28 = timeSeries1.getTimePeriods();
//        java.lang.String str29 = timeSeries1.getDomainDescription();
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
//        timeSeries1.setDescription("First");
//        timeSeries1.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442601451L + "'", long6 == 1560442601451L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("9-January-1900");
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        timeSeries20.removeAgedItems(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries20.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date28 = spreadsheetDate27.toDate();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date30 = day29.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month((int) (short) 1, year31);
        org.jfree.data.time.Year year33 = month32.getYear();
        long long34 = month32.getFirstMillisecond();
        org.jfree.data.time.Year year35 = month32.getYear();
        long long36 = month32.getSerialIndex();
        int int37 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-2208960000000L) + "'", long34 == (-2208960000000L));
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 22801L + "'", long36 == 22801L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        long long9 = day3.getSerialIndex();
        long long10 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        long long7 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        fixedMillisecond1.peg(calendar8);
        java.util.Calendar calendar10 = null;
        fixedMillisecond1.peg(calendar10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442594340L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 1560442579256L);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        java.lang.String str7 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date11 = spreadsheetDate10.toDate();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean21 = spreadsheetDate10.equals((java.lang.Object) spreadsheetDate14);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date25 = spreadsheetDate24.toDate();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        boolean boolean27 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, serialDate26);
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getNearestDayOfWeek(4);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate26);
        long long31 = day30.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2208268800000L) + "'", long31 == (-2208268800000L));
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        java.util.Collection collection28 = timeSeries1.getTimePeriods();
//        boolean boolean29 = timeSeries1.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date32 = spreadsheetDate31.toDate();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day33.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass41 = seriesChangeEvent40.getClass();
//        java.net.URL uRL42 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date45 = spreadsheetDate44.toDate();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        java.util.Date date47 = day46.getEnd();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod35, "hi!", "", (java.lang.Class) wildcardClass41);
//        java.lang.String str51 = timeSeries50.getDomainDescription();
//        java.lang.String str52 = timeSeries50.getRangeDescription();
//        boolean boolean53 = timeSeries1.equals((java.lang.Object) timeSeries50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date56 = spreadsheetDate55.toDate();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day57.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries1.getDataItem(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442604021L + "'", long6 == 1560442604021L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNull(uRL42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        long long7 = day3.getSerialIndex();
        java.lang.String str8 = day3.toString();
        long long9 = day3.getFirstMillisecond();
        java.lang.String str10 = day3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208268800000L) + "'", long9 == (-2208268800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9-January-1900" + "'", str10.equals("9-January-1900"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        java.util.Date date28 = day27.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 1, year29);
        long long31 = year29.getSerialIndex();
        int int32 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = null;
        java.lang.Number number34 = null;
        try {
            timeSeries20.add(regularTimePeriod33, number34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1900L + "'", long31 == 1900L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getLastMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond6);
//        int int8 = fixedMillisecond0.compareTo((java.lang.Object) fixedMillisecond6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getFirstMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442604798L + "'", long2 == 1560442604798L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442604798L + "'", long4 == 1560442604798L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560442604799L + "'", long10 == 1560442604799L);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        java.util.Date date9 = day3.getStart();
        int int10 = day3.getDayOfMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        java.util.Collection collection28 = timeSeries1.getTimePeriods();
//        boolean boolean29 = timeSeries1.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date32 = spreadsheetDate31.toDate();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day33.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass41 = seriesChangeEvent40.getClass();
//        java.net.URL uRL42 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date45 = spreadsheetDate44.toDate();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        java.util.Date date47 = day46.getEnd();
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod35, "hi!", "", (java.lang.Class) wildcardClass41);
//        java.lang.String str51 = timeSeries50.getDomainDescription();
//        java.lang.String str52 = timeSeries50.getRangeDescription();
//        boolean boolean53 = timeSeries1.equals((java.lang.Object) timeSeries50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date56 = spreadsheetDate55.toDate();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day57.previous();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass63 = seriesChangeEvent62.getClass();
//        java.io.InputStream inputStream64 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass63);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date67 = spreadsheetDate66.toDate();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate66);
//        java.lang.Class<?> wildcardClass69 = day68.getClass();
//        java.lang.Object obj70 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass63, (java.lang.Class) wildcardClass69);
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day57, (java.lang.Class) wildcardClass69);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date74 = spreadsheetDate73.toDate();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day75.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day75.next();
//        long long78 = day75.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day75, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = timeSeriesDataItem80.getPeriod();
//        timeSeriesDataItem80.setValue((java.lang.Number) 1560442536737L);
//        java.lang.Class<?> wildcardClass84 = timeSeriesDataItem80.getClass();
//        timeSeries71.add(timeSeriesDataItem80, false);
//        try {
//            timeSeries50.add(timeSeriesDataItem80);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442604863L + "'", long6 == 1560442604863L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNull(uRL42);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNotNull(inputStream64);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertNull(obj70);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(wildcardClass84);
//    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        int int6 = day3.getDayOfMonth();
        java.lang.String str7 = day3.toString();
        long long8 = day3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208268800000L) + "'", long8 == (-2208268800000L));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate10.equals((java.lang.Object) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date18 = spreadsheetDate17.toDate();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        try {
            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(9999, (org.jfree.data.time.SerialDate) spreadsheetDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442540821L);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener2);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        java.util.Collection collection28 = timeSeries1.getTimePeriods();
//        boolean boolean29 = timeSeries1.isEmpty();
//        java.lang.Class<?> wildcardClass30 = timeSeries1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        timeSeries32.setKey((java.lang.Comparable) 100.0f);
//        timeSeries32.fireSeriesChanged();
//        boolean boolean37 = timeSeries32.equals((java.lang.Object) 1560442542955L);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries1.addAndOrUpdate(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442604977L + "'", long6 == 1560442604977L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getLastMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getEnd();
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond3.getClass();
//        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("First", (java.lang.Class) wildcardClass9);
//        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass9);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass18 = seriesChangeEvent17.getClass();
//        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date22 = spreadsheetDate21.toDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        java.lang.Class<?> wildcardClass24 = day23.getClass();
//        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass18, (java.lang.Class) wildcardClass24);
//        java.net.URL uRL26 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Last", (java.lang.Class) wildcardClass24);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass30 = seriesChangeEvent29.getClass();
//        java.net.URL uRL31 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date34 = spreadsheetDate33.toDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate33);
//        java.util.Date date36 = day35.getEnd();
//        java.util.TimeZone timeZone37 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date36, timeZone37);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass42 = seriesChangeEvent41.getClass();
//        java.io.InputStream inputStream43 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass42);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date46 = spreadsheetDate45.toDate();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        java.util.Date date48 = day47.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone49);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date36, timeZone49);
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date36, timeZone52);
//        java.lang.Object obj54 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass9, (java.lang.Class) wildcardClass24);
//        java.lang.ClassLoader classLoader55 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass24);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560442605219L + "'", long5 == 1560442605219L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442605219L + "'", long7 == 1560442605219L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNull(inputStream10);
//        org.junit.Assert.assertNotNull(inputStream11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(inputStream19);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNull(obj25);
//        org.junit.Assert.assertNull(uRL26);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(uRL31);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(inputStream43);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNull(obj54);
//        org.junit.Assert.assertNotNull(classLoader55);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date4 = spreadsheetDate3.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (short) 1, year7);
        long long9 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, year7);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year7.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1900L + "'", long9 == 1900L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date5 = spreadsheetDate4.toDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate10.equals((java.lang.Object) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date18 = spreadsheetDate17.toDate();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.Object obj22 = null;
        boolean boolean23 = spreadsheetDate10.equals(obj22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate24);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = timeSeriesDataItem8.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass19 = seriesChangeEvent18.getClass();
        java.net.URL uRL20 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date22, timeZone23);
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Thu Jun 13 09:15:46 PDT 2019", class25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem8, class25);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(uRL20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNull(inputStream26);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, 6);
        java.lang.String str17 = spreadsheetDate6.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9-January-1900" + "'", str17.equals("9-January-1900"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("First");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("March");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("First");
        boolean boolean7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) "March", (java.lang.Object) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: First" + "'", str2.equals("org.jfree.data.general.SeriesException: First"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date10 = spreadsheetDate9.toDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.Class<?> wildcardClass12 = day11.getClass();
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass6, (java.lang.Class) wildcardClass12);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", (java.lang.Class) wildcardClass12);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(inputStream7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(uRL14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNull(uRL16);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        timeSeries1.setDomainDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries1.addPropertyChangeListener(propertyChangeListener45);
//        timeSeries1.clear();
//        boolean boolean48 = timeSeries1.isEmpty();
//        java.lang.Class class49 = timeSeries1.getTimePeriodClass();
//        java.lang.Comparable comparable50 = timeSeries1.getKey();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442607395L + "'", long4 == 1560442607395L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442607401L + "'", long37 == 1560442607401L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442607401L + "'", long40 == 1560442607401L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + comparable50 + "' != '" + 100L + "'", comparable50.equals(100L));
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass14 = seriesChangeEvent13.getClass();
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date18 = spreadsheetDate17.toDate();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Class<?> wildcardClass20 = day19.getClass();
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass14, (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, (java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 10, "SerialDate.weekInMonthToString(): invalid code.", "ERROR : Relative To String", (java.lang.Class) wildcardClass20);
        java.lang.Class<?> wildcardClass24 = timeSeries23.getClass();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate11.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean18 = spreadsheetDate7.equals((java.lang.Object) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date22 = spreadsheetDate21.toDate();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean24 = spreadsheetDate2.isInRange(serialDate19, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        try {
            org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '4', serialDate19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        timeSeries1.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442608034L + "'", long4 == 1560442608034L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        int int4 = spreadsheetDate1.getMonth();
        int int5 = spreadsheetDate1.getMonth();
        java.util.Date date6 = spreadsheetDate1.toDate();
        java.lang.String str7 = spreadsheetDate1.toString();
        try {
            org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate1.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9-January-1900" + "'", str7.equals("9-January-1900"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Third" + "'", str1.equals("Third"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean10 = spreadsheetDate5.equals((java.lang.Object) spreadsheetDate8);
        spreadsheetDate8.setDescription("");
        java.util.Date date13 = spreadsheetDate8.toDate();
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate8);
        try {
            org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate2.getFollowingDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        timeSeries1.setNotify(true);
//        timeSeries1.setDomainDescription("Time");
//        int int28 = timeSeries1.getItemCount();
//        timeSeries1.setNotify(false);
//        java.util.Collection collection31 = timeSeries1.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442608585L + "'", long4 == 1560442608585L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(collection31);
//    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond25.getFirstMillisecond(calendar29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond25.getFirstMillisecond(calendar31);
//        java.lang.Number number33 = null;
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number33);
//        java.lang.Class class35 = timeSeries1.getTimePeriodClass();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        java.util.Date date40 = day39.getEnd();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
//        long long42 = year41.getFirstMillisecond();
//        java.lang.Number number43 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year41, number43);
//        try {
//            timeSeries1.delete(8, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442608709L + "'", long4 == 1560442608709L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208960000000L) + "'", long42 == (-2208960000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem44);
//    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate9);
//        boolean boolean11 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        boolean boolean12 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getLastMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getEnd();
//        java.lang.Class<?> wildcardClass21 = fixedMillisecond15.getClass();
//        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("First", (java.lang.Class) wildcardClass21);
//        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries25 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries24.addAndOrUpdate(timeSeries25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560442608739L + "'", long17 == 1560442608739L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560442608739L + "'", long19 == 1560442608739L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNull(inputStream22);
//        org.junit.Assert.assertNotNull(inputStream23);
//    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond2.getLastMillisecond(calendar7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        int int13 = spreadsheetDate10.getMonth();
//        int int14 = spreadsheetDate10.toSerial();
//        boolean boolean15 = fixedMillisecond2.equals((java.lang.Object) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date19 = spreadsheetDate18.toDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate18);
//        boolean boolean22 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442608756L + "'", long4 == 1560442608756L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560442608756L + "'", long8 == 1560442608756L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        timeSeriesDataItem8.setValue((java.lang.Number) 1560442536737L);
        java.lang.Class<?> wildcardClass12 = timeSeriesDataItem8.getClass();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.next();
        long long19 = day16.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem21.getPeriod();
        timeSeriesDataItem21.setValue((java.lang.Number) 1560442536737L);
        java.lang.Class<?> wildcardClass25 = timeSeriesDataItem21.getClass();
        java.lang.Number number26 = timeSeriesDataItem21.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem21.getPeriod();
        boolean boolean28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) wildcardClass12, (java.lang.Object) timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1560442536737L + "'", number26.equals(1560442536737L));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) 1560442557784L);
//        boolean boolean9 = timeSeries1.getNotify();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442609093L + "'", long4 == 1560442609093L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass3 = seriesChangeEvent2.getClass();
//        java.net.URL uRL4 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date7 = spreadsheetDate6.toDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
//        java.util.Date date9 = day8.getEnd();
//        java.util.TimeZone timeZone10 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date9, timeZone10);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass15 = seriesChangeEvent14.getClass();
//        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date19 = spreadsheetDate18.toDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        java.util.Date date21 = day20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date9, timeZone22);
//        java.lang.String str25 = month24.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date28 = spreadsheetDate27.toDate();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass37 = seriesChangeEvent36.getClass();
//        java.net.URL uRL38 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass37);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date41 = spreadsheetDate40.toDate();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        java.util.Date date43 = day42.getEnd();
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod31, "hi!", "", (java.lang.Class) wildcardClass37);
//        java.lang.String str47 = timeSeries46.getDomainDescription();
//        java.lang.String str48 = timeSeries46.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond49.getMiddleMillisecond(calendar50);
//        java.util.Date date52 = fixedMillisecond49.getEnd();
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond49.getLastMillisecond(calendar53);
//        long long55 = fixedMillisecond49.getSerialIndex();
//        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
//        int int57 = month24.compareTo((java.lang.Object) timeSeries46);
//        long long58 = month24.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNull(uRL4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(inputStream16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "January 1900" + "'", str25.equals("January 1900"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNull(uRL38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560442609124L + "'", long51 == 1560442609124L);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560442609124L + "'", long54 == 1560442609124L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560442609124L + "'", long55 == 1560442609124L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2208960000000L) + "'", long58 == (-2208960000000L));
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean23 = timeSeries20.equals((java.lang.Object) 1560442537682L);
        java.util.List list24 = timeSeries20.getItems();
        timeSeries20.setNotify(false);
        int int27 = timeSeries20.getMaximumItemCount();
        try {
            timeSeries20.removeAgedItems(0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean16 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, (org.jfree.data.time.SerialDate) spreadsheetDate8, 6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addDays((int) 'a', serialDate23);
        boolean boolean25 = spreadsheetDate6.isAfter(serialDate23);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        boolean boolean8 = timeSeries1.equals((java.lang.Object) 1560442557784L);
//        int int9 = timeSeries1.getItemCount();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442609745L + "'", long4 == 1560442609745L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        long long7 = day3.getSerialIndex();
        java.lang.String str8 = day3.toString();
        long long9 = day3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day3.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-January-1900" + "'", str8.equals("9-January-1900"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208268800000L) + "'", long9 == (-2208268800000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries28.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.next();
//        long long42 = day39.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean48 = timeSeriesDataItem44.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem44.getPeriod();
//        timeSeries28.add(timeSeriesDataItem44);
//        timeSeries26.add(timeSeriesDataItem44, false);
//        java.util.Collection collection53 = timeSeries26.getTimePeriods();
//        boolean boolean54 = timeSeries26.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date57 = spreadsheetDate56.toDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
//        java.net.URL uRL67 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        java.util.Date date72 = day71.getEnd();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod60, "hi!", "", (java.lang.Class) wildcardClass66);
//        java.lang.String str76 = timeSeries75.getDomainDescription();
//        java.lang.String str77 = timeSeries75.getRangeDescription();
//        boolean boolean78 = timeSeries26.equals((java.lang.Object) timeSeries75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries24.addAndOrUpdate(timeSeries75);
//        java.lang.Comparable comparable80 = timeSeries75.getKey();
//        timeSeries75.setMaximumItemCount((int) (byte) 10);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442609791L + "'", long31 == 1560442609791L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(uRL67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertNotNull(comparable80);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond25.getFirstMillisecond(calendar29);
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond25.getFirstMillisecond(calendar31);
//        java.lang.Number number33 = null;
//        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, number33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeries1.getNextTimePeriod();
//        boolean boolean36 = timeSeries1.getNotify();
//        timeSeries1.setMaximumItemAge(0L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442610690L + "'", long4 == 1560442610690L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        timeSeriesDataItem8.setValue((java.lang.Number) 1560442536737L);
        java.lang.Object obj12 = timeSeriesDataItem8.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem8.getPeriod();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setDescription("Fourth");
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442610872L + "'", long4 == 1560442610872L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        boolean boolean7 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate5);
        java.lang.String str8 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date16 = spreadsheetDate15.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean21 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean22 = spreadsheetDate11.equals((java.lang.Object) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        boolean boolean28 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = serialDate27.getNearestDayOfWeek(4);
        try {
            org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, serialDate30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        try {
            org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate4.getNearestDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        java.lang.Class<?> wildcardClass4 = day3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
//        java.util.Date date10 = fixedMillisecond7.getEnd();
//        int int11 = timeSeries6.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long14 = fixedMillisecond13.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.next();
//        int int16 = timeSeries6.getIndex(regularTimePeriod15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date19 = spreadsheetDate18.toDate();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day20.next();
//        long long23 = day20.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long26 = fixedMillisecond25.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond25.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.previous();
//        int int29 = day20.compareTo((java.lang.Object) regularTimePeriod28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date32 = spreadsheetDate31.toDate();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day33.next();
//        long long36 = day33.getSerialIndex();
//        long long37 = day33.getSerialIndex();
//        java.lang.String str38 = day33.toString();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries6.createCopy(regularTimePeriod28, (org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        java.util.Date date43 = fixedMillisecond40.getEnd();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond40.getLastMillisecond(calendar44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond40.next();
//        java.lang.Number number47 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
//        timeSeries6.removeAgedItems(1560442555647L, false);
//        timeSeries6.setMaximumItemCount(8);
//        timeSeries6.clear();
//        boolean boolean54 = day3.equals((java.lang.Object) timeSeries6);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560442612365L + "'", long9 == 1560442612365L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-January-1900" + "'", str38.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560442612370L + "'", long42 == 1560442612370L);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560442612370L + "'", long45 == 1560442612370L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNull(number47);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate8 = spreadsheetDate1.getNearestDayOfWeek(7);
        int int9 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond5.getEnd();
//        int int9 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        timeSeries4.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeriesDataItem20.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean24 = timeSeriesDataItem20.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = timeSeriesDataItem20.getPeriod();
//        timeSeries4.add(timeSeriesDataItem20);
//        java.lang.String str27 = timeSeries4.getDomainDescription();
//        java.lang.Class class28 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560442594931L, "1900", "Fourth", class28);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560442612937L + "'", long7 == 1560442612937L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertNotNull(class28);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        long long7 = day6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-57600000L) + "'", long7 == (-57600000L));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass7 = seriesChangeEvent6.getClass();
        java.net.URL uRL8 = org.jfree.chart.util.ObjectUtilities.getResource("Last", (java.lang.Class) wildcardClass7);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, "", "December 1969", (java.lang.Class) wildcardClass7);
        java.lang.Comparable comparable10 = timeSeries9.getKey();
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(uRL8);
        org.junit.Assert.assertNotNull(comparable10);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date6 = spreadsheetDate5.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate9);
//        boolean boolean11 = spreadsheetDate5.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        boolean boolean12 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getLastMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getEnd();
//        java.lang.Class<?> wildcardClass21 = fixedMillisecond15.getClass();
//        java.io.InputStream inputStream22 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("First", (java.lang.Class) wildcardClass21);
//        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass21);
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1, (java.lang.Class) wildcardClass21);
//        timeSeries24.setMaximumItemAge(1560442577039L);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long36 = fixedMillisecond35.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond35.next();
//        int int38 = timeSeries28.getIndex(regularTimePeriod37);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date41 = spreadsheetDate40.toDate();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.next();
//        long long45 = day42.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long48 = fixedMillisecond47.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond47.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond47.previous();
//        int int51 = day42.compareTo((java.lang.Object) regularTimePeriod50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date54 = spreadsheetDate53.toDate();
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day55.next();
//        long long58 = day55.getSerialIndex();
//        long long59 = day55.getSerialIndex();
//        java.lang.String str60 = day55.toString();
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries28.createCopy(regularTimePeriod50, (org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getMiddleMillisecond(calendar63);
//        java.util.Date date65 = fixedMillisecond62.getEnd();
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond62.getLastMillisecond(calendar66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = fixedMillisecond62.next();
//        java.lang.Number number69 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) 10L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date74 = spreadsheetDate73.toDate();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day75.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day75.next();
//        long long78 = day75.getSerialIndex();
//        long long79 = day75.getSerialIndex();
//        java.lang.String str80 = day75.toString();
//        int int81 = fixedMillisecond62.compareTo((java.lang.Object) day75);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560442613131L + "'", long17 == 1560442613131L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560442613131L + "'", long19 == 1560442613131L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNull(inputStream22);
//        org.junit.Assert.assertNotNull(inputStream23);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442613133L + "'", long31 == 1560442613133L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 35L + "'", long48 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 10L + "'", long58 == 10L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9-January-1900" + "'", str60.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560442613139L + "'", long64 == 1560442613139L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560442613139L + "'", long67 == 1560442613139L);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(number69);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 10L + "'", long79 == 10L);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "9-January-1900" + "'", str80.equals("9-January-1900"));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
//    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.next();
//        int int11 = timeSeries1.getIndex(regularTimePeriod10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date14 = spreadsheetDate13.toDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
//        long long18 = day15.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long21 = fixedMillisecond20.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond20.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
//        int int24 = day15.compareTo((java.lang.Object) regularTimePeriod23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date27 = spreadsheetDate26.toDate();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day28.next();
//        long long31 = day28.getSerialIndex();
//        long long32 = day28.getSerialIndex();
//        java.lang.String str33 = day28.toString();
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries1.createCopy(regularTimePeriod23, (org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        java.util.Date date38 = fixedMillisecond35.getEnd();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond35.getLastMillisecond(calendar39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond35.next();
//        java.lang.Number number42 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        java.util.Calendar calendar43 = null;
//        fixedMillisecond35.peg(calendar43);
//        long long45 = fixedMillisecond35.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442614402L + "'", long4 == 1560442614402L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "9-January-1900" + "'", str33.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560442614408L + "'", long37 == 1560442614408L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560442614408L + "'", long40 == 1560442614408L);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560442614408L + "'", long45 == 1560442614408L);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = timeSeriesDataItem8.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem8.getPeriod();
        timeSeriesDataItem8.setValue((java.lang.Number) (-2206281600001L));
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        int int9 = day3.getMonth();
        int int10 = day3.getYear();
        long long11 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        int int8 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date13 = spreadsheetDate12.toDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.next();
//        long long17 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem19.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean23 = timeSeriesDataItem19.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem19.getPeriod();
//        timeSeries3.add(timeSeriesDataItem19);
//        timeSeries1.add(timeSeriesDataItem19, false);
//        boolean boolean28 = timeSeries1.isEmpty();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries1.removeChangeListener(seriesChangeListener29);
//        timeSeries1.setNotify(false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560442614798L + "'", long6 == 1560442614798L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        spreadsheetDate4.setDescription("");
        java.util.Date date9 = spreadsheetDate4.toDate();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass14 = seriesChangeEvent13.getClass();
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date17, timeZone18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date26 = day25.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month((int) (short) 1, year27);
        java.util.Date date29 = month28.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass33 = seriesChangeEvent32.getClass();
        java.io.InputStream inputStream34 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date37 = spreadsheetDate36.toDate();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        java.util.Date date39 = day38.getEnd();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date29, timeZone40);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date9, timeZone40);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(inputStream34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNull(regularTimePeriod42);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass5 = seriesChangeEvent4.getClass();
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.Class<?> wildcardClass11 = day10.getClass();
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Last", (java.lang.Class) wildcardClass11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass17 = seriesChangeEvent16.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date21 = spreadsheetDate20.toDate();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate20);
        java.util.Date date23 = day22.getEnd();
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass29 = seriesChangeEvent28.getClass();
        java.io.InputStream inputStream30 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date33 = spreadsheetDate32.toDate();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate32);
        java.util.Date date35 = day34.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date23, timeZone36);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date23, timeZone39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date23);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond41.getLastMillisecond(calendar42);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(inputStream6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(inputStream30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-2208182400001L) + "'", long43 == (-2208182400001L));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date7 = spreadsheetDate6.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean12 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean13 = spreadsheetDate2.equals((java.lang.Object) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(4, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date17 = spreadsheetDate16.toDate();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.String str19 = spreadsheetDate16.getDescription();
        int int20 = spreadsheetDate16.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate22.equals((java.lang.Object) spreadsheetDate25);
        spreadsheetDate25.setDescription("");
        java.lang.String str30 = spreadsheetDate25.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date35 = spreadsheetDate34.toDate();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date39 = spreadsheetDate38.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = spreadsheetDate38.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean45 = spreadsheetDate34.equals((java.lang.Object) spreadsheetDate38);
        java.lang.String str46 = spreadsheetDate38.getDescription();
        boolean boolean47 = spreadsheetDate32.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean48 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        boolean boolean49 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date52 = spreadsheetDate51.toDate();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate51);
        int int54 = spreadsheetDate51.getMonth();
        int int55 = spreadsheetDate51.toSerial();
        boolean boolean57 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate51, (int) '4');
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "9-January-1900" + "'", str30.equals("9-January-1900"));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560442616661L + "'", long2 == 1560442616661L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442616661L + "'", long4 == 1560442616661L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date10 = day9.getEnd();
        boolean boolean11 = spreadsheetDate2.equals((java.lang.Object) date10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate2.compareTo((java.lang.Object) spreadsheetDate13);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date3 = spreadsheetDate2.toDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date8 = spreadsheetDate7.toDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.util.Date date10 = day9.getEnd();
        boolean boolean11 = spreadsheetDate2.equals((java.lang.Object) date10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date10);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        java.lang.String str14 = seriesChangeEvent12.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 09 23:59:59 PST 1900]" + "'", str14.equals("org.jfree.data.general.SeriesChangeEvent[source=Tue Jan 09 23:59:59 PST 1900]"));
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date11 = spreadsheetDate10.toDate();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day12.next();
//        long long15 = day12.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean21 = timeSeriesDataItem17.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem17.getPeriod();
//        timeSeries1.add(timeSeriesDataItem17);
//        boolean boolean24 = timeSeries1.isEmpty();
//        timeSeries1.setMaximumItemAge(0L);
//        java.lang.String str27 = timeSeries1.getRangeDescription();
//        timeSeries1.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442616790L + "'", long4 == 1560442616790L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date15 = spreadsheetDate14.toDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.util.Date date17 = day16.getEnd();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date26 = spreadsheetDate25.toDate();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate25);
        java.util.Date date28 = day27.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month((int) (short) 1, year29);
        long long31 = year29.getSerialIndex();
        int int32 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) year29);
        java.util.Calendar calendar33 = null;
        try {
            long long34 = year29.getFirstMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1900L + "'", long31 == 1900L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries28.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.next();
//        long long42 = day39.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean48 = timeSeriesDataItem44.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem44.getPeriod();
//        timeSeries28.add(timeSeriesDataItem44);
//        timeSeries26.add(timeSeriesDataItem44, false);
//        java.util.Collection collection53 = timeSeries26.getTimePeriods();
//        boolean boolean54 = timeSeries26.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date57 = spreadsheetDate56.toDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
//        java.net.URL uRL67 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        java.util.Date date72 = day71.getEnd();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod60, "hi!", "", (java.lang.Class) wildcardClass66);
//        java.lang.String str76 = timeSeries75.getDomainDescription();
//        java.lang.String str77 = timeSeries75.getRangeDescription();
//        boolean boolean78 = timeSeries26.equals((java.lang.Object) timeSeries75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries24.addAndOrUpdate(timeSeries75);
//        long long80 = timeSeries24.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442616993L + "'", long31 == 1560442616993L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(uRL67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 9223372036854775807L + "'", long80 == 9223372036854775807L);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Date date4 = regularTimePeriod3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass8 = seriesChangeEvent7.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date12 = spreadsheetDate11.toDate();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.util.Date date14 = day13.getEnd();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass20 = seriesChangeEvent19.getClass();
        java.io.InputStream inputStream21 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date24 = spreadsheetDate23.toDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.util.Date date26 = day25.getEnd();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date26, timeZone27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date14, timeZone27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date4, timeZone27);
        long long31 = month30.getFirstMillisecond();
        org.jfree.data.time.Year year32 = month30.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(inputStream21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2649600000L) + "'", long31 == (-2649600000L));
        org.junit.Assert.assertNotNull(year32);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date9 = spreadsheetDate8.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate8);
        boolean boolean11 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-January-1900" + "'", str12.equals("9-January-1900"));
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        boolean boolean23 = timeSeries20.equals((java.lang.Object) 1560442537682L);
//        java.util.List list24 = timeSeries20.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond25.getLastMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond25.getEnd();
//        try {
//            timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 1560442542235L, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.general.SeriesChangeEvent.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560442618055L + "'", long27 == 1560442618055L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560442618055L + "'", long29 == 1560442618055L);
//        org.junit.Assert.assertNotNull(date30);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getLastMillisecond();
        int int7 = year5.getYear();
        long long8 = year5.getFirstMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass14 = seriesChangeEvent13.getClass();
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date18 = spreadsheetDate17.toDate();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.Class<?> wildcardClass20 = day19.getClass();
        java.lang.Object obj21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass14, (java.lang.Class) wildcardClass20);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", (java.lang.Class) wildcardClass20);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
        java.lang.Class<?> wildcardClass26 = seriesChangeEvent25.getClass();
        java.net.URL uRL27 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date30 = spreadsheetDate29.toDate();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.util.Date date32 = day31.getEnd();
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date32, timeZone33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date32);
        java.util.TimeZone timeZone36 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date32, timeZone36);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5, (java.lang.Class) wildcardClass20);
        boolean boolean39 = timeSeries38.isEmpty();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2177424000001L) + "'", long6 == (-2177424000001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208960000000L) + "'", long8 == (-2208960000000L));
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(inputStream15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(uRL22);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNull(uRL27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timeSeries1.addChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getEnd();
//        int int17 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long20 = fixedMillisecond19.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond19.next();
//        int int22 = timeSeries12.getIndex(regularTimePeriod21);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date25 = spreadsheetDate24.toDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.next();
//        long long29 = day26.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
//        long long32 = fixedMillisecond31.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond31.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond31.previous();
//        int int35 = day26.compareTo((java.lang.Object) regularTimePeriod34);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.next();
//        long long42 = day39.getSerialIndex();
//        long long43 = day39.getSerialIndex();
//        java.lang.String str44 = day39.toString();
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries12.createCopy(regularTimePeriod34, (org.jfree.data.time.RegularTimePeriod) day39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
//        java.util.Date date49 = fixedMillisecond46.getEnd();
//        java.util.Calendar calendar50 = null;
//        long long51 = fixedMillisecond46.getLastMillisecond(calendar50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond46.next();
//        java.lang.Number number53 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        java.util.Calendar calendar54 = null;
//        fixedMillisecond46.peg(calendar54);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442619736L + "'", long4 == 1560442619736L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560442619738L + "'", long15 == 1560442619738L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 35L + "'", long20 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "9-January-1900" + "'", str44.equals("9-January-1900"));
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560442619755L + "'", long48 == 1560442619755L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560442619755L + "'", long51 == 1560442619755L);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(number53);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries28.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.next();
//        long long42 = day39.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean48 = timeSeriesDataItem44.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem44.getPeriod();
//        timeSeries28.add(timeSeriesDataItem44);
//        timeSeries26.add(timeSeriesDataItem44, false);
//        java.util.Collection collection53 = timeSeries26.getTimePeriods();
//        boolean boolean54 = timeSeries26.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date57 = spreadsheetDate56.toDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
//        java.net.URL uRL67 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        java.util.Date date72 = day71.getEnd();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod60, "hi!", "", (java.lang.Class) wildcardClass66);
//        java.lang.String str76 = timeSeries75.getDomainDescription();
//        java.lang.String str77 = timeSeries75.getRangeDescription();
//        boolean boolean78 = timeSeries26.equals((java.lang.Object) timeSeries75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries24.addAndOrUpdate(timeSeries75);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar81 = null;
//        long long82 = fixedMillisecond80.getMiddleMillisecond(calendar81);
//        java.util.Date date83 = fixedMillisecond80.getEnd();
//        java.util.Calendar calendar84 = null;
//        long long85 = fixedMillisecond80.getLastMillisecond(calendar84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = fixedMillisecond80.next();
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80);
//        timeSeries24.setDomainDescription("ThreadContext");
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442620279L + "'", long31 == 1560442620279L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(uRL67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560442620294L + "'", long82 == 1560442620294L);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1560442620294L + "'", long85 == 1560442620294L);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, (java.lang.Number) 0.0d);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        java.util.Date date2 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean12 = timeSeriesDataItem8.equals((java.lang.Object) (byte) 10);
        timeSeriesDataItem8.setValue((java.lang.Number) 1560442534618L);
        java.lang.Number number15 = timeSeriesDataItem8.getValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1560442534618L + "'", number15.equals(1560442534618L));
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date2 = spreadsheetDate1.toDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass11 = seriesChangeEvent10.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date15 = spreadsheetDate14.toDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        java.util.Date date17 = day16.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date17, timeZone18);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod5, "hi!", "", (java.lang.Class) wildcardClass11);
//        java.lang.String str21 = timeSeries20.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries20.createCopy(3, 8);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getEnd();
//        int int33 = timeSeries28.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries28.setNotify(false);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date38 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.next();
//        long long42 = day39.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (double) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        boolean boolean48 = timeSeriesDataItem44.equals((java.lang.Object) (byte) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem44.getPeriod();
//        timeSeries28.add(timeSeriesDataItem44);
//        timeSeries26.add(timeSeriesDataItem44, false);
//        java.util.Collection collection53 = timeSeries26.getTimePeriods();
//        boolean boolean54 = timeSeries26.isEmpty();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date57 = spreadsheetDate56.toDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day58.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 10.0d);
//        java.lang.Class<?> wildcardClass66 = seriesChangeEvent65.getClass();
//        java.net.URL uRL67 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", (java.lang.Class) wildcardClass66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
//        java.util.Date date70 = spreadsheetDate69.toDate();
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        java.util.Date date72 = day71.getEnd();
//        java.util.TimeZone timeZone73 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date72, timeZone73);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod60, "hi!", "", (java.lang.Class) wildcardClass66);
//        java.lang.String str76 = timeSeries75.getDomainDescription();
//        java.lang.String str77 = timeSeries75.getRangeDescription();
//        boolean boolean78 = timeSeries26.equals((java.lang.Object) timeSeries75);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries24.addAndOrUpdate(timeSeries75);
//        java.lang.Comparable comparable80 = timeSeries75.getKey();
//        try {
//            timeSeries75.setMaximumItemCount((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560442621470L + "'", long31 == 1560442621470L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 10L + "'", long42 == 10L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(wildcardClass66);
//        org.junit.Assert.assertNull(uRL67);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertNotNull(comparable80);
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond2.getEnd();
//        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2);
//        timeSeries1.setNotify(false);
//        timeSeries1.setMaximumItemAge(1560442582209L);
//        timeSeries1.removeAgedItems(1560442588110L, true);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560442621499L + "'", long4 == 1560442621499L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-457), 3, (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

