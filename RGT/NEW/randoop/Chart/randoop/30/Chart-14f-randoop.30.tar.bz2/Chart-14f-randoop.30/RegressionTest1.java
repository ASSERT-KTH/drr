import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis0.configure();
//        double double2 = categoryAxis0.getCategoryMargin();
//        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getFirstMillisecond();
//        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) long5, "java.awt.Color[r=255,g=255,b=0]");
//        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = null;
//        try {
//            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        int int63 = xYPlot33.getSeriesCount();
        xYPlot33.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("hi!");
        double double68 = dateAxis67.getLowerMargin();
        float float69 = dateAxis67.getTickMarkOutsideLength();
        dateAxis67.setTickLabelsVisible(true);
        dateAxis67.setInverted(false);
        xYPlot33.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis67);
        org.jfree.data.Range range75 = dateAxis67.getDefaultAutoRange();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.05d + "'", double68 == 0.05d);
        org.junit.Assert.assertTrue("'" + float69 + "' != '" + 2.0f + "'", float69 == 2.0f);
        org.junit.Assert.assertNotNull(range75);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        categoryPlot37.setRangeAxisLocation((int) (byte) 100, axisLocation39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        categoryPlot37.datasetChanged(datasetChangeEvent41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot37.setFixedRangeAxisSpace(axisSpace43);
        categoryPlot37.configureDomainAxes();
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) layer47);
        java.util.Collection collection49 = categoryPlot37.getRangeMarkers((int) ' ', layer47);
        java.util.Collection collection50 = xYPlot33.getDomainMarkers(layer47);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot33.setQuadrantPaint(0, (java.awt.Paint) color52);
        java.lang.Object obj54 = xYPlot33.clone();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(obj54);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot11 = dateAxis10.getPlot();
        boolean boolean12 = dateAxis10.isNegativeArrowVisible();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis10.setTimeZone(timeZone13);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis10.setLabelFont(font15);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis10.valueToJava2D((double) 10.0f, rectangle2D18, rectangleEdge19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        java.util.List list25 = dateAxis10.refreshTicks(graphics2D21, axisState22, rectangle2D23, rectangleEdge24);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Image image27 = null;
        categoryPlot0.setBackgroundImage(image27);
        categoryPlot0.setForegroundAlpha((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(list25);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str1.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot0.setRenderers(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot33.getFixedRangeAxisSpace();
        boolean boolean36 = xYPlot33.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        xYPlot33.setFixedDomainAxisSpace(axisSpace37, false);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.clearRangeMarkers(500);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(255, valueAxis7, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Paint paint11 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str13 = axisLocation12.toString();
        categoryPlot0.setRangeAxisLocation(axisLocation12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str13.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
//        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis2.setTimeZone(timeZone5);
//        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis2.setLabelFont(font7);
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
//        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
//        dateAxis2.setAutoTickUnitSelection(false, true);
//        dateAxis2.setAutoRange(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
//        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
//        boolean boolean23 = dateAxis20.isVerticalTickLabels();
//        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
//        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis26.setTimeZone(timeZone29);
//        dateAxis20.setTimeZone(timeZone29);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
//        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
//        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) 0);
//        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double39 = dateAxis38.getLowerMargin();
//        java.awt.Color color40 = java.awt.Color.RED;
//        dateAxis38.setLabelPaint((java.awt.Paint) color40);
//        java.awt.Color color42 = color40.brighter();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getFirstMillisecond();
//        long long45 = day43.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot48 = dateAxis47.getPlot();
//        boolean boolean49 = dateAxis47.isNegativeArrowVisible();
//        boolean boolean50 = dateAxis47.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date53 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D54 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
//        double double56 = dateAxis52.dateToJava2D(date53, rectangle2D54, rectangleEdge55);
//        java.awt.geom.Rectangle2D rectangle2D57 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
//        double double59 = dateAxis47.dateToJava2D(date53, rectangle2D57, rectangleEdge58);
//        int int60 = day43.compareTo((java.lang.Object) date53);
//        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke62 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day43, (java.awt.Paint) color61, stroke62);
//        org.jfree.chart.plot.CategoryMarker categoryMarker64 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) '#', (java.awt.Paint) color42, stroke62);
//        xYPlot33.setDomainCrosshairStroke(stroke62);
//        org.junit.Assert.assertNull(plot3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(font7);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertNotNull(tickUnitSource18);
//        org.junit.Assert.assertNull(plot21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(plot27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(valueAxis35);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
//        org.junit.Assert.assertNotNull(color40);
//        org.junit.Assert.assertNotNull(color42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560409200000L + "'", long44 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 43629L + "'", long45 == 43629L);
//        org.junit.Assert.assertNull(plot48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
//        org.junit.Assert.assertNotNull(color61);
//        org.junit.Assert.assertNotNull(stroke62);
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double2 = dateAxis1.getLowerMargin();
//        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
//        dateAxis1.setLowerMargin((double) 0);
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
//        categoryPlot6.setRangeAxisLocation((int) (byte) 100, axisLocation8);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
//        categoryPlot6.datasetChanged(datasetChangeEvent10);
//        categoryPlot6.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
//        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot6.getOrientation();
//        boolean boolean16 = dateAxis1.hasListener((java.util.EventListener) categoryPlot6);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getFirstMillisecond();
//        long long19 = day17.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot22 = dateAxis21.getPlot();
//        boolean boolean23 = dateAxis21.isNegativeArrowVisible();
//        boolean boolean24 = dateAxis21.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D28 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
//        double double30 = dateAxis26.dateToJava2D(date27, rectangle2D28, rectangleEdge29);
//        java.awt.geom.Rectangle2D rectangle2D31 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
//        double double33 = dateAxis21.dateToJava2D(date27, rectangle2D31, rectangleEdge32);
//        int int34 = day17.compareTo((java.lang.Object) date27);
//        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day17, (java.awt.Paint) color35, stroke36);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double40 = dateAxis39.getLowerMargin();
//        float float41 = dateAxis39.getTickMarkOutsideLength();
//        dateAxis39.setTickLabelsVisible(true);
//        dateAxis39.setInverted(false);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = null;
//        dateAxis39.setTickUnit(dateTickUnit46);
//        double double48 = dateAxis39.getFixedDimension();
//        boolean boolean49 = categoryMarker37.equals((java.lang.Object) dateAxis39);
//        categoryPlot6.addDomainMarker(categoryMarker37);
//        java.awt.Stroke stroke51 = categoryMarker37.getOutlineStroke();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertNotNull(plotOrientation15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertNull(plot22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(color35);
//        org.junit.Assert.assertNotNull(stroke36);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 2.0f + "'", float41 == 2.0f);
//        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(stroke51);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot33.setRangeGridlinePaint(paint37);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot33.setDataset(255, xYDataset40);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        xYPlot33.setFixedDomainAxisSpace(axisSpace42, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = xYPlot33.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        org.jfree.data.Range range6 = dateAxis1.getRange();
        java.util.TimeZone timeZone7 = dateAxis1.getTimeZone();
        java.text.DateFormat dateFormat8 = null;
        dateAxis1.setDateFormatOverride(dateFormat8);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis1.setTickUnit(dateTickUnit8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot12 = dateAxis11.getPlot();
        boolean boolean13 = dateAxis11.isNegativeArrowVisible();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis11.setTimeZone(timeZone14);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis11.setLabelFont(font16);
        dateAxis1.setTickLabelFont(font16);
        java.awt.Stroke stroke19 = dateAxis1.getAxisLineStroke();
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Font font22 = dateAxis1.getLabelFont();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(font22);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D3 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
//        double double5 = dateAxis1.dateToJava2D(date2, rectangle2D3, rectangleEdge4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date2, timeZone6);
//        long long9 = day8.getSerialIndex();
//        java.util.Date date10 = day8.getStart();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(tickUnitSource7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertNotNull(date10);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot5 = dateAxis4.getPlot();
//        boolean boolean6 = dateAxis4.isNegativeArrowVisible();
//        boolean boolean7 = dateAxis4.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis4.dateToJava2D(date10, rectangle2D14, rectangleEdge15);
//        int int17 = day0.compareTo((java.lang.Object) date10);
//        long long18 = day0.getLastMillisecond();
//        int int19 = day0.getDayOfMonth();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        long long21 = day20.getFirstMillisecond();
//        long long22 = day20.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot25 = dateAxis24.getPlot();
//        boolean boolean26 = dateAxis24.isNegativeArrowVisible();
//        boolean boolean27 = dateAxis24.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D31 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
//        double double33 = dateAxis29.dateToJava2D(date30, rectangle2D31, rectangleEdge32);
//        java.awt.geom.Rectangle2D rectangle2D34 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
//        double double36 = dateAxis24.dateToJava2D(date30, rectangle2D34, rectangleEdge35);
//        int int37 = day20.compareTo((java.lang.Object) date30);
//        org.jfree.data.time.SerialDate serialDate38 = day20.getSerialDate();
//        int int39 = day0.compareTo((java.lang.Object) day20);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNull(plot5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43629L + "'", long22 == 43629L);
//        org.junit.Assert.assertNull(plot25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor3 = intervalMarker2.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = intervalMarker2.getLabelOffsetType();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean8 = valueMarker6.equals((java.lang.Object) 100L);
        boolean boolean10 = valueMarker6.equals((java.lang.Object) 3);
        boolean boolean11 = lengthAdjustmentType4.equals((java.lang.Object) valueMarker6);
        java.awt.Paint paint12 = valueMarker6.getPaint();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        double double15 = dateAxis14.getLowerMargin();
        float float16 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setTickLabelsVisible(true);
        dateAxis14.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis14.setTickUnit(dateTickUnit21);
        java.lang.String str23 = dateAxis14.getLabelToolTip();
        java.lang.Class<?> wildcardClass24 = dateAxis14.getClass();
        try {
            java.util.EventListener[] eventListenerArray25 = valueMarker6.getListeners((java.lang.Class) wildcardClass24);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.axis.DateAxis; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot5 = dateAxis4.getPlot();
//        boolean boolean6 = dateAxis4.isNegativeArrowVisible();
//        boolean boolean7 = dateAxis4.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis4.dateToJava2D(date10, rectangle2D14, rectangleEdge15);
//        int int17 = day0.compareTo((java.lang.Object) date10);
//        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color18, stroke19);
//        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double23 = dateAxis22.getLowerMargin();
//        float float24 = dateAxis22.getTickMarkOutsideLength();
//        dateAxis22.setTickLabelsVisible(true);
//        dateAxis22.setInverted(false);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
//        dateAxis22.setTickUnit(dateTickUnit29);
//        double double31 = dateAxis22.getFixedDimension();
//        boolean boolean32 = categoryMarker20.equals((java.lang.Object) dateAxis22);
//        org.jfree.chart.text.TextAnchor textAnchor33 = categoryMarker20.getLabelTextAnchor();
//        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
//        categoryPlot34.setRangeAxisLocation((int) (byte) 100, axisLocation36);
//        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d);
//        boolean boolean41 = valueMarker39.equals((java.lang.Object) 100L);
//        boolean boolean43 = valueMarker39.equals((java.lang.Object) 3);
//        categoryPlot34.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker39);
//        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
//        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis46.setTimeZone(timeZone49);
//        java.awt.Font font51 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis46.setLabelFont(font51);
//        java.awt.geom.Rectangle2D rectangle2D54 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
//        double double56 = dateAxis46.valueToJava2D((double) 10.0f, rectangle2D54, rectangleEdge55);
//        dateAxis46.setAutoTickUnitSelection(false, true);
//        dateAxis46.setRangeAboutValue(0.0d, (double) 2.0f);
//        org.jfree.data.Range range63 = categoryPlot34.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis46);
//        boolean boolean64 = categoryMarker20.equals((java.lang.Object) dateAxis46);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNull(plot5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(textAnchor33);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNull(plot47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(font51);
//        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
//        org.junit.Assert.assertNull(range63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setCategoryLabelPositionOffset(100);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        boolean boolean12 = categoryAxis0.equals((java.lang.Object) renderingHints10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean5 = sortOrder3.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder3);
        java.awt.Paint paint7 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.mapDatasetToDomainAxis(4, (int) (short) 0);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(255, valueAxis7, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Paint paint11 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateBottomOutset((double) 1);
        categoryPlot0.setInsets(rectangleInsets12, true);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets12.createInsetRectangle(rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        boolean boolean4 = dateAxis1.isVerticalTickLabels();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis12.dateToJava2D(date13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = dateAxis18.dateToJava2D(date19, rectangle2D20, rectangleEdge21);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis18.java2DToValue((double) (short) -1, rectangle2D24, rectangleEdge25);
        java.awt.Font font27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis18.setTickLabelFont(font27);
        dateAxis12.setLabelFont(font27);
        org.jfree.data.Range range30 = dateAxis12.getRange();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis12.setRightArrow(shape31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, categoryItemRenderer33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot35.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        categoryPlot35.setRenderer(categoryItemRenderer38);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        categoryPlot35.setDomainAxis(7, categoryAxis41, false);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int45 = color44.getAlpha();
        categoryPlot35.setRangeCrosshairPaint((java.awt.Paint) color44);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder47 = categoryPlot35.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryPlot35.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot35.getRangeAxisEdge((int) 'a');
        boolean boolean51 = categoryAxis10.equals((java.lang.Object) rectangleEdge50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        try {
            org.jfree.chart.axis.AxisState axisState53 = dateAxis1.draw(graphics2D5, (double) '#', rectangle2D7, rectangle2D8, rectangleEdge50, plotRenderingInfo52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-9.223372036854776E18d) + "'", double26 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 255 + "'", int45 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        categoryPlot0.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        int int5 = categoryPlot0.getDatasetCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawBackgroundImage(graphics2D8, rectangle2D9);
        java.lang.Object obj11 = categoryPlot0.clone();
        categoryPlot0.clearDomainAxes();
        float float13 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        xYPlot33.zoomRangeAxes((double) 9, plotRenderingInfo39, point2D40);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
        categoryPlot42.setRangeAxisLocation((int) (byte) 100, axisLocation44);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = null;
        categoryPlot42.datasetChanged(datasetChangeEvent46);
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        categoryPlot42.setFixedRangeAxisSpace(axisSpace48);
        categoryPlot42.configureDomainAxes();
        float float51 = categoryPlot42.getForegroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation52, plotOrientation53);
        categoryPlot42.setRangeAxisLocation(axisLocation52, false);
        xYPlot33.setDomainAxisLocation(axisLocation52, true);
        boolean boolean59 = xYPlot33.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 1.0f + "'", float51 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D((-9.223372036854776E18d), rectangle2D3, rectangleEdge4);
        java.lang.Object obj6 = dateAxis1.clone();
        dateAxis1.setFixedDimension((double) 0);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        double double11 = dateAxis10.getLowerMargin();
        java.awt.Color color12 = java.awt.Color.RED;
        dateAxis10.setLabelPaint((java.awt.Paint) color12);
        double double14 = dateAxis10.getFixedDimension();
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis10.setLabelFont(font15);
        dateAxis1.setLabelFont(font15);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        org.jfree.data.Range range6 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = dateAxis8.getPlot();
        boolean boolean10 = dateAxis8.isNegativeArrowVisible();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis8.setTimeZone(timeZone11);
        org.jfree.data.Range range13 = dateAxis8.getRange();
        dateAxis1.setRange(range13);
        boolean boolean15 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setRangeAxisLocation((int) (byte) 100, axisLocation6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        boolean boolean10 = dateAxis1.hasListener((java.util.EventListener) categoryPlot4);
        float float11 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot4.getDataset();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        double double16 = dateAxis15.getLowerMargin();
        float float17 = dateAxis15.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot18.setRangeAxisLocation((int) (byte) 100, axisLocation20);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        categoryPlot18.datasetChanged(datasetChangeEvent22);
        boolean boolean24 = dateAxis15.hasListener((java.util.EventListener) categoryPlot18);
        float float25 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot18.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean31 = valueMarker29.equals((java.lang.Object) 100L);
        boolean boolean33 = valueMarker29.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = categoryPlot18.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker29, layer34);
        java.util.Collection collection36 = categoryPlot4.getRangeMarkers(layer34);
        categoryPlot4.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(collection36);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        double double3 = categoryAxis0.getLowerMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 2019);
        boolean boolean7 = categoryAxis0.equals((java.lang.Object) 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot33.setRangeGridlinePaint(paint37);
        java.awt.Stroke stroke39 = xYPlot33.getDomainCrosshairStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        intervalMarker42.setStartValue((double) (short) 10);
        java.lang.Object obj45 = intervalMarker42.clone();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        intervalMarker42.setLabelPaint((java.awt.Paint) color46);
        xYPlot33.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(color46);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot5 = dateAxis4.getPlot();
//        boolean boolean6 = dateAxis4.isNegativeArrowVisible();
//        boolean boolean7 = dateAxis4.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis4.dateToJava2D(date10, rectangle2D14, rectangleEdge15);
//        int int17 = day0.compareTo((java.lang.Object) date10);
//        org.jfree.data.time.SerialDate serialDate18 = day0.getSerialDate();
//        org.jfree.chart.JFreeChart jFreeChart20 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 9, jFreeChart20, chartChangeEventType21);
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = chartChangeEvent22.getType();
//        int int24 = day0.compareTo((java.lang.Object) chartChangeEvent22);
//        long long25 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNull(plot5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(chartChangeEventType21);
//        org.junit.Assert.assertNotNull(chartChangeEventType23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560452399999L + "'", long25 == 1560452399999L);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.configure();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot3.setRenderer(categoryItemRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot3.setDomainAxis(7, categoryAxis9, false);
        java.awt.Paint paint12 = null;
        categoryPlot3.setBackgroundPaint(paint12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot3.getRenderer((int) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        double double19 = dateAxis18.getLowerMargin();
        float float20 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        categoryPlot21.setRangeAxisLocation((int) (byte) 100, axisLocation23);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        categoryPlot21.datasetChanged(datasetChangeEvent25);
        boolean boolean27 = dateAxis18.hasListener((java.util.EventListener) categoryPlot21);
        float float28 = categoryPlot21.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot21.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace31 = categoryAxis0.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) categoryPlot3, rectangle2D16, rectangleEdge29, axisSpace30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace40 = xYPlot33.getFixedDomainAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date44 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = dateAxis43.dateToJava2D(date44, rectangle2D45, rectangleEdge46);
        org.jfree.chart.event.AxisChangeListener axisChangeListener48 = null;
        dateAxis43.addChangeListener(axisChangeListener48);
        xYPlot33.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis43, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation52 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        xYPlot33.setOrientation(plotOrientation52);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation52);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        java.awt.Paint paint36 = xYPlot33.getDomainGridlinePaint();
        boolean boolean37 = xYPlot33.isDomainZoomable();
        java.awt.Stroke stroke38 = xYPlot33.getDomainCrosshairStroke();
        java.awt.Stroke stroke39 = xYPlot33.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer2 = null;
        java.util.Collection collection3 = categoryPlot0.getDomainMarkers((int) (short) 100, layer2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean8 = categoryPlot7.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot7.getRendererForDataset(categoryDataset9);
        org.jfree.chart.util.SortOrder sortOrder11 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean13 = sortOrder11.equals((java.lang.Object) 10L);
        categoryPlot7.setRowRenderingOrder(sortOrder11);
        categoryPlot4.setColumnRenderingOrder(sortOrder11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomRangeAxes((double) 0.0f, plotRenderingInfo17, point2D18);
        categoryPlot4.clearAnnotations();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        java.awt.Stroke stroke25 = intervalMarker24.getStroke();
        boolean boolean26 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.junit.Assert.assertNull(collection3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        intervalMarker2.setStartValue((double) (short) 10);
        java.lang.Object obj5 = intervalMarker2.clone();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        intervalMarker2.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.text.TextAnchor textAnchor8 = intervalMarker2.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        boolean boolean3 = objectList1.equals((java.lang.Object) "13-June-2019");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        double double38 = dateAxis37.getLowerMargin();
        float float39 = dateAxis37.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot40.setRangeAxisLocation((int) (byte) 100, axisLocation42);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        categoryPlot40.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = dateAxis37.hasListener((java.util.EventListener) categoryPlot40);
        float float47 = categoryPlot40.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot40.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean53 = valueMarker51.equals((java.lang.Object) 100L);
        boolean boolean55 = valueMarker51.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean57 = categoryPlot40.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker51, layer56);
        java.util.Collection collection58 = xYPlot33.getDomainMarkers((-16777216), layer56);
        xYPlot33.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace60 = xYPlot33.getFixedRangeAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
        double double63 = dateAxis62.getLowerMargin();
        float float64 = dateAxis62.getTickMarkOutsideLength();
        dateAxis62.setTickLabelsVisible(true);
        dateAxis62.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit69 = null;
        dateAxis62.setTickUnit(dateTickUnit69);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot73 = dateAxis72.getPlot();
        boolean boolean74 = dateAxis72.isNegativeArrowVisible();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis72.setTimeZone(timeZone75);
        java.awt.Font font77 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis72.setLabelFont(font77);
        dateAxis62.setTickLabelFont(font77);
        java.awt.Stroke stroke80 = dateAxis62.getAxisLineStroke();
        xYPlot33.setDomainCrosshairStroke(stroke80);
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation85 = null;
        categoryPlot83.setRangeAxisLocation((int) (byte) 100, axisLocation85);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent87 = null;
        categoryPlot83.datasetChanged(datasetChangeEvent87);
        org.jfree.chart.axis.ValueAxis valueAxis90 = null;
        categoryPlot83.setRangeAxis(255, valueAxis90, false);
        org.jfree.chart.LegendItemCollection legendItemCollection93 = categoryPlot83.getLegendItems();
        java.awt.Paint paint94 = categoryPlot83.getOutlinePaint();
        try {
            xYPlot33.setQuadrantPaint((int) ' ', paint94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (32) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertNull(axisSpace60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.05d + "'", double63 == 0.05d);
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 2.0f + "'", float64 == 2.0f);
        org.junit.Assert.assertNull(plot73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(legendItemCollection93);
        org.junit.Assert.assertNotNull(paint94);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        double double1 = categoryAxis0.getCategoryMargin();
//        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (short) -1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getFirstMillisecond();
//        long long6 = day4.getSerialIndex();
//        int int7 = day4.getYear();
//        int int8 = day4.getDayOfMonth();
//        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
//        java.awt.geom.Rectangle2D rectangle2D12 = null;
//        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation14);
//        try {
//            double double16 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) day4, (java.lang.Comparable) 5, categoryDataset10, (-1.0d), rectangle2D12, rectangleEdge15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
//        org.junit.Assert.assertNotNull(font3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560409200000L + "'", long5 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertNotNull(axisLocation13);
//        org.junit.Assert.assertNotNull(plotOrientation14);
//        org.junit.Assert.assertNotNull(rectangleEdge15);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        xYPlot33.clearDomainMarkers();
        java.lang.String str37 = xYPlot33.getPlotType();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "XY Plot" + "'", str37.equals("XY Plot"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        xYPlot33.setRangeCrosshairValue((double) (short) 0);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot33.setDataset(12, xYDataset38);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Color color4 = java.awt.Color.getColor("ChartChangeEventType.NEW_DATASET", 500);
        java.awt.Color color5 = java.awt.Color.cyan;
        java.awt.Color color6 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        float[] floatArray12 = new float[] { (byte) 10, 10, (short) 1, 0L };
        float[] floatArray13 = color5.getColorComponents(colorSpace7, floatArray12);
        java.awt.Color color14 = java.awt.Color.cyan;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace16 = color15.getColorSpace();
        float[] floatArray21 = new float[] { (byte) 10, 10, (short) 1, 0L };
        float[] floatArray22 = color14.getColorComponents(colorSpace16, floatArray21);
        float[] floatArray23 = color4.getColorComponents(colorSpace7, floatArray22);
        float[] floatArray24 = color1.getComponents(floatArray23);
        float[] floatArray25 = color0.getColorComponents(floatArray23);
        int int26 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        intervalMarker11.removeChangeListener(markerChangeListener13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot0.removeRangeMarker(10, (org.jfree.chart.plot.Marker) intervalMarker11, layer15);
        intervalMarker11.setEndValue((double) ' ');
        java.awt.Paint paint19 = intervalMarker11.getPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (short) -1);
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        double double10 = dateAxis9.getLowerMargin();
        float float11 = dateAxis9.getTickMarkOutsideLength();
        java.util.Date date12 = dateAxis9.getMinimumDate();
        boolean boolean13 = categoryAnchor7.equals((java.lang.Object) dateAxis9);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        categoryPlot17.setRenderer(categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot17.setDomainAxis(7, categoryAxis23, false);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int27 = color26.getAlpha();
        categoryPlot17.setRangeCrosshairPaint((java.awt.Paint) color26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot17.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryPlot17.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot17.getRangeAxisEdge((int) 'a');
        try {
            double double33 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor7, 6, 7, rectangle2D16, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 255 + "'", int27 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        double double38 = dateAxis37.getLowerMargin();
        float float39 = dateAxis37.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot40.setRangeAxisLocation((int) (byte) 100, axisLocation42);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        categoryPlot40.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = dateAxis37.hasListener((java.util.EventListener) categoryPlot40);
        float float47 = categoryPlot40.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot40.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean53 = valueMarker51.equals((java.lang.Object) 100L);
        boolean boolean55 = valueMarker51.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean57 = categoryPlot40.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker51, layer56);
        java.util.Collection collection58 = xYPlot33.getDomainMarkers((-16777216), layer56);
        xYPlot33.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        xYPlot33.setDataset(xYDataset60);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
//        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis2.setTimeZone(timeZone5);
//        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis2.setLabelFont(font7);
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
//        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
//        dateAxis2.setAutoTickUnitSelection(false, true);
//        dateAxis2.setAutoRange(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
//        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
//        boolean boolean23 = dateAxis20.isVerticalTickLabels();
//        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
//        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis26.setTimeZone(timeZone29);
//        dateAxis20.setTimeZone(timeZone29);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
//        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
//        xYPlot33.configureDomainAxes();
//        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot33.getFixedRangeAxisSpace();
//        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double38 = dateAxis37.getLowerMargin();
//        java.awt.Paint paint39 = dateAxis37.getTickMarkPaint();
//        dateAxis37.setLowerMargin((double) 0);
//        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
//        categoryPlot42.setRangeAxisLocation((int) (byte) 100, axisLocation44);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = null;
//        categoryPlot42.datasetChanged(datasetChangeEvent46);
//        categoryPlot42.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
//        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot42.getOrientation();
//        boolean boolean52 = dateAxis37.hasListener((java.util.EventListener) categoryPlot42);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        long long54 = day53.getFirstMillisecond();
//        long long55 = day53.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot58 = dateAxis57.getPlot();
//        boolean boolean59 = dateAxis57.isNegativeArrowVisible();
//        boolean boolean60 = dateAxis57.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date63 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D64 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
//        double double66 = dateAxis62.dateToJava2D(date63, rectangle2D64, rectangleEdge65);
//        java.awt.geom.Rectangle2D rectangle2D67 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
//        double double69 = dateAxis57.dateToJava2D(date63, rectangle2D67, rectangleEdge68);
//        int int70 = day53.compareTo((java.lang.Object) date63);
//        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker73 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day53, (java.awt.Paint) color71, stroke72);
//        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double76 = dateAxis75.getLowerMargin();
//        float float77 = dateAxis75.getTickMarkOutsideLength();
//        dateAxis75.setTickLabelsVisible(true);
//        dateAxis75.setInverted(false);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit82 = null;
//        dateAxis75.setTickUnit(dateTickUnit82);
//        double double84 = dateAxis75.getFixedDimension();
//        boolean boolean85 = categoryMarker73.equals((java.lang.Object) dateAxis75);
//        categoryPlot42.addDomainMarker(categoryMarker73);
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType87 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        boolean boolean88 = categoryMarker73.equals((java.lang.Object) chartChangeEventType87);
//        xYPlot33.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker73);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer91 = xYPlot33.getRenderer(0);
//        boolean boolean92 = xYPlot33.isRangeCrosshairLockedOnData();
//        boolean boolean93 = xYPlot33.isRangeCrosshairVisible();
//        org.junit.Assert.assertNull(plot3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(font7);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertNotNull(tickUnitSource18);
//        org.junit.Assert.assertNull(plot21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(plot27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(axisSpace35);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
//        org.junit.Assert.assertNotNull(paint39);
//        org.junit.Assert.assertNotNull(plotOrientation51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560409200000L + "'", long54 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43629L + "'", long55 == 43629L);
//        org.junit.Assert.assertNull(plot58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(color71);
//        org.junit.Assert.assertNotNull(stroke72);
//        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 2.0f + "'", float77 == 2.0f);
//        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(chartChangeEventType87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNull(xYItemRenderer91);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis1.valueToJava2D((double) 10.0f, rectangle2D9, rectangleEdge10);
        java.lang.String str12 = dateAxis1.getLabelToolTip();
        dateAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str12);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot5 = dateAxis4.getPlot();
//        boolean boolean6 = dateAxis4.isNegativeArrowVisible();
//        boolean boolean7 = dateAxis4.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis4.dateToJava2D(date10, rectangle2D14, rectangleEdge15);
//        int int17 = day0.compareTo((java.lang.Object) date10);
//        org.jfree.data.time.SerialDate serialDate18 = day0.getSerialDate();
//        long long19 = day0.getMiddleMillisecond();
//        java.util.Date date20 = day0.getStart();
//        long long21 = day0.getSerialIndex();
//        java.util.Date date22 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNull(plot5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560452399999L + "'", long19 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43629L + "'", long21 == 43629L);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        java.awt.Stroke stroke36 = xYPlot33.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        java.awt.Paint paint36 = xYPlot33.getDomainGridlinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation37 = null;
        try {
            xYPlot33.addAnnotation(xYAnnotation37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        int int35 = xYPlot33.getDatasetCount();
        int int36 = xYPlot33.getDatasetCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder37 = xYPlot33.getSeriesRenderingOrder();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder37);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color3);
        double double5 = dateAxis1.getFixedDimension();
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font6);
        java.lang.Class<?> wildcardClass8 = font6.getClass();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SortOrder.DESCENDING");
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot0.setRangeAxisLocation(7, axisLocation4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot0.setRenderer(categoryItemRenderer6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace40 = xYPlot33.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray42 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer41 };
        xYPlot33.setRenderers(xYItemRendererArray42);
        java.awt.Paint paint44 = xYPlot33.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(xYItemRendererArray42);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        java.awt.Paint paint9 = null;
        categoryPlot0.setBackgroundPaint(paint9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(axisLocation11);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = dateAxis1.clone();
        dateAxis1.setTickMarkOutsideLength((float) (byte) 1);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.valueToJava2D((-9.223372036854776E18d), rectangle2D8, rectangleEdge9);
        java.lang.String str11 = dateAxis6.getLabelToolTip();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot14 = dateAxis13.getPlot();
        boolean boolean15 = dateAxis13.isNegativeArrowVisible();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis13.setTimeZone(timeZone16);
        org.jfree.data.Range range18 = dateAxis13.getRange();
        dateAxis6.setDefaultAutoRange(range18);
        dateAxis6.setTickMarksVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot24 = dateAxis23.getPlot();
        boolean boolean25 = dateAxis23.isNegativeArrowVisible();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis23.setTimeZone(timeZone26);
        org.jfree.data.Range range28 = dateAxis23.getRange();
        dateAxis6.setRangeWithMargins(range28, true, true);
        dateAxis1.setRange(range28);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        int int63 = xYPlot33.getSeriesCount();
        xYPlot33.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("hi!");
        double double68 = dateAxis67.getLowerMargin();
        float float69 = dateAxis67.getTickMarkOutsideLength();
        dateAxis67.setTickLabelsVisible(true);
        dateAxis67.setInverted(false);
        xYPlot33.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis67);
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis("hi!");
        double double77 = dateAxis76.getUpperBound();
        dateAxis76.setTickMarkOutsideLength((float) (byte) 100);
        dateAxis76.setTickMarkOutsideLength((float) 255);
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date84 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        double double87 = dateAxis83.dateToJava2D(date84, rectangle2D85, rectangleEdge86);
        org.jfree.chart.axis.DateAxis dateAxis89 = new org.jfree.chart.axis.DateAxis("hi!");
        double double90 = dateAxis89.getLowerMargin();
        float float91 = dateAxis89.getTickMarkOutsideLength();
        dateAxis89.setTickLabelsVisible(true);
        org.jfree.chart.axis.Timeline timeline94 = dateAxis89.getTimeline();
        dateAxis83.setTimeline(timeline94);
        dateAxis76.setTimeline(timeline94);
        org.jfree.data.Range range97 = xYPlot33.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis76);
        org.jfree.data.xy.XYDataset xYDataset98 = null;
        xYPlot33.setDataset(xYDataset98);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.05d + "'", double68 == 0.05d);
        org.junit.Assert.assertTrue("'" + float69 + "' != '" + 2.0f + "'", float69 == 2.0f);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 1.0d + "'", double77 == 1.0d);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.05d + "'", double90 == 0.05d);
        org.junit.Assert.assertTrue("'" + float91 + "' != '" + 2.0f + "'", float91 == 2.0f);
        org.junit.Assert.assertNotNull(timeline94);
        org.junit.Assert.assertNull(range97);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot33.getRangeAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot38.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot38.setRenderer(categoryItemRenderer41);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean45 = categoryPlot44.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot44.getRendererForDataset(categoryDataset46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot44.setDomainAxisLocation(0, axisLocation49);
        categoryPlot38.setRangeAxisLocation((int) (byte) 100, axisLocation49);
        categoryPlot38.setRangeCrosshairLockedOnData(true);
        java.awt.Image image54 = null;
        categoryPlot38.setBackgroundImage(image54);
        valueAxis37.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        valueAxis37.setTickMarksVisible(false);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        categoryPlot0.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        int int5 = categoryPlot0.getDatasetCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        categoryPlot0.drawBackgroundImage(graphics2D8, rectangle2D9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean12 = categoryPlot11.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot11.getRendererForDataset(categoryDataset13);
        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean17 = sortOrder15.equals((java.lang.Object) 10L);
        categoryPlot11.setRowRenderingOrder(sortOrder15);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot22 = dateAxis21.getPlot();
        boolean boolean23 = dateAxis21.isNegativeArrowVisible();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis21.setTimeZone(timeZone24);
        java.awt.Font font26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis21.setLabelFont(font26);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = dateAxis21.valueToJava2D((double) 10.0f, rectangle2D29, rectangleEdge30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.axis.AxisState axisState33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        java.util.List list36 = dateAxis21.refreshTicks(graphics2D32, axisState33, rectangle2D34, rectangleEdge35);
        categoryPlot11.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor38 = categoryPlot11.getDomainGridlinePosition();
        categoryPlot0.setDomainGridlinePosition(categoryAnchor38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot45 = dateAxis44.getPlot();
        boolean boolean46 = dateAxis44.isNegativeArrowVisible();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis44.setTimeZone(timeZone47);
        java.awt.Font font49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis44.setLabelFont(font49);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = dateAxis44.valueToJava2D((double) 10.0f, rectangle2D52, rectangleEdge53);
        dateAxis44.setAutoTickUnitSelection(false, true);
        dateAxis44.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource60 = dateAxis44.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot63 = dateAxis62.getPlot();
        boolean boolean64 = dateAxis62.isNegativeArrowVisible();
        boolean boolean65 = dateAxis62.isVerticalTickLabels();
        java.util.TimeZone timeZone66 = dateAxis62.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot69 = dateAxis68.getPlot();
        boolean boolean70 = dateAxis68.isNegativeArrowVisible();
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis68.setTimeZone(timeZone71);
        dateAxis62.setTimeZone(timeZone71);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = null;
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis62, xYItemRenderer74);
        java.awt.Paint paint76 = xYPlot75.getRangeZeroBaselinePaint();
        boolean boolean77 = xYPlot75.isRangeCrosshairLockedOnData();
        java.awt.Paint paint78 = xYPlot75.getDomainGridlinePaint();
        boolean boolean79 = xYPlot75.isDomainZoomable();
        boolean boolean80 = xYPlot75.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D81 = xYPlot75.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) 1560495599999L, plotRenderingInfo41, point2D81);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(list36);
        org.junit.Assert.assertNotNull(categoryAnchor38);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource60);
        org.junit.Assert.assertNull(plot63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(plot69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(point2D81);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setRangeAxisLocation((int) (byte) 100, axisLocation6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        boolean boolean10 = dateAxis1.hasListener((java.util.EventListener) categoryPlot4);
        float float11 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean17 = valueMarker15.equals((java.lang.Object) 100L);
        boolean boolean19 = valueMarker15.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean21 = categoryPlot4.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker15, layer20);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        double double24 = dateAxis23.getLowerMargin();
        float float25 = dateAxis23.getTickMarkOutsideLength();
        dateAxis23.setTickLabelsVisible(true);
        dateAxis23.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot32 = dateAxis31.getPlot();
        boolean boolean33 = dateAxis31.isNegativeArrowVisible();
        boolean boolean34 = dateAxis31.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = dateAxis36.dateToJava2D(date37, rectangle2D38, rectangleEdge39);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = dateAxis31.dateToJava2D(date37, rectangle2D41, rectangleEdge42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis31.setTickMarkStroke(stroke44);
        dateAxis23.setAxisLineStroke(stroke44);
        java.lang.Object obj47 = dateAxis23.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot48.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        categoryPlot48.setRenderer(categoryItemRenderer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        categoryPlot48.setDomainAxis(7, categoryAxis54, false);
        dateAxis23.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot48);
        categoryPlot48.setForegroundAlpha((float) 6);
        java.awt.Stroke stroke60 = categoryPlot48.getDomainGridlineStroke();
        boolean boolean61 = layer20.equals((java.lang.Object) stroke60);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        xYPlot33.configureDomainAxes();
        xYPlot33.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = dateAxis1.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource3);
        boolean boolean5 = dateAxis1.isTickMarksVisible();
        java.awt.Color color6 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        dateAxis1.setLabelPaint((java.awt.Paint) color6);
        java.awt.Font font9 = dateAxis1.getTickLabelFont();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = dateAxis1.hasListener(eventListener4);
        boolean boolean6 = dateAxis1.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot7.setRangeAxisLocation((int) (byte) 100, axisLocation9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot7.datasetChanged(datasetChangeEvent11);
        categoryPlot7.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        double double19 = dateAxis18.getLowerMargin();
        float float20 = dateAxis18.getTickMarkOutsideLength();
        dateAxis18.setTickLabelsVisible(true);
        dateAxis18.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis18.setTickUnit(dateTickUnit25);
        boolean boolean27 = dateAxis1.equals((java.lang.Object) dateTickUnit25);
        org.jfree.chart.text.TextAnchor textAnchor28 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double31 = rectangleInsets29.calculateRightInset((double) (byte) 0);
        double double33 = rectangleInsets29.calculateTopOutset((double) 1);
        double double35 = rectangleInsets29.trimWidth(0.0d);
        boolean boolean36 = textAnchor28.equals((java.lang.Object) rectangleInsets29);
        dateAxis1.setTickLabelInsets(rectangleInsets29);
        java.awt.Color color38 = java.awt.Color.YELLOW;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color38);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.0d + "'", double33 == 2.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-8.0d) + "'", double35 == (-8.0d));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot11 = dateAxis10.getPlot();
        boolean boolean12 = dateAxis10.isNegativeArrowVisible();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis10.setTimeZone(timeZone13);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis10.setLabelFont(font15);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis10.valueToJava2D((double) 10.0f, rectangle2D18, rectangleEdge19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        java.util.List list25 = dateAxis10.refreshTicks(graphics2D21, axisState22, rectangle2D23, rectangleEdge24);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setBackgroundAlpha((float) 255);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(list25);
        org.junit.Assert.assertNotNull(categoryAnchor27);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D((-9.223372036854776E18d), rectangle2D3, rectangleEdge4);
        dateAxis1.setTickMarksVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        java.awt.Shape shape11 = defaultDrawingSupplier9.getNextShape();
        dateAxis1.setRightArrow(shape11);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 9, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        categoryPlot5.setRangeAxisLocation((int) (byte) 100, axisLocation7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        categoryPlot5.datasetChanged(datasetChangeEvent9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace11);
        categoryPlot5.configureDomainAxes();
        boolean boolean14 = chartChangeEventType4.equals((java.lang.Object) categoryPlot5);
        java.awt.Stroke stroke15 = categoryPlot5.getOutlineStroke();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            categoryPlot5.drawOutline(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis1.setTickUnit(dateTickUnit8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot12 = dateAxis11.getPlot();
        boolean boolean13 = dateAxis11.isNegativeArrowVisible();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis11.setTimeZone(timeZone14);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis11.setLabelFont(font16);
        dateAxis1.setTickLabelFont(font16);
        java.lang.String str19 = dateAxis1.getLabel();
        boolean boolean21 = dateAxis1.isHiddenValue((long) 4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = dateAxis1.getTickUnit();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getLowerMargin();
        java.awt.Color color26 = java.awt.Color.RED;
        dateAxis24.setLabelPaint((java.awt.Paint) color26);
        java.awt.Color color28 = color26.brighter();
        boolean boolean30 = color26.equals((java.lang.Object) (-1.0d));
        java.awt.Color color31 = color26.darker();
        dateAxis1.setTickMarkPaint((java.awt.Paint) color26);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(dateTickUnit22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        java.awt.Stroke stroke5 = intervalMarker4.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "hi!", paint1, stroke5);
        categoryMarker6.setKey((java.lang.Comparable) 4.0d);
        java.awt.Color color9 = java.awt.Color.black;
        categoryMarker6.setLabelPaint((java.awt.Paint) color9);
        categoryMarker6.setKey((java.lang.Comparable) (-16777216));
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color9);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
//        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis2.setTimeZone(timeZone5);
//        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis2.setLabelFont(font7);
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
//        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
//        dateAxis2.setAutoTickUnitSelection(false, true);
//        dateAxis2.setAutoRange(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
//        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
//        boolean boolean23 = dateAxis20.isVerticalTickLabels();
//        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
//        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis26.setTimeZone(timeZone29);
//        dateAxis20.setTimeZone(timeZone29);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
//        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
//        xYPlot33.configureDomainAxes();
//        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot33.getFixedRangeAxisSpace();
//        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double38 = dateAxis37.getLowerMargin();
//        java.awt.Paint paint39 = dateAxis37.getTickMarkPaint();
//        dateAxis37.setLowerMargin((double) 0);
//        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
//        categoryPlot42.setRangeAxisLocation((int) (byte) 100, axisLocation44);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = null;
//        categoryPlot42.datasetChanged(datasetChangeEvent46);
//        categoryPlot42.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
//        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot42.getOrientation();
//        boolean boolean52 = dateAxis37.hasListener((java.util.EventListener) categoryPlot42);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        long long54 = day53.getFirstMillisecond();
//        long long55 = day53.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot58 = dateAxis57.getPlot();
//        boolean boolean59 = dateAxis57.isNegativeArrowVisible();
//        boolean boolean60 = dateAxis57.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date63 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D64 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
//        double double66 = dateAxis62.dateToJava2D(date63, rectangle2D64, rectangleEdge65);
//        java.awt.geom.Rectangle2D rectangle2D67 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
//        double double69 = dateAxis57.dateToJava2D(date63, rectangle2D67, rectangleEdge68);
//        int int70 = day53.compareTo((java.lang.Object) date63);
//        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker73 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day53, (java.awt.Paint) color71, stroke72);
//        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double76 = dateAxis75.getLowerMargin();
//        float float77 = dateAxis75.getTickMarkOutsideLength();
//        dateAxis75.setTickLabelsVisible(true);
//        dateAxis75.setInverted(false);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit82 = null;
//        dateAxis75.setTickUnit(dateTickUnit82);
//        double double84 = dateAxis75.getFixedDimension();
//        boolean boolean85 = categoryMarker73.equals((java.lang.Object) dateAxis75);
//        categoryPlot42.addDomainMarker(categoryMarker73);
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType87 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        boolean boolean88 = categoryMarker73.equals((java.lang.Object) chartChangeEventType87);
//        xYPlot33.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker73);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer91 = xYPlot33.getRenderer(0);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer93 = null;
//        xYPlot33.setRenderer(13, xYItemRenderer93);
//        org.jfree.chart.annotations.XYAnnotation xYAnnotation95 = null;
//        try {
//            xYPlot33.addAnnotation(xYAnnotation95);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(plot3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(font7);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertNotNull(tickUnitSource18);
//        org.junit.Assert.assertNull(plot21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(plot27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(axisSpace35);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
//        org.junit.Assert.assertNotNull(paint39);
//        org.junit.Assert.assertNotNull(plotOrientation51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560409200000L + "'", long54 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43629L + "'", long55 == 43629L);
//        org.junit.Assert.assertNull(plot58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(color71);
//        org.junit.Assert.assertNotNull(stroke72);
//        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 2.0f + "'", float77 == 2.0f);
//        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(chartChangeEventType87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNull(xYItemRenderer91);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis1.valueToJava2D((double) 10.0f, rectangle2D9, rectangleEdge10);
        dateAxis1.setAutoTickUnitSelection(false, true);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis1.getStandardTickUnits();
        double double18 = dateAxis1.getAutoRangeMinimumSize();
        try {
            dateAxis1.setRangeAboutValue(8.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8.5) <= upper (7.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis((int) (byte) 100);
        xYPlot33.setRangeCrosshairValue((double) 1, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation43 = null;
        try {
            xYPlot33.addAnnotation(xYAnnotation43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setWeight(0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        dateAxis1.setLowerMargin((double) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot6.setRangeAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent10);
        categoryPlot6.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot6.getOrientation();
        boolean boolean16 = dateAxis1.hasListener((java.util.EventListener) categoryPlot6);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot6.getRendererForDataset(categoryDataset17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryItemRenderer18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        boolean boolean8 = categoryPlot0.isDomainGridlinesVisible();
        float float9 = categoryPlot0.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot0.getDataset();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNull(categoryDataset10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        categoryPlot3.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot3.setRenderer(500, categoryItemRenderer9, false);
        boolean boolean12 = numberAxis0.equals((java.lang.Object) false);
        numberAxis0.setVisible(false);
        numberAxis0.setUpperMargin(1.0E-8d);
        double double17 = numberAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D((-9.223372036854776E18d), rectangle2D3, rectangleEdge4);
        java.lang.String str6 = dateAxis1.getLabelToolTip();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = dateAxis8.getPlot();
        boolean boolean10 = dateAxis8.isNegativeArrowVisible();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis8.setTimeZone(timeZone11);
        org.jfree.data.Range range13 = dateAxis8.getRange();
        dateAxis1.setDefaultAutoRange(range13);
        dateAxis1.setTickMarksVisible(true);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.dateToJava2D(date22, rectangle2D23, rectangleEdge24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double28 = rectangleInsets26.extendWidth((double) (byte) 0);
        dateAxis21.setTickLabelInsets(rectangleInsets26);
        double double31 = rectangleInsets26.calculateBottomOutset(4.0d);
        dateAxis1.setLabelInsets(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 16.0d + "'", double28 == 16.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        xYPlot33.configureDomainAxes();
        xYPlot33.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        double double5 = dateAxis4.getLowerMargin();
        float float6 = dateAxis4.getTickMarkOutsideLength();
        dateAxis4.setTickLabelsVisible(true);
        dateAxis4.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot13 = dateAxis12.getPlot();
        boolean boolean14 = dateAxis12.isNegativeArrowVisible();
        boolean boolean15 = dateAxis12.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.dateToJava2D(date18, rectangle2D19, rectangleEdge20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis12.dateToJava2D(date18, rectangle2D22, rectangleEdge23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis12.setTickMarkStroke(stroke25);
        dateAxis4.setAxisLineStroke(stroke25);
        categoryPlot0.setOutlineStroke(stroke25);
        categoryPlot0.setRangeCrosshairValue((double) 100L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        double double38 = dateAxis37.getLowerMargin();
        float float39 = dateAxis37.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot40.setRangeAxisLocation((int) (byte) 100, axisLocation42);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        categoryPlot40.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = dateAxis37.hasListener((java.util.EventListener) categoryPlot40);
        float float47 = categoryPlot40.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot40.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean53 = valueMarker51.equals((java.lang.Object) 100L);
        boolean boolean55 = valueMarker51.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean57 = categoryPlot40.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker51, layer56);
        java.util.Collection collection58 = xYPlot33.getDomainMarkers((-16777216), layer56);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = xYPlot33.getRendererForDataset(xYDataset59);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertNull(xYItemRenderer60);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot33.setRangeGridlinePaint(paint37);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot33.setDataset(255, xYDataset40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            xYPlot33.drawOutline(graphics2D42, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean5 = sortOrder3.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder3);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot33.getFixedRangeAxisSpace();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation36 = null;
        try {
            boolean boolean37 = xYPlot33.removeAnnotation(xYAnnotation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(axisSpace35);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        intervalMarker6.setStartValue((double) (short) 10);
        java.lang.Object obj9 = intervalMarker6.clone();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        intervalMarker6.setLabelPaint((java.awt.Paint) color10);
        dateAxis1.setLabelPaint((java.awt.Paint) color10);
        dateAxis1.resizeRange(0.0d, (double) 1560495599999L);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = dateAxis1.hasListener(eventListener4);
        boolean boolean6 = dateAxis1.isInverted();
        double double7 = dateAxis1.getUpperBound();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        java.awt.Shape shape11 = defaultDrawingSupplier9.getNextShape();
        dateAxis1.setLeftArrow(shape11);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor3 = intervalMarker2.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = intervalMarker2.getLabelOffsetType();
        java.awt.Paint paint5 = intervalMarker2.getPaint();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxis();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = dateAxis8.getPlot();
        boolean boolean10 = dateAxis8.isNegativeArrowVisible();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis8.setTimeZone(timeZone11);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis8.setLabelFont(font13);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = dateAxis8.valueToJava2D((double) 10.0f, rectangle2D16, rectangleEdge17);
        dateAxis8.setAutoTickUnitSelection(false, true);
        dateAxis8.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = dateAxis8.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        boolean boolean29 = dateAxis26.isVerticalTickLabels();
        java.util.TimeZone timeZone30 = dateAxis26.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot33 = dateAxis32.getPlot();
        boolean boolean34 = dateAxis32.isNegativeArrowVisible();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis32.setTimeZone(timeZone35);
        dateAxis26.setTimeZone(timeZone35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer38);
        java.awt.Paint paint40 = xYPlot39.getRangeZeroBaselinePaint();
        boolean boolean41 = xYPlot39.isRangeCrosshairLockedOnData();
        java.awt.Paint paint42 = xYPlot39.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot39.setRangeAxisLocation(9, axisLocation44, true);
        categoryPlot0.setRangeAxisLocation(axisLocation44, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis49.configure();
        double double51 = categoryAxis49.getCategoryMargin();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date55 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis54.dateToJava2D(date55, rectangle2D56, rectangleEdge57);
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        double double62 = dateAxis54.java2DToValue((double) (short) -1, rectangle2D60, rectangleEdge61);
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date65 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = null;
        double double68 = dateAxis64.dateToJava2D(date65, rectangle2D66, rectangleEdge67);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = dateAxis64.java2DToValue((double) (short) -1, rectangle2D70, rectangleEdge71);
        java.awt.Font font73 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis64.setTickLabelFont(font73);
        dateAxis54.setTickLabelFont(font73);
        categoryAxis49.setTickLabelFont((java.lang.Comparable) "java.awt.Color[r=255,g=255,b=0]", font73);
        boolean boolean77 = axisLocation44.equals((java.lang.Object) categoryAxis49);
        java.lang.String str78 = categoryAxis49.getLabel();
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.2d + "'", double51 == 0.2d);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + (-9.223372036854776E18d) + "'", double62 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + (-9.223372036854776E18d) + "'", double72 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(str78);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        double double7 = categoryAxis6.getCategoryMargin();
        java.awt.Font font9 = categoryAxis6.getTickLabelFont((java.lang.Comparable) (short) -1);
        int int10 = categoryAxis6.getMaximumCategoryLabelLines();
        boolean boolean11 = defaultDrawingSupplier4.equals((java.lang.Object) int10);
        java.awt.Shape shape12 = defaultDrawingSupplier4.getNextShape();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot15 = dateAxis14.getPlot();
        boolean boolean16 = dateAxis14.isNegativeArrowVisible();
        boolean boolean17 = dateAxis14.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis19.dateToJava2D(date20, rectangle2D21, rectangleEdge22);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis14.dateToJava2D(date20, rectangle2D24, rectangleEdge25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis14.setTickMarkStroke(stroke27);
        dateAxis14.setTickMarksVisible(false);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = dateAxis14.java2DToValue((double) 1560409200000L, rectangle2D32, rectangleEdge33);
        java.awt.Shape shape35 = dateAxis14.getLeftArrow();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        double double38 = dateAxis37.getLowerMargin();
        float float39 = dateAxis37.getTickMarkOutsideLength();
        dateAxis37.setTickLabelsVisible(true);
        dateAxis37.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = null;
        dateAxis37.setTickUnit(dateTickUnit44);
        java.lang.String str46 = dateAxis37.getLabelToolTip();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("hi!");
        double double49 = dateAxis48.getLowerMargin();
        float float50 = dateAxis48.getTickMarkOutsideLength();
        dateAxis48.setTickLabelsVisible(true);
        dateAxis48.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date57 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = dateAxis56.dateToJava2D(date57, rectangle2D58, rectangleEdge59);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        double double64 = dateAxis56.java2DToValue((double) (short) -1, rectangle2D62, rectangleEdge63);
        java.awt.Font font65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis56.setTickLabelFont(font65);
        dateAxis48.setLabelFont(font65);
        java.awt.Shape shape68 = dateAxis48.getDownArrow();
        dateAxis37.setRightArrow(shape68);
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot72 = dateAxis71.getPlot();
        boolean boolean73 = dateAxis71.isNegativeArrowVisible();
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis71.setTimeZone(timeZone74);
        java.awt.Paint paint76 = dateAxis71.getAxisLinePaint();
        java.awt.Shape shape77 = dateAxis71.getRightArrow();
        java.awt.Shape[] shapeArray78 = new java.awt.Shape[] { shape12, shape35, shape68, shape77 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier79 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray78);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 9.223372036854776E18d + "'", double34 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 2.0f + "'", float50 == 2.0f);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + (-9.223372036854776E18d) + "'", double64 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNull(plot72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(shapeArray78);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot0.setRangeAxis(0, valueAxis12, true);
        categoryPlot0.setOutlineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot0.getDataset((int) ' ');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot0.zoomRangeAxes((double) 5, plotRenderingInfo20, point2D21, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        try {
            boolean boolean26 = categoryPlot0.removeAnnotation(categoryAnnotation24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset18);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(0, layer5);
        categoryPlot0.setRangeCrosshairValue((double) 0L, false);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean5 = sortOrder3.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder3);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot0.setDataset(15, categoryDataset8);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot33.getRangeAxis();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = null;
        xYPlot33.datasetChanged(datasetChangeEvent38);
        double double40 = xYPlot33.getRangeCrosshairValue();
        int int41 = xYPlot33.getWeight();
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot44.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        categoryPlot44.setRenderer(categoryItemRenderer47);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        categoryPlot44.setDomainAxis(7, categoryAxis50, false);
        categoryPlot44.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        categoryPlot44.setRangeAxis(0, valueAxis56, true);
        categoryPlot44.setOutlineVisible(false);
        float float61 = categoryPlot44.getBackgroundAlpha();
        java.util.List list62 = categoryPlot44.getAnnotations();
        xYPlot33.drawDomainTickBands(graphics2D42, rectangle2D43, list62);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 1.0f + "'", float61 == 1.0f);
        org.junit.Assert.assertNotNull(list62);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color6 = java.awt.Color.getColor("ChartChangeEventType.NEW_DATASET", 500);
        java.awt.Color color7 = java.awt.Color.cyan;
        java.awt.Color color8 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        float[] floatArray14 = new float[] { (byte) 10, 10, (short) 1, 0L };
        float[] floatArray15 = color7.getColorComponents(colorSpace9, floatArray14);
        java.awt.Color color16 = java.awt.Color.cyan;
        java.awt.Color color17 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        float[] floatArray23 = new float[] { (byte) 10, 10, (short) 1, 0L };
        float[] floatArray24 = color16.getColorComponents(colorSpace18, floatArray23);
        float[] floatArray25 = color6.getColorComponents(colorSpace9, floatArray24);
        java.awt.Color color26 = java.awt.Color.BLUE;
        java.awt.Color color29 = java.awt.Color.getColor("ChartChangeEventType.NEW_DATASET", 500);
        java.awt.Color color30 = java.awt.Color.cyan;
        java.awt.Color color31 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        float[] floatArray37 = new float[] { (byte) 10, 10, (short) 1, 0L };
        float[] floatArray38 = color30.getColorComponents(colorSpace32, floatArray37);
        java.awt.Color color39 = java.awt.Color.cyan;
        java.awt.Color color40 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace41 = color40.getColorSpace();
        float[] floatArray46 = new float[] { (byte) 10, 10, (short) 1, 0L };
        float[] floatArray47 = color39.getColorComponents(colorSpace41, floatArray46);
        float[] floatArray48 = color29.getColorComponents(colorSpace32, floatArray47);
        float[] floatArray49 = color26.getComponents(floatArray48);
        float[] floatArray50 = color3.getColorComponents(colorSpace9, floatArray48);
        float[] floatArray51 = java.awt.Color.RGBtoHSB((int) (short) 10, (int) 'a', 10, floatArray48);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(colorSpace41);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.dateToJava2D(date2, rectangle2D3, rectangleEdge4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double8 = rectangleInsets6.extendWidth((double) (byte) 0);
        dateAxis1.setTickLabelInsets(rectangleInsets6);
        double double11 = rectangleInsets6.trimWidth((double) 500);
        double double13 = rectangleInsets6.calculateBottomInset((double) 1560409200000L);
        double double15 = rectangleInsets6.calculateLeftOutset((double) 255);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 16.0d + "'", double8 == 16.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 484.0d + "'", double11 == 484.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.configure();
        dateAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (short) -1);
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setTickMarkInsideLength((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis((int) (byte) 100);
        double double40 = xYPlot33.getDomainCrosshairValue();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D((-9.223372036854776E18d), rectangle2D3, rectangleEdge4);
        dateAxis1.setTickMarksVisible(false);
        boolean boolean8 = dateAxis1.isAutoTickUnitSelection();
        java.lang.String str9 = dateAxis1.getLabelURL();
        try {
            dateAxis1.zoomRange(1.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        double double3 = categoryAxis2.getCategoryMargin();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) (short) -1);
        int int6 = categoryAxis2.getMaximumCategoryLabelLines();
        boolean boolean7 = defaultDrawingSupplier0.equals((java.lang.Object) int6);
        java.awt.Shape shape8 = defaultDrawingSupplier0.getNextShape();
        java.awt.Paint paint9 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint9);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
//        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis2.setTimeZone(timeZone5);
//        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis2.setLabelFont(font7);
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
//        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
//        dateAxis2.setAutoTickUnitSelection(false, true);
//        dateAxis2.setAutoRange(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
//        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
//        boolean boolean23 = dateAxis20.isVerticalTickLabels();
//        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
//        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis26.setTimeZone(timeZone29);
//        dateAxis20.setTimeZone(timeZone29);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
//        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
//        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
//        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
//        java.awt.Paint paint36 = xYPlot33.getDomainGridlinePaint();
//        boolean boolean37 = xYPlot33.isDomainZoomable();
//        boolean boolean38 = xYPlot33.isRangeZeroBaselineVisible();
//        java.awt.geom.Point2D point2D39 = xYPlot33.getQuadrantOrigin();
//        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double42 = dateAxis41.getLowerMargin();
//        java.awt.Paint paint43 = dateAxis41.getTickMarkPaint();
//        dateAxis41.setLowerMargin((double) 0);
//        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation48 = null;
//        categoryPlot46.setRangeAxisLocation((int) (byte) 100, axisLocation48);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = null;
//        categoryPlot46.datasetChanged(datasetChangeEvent50);
//        categoryPlot46.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
//        org.jfree.chart.plot.PlotOrientation plotOrientation55 = categoryPlot46.getOrientation();
//        boolean boolean56 = dateAxis41.hasListener((java.util.EventListener) categoryPlot46);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        long long58 = day57.getFirstMillisecond();
//        long long59 = day57.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot62 = dateAxis61.getPlot();
//        boolean boolean63 = dateAxis61.isNegativeArrowVisible();
//        boolean boolean64 = dateAxis61.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date67 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D68 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
//        double double70 = dateAxis66.dateToJava2D(date67, rectangle2D68, rectangleEdge69);
//        java.awt.geom.Rectangle2D rectangle2D71 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
//        double double73 = dateAxis61.dateToJava2D(date67, rectangle2D71, rectangleEdge72);
//        int int74 = day57.compareTo((java.lang.Object) date67);
//        java.awt.Color color75 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke76 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day57, (java.awt.Paint) color75, stroke76);
//        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double80 = dateAxis79.getLowerMargin();
//        float float81 = dateAxis79.getTickMarkOutsideLength();
//        dateAxis79.setTickLabelsVisible(true);
//        dateAxis79.setInverted(false);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit86 = null;
//        dateAxis79.setTickUnit(dateTickUnit86);
//        double double88 = dateAxis79.getFixedDimension();
//        boolean boolean89 = categoryMarker77.equals((java.lang.Object) dateAxis79);
//        categoryPlot46.addDomainMarker(categoryMarker77);
//        boolean boolean91 = xYPlot33.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker77);
//        org.junit.Assert.assertNull(plot3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(font7);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertNotNull(tickUnitSource18);
//        org.junit.Assert.assertNull(plot21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(plot27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(paint34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(paint36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(point2D39);
//        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
//        org.junit.Assert.assertNotNull(paint43);
//        org.junit.Assert.assertNotNull(plotOrientation55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560409200000L + "'", long58 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertNull(plot62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNotNull(color75);
//        org.junit.Assert.assertNotNull(stroke76);
//        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.05d + "'", double80 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float81 + "' != '" + 2.0f + "'", float81 == 2.0f);
//        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double38 = rectangleInsets36.extendWidth((double) (byte) 0);
        xYPlot33.setAxisOffset(rectangleInsets36);
        try {
            xYPlot33.setBackgroundImageAlpha((float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 16.0d + "'", double38 == 16.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.dateToJava2D(date2, rectangle2D3, rectangleEdge4);
        org.jfree.chart.event.AxisChangeListener axisChangeListener6 = null;
        dateAxis1.addChangeListener(axisChangeListener6);
        dateAxis1.setTickLabelsVisible(true);
        double double10 = dateAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
//        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis2.setTimeZone(timeZone5);
//        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis2.setLabelFont(font7);
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
//        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
//        dateAxis2.setAutoTickUnitSelection(false, true);
//        dateAxis2.setAutoRange(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
//        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
//        boolean boolean23 = dateAxis20.isVerticalTickLabels();
//        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
//        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis26.setTimeZone(timeZone29);
//        dateAxis20.setTimeZone(timeZone29);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
//        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
//        xYPlot33.configureDomainAxes();
//        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
//        categoryPlot35.setFixedDomainAxisSpace(axisSpace36);
//        org.jfree.chart.util.SortOrder sortOrder38 = org.jfree.chart.util.SortOrder.DESCENDING;
//        boolean boolean40 = sortOrder38.equals((java.lang.Object) 10L);
//        categoryPlot35.setRowRenderingOrder(sortOrder38);
//        java.awt.Paint paint42 = categoryPlot35.getRangeCrosshairPaint();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        long long45 = day44.getFirstMillisecond();
//        long long46 = day44.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot49 = dateAxis48.getPlot();
//        boolean boolean50 = dateAxis48.isNegativeArrowVisible();
//        boolean boolean51 = dateAxis48.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date54 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D55 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
//        double double57 = dateAxis53.dateToJava2D(date54, rectangle2D55, rectangleEdge56);
//        java.awt.geom.Rectangle2D rectangle2D58 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
//        double double60 = dateAxis48.dateToJava2D(date54, rectangle2D58, rectangleEdge59);
//        int int61 = day44.compareTo((java.lang.Object) date54);
//        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke63 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker64 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day44, (java.awt.Paint) color62, stroke63);
//        org.jfree.chart.text.TextAnchor textAnchor65 = categoryMarker64.getLabelTextAnchor();
//        java.awt.Stroke stroke66 = categoryMarker64.getStroke();
//        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double69 = dateAxis68.getLowerMargin();
//        float float70 = dateAxis68.getTickMarkOutsideLength();
//        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation73 = null;
//        categoryPlot71.setRangeAxisLocation((int) (byte) 100, axisLocation73);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent75 = null;
//        categoryPlot71.datasetChanged(datasetChangeEvent75);
//        boolean boolean77 = dateAxis68.hasListener((java.util.EventListener) categoryPlot71);
//        float float78 = categoryPlot71.getBackgroundAlpha();
//        org.jfree.chart.util.RectangleEdge rectangleEdge79 = categoryPlot71.getDomainAxisEdge();
//        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d);
//        boolean boolean84 = valueMarker82.equals((java.lang.Object) 100L);
//        boolean boolean86 = valueMarker82.equals((java.lang.Object) 3);
//        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean88 = categoryPlot71.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker82, layer87);
//        boolean boolean90 = categoryPlot35.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker64, layer87, true);
//        xYPlot33.setParent((org.jfree.chart.plot.Plot) categoryPlot35);
//        org.junit.Assert.assertNull(plot3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(font7);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertNotNull(tickUnitSource18);
//        org.junit.Assert.assertNull(plot21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(plot27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(sortOrder38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(paint42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560409200000L + "'", long45 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43629L + "'", long46 == 43629L);
//        org.junit.Assert.assertNull(plot49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(color62);
//        org.junit.Assert.assertNotNull(stroke63);
//        org.junit.Assert.assertNotNull(textAnchor65);
//        org.junit.Assert.assertNotNull(stroke66);
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.05d + "'", double69 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 2.0f + "'", float70 == 2.0f);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 1.0f + "'", float78 == 1.0f);
//        org.junit.Assert.assertNotNull(rectangleEdge79);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(layer87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(255, valueAxis7, false);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot11.setRangeAxisLocation((int) (byte) 100, axisLocation13);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        double double17 = dateAxis16.getLowerMargin();
        java.awt.Paint paint18 = dateAxis16.getTickMarkPaint();
        dateAxis16.setLowerMargin((double) 0);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { dateAxis16 };
        categoryPlot11.setRangeAxes(valueAxisArray21);
        categoryPlot0.setRangeAxes(valueAxisArray21);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double38 = rectangleInsets36.extendWidth((double) (byte) 0);
        xYPlot33.setAxisOffset(rectangleInsets36);
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot33.getDataset(13);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot33.setDomainCrosshairPaint((java.awt.Paint) color42);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 16.0d + "'", double38 == 16.0d);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        java.awt.Paint paint4 = dateAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 4, (-1.0d));
        intervalMarker2.setEndValue(0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        double double4 = dateAxis1.getLowerBound();
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        double double38 = dateAxis37.getLowerMargin();
        float float39 = dateAxis37.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot40.setRangeAxisLocation((int) (byte) 100, axisLocation42);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        categoryPlot40.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = dateAxis37.hasListener((java.util.EventListener) categoryPlot40);
        float float47 = categoryPlot40.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot40.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean53 = valueMarker51.equals((java.lang.Object) 100L);
        boolean boolean55 = valueMarker51.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean57 = categoryPlot40.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker51, layer56);
        java.util.Collection collection58 = xYPlot33.getDomainMarkers((-16777216), layer56);
        boolean boolean59 = xYPlot33.isDomainZoomable();
        boolean boolean60 = xYPlot33.isOutlineVisible();
        xYPlot33.clearDomainMarkers();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        int int63 = xYPlot33.getSeriesCount();
        xYPlot33.mapDatasetToDomainAxis((int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis1.valueToJava2D((double) 10.0f, rectangle2D9, rectangleEdge10);
        dateAxis1.setAutoTickUnitSelection(false, true);
        java.util.Date date15 = null;
        try {
            dateAxis1.setMaximumDate(date15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'maximumDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        int int35 = xYPlot33.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot33.setFixedRangeAxisSpace(axisSpace36);
        java.lang.String str38 = xYPlot33.getPlotType();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = dateAxis40.valueToJava2D((-9.223372036854776E18d), rectangle2D42, rectangleEdge43);
        dateAxis40.setTickMarksVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("hi!");
        double double49 = dateAxis48.getLowerMargin();
        float float50 = dateAxis48.getTickMarkOutsideLength();
        dateAxis48.setTickLabelsVisible(true);
        dateAxis48.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date57 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = dateAxis56.dateToJava2D(date57, rectangle2D58, rectangleEdge59);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        double double64 = dateAxis56.java2DToValue((double) (short) -1, rectangle2D62, rectangleEdge63);
        java.awt.Font font65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis56.setTickLabelFont(font65);
        dateAxis48.setLabelFont(font65);
        boolean boolean68 = dateAxis48.isAxisLineVisible();
        dateAxis48.setLowerBound((-1.0d));
        org.jfree.chart.axis.ValueAxis[] valueAxisArray71 = new org.jfree.chart.axis.ValueAxis[] { dateAxis40, dateAxis48 };
        xYPlot33.setDomainAxes(valueAxisArray71);
        xYPlot33.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "XY Plot" + "'", str38.equals("XY Plot"));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.05d + "'", double49 == 0.05d);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 2.0f + "'", float50 == 2.0f);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + (-9.223372036854776E18d) + "'", double64 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(valueAxisArray71);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot5 = dateAxis4.getPlot();
//        boolean boolean6 = dateAxis4.isNegativeArrowVisible();
//        boolean boolean7 = dateAxis4.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis4.dateToJava2D(date10, rectangle2D14, rectangleEdge15);
//        int int17 = day0.compareTo((java.lang.Object) date10);
//        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color18, stroke19);
//        org.jfree.data.time.SerialDate serialDate21 = day0.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNull(plot5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(serialDate21);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        categoryPlot0.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getDomainAxisLocation();
        java.awt.Color color8 = java.awt.Color.getColor("", (int) (byte) 0);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean14 = categoryPlot13.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot13.getRendererForDataset(categoryDataset15);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean19 = sortOrder17.equals((java.lang.Object) 10L);
        categoryPlot13.setRowRenderingOrder(sortOrder17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot13.zoomDomainAxes((double) 100L, plotRenderingInfo22, point2D23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot30 = dateAxis29.getPlot();
        boolean boolean31 = dateAxis29.isNegativeArrowVisible();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis29.setTimeZone(timeZone32);
        java.awt.Font font34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis29.setLabelFont(font34);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis29.valueToJava2D((double) 10.0f, rectangle2D37, rectangleEdge38);
        dateAxis29.setAutoTickUnitSelection(false, true);
        dateAxis29.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = dateAxis29.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot48 = dateAxis47.getPlot();
        boolean boolean49 = dateAxis47.isNegativeArrowVisible();
        boolean boolean50 = dateAxis47.isVerticalTickLabels();
        java.util.TimeZone timeZone51 = dateAxis47.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot54 = dateAxis53.getPlot();
        boolean boolean55 = dateAxis53.isNegativeArrowVisible();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis53.setTimeZone(timeZone56);
        dateAxis47.setTimeZone(timeZone56);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer59);
        java.awt.Paint paint61 = xYPlot60.getRangeZeroBaselinePaint();
        boolean boolean62 = xYPlot60.isRangeCrosshairLockedOnData();
        java.awt.Paint paint63 = xYPlot60.getDomainGridlinePaint();
        boolean boolean64 = xYPlot60.isDomainZoomable();
        boolean boolean65 = xYPlot60.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D66 = xYPlot60.getQuadrantOrigin();
        categoryPlot13.zoomRangeAxes((double) 43629L, plotRenderingInfo26, point2D66, true);
        categoryPlot0.zoomDomainAxes((double) 12, (double) (byte) 1, plotRenderingInfo12, point2D66);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertNull(plot48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(point2D66);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.RED;
        dateAxis1.setLabelPaint((java.awt.Paint) color3);
        java.awt.Color color5 = color3.brighter();
        boolean boolean7 = color3.equals((java.lang.Object) (-1.0d));
        java.awt.Color color8 = color3.darker();
        int int9 = color3.getTransparency();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        categoryPlot3.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot3.setRenderer(500, categoryItemRenderer9, false);
        boolean boolean12 = numberAxis0.equals((java.lang.Object) false);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean16 = categoryPlot15.isSubplot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot15.zoomDomainAxes((double) 2019, plotRenderingInfo18, point2D19, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot15.getRangeAxisEdge();
        try {
            double double23 = numberAxis0.java2DToValue(0.2d, rectangle2D14, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D((-9.223372036854776E18d), rectangle2D3, rectangleEdge4);
        java.lang.String str6 = dateAxis1.getLabelToolTip();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot9 = dateAxis8.getPlot();
        boolean boolean10 = dateAxis8.isNegativeArrowVisible();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis8.setTimeZone(timeZone11);
        org.jfree.data.Range range13 = dateAxis8.getRange();
        dateAxis1.setDefaultAutoRange(range13);
        dateAxis1.setTickMarksVisible(true);
        dateAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        categoryPlot0.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot8 = dateAxis7.getPlot();
        boolean boolean9 = dateAxis7.isNegativeArrowVisible();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis7.setTimeZone(timeZone10);
        java.awt.Font font12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis7.setLabelFont(font12);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis7.valueToJava2D((double) 10.0f, rectangle2D15, rectangleEdge16);
        dateAxis7.setAutoRangeMinimumSize((double) 1);
        dateAxis7.setLabelURL("");
        categoryPlot0.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis7, true);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getFirstMillisecond();
//        long long3 = day1.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot6 = dateAxis5.getPlot();
//        boolean boolean7 = dateAxis5.isNegativeArrowVisible();
//        boolean boolean8 = dateAxis5.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D12 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
//        double double14 = dateAxis10.dateToJava2D(date11, rectangle2D12, rectangleEdge13);
//        java.awt.geom.Rectangle2D rectangle2D15 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
//        double double17 = dateAxis5.dateToJava2D(date11, rectangle2D15, rectangleEdge16);
//        int int18 = day1.compareTo((java.lang.Object) date11);
//        java.awt.Font font19 = categoryAxis0.getTickLabelFont((java.lang.Comparable) date11);
//        double double20 = categoryAxis0.getCategoryMargin();
//        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double23 = dateAxis22.getLowerMargin();
//        float float24 = dateAxis22.getTickMarkOutsideLength();
//        java.util.Date date25 = dateAxis22.getMinimumDate();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        org.jfree.data.time.SerialDate serialDate27 = day26.getSerialDate();
//        java.awt.Paint paint28 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) serialDate27);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//        org.junit.Assert.assertNull(plot6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(font19);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.2d + "'", double20 == 0.2d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(paint28);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.awt.Color color3 = java.awt.Color.getColor("ChartChangeEventType.NEW_DATASET", 500);
        java.awt.Color color4 = java.awt.Color.cyan;
        java.awt.Color color5 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        float[] floatArray11 = new float[] { (byte) 10, 10, (short) 1, 0L };
        float[] floatArray12 = color4.getColorComponents(colorSpace6, floatArray11);
        java.awt.Color color13 = java.awt.Color.cyan;
        java.awt.Color color14 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace15 = color14.getColorSpace();
        float[] floatArray20 = new float[] { (byte) 10, 10, (short) 1, 0L };
        float[] floatArray21 = color13.getColorComponents(colorSpace15, floatArray20);
        float[] floatArray22 = color3.getColorComponents(colorSpace6, floatArray21);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        double double25 = dateAxis24.getLowerMargin();
        float float26 = dateAxis24.getTickMarkOutsideLength();
        dateAxis24.setTickLabelsVisible(true);
        dateAxis24.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot33 = dateAxis32.getPlot();
        boolean boolean34 = dateAxis32.isNegativeArrowVisible();
        boolean boolean35 = dateAxis32.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date38 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = dateAxis37.dateToJava2D(date38, rectangle2D39, rectangleEdge40);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = dateAxis32.dateToJava2D(date38, rectangle2D42, rectangleEdge43);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis32.setTickMarkStroke(stroke45);
        dateAxis24.setAxisLineStroke(stroke45);
        java.lang.Object obj48 = dateAxis24.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot49.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier50);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        categoryPlot49.setRenderer(categoryItemRenderer52);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        categoryPlot49.setDomainAxis(7, categoryAxis55, false);
        dateAxis24.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot49);
        categoryPlot49.setForegroundAlpha((float) 6);
        java.awt.Stroke stroke61 = categoryPlot49.getDomainGridlineStroke();
        java.awt.Color color64 = java.awt.Color.getColor("SeriesRenderingOrder.FORWARD", 10);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("hi!");
        double double67 = dateAxis66.getLowerMargin();
        float float68 = dateAxis66.getTickMarkOutsideLength();
        java.util.Date date69 = dateAxis66.getMinimumDate();
        org.jfree.chart.plot.IntervalMarker intervalMarker72 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        java.awt.Stroke stroke73 = intervalMarker72.getStroke();
        dateAxis66.setAxisLineStroke(stroke73);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker76 = new org.jfree.chart.plot.ValueMarker((double) 5, (java.awt.Paint) color3, stroke61, (java.awt.Paint) color64, stroke73, (float) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.05d + "'", double67 == 0.05d);
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 2.0f + "'", float68 == 2.0f);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        double double38 = dateAxis37.getLowerMargin();
        float float39 = dateAxis37.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot40.setRangeAxisLocation((int) (byte) 100, axisLocation42);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        categoryPlot40.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = dateAxis37.hasListener((java.util.EventListener) categoryPlot40);
        float float47 = categoryPlot40.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot40.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean53 = valueMarker51.equals((java.lang.Object) 100L);
        boolean boolean55 = valueMarker51.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean57 = categoryPlot40.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker51, layer56);
        java.util.Collection collection58 = xYPlot33.getDomainMarkers((-16777216), layer56);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        xYPlot33.drawAnnotations(graphics2D59, rectangle2D60, plotRenderingInfo61);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean65 = categoryPlot64.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset66 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = categoryPlot64.getRendererForDataset(categoryDataset66);
        org.jfree.chart.util.SortOrder sortOrder68 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean70 = sortOrder68.equals((java.lang.Object) 10L);
        categoryPlot64.setRowRenderingOrder(sortOrder68);
        org.jfree.chart.plot.IntervalMarker intervalMarker75 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        java.awt.Stroke stroke76 = intervalMarker75.getStroke();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener77 = null;
        intervalMarker75.removeChangeListener(markerChangeListener77);
        org.jfree.chart.util.Layer layer79 = null;
        boolean boolean80 = categoryPlot64.removeRangeMarker(10, (org.jfree.chart.plot.Marker) intervalMarker75, layer79);
        intervalMarker75.setEndValue((double) ' ');
        org.jfree.chart.util.Layer layer83 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot33.addDomainMarker((int) (short) 10, (org.jfree.chart.plot.Marker) intervalMarker75, layer83);
        xYPlot33.setDomainCrosshairValue((double) '#');
        xYPlot33.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder89 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot33.setSeriesRenderingOrder(seriesRenderingOrder89);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(categoryItemRenderer67);
        org.junit.Assert.assertNotNull(sortOrder68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(layer83);
        org.junit.Assert.assertNotNull(seriesRenderingOrder89);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int10 = color9.getAlpha();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint13 = categoryPlot0.getOutlinePaint();
        java.awt.Paint paint14 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        java.awt.Paint paint37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot33.setRangeGridlinePaint(paint37);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        xYPlot33.setDataset(255, xYDataset40);
        org.jfree.chart.axis.AxisSpace axisSpace42 = null;
        xYPlot33.setFixedDomainAxisSpace(axisSpace42, false);
        xYPlot33.setRangeCrosshairValue((double) 5);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int10 = color9.getAlpha();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color9);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot0.getRangeAxisLocation((int) (byte) 100);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot33.getRangeAxis();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = null;
        xYPlot33.datasetChanged(datasetChangeEvent38);
        double double40 = xYPlot33.getRangeCrosshairValue();
        int int41 = xYPlot33.getWeight();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        xYPlot33.rendererChanged(rendererChangeEvent42);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        categoryPlot3.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot3.setRenderer(500, categoryItemRenderer9, false);
        boolean boolean12 = numberAxis0.equals((java.lang.Object) false);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        numberAxis0.setTickMarkStroke(stroke13);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(numberTickUnit15);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis1.valueToJava2D((double) 10.0f, rectangle2D9, rectangleEdge10);
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range14);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor19 = intervalMarker18.getLabelTextAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = intervalMarker18.getLabelOffsetType();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean24 = valueMarker22.equals((java.lang.Object) 100L);
        boolean boolean26 = valueMarker22.equals((java.lang.Object) 3);
        boolean boolean27 = lengthAdjustmentType20.equals((java.lang.Object) valueMarker22);
        boolean boolean28 = dateAxis1.equals((java.lang.Object) valueMarker22);
        double double29 = valueMarker22.getValue();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        intervalMarker2.setStartValue((double) (short) 10);
        java.lang.Object obj5 = intervalMarker2.clone();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        intervalMarker2.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = intervalMarker2.getGradientPaintTransformer();
        java.awt.Paint paint9 = intervalMarker2.getLabelPaint();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(gradientPaintTransformer8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis((int) (byte) 100);
        xYPlot33.setRangeCrosshairValue((double) 1, true);
        java.awt.Stroke stroke43 = null;
        try {
            xYPlot33.setDomainZeroBaselineStroke(stroke43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.util.ObjectList objectList39 = new org.jfree.chart.util.ObjectList(3);
        int int40 = objectList39.size();
        boolean boolean41 = axisLocation35.equals((java.lang.Object) int40);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot5 = dateAxis4.getPlot();
//        boolean boolean6 = dateAxis4.isNegativeArrowVisible();
//        boolean boolean7 = dateAxis4.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis4.dateToJava2D(date10, rectangle2D14, rectangleEdge15);
//        int int17 = day0.compareTo((java.lang.Object) date10);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date10, timeZone18);
//        long long20 = day19.getFirstMillisecond();
//        long long21 = day19.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNull(plot5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        dateAxis1.setAutoRange(true);
        boolean boolean5 = dateAxis1.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = dateAxis1.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj9 = dateAxis8.clone();
        dateAxis8.setTickMarkOutsideLength((float) (byte) 1);
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis8.setMaximumDate(date12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        double double16 = dateAxis15.getLowerMargin();
        float float17 = dateAxis15.getTickMarkOutsideLength();
        dateAxis15.setTickLabelsVisible(true);
        dateAxis15.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit22 = null;
        dateAxis15.setTickUnit(dateTickUnit22);
        double double24 = dateAxis15.getLowerMargin();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition25 = dateAxis15.getTickMarkPosition();
        dateAxis8.setTickMarkPosition(dateTickMarkPosition25);
        dateAxis1.setTickMarkPosition(dateTickMarkPosition25);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition25);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Paint paint7 = dateAxis2.getAxisLinePaint();
        boolean boolean8 = plotOrientation0.equals((java.lang.Object) dateAxis2);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        double double11 = dateAxis10.getLowerMargin();
        float float12 = dateAxis10.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setRangeAxisLocation((int) (byte) 100, axisLocation15);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = null;
        categoryPlot13.datasetChanged(datasetChangeEvent17);
        boolean boolean19 = dateAxis10.hasListener((java.util.EventListener) categoryPlot13);
        dateAxis10.setTickMarkInsideLength((float) (-1L));
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis10.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setDefaultAutoRange((org.jfree.data.Range) dateRange23);
        boolean boolean25 = plotOrientation0.equals((java.lang.Object) dateAxis10);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot28.setRenderer(categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot28.setDomainAxis(7, categoryAxis34, false);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int38 = color37.getAlpha();
        categoryPlot28.setRangeCrosshairPaint((java.awt.Paint) color37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder40 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = categoryPlot28.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot28.getRangeAxisEdge((int) 'a');
        try {
            double double44 = dateAxis10.java2DToValue((double) (short) 0, rectangle2D27, rectangleEdge43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        boolean boolean4 = dateAxis1.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = dateAxis6.dateToJava2D(date7, rectangle2D8, rectangleEdge9);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis1.dateToJava2D(date7, rectangle2D11, rectangleEdge12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis1.setTickMarkStroke(stroke14);
        dateAxis1.setTickMarksVisible(false);
        dateAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        dateAxis1.setAutoRange(true);
        boolean boolean5 = dateAxis1.isVerticalTickLabels();
        java.lang.String str6 = dateAxis1.getLabelURL();
        dateAxis1.setInverted(true);
        dateAxis1.setAutoRange(false);
        boolean boolean11 = dateAxis1.isTickLabelsVisible();
        dateAxis1.zoomRange((double) 13, (double) 43629L);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis16.dateToJava2D(date17, rectangle2D18, rectangleEdge19);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis22.dateToJava2D(date23, rectangle2D24, rectangleEdge25);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis22.java2DToValue((double) (short) -1, rectangle2D28, rectangleEdge29);
        java.awt.Font font31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis22.setTickLabelFont(font31);
        dateAxis16.setLabelFont(font31);
        java.awt.Paint paint34 = dateAxis16.getAxisLinePaint();
        org.jfree.data.Range range35 = dateAxis16.getDefaultAutoRange();
        dateAxis1.setRange(range35);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-9.223372036854776E18d) + "'", double30 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double38 = rectangleInsets36.extendWidth((double) (byte) 0);
        xYPlot33.setAxisOffset(rectangleInsets36);
        org.jfree.data.xy.XYDataset xYDataset41 = xYPlot33.getDataset(13);
        java.awt.Stroke stroke42 = xYPlot33.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 16.0d + "'", double38 == 16.0d);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(255, valueAxis7, false);
        org.jfree.chart.plot.Plot plot10 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(plot10);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
//        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis1.setTimeZone(timeZone4);
//        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis1.setLabelFont(font6);
//        java.awt.geom.Rectangle2D rectangle2D9 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
//        double double11 = dateAxis1.valueToJava2D((double) 10.0f, rectangle2D9, rectangleEdge10);
//        java.awt.Graphics2D graphics2D12 = null;
//        org.jfree.chart.axis.AxisState axisState13 = null;
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        java.util.List list16 = dateAxis1.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
//        java.awt.Stroke stroke17 = dateAxis1.getAxisLineStroke();
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getFirstMillisecond();
//        long long21 = day19.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot24 = dateAxis23.getPlot();
//        boolean boolean25 = dateAxis23.isNegativeArrowVisible();
//        boolean boolean26 = dateAxis23.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D30 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
//        double double32 = dateAxis28.dateToJava2D(date29, rectangle2D30, rectangleEdge31);
//        java.awt.geom.Rectangle2D rectangle2D33 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
//        double double35 = dateAxis23.dateToJava2D(date29, rectangle2D33, rectangleEdge34);
//        int int36 = day19.compareTo((java.lang.Object) date29);
//        java.awt.Font font37 = categoryAxis18.getTickLabelFont((java.lang.Comparable) date29);
//        java.awt.geom.Rectangle2D rectangle2D38 = null;
//        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double41 = dateAxis40.getLowerMargin();
//        float float42 = dateAxis40.getTickMarkOutsideLength();
//        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation45 = null;
//        categoryPlot43.setRangeAxisLocation((int) (byte) 100, axisLocation45);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
//        categoryPlot43.datasetChanged(datasetChangeEvent47);
//        boolean boolean49 = dateAxis40.hasListener((java.util.EventListener) categoryPlot43);
//        float float50 = categoryPlot43.getBackgroundAlpha();
//        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot43.getDomainAxisEdge();
//        try {
//            double double52 = dateAxis1.dateToJava2D(date29, rectangle2D38, rectangleEdge51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(plot2);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(font6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertNull(list16);
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43629L + "'", long21 == 43629L);
//        org.junit.Assert.assertNull(plot24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(font37);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 1.0f + "'", float50 == 1.0f);
//        org.junit.Assert.assertNotNull(rectangleEdge51);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D((-9.223372036854776E18d), rectangle2D3, rectangleEdge4);
        java.text.DateFormat dateFormat6 = null;
        dateAxis1.setDateFormatOverride(dateFormat6);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomDomainAxes((double) 2019, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getRangeAxisEdge();
        java.awt.Color color8 = java.awt.Color.cyan;
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        categoryPlot37.setRangeAxisLocation((int) (byte) 100, axisLocation39);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        categoryPlot37.datasetChanged(datasetChangeEvent41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot37.setFixedRangeAxisSpace(axisSpace43);
        categoryPlot37.configureDomainAxes();
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) layer47);
        java.util.Collection collection49 = categoryPlot37.getRangeMarkers((int) ' ', layer47);
        java.util.Collection collection50 = xYPlot33.getDomainMarkers(layer47);
        java.awt.Color color51 = java.awt.Color.GREEN;
        int int52 = color51.getTransparency();
        xYPlot33.setDomainGridlinePaint((java.awt.Paint) color51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = xYPlot33.getRangeAxisLocation();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        double double38 = dateAxis37.getLowerMargin();
        float float39 = dateAxis37.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        categoryPlot40.setRangeAxisLocation((int) (byte) 100, axisLocation42);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent44 = null;
        categoryPlot40.datasetChanged(datasetChangeEvent44);
        boolean boolean46 = dateAxis37.hasListener((java.util.EventListener) categoryPlot40);
        float float47 = categoryPlot40.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot40.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean53 = valueMarker51.equals((java.lang.Object) 100L);
        boolean boolean55 = valueMarker51.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean57 = categoryPlot40.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker51, layer56);
        java.util.Collection collection58 = xYPlot33.getDomainMarkers((-16777216), layer56);
        xYPlot33.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace60 = xYPlot33.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        xYPlot33.setDataset((int) (short) 1, xYDataset62);
        java.awt.Paint paint64 = null;
        try {
            xYPlot33.setDomainZeroBaselinePaint(paint64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 2.0f + "'", float39 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertNull(axisSpace60);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setRangeAxisLocation((int) (byte) 100, axisLocation6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        boolean boolean10 = dateAxis1.hasListener((java.util.EventListener) categoryPlot4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot4.zoomRangeAxes((double) 2, plotRenderingInfo12, point2D13, false);
        categoryPlot4.clearDomainAxes();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot4.getRangeAxisEdge(1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(255, valueAxis7, false);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Paint paint11 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateBottomOutset((double) 1);
        categoryPlot0.setInsets(rectangleInsets12, true);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot20 = dateAxis19.getPlot();
        boolean boolean21 = dateAxis19.isNegativeArrowVisible();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis19.setTimeZone(timeZone22);
        java.awt.Font font24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis19.setLabelFont(font24);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = dateAxis19.valueToJava2D((double) 10.0f, rectangle2D27, rectangleEdge28);
        dateAxis19.setAutoTickUnitSelection(false, true);
        dateAxis19.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = dateAxis19.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot38 = dateAxis37.getPlot();
        boolean boolean39 = dateAxis37.isNegativeArrowVisible();
        boolean boolean40 = dateAxis37.isVerticalTickLabels();
        java.util.TimeZone timeZone41 = dateAxis37.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot44 = dateAxis43.getPlot();
        boolean boolean45 = dateAxis43.isNegativeArrowVisible();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis43.setTimeZone(timeZone46);
        dateAxis37.setTimeZone(timeZone46);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer49);
        java.awt.Paint paint51 = xYPlot50.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        xYPlot50.setFixedDomainAxisSpace(axisSpace52, false);
        org.jfree.chart.axis.AxisLocation axisLocation55 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str56 = axisLocation55.toString();
        xYPlot50.setDomainAxisLocation(axisLocation55);
        categoryPlot0.setDomainAxisLocation(axisLocation55);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource35);
        org.junit.Assert.assertNull(plot38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(plot44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str56.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
//        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis2.setTimeZone(timeZone5);
//        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis2.setLabelFont(font7);
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
//        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
//        dateAxis2.setAutoTickUnitSelection(false, true);
//        dateAxis2.setAutoRange(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
//        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
//        boolean boolean23 = dateAxis20.isVerticalTickLabels();
//        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
//        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis26.setTimeZone(timeZone29);
//        dateAxis20.setTimeZone(timeZone29);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
//        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
//        xYPlot33.configureDomainAxes();
//        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot33.getFixedRangeAxisSpace();
//        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double38 = dateAxis37.getLowerMargin();
//        java.awt.Paint paint39 = dateAxis37.getTickMarkPaint();
//        dateAxis37.setLowerMargin((double) 0);
//        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
//        categoryPlot42.setRangeAxisLocation((int) (byte) 100, axisLocation44);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = null;
//        categoryPlot42.datasetChanged(datasetChangeEvent46);
//        categoryPlot42.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
//        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot42.getOrientation();
//        boolean boolean52 = dateAxis37.hasListener((java.util.EventListener) categoryPlot42);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        long long54 = day53.getFirstMillisecond();
//        long long55 = day53.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot58 = dateAxis57.getPlot();
//        boolean boolean59 = dateAxis57.isNegativeArrowVisible();
//        boolean boolean60 = dateAxis57.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date63 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D64 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
//        double double66 = dateAxis62.dateToJava2D(date63, rectangle2D64, rectangleEdge65);
//        java.awt.geom.Rectangle2D rectangle2D67 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
//        double double69 = dateAxis57.dateToJava2D(date63, rectangle2D67, rectangleEdge68);
//        int int70 = day53.compareTo((java.lang.Object) date63);
//        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker73 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day53, (java.awt.Paint) color71, stroke72);
//        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double76 = dateAxis75.getLowerMargin();
//        float float77 = dateAxis75.getTickMarkOutsideLength();
//        dateAxis75.setTickLabelsVisible(true);
//        dateAxis75.setInverted(false);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit82 = null;
//        dateAxis75.setTickUnit(dateTickUnit82);
//        double double84 = dateAxis75.getFixedDimension();
//        boolean boolean85 = categoryMarker73.equals((java.lang.Object) dateAxis75);
//        categoryPlot42.addDomainMarker(categoryMarker73);
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType87 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        boolean boolean88 = categoryMarker73.equals((java.lang.Object) chartChangeEventType87);
//        xYPlot33.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker73);
//        categoryMarker73.setLabel("AxisLocation.BOTTOM_OR_RIGHT");
//        org.jfree.chart.axis.NumberAxis numberAxis92 = new org.jfree.chart.axis.NumberAxis();
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit93 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
//        numberAxis92.setTickUnit(numberTickUnit93);
//        categoryMarker73.setKey((java.lang.Comparable) numberTickUnit93);
//        org.junit.Assert.assertNull(plot3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(font7);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertNotNull(tickUnitSource18);
//        org.junit.Assert.assertNull(plot21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(plot27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(axisSpace35);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
//        org.junit.Assert.assertNotNull(paint39);
//        org.junit.Assert.assertNotNull(plotOrientation51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560409200000L + "'", long54 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43629L + "'", long55 == 43629L);
//        org.junit.Assert.assertNull(plot58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(color71);
//        org.junit.Assert.assertNotNull(stroke72);
//        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 2.0f + "'", float77 == 2.0f);
//        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(chartChangeEventType87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(numberTickUnit93);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setRangeAxisLocation((int) (byte) 100, axisLocation6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        boolean boolean10 = dateAxis1.hasListener((java.util.EventListener) categoryPlot4);
        float float11 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot4.getDataset();
        java.awt.Paint paint14 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot4.getRangeAxisLocation(10);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot4.setRowRenderingOrder(sortOrder17);
        categoryPlot4.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(sortOrder17);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
//        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
//        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.DESCENDING;
//        boolean boolean5 = sortOrder3.equals((java.lang.Object) 10L);
//        categoryPlot0.setRowRenderingOrder(sortOrder3);
//        java.awt.Paint paint7 = categoryPlot0.getRangeCrosshairPaint();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getFirstMillisecond();
//        long long11 = day9.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot14 = dateAxis13.getPlot();
//        boolean boolean15 = dateAxis13.isNegativeArrowVisible();
//        boolean boolean16 = dateAxis13.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D20 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
//        double double22 = dateAxis18.dateToJava2D(date19, rectangle2D20, rectangleEdge21);
//        java.awt.geom.Rectangle2D rectangle2D23 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
//        double double25 = dateAxis13.dateToJava2D(date19, rectangle2D23, rectangleEdge24);
//        int int26 = day9.compareTo((java.lang.Object) date19);
//        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day9, (java.awt.Paint) color27, stroke28);
//        org.jfree.chart.text.TextAnchor textAnchor30 = categoryMarker29.getLabelTextAnchor();
//        java.awt.Stroke stroke31 = categoryMarker29.getStroke();
//        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double34 = dateAxis33.getLowerMargin();
//        float float35 = dateAxis33.getTickMarkOutsideLength();
//        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
//        categoryPlot36.setRangeAxisLocation((int) (byte) 100, axisLocation38);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = null;
//        categoryPlot36.datasetChanged(datasetChangeEvent40);
//        boolean boolean42 = dateAxis33.hasListener((java.util.EventListener) categoryPlot36);
//        float float43 = categoryPlot36.getBackgroundAlpha();
//        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot36.getDomainAxisEdge();
//        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker(0.0d);
//        boolean boolean49 = valueMarker47.equals((java.lang.Object) 100L);
//        boolean boolean51 = valueMarker47.equals((java.lang.Object) 3);
//        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean53 = categoryPlot36.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker47, layer52);
//        boolean boolean55 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker29, layer52, true);
//        boolean boolean56 = categoryMarker29.getDrawAsLine();
//        org.junit.Assert.assertNotNull(sortOrder3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNull(plot14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(color27);
//        org.junit.Assert.assertNotNull(stroke28);
//        org.junit.Assert.assertNotNull(textAnchor30);
//        org.junit.Assert.assertNotNull(stroke31);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 2.0f + "'", float35 == 2.0f);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
//        org.junit.Assert.assertNotNull(rectangleEdge44);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(layer52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D3 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
//        double double5 = dateAxis1.dateToJava2D(date2, rectangle2D3, rectangleEdge4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date2, timeZone6);
//        long long9 = day8.getFirstMillisecond();
//        java.util.Date date10 = day8.getStart();
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot13 = dateAxis12.getPlot();
//        boolean boolean14 = dateAxis12.isNegativeArrowVisible();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis12.setTimeZone(timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date10, timeZone15);
//        int int18 = day17.getDayOfMonth();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        long long20 = day19.getFirstMillisecond();
//        long long21 = day19.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot24 = dateAxis23.getPlot();
//        boolean boolean25 = dateAxis23.isNegativeArrowVisible();
//        boolean boolean26 = dateAxis23.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D30 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
//        double double32 = dateAxis28.dateToJava2D(date29, rectangle2D30, rectangleEdge31);
//        java.awt.geom.Rectangle2D rectangle2D33 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
//        double double35 = dateAxis23.dateToJava2D(date29, rectangle2D33, rectangleEdge34);
//        int int36 = day19.compareTo((java.lang.Object) date29);
//        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day19, (java.awt.Paint) color37, stroke38);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType40 = categoryMarker39.getLabelOffsetType();
//        int int41 = day17.compareTo((java.lang.Object) lengthAdjustmentType40);
//        java.lang.String str42 = lengthAdjustmentType40.toString();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(tickUnitSource7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(plot13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43629L + "'", long21 == 43629L);
//        org.junit.Assert.assertNull(plot24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(color37);
//        org.junit.Assert.assertNotNull(stroke38);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "EXPAND" + "'", str42.equals("EXPAND"));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot0.setRangeAxis(0, valueAxis12, true);
        categoryPlot0.setOutlineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot0.getDataset((int) ' ');
        double double19 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(axisSpace20);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
//        java.text.NumberFormat numberFormat1 = null;
//        numberAxis0.setNumberFormatOverride(numberFormat1);
//        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
//        categoryPlot3.setNoDataMessage("SeriesRenderingOrder.FORWARD");
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        categoryPlot3.setRenderer(500, categoryItemRenderer9, false);
//        boolean boolean12 = numberAxis0.equals((java.lang.Object) false);
//        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        numberAxis0.setTickMarkStroke(stroke13);
//        java.lang.Object obj15 = numberAxis0.clone();
//        java.awt.geom.Rectangle2D rectangle2D17 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
//        categoryPlot18.setFixedDomainAxisSpace(axisSpace19);
//        org.jfree.chart.util.SortOrder sortOrder21 = org.jfree.chart.util.SortOrder.DESCENDING;
//        boolean boolean23 = sortOrder21.equals((java.lang.Object) 10L);
//        categoryPlot18.setRowRenderingOrder(sortOrder21);
//        java.awt.Paint paint25 = categoryPlot18.getRangeCrosshairPaint();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        long long28 = day27.getFirstMillisecond();
//        long long29 = day27.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot32 = dateAxis31.getPlot();
//        boolean boolean33 = dateAxis31.isNegativeArrowVisible();
//        boolean boolean34 = dateAxis31.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D38 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
//        double double40 = dateAxis36.dateToJava2D(date37, rectangle2D38, rectangleEdge39);
//        java.awt.geom.Rectangle2D rectangle2D41 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
//        double double43 = dateAxis31.dateToJava2D(date37, rectangle2D41, rectangleEdge42);
//        int int44 = day27.compareTo((java.lang.Object) date37);
//        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day27, (java.awt.Paint) color45, stroke46);
//        org.jfree.chart.text.TextAnchor textAnchor48 = categoryMarker47.getLabelTextAnchor();
//        java.awt.Stroke stroke49 = categoryMarker47.getStroke();
//        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double52 = dateAxis51.getLowerMargin();
//        float float53 = dateAxis51.getTickMarkOutsideLength();
//        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation56 = null;
//        categoryPlot54.setRangeAxisLocation((int) (byte) 100, axisLocation56);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent58 = null;
//        categoryPlot54.datasetChanged(datasetChangeEvent58);
//        boolean boolean60 = dateAxis51.hasListener((java.util.EventListener) categoryPlot54);
//        float float61 = categoryPlot54.getBackgroundAlpha();
//        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot54.getDomainAxisEdge();
//        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker(0.0d);
//        boolean boolean67 = valueMarker65.equals((java.lang.Object) 100L);
//        boolean boolean69 = valueMarker65.equals((java.lang.Object) 3);
//        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean71 = categoryPlot54.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker65, layer70);
//        boolean boolean73 = categoryPlot18.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker47, layer70, true);
//        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot18.getRangeAxisEdge();
//        try {
//            double double75 = numberAxis0.valueToJava2D((double) (short) 10, rectangle2D17, rectangleEdge74);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(stroke13);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertNotNull(sortOrder21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560409200000L + "'", long28 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 43629L + "'", long29 == 43629L);
//        org.junit.Assert.assertNull(plot32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(color45);
//        org.junit.Assert.assertNotNull(stroke46);
//        org.junit.Assert.assertNotNull(textAnchor48);
//        org.junit.Assert.assertNotNull(stroke49);
//        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.05d + "'", double52 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 2.0f + "'", float53 == 2.0f);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 1.0f + "'", float61 == 1.0f);
//        org.junit.Assert.assertNotNull(rectangleEdge62);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(layer70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge74);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D3 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
//        double double5 = dateAxis1.dateToJava2D(date2, rectangle2D3, rectangleEdge4);
//        java.awt.geom.Rectangle2D rectangle2D7 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
//        double double9 = dateAxis1.java2DToValue((double) (short) -1, rectangle2D7, rectangleEdge8);
//        boolean boolean10 = dateAxis1.isAutoTickUnitSelection();
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis12.dateToJava2D(date13, rectangle2D14, rectangleEdge15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date13, timeZone17);
//        long long20 = day19.getFirstMillisecond();
//        java.util.Date date21 = day19.getStart();
//        dateAxis1.setMinimumDate(date21);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-9.223372036854776E18d) + "'", double9 == (-9.223372036854776E18d));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(tickUnitSource18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560409200000L + "'", long20 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = dateAxis1.hasListener(eventListener4);
        boolean boolean6 = dateAxis1.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj9 = dateAxis8.clone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        dateAxis8.setStandardTickUnits(tickUnitSource10);
        boolean boolean12 = dateAxis8.isTickMarksVisible();
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        dateAxis8.setLabelPaint((java.awt.Paint) color13);
        dateAxis1.setAxisLinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        xYPlot33.setDomainZeroBaselineVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        xYPlot33.setRenderer(xYItemRenderer40);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        xYPlot33.setRenderer(xYItemRenderer42);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) layer10);
        java.util.Collection collection12 = categoryPlot0.getRangeMarkers((int) ' ', layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot15.setDomainAxis(7, categoryAxis21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int25 = color24.getAlpha();
        categoryPlot15.setRangeCrosshairPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = categoryPlot15.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot15.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot15.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot36 = dateAxis35.getPlot();
        boolean boolean37 = dateAxis35.isNegativeArrowVisible();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis35.setTimeZone(timeZone38);
        java.awt.Font font40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis35.setLabelFont(font40);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis35.valueToJava2D((double) 10.0f, rectangle2D43, rectangleEdge44);
        dateAxis35.setAutoTickUnitSelection(false, true);
        dateAxis35.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = dateAxis35.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot54 = dateAxis53.getPlot();
        boolean boolean55 = dateAxis53.isNegativeArrowVisible();
        boolean boolean56 = dateAxis53.isVerticalTickLabels();
        java.util.TimeZone timeZone57 = dateAxis53.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot60 = dateAxis59.getPlot();
        boolean boolean61 = dateAxis59.isNegativeArrowVisible();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis59.setTimeZone(timeZone62);
        dateAxis53.setTimeZone(timeZone62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis53, xYItemRenderer65);
        java.awt.Paint paint67 = xYPlot66.getRangeZeroBaselinePaint();
        boolean boolean68 = xYPlot66.isRangeCrosshairLockedOnData();
        java.awt.Paint paint69 = xYPlot66.getDomainGridlinePaint();
        boolean boolean70 = xYPlot66.isDomainZoomable();
        boolean boolean71 = xYPlot66.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D72 = xYPlot66.getQuadrantOrigin();
        categoryPlot15.zoomRangeAxes(2.0d, plotRenderingInfo32, point2D72);
        categoryPlot0.zoomRangeAxes(0.05d, plotRenderingInfo14, point2D72);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(plot60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(point2D72);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (short) 1);
        double double4 = rectangleInsets0.calculateTopInset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color1 = color0.darker();
        java.awt.Color color2 = color1.darker();
        java.lang.String str3 = color1.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=0,g=0,b=134]" + "'", str3.equals("java.awt.Color[r=0,g=0,b=134]"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        java.awt.Paint paint36 = xYPlot33.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot38.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot38.setRenderer(categoryItemRenderer41);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean45 = categoryPlot44.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot44.getRendererForDataset(categoryDataset46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot44.setDomainAxisLocation(0, axisLocation49);
        categoryPlot38.setRangeAxisLocation((int) (byte) 100, axisLocation49);
        xYPlot33.setDomainAxisLocation(6, axisLocation49);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot33.getRangeAxisForDataset(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 7 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        categoryPlot0.setDataset(categoryDataset3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot7 = dateAxis6.getPlot();
        int int8 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis6);
        boolean boolean9 = categoryPlot0.isRangeZoomable();
        java.awt.Stroke stroke10 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        double double13 = dateAxis12.getLowerMargin();
        float float14 = dateAxis12.getTickMarkOutsideLength();
        dateAxis12.setTickLabelsVisible(true);
        dateAxis12.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = null;
        dateAxis12.setTickUnit(dateTickUnit19);
        double double21 = dateAxis12.getLowerMargin();
        int int22 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis12);
        boolean boolean23 = dateAxis12.isTickMarksVisible();
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        int int35 = xYPlot33.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot33.setFixedRangeAxisSpace(axisSpace36);
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint38, dataset39);
        xYPlot33.datasetChanged(datasetChangeEvent40);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(paint38);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        int int3 = day0.getYear();
//        long long4 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        categoryPlot0.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        int int5 = categoryPlot0.getDatasetCount();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        boolean boolean10 = layer8.equals((java.lang.Object) textAnchor9);
        boolean boolean11 = categoryPlot0.removeDomainMarker(marker7, layer8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        org.jfree.data.Range range6 = dateAxis1.getRange();
        java.util.TimeZone timeZone7 = dateAxis1.getTimeZone();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range8, true, true);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(range8);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
//        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis2.setTimeZone(timeZone5);
//        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        dateAxis2.setLabelFont(font7);
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
//        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
//        dateAxis2.setAutoTickUnitSelection(false, true);
//        dateAxis2.setAutoRange(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
//        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
//        boolean boolean23 = dateAxis20.isVerticalTickLabels();
//        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
//        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        dateAxis26.setTimeZone(timeZone29);
//        dateAxis20.setTimeZone(timeZone29);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
//        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
//        xYPlot33.configureDomainAxes();
//        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot33.getFixedRangeAxisSpace();
//        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double38 = dateAxis37.getLowerMargin();
//        java.awt.Paint paint39 = dateAxis37.getTickMarkPaint();
//        dateAxis37.setLowerMargin((double) 0);
//        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
//        categoryPlot42.setRangeAxisLocation((int) (byte) 100, axisLocation44);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent46 = null;
//        categoryPlot42.datasetChanged(datasetChangeEvent46);
//        categoryPlot42.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
//        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot42.getOrientation();
//        boolean boolean52 = dateAxis37.hasListener((java.util.EventListener) categoryPlot42);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        long long54 = day53.getFirstMillisecond();
//        long long55 = day53.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot58 = dateAxis57.getPlot();
//        boolean boolean59 = dateAxis57.isNegativeArrowVisible();
//        boolean boolean60 = dateAxis57.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date63 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D64 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge65 = null;
//        double double66 = dateAxis62.dateToJava2D(date63, rectangle2D64, rectangleEdge65);
//        java.awt.geom.Rectangle2D rectangle2D67 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
//        double double69 = dateAxis57.dateToJava2D(date63, rectangle2D67, rectangleEdge68);
//        int int70 = day53.compareTo((java.lang.Object) date63);
//        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker73 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day53, (java.awt.Paint) color71, stroke72);
//        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double76 = dateAxis75.getLowerMargin();
//        float float77 = dateAxis75.getTickMarkOutsideLength();
//        dateAxis75.setTickLabelsVisible(true);
//        dateAxis75.setInverted(false);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit82 = null;
//        dateAxis75.setTickUnit(dateTickUnit82);
//        double double84 = dateAxis75.getFixedDimension();
//        boolean boolean85 = categoryMarker73.equals((java.lang.Object) dateAxis75);
//        categoryPlot42.addDomainMarker(categoryMarker73);
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType87 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        boolean boolean88 = categoryMarker73.equals((java.lang.Object) chartChangeEventType87);
//        xYPlot33.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker73);
//        org.jfree.chart.annotations.XYAnnotation xYAnnotation90 = null;
//        try {
//            boolean boolean92 = xYPlot33.removeAnnotation(xYAnnotation90, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(plot3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(font7);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertNotNull(tickUnitSource18);
//        org.junit.Assert.assertNull(plot21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(plot27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(axisSpace35);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
//        org.junit.Assert.assertNotNull(paint39);
//        org.junit.Assert.assertNotNull(plotOrientation51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560409200000L + "'", long54 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43629L + "'", long55 == 43629L);
//        org.junit.Assert.assertNull(plot58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(color71);
//        org.junit.Assert.assertNotNull(stroke72);
//        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 2.0f + "'", float77 == 2.0f);
//        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(chartChangeEventType87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis1.setTickUnit(dateTickUnit8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot12 = dateAxis11.getPlot();
        boolean boolean13 = dateAxis11.isNegativeArrowVisible();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis11.setTimeZone(timeZone14);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis11.setLabelFont(font16);
        dateAxis1.setTickLabelFont(font16);
        java.lang.String str19 = dateAxis1.getLabel();
        boolean boolean21 = dateAxis1.isHiddenValue((long) 4);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot22.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier23);
        categoryPlot22.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        int int27 = categoryPlot22.getDatasetCount();
        double double28 = categoryPlot22.getRangeCrosshairValue();
        java.lang.Object obj29 = categoryPlot22.clone();
        boolean boolean30 = dateAxis1.hasListener((java.util.EventListener) categoryPlot22);
        java.util.List list31 = categoryPlot22.getCategories();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(list31);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.Color color7 = java.awt.Color.pink;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        float[] floatArray14 = new float[] { (short) -1, 13, (short) 10, 6, 1560495599999L };
        float[] floatArray15 = color8.getRGBColorComponents(floatArray14);
        float[] floatArray16 = color7.getColorComponents(floatArray15);
        float[] floatArray17 = color0.getColorComponents(floatArray16);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        java.awt.Paint paint36 = xYPlot33.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot38.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot38.setRenderer(categoryItemRenderer41);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean45 = categoryPlot44.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot44.getRendererForDataset(categoryDataset46);
        org.jfree.chart.axis.AxisLocation axisLocation49 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot44.setDomainAxisLocation(0, axisLocation49);
        categoryPlot38.setRangeAxisLocation((int) (byte) 100, axisLocation49);
        xYPlot33.setDomainAxisLocation(6, axisLocation49);
        boolean boolean53 = xYPlot33.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        java.awt.Paint paint36 = xYPlot33.getDomainGridlinePaint();
        boolean boolean37 = xYPlot33.isDomainZoomable();
        java.awt.Stroke stroke38 = xYPlot33.getDomainCrosshairStroke();
        boolean boolean39 = xYPlot33.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot33.getDomainAxisEdge();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation41 = null;
        try {
            boolean boolean43 = xYPlot33.removeAnnotation(xYAnnotation41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        intervalMarker11.removeChangeListener(markerChangeListener13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot0.removeRangeMarker(10, (org.jfree.chart.plot.Marker) intervalMarker11, layer15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot19 = dateAxis18.getPlot();
        boolean boolean20 = dateAxis18.isNegativeArrowVisible();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis18.setTimeZone(timeZone21);
        java.awt.Font font23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis18.setLabelFont(font23);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = dateAxis18.valueToJava2D((double) 10.0f, rectangle2D26, rectangleEdge27);
        dateAxis18.setAutoTickUnitSelection(false, true);
        java.awt.Paint paint32 = dateAxis18.getTickLabelPaint();
        intervalMarker11.setLabelPaint(paint32);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(plot19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        org.jfree.data.general.DatasetGroup datasetGroup63 = xYPlot33.getDatasetGroup();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNull(datasetGroup63);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double38 = rectangleInsets36.extendWidth((double) (byte) 0);
        xYPlot33.setAxisOffset(rectangleInsets36);
        java.awt.Stroke stroke40 = xYPlot33.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 16.0d + "'", double38 == 16.0d);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(0, layer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes(1.0E-8d, 100.0d, plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean15 = valueMarker13.equals((java.lang.Object) 100L);
        double double16 = valueMarker13.getValue();
        boolean boolean17 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker13);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis20.setTimeZone(timeZone23);
        java.awt.Font font25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis20.setLabelFont(font25);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis20.valueToJava2D((double) 10.0f, rectangle2D28, rectangleEdge29);
        dateAxis20.setAutoTickUnitSelection(false, true);
        dateAxis20.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = dateAxis20.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot39 = dateAxis38.getPlot();
        boolean boolean40 = dateAxis38.isNegativeArrowVisible();
        boolean boolean41 = dateAxis38.isVerticalTickLabels();
        java.util.TimeZone timeZone42 = dateAxis38.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot45 = dateAxis44.getPlot();
        boolean boolean46 = dateAxis44.isNegativeArrowVisible();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis44.setTimeZone(timeZone47);
        dateAxis38.setTimeZone(timeZone47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str54 = axisLocation53.toString();
        xYPlot51.setDomainAxisLocation((int) (byte) 100, axisLocation53);
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot51.getRangeAxis((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace58 = xYPlot51.getFixedDomainAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date62 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = dateAxis61.dateToJava2D(date62, rectangle2D63, rectangleEdge64);
        org.jfree.chart.event.AxisChangeListener axisChangeListener66 = null;
        dateAxis61.addChangeListener(axisChangeListener66);
        xYPlot51.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis61, true);
        boolean boolean70 = categoryPlot0.equals((java.lang.Object) 11);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertNull(plot39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(plot45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str54.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNull(axisSpace58);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot5 = dateAxis4.getPlot();
//        boolean boolean6 = dateAxis4.isNegativeArrowVisible();
//        boolean boolean7 = dateAxis4.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis4.dateToJava2D(date10, rectangle2D14, rectangleEdge15);
//        int int17 = day0.compareTo((java.lang.Object) date10);
//        org.jfree.data.time.SerialDate serialDate18 = day0.getSerialDate();
//        long long19 = day0.getMiddleMillisecond();
//        java.util.Date date20 = day0.getStart();
//        long long21 = day0.getSerialIndex();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day0.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNull(plot5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560452399999L + "'", long19 == 1560452399999L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43629L + "'", long21 == 43629L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot11 = dateAxis10.getPlot();
        boolean boolean12 = dateAxis10.isNegativeArrowVisible();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis10.setTimeZone(timeZone13);
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis10.setLabelFont(font15);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = dateAxis10.valueToJava2D((double) 10.0f, rectangle2D18, rectangleEdge19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        java.util.List list25 = dateAxis10.refreshTicks(graphics2D21, axisState22, rectangle2D23, rectangleEdge24);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = categoryPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(list25);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNotNull(plotOrientation28);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.awt.Color color1 = java.awt.Color.black;
        java.awt.Color color2 = color1.darker();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot6 = dateAxis5.getPlot();
        boolean boolean7 = dateAxis5.isNegativeArrowVisible();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis5.setTimeZone(timeZone8);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setLabelFont(font10);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = dateAxis5.valueToJava2D((double) 10.0f, rectangle2D13, rectangleEdge14);
        dateAxis5.setAutoTickUnitSelection(false, true);
        dateAxis5.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis5.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot24 = dateAxis23.getPlot();
        boolean boolean25 = dateAxis23.isNegativeArrowVisible();
        boolean boolean26 = dateAxis23.isVerticalTickLabels();
        java.util.TimeZone timeZone27 = dateAxis23.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot30 = dateAxis29.getPlot();
        boolean boolean31 = dateAxis29.isNegativeArrowVisible();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis29.setTimeZone(timeZone32);
        dateAxis23.setTimeZone(timeZone32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer35);
        xYPlot36.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        double double41 = dateAxis40.getLowerMargin();
        float float42 = dateAxis40.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation45 = null;
        categoryPlot43.setRangeAxisLocation((int) (byte) 100, axisLocation45);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent47 = null;
        categoryPlot43.datasetChanged(datasetChangeEvent47);
        boolean boolean49 = dateAxis40.hasListener((java.util.EventListener) categoryPlot43);
        float float50 = categoryPlot43.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot43.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean56 = valueMarker54.equals((java.lang.Object) 100L);
        boolean boolean58 = valueMarker54.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean60 = categoryPlot43.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker54, layer59);
        java.util.Collection collection61 = xYPlot36.getDomainMarkers((-16777216), layer59);
        xYPlot36.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace63 = xYPlot36.getFixedRangeAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("hi!");
        double double66 = dateAxis65.getLowerMargin();
        float float67 = dateAxis65.getTickMarkOutsideLength();
        dateAxis65.setTickLabelsVisible(true);
        dateAxis65.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit72 = null;
        dateAxis65.setTickUnit(dateTickUnit72);
        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot76 = dateAxis75.getPlot();
        boolean boolean77 = dateAxis75.isNegativeArrowVisible();
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis75.setTimeZone(timeZone78);
        java.awt.Font font80 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis75.setLabelFont(font80);
        dateAxis65.setTickLabelFont(font80);
        java.awt.Stroke stroke83 = dateAxis65.getAxisLineStroke();
        xYPlot36.setDomainCrosshairStroke(stroke83);
        org.jfree.chart.plot.ValueMarker valueMarker85 = new org.jfree.chart.plot.ValueMarker((double) 10.0f, (java.awt.Paint) color2, stroke83);
        java.awt.Paint paint86 = valueMarker85.getOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 2.0f + "'", float42 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 1.0f + "'", float50 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNull(axisSpace63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.05d + "'", double66 == 0.05d);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 2.0f + "'", float67 == 2.0f);
        org.junit.Assert.assertNull(plot76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNotNull(font80);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(paint86);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        xYPlot33.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace35 = xYPlot33.getFixedRangeAxisSpace();
        boolean boolean36 = xYPlot33.isRangeZeroBaselineVisible();
        java.awt.Paint paint37 = xYPlot33.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
        double double5 = dateAxis4.getLowerMargin();
        float float6 = dateAxis4.getTickMarkOutsideLength();
        dateAxis4.setTickLabelsVisible(true);
        dateAxis4.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot13 = dateAxis12.getPlot();
        boolean boolean14 = dateAxis12.isNegativeArrowVisible();
        boolean boolean15 = dateAxis12.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis17.dateToJava2D(date18, rectangle2D19, rectangleEdge20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis12.dateToJava2D(date18, rectangle2D22, rectangleEdge23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis12.setTickMarkStroke(stroke25);
        dateAxis4.setAxisLineStroke(stroke25);
        categoryPlot0.setOutlineStroke(stroke25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot0.getDatasetRenderingOrder();
        java.lang.String str30 = datasetRenderingOrder29.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str30.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj2 = dateAxis1.clone();
        double double3 = dateAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        java.awt.Paint paint36 = xYPlot33.getDomainGridlinePaint();
        boolean boolean37 = xYPlot33.isDomainZoomable();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.util.List list40 = null;
        xYPlot33.drawDomainTickBands(graphics2D38, rectangle2D39, list40);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date44 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = dateAxis43.dateToJava2D(date44, rectangle2D45, rectangleEdge46);
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("hi!");
        double double50 = dateAxis49.getLowerMargin();
        float float51 = dateAxis49.getTickMarkOutsideLength();
        dateAxis49.setTickLabelsVisible(true);
        org.jfree.chart.axis.Timeline timeline54 = dateAxis49.getTimeline();
        dateAxis43.setTimeline(timeline54);
        dateAxis43.configure();
        org.jfree.data.Range range57 = xYPlot33.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis43);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 2.0f + "'", float51 == 2.0f);
        org.junit.Assert.assertNotNull(timeline54);
        org.junit.Assert.assertNull(range57);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis1.setTickUnit(dateTickUnit8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot12 = dateAxis11.getPlot();
        boolean boolean13 = dateAxis11.isNegativeArrowVisible();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis11.setTimeZone(timeZone14);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis11.setLabelFont(font16);
        dateAxis1.setTickLabelFont(font16);
        java.awt.Stroke stroke19 = dateAxis1.getAxisLineStroke();
        dateAxis1.setNegativeArrowVisible(false);
        boolean boolean22 = dateAxis1.isAutoRange();
        dateAxis1.resizeRange((double) 255, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = dateAxis1.valueToJava2D((-9.223372036854776E18d), rectangle2D3, rectangleEdge4);
        java.lang.String str6 = dateAxis1.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        dateAxis1.setTickLabelInsets(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        java.awt.Font font6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis1.setLabelFont(font6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = dateAxis1.valueToJava2D((double) 10.0f, rectangle2D9, rectangleEdge10);
        dateAxis1.setAutoTickUnitSelection(false, true);
        java.awt.Shape shape15 = dateAxis1.getRightArrow();
        java.awt.Paint paint16 = dateAxis1.getTickLabelPaint();
        dateAxis1.setPositiveArrowVisible(true);
        java.util.Date date19 = dateAxis1.getMinimumDate();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isSubplot();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = categoryPlot0.getDrawingSupplier();
        float float14 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace40 = xYPlot33.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray42 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer41 };
        xYPlot33.setRenderers(xYItemRendererArray42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        xYPlot33.setFixedDomainAxisSpace(axisSpace44, true);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(xYItemRendererArray42);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        categoryPlot4.setRangeAxisLocation((int) (byte) 100, axisLocation6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        boolean boolean10 = dateAxis1.hasListener((java.util.EventListener) categoryPlot4);
        float float11 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot4.getDataset();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("hi!");
        double double16 = dateAxis15.getLowerMargin();
        float float17 = dateAxis15.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot18.setRangeAxisLocation((int) (byte) 100, axisLocation20);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        categoryPlot18.datasetChanged(datasetChangeEvent22);
        boolean boolean24 = dateAxis15.hasListener((java.util.EventListener) categoryPlot18);
        float float25 = categoryPlot18.getBackgroundAlpha();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot18.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean31 = valueMarker29.equals((java.lang.Object) 100L);
        boolean boolean33 = valueMarker29.equals((java.lang.Object) 3);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = categoryPlot18.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker29, layer34);
        java.util.Collection collection36 = categoryPlot4.getRangeMarkers(layer34);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot41 = dateAxis40.getPlot();
        boolean boolean42 = dateAxis40.isNegativeArrowVisible();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis40.setTimeZone(timeZone43);
        java.awt.Font font45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis40.setLabelFont(font45);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = dateAxis40.valueToJava2D((double) 10.0f, rectangle2D48, rectangleEdge49);
        dateAxis40.setAutoTickUnitSelection(false, true);
        dateAxis40.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource56 = dateAxis40.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot59 = dateAxis58.getPlot();
        boolean boolean60 = dateAxis58.isNegativeArrowVisible();
        boolean boolean61 = dateAxis58.isVerticalTickLabels();
        java.util.TimeZone timeZone62 = dateAxis58.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot65 = dateAxis64.getPlot();
        boolean boolean66 = dateAxis64.isNegativeArrowVisible();
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis64.setTimeZone(timeZone67);
        dateAxis58.setTimeZone(timeZone67);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer70 = null;
        org.jfree.chart.plot.XYPlot xYPlot71 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) dateAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis58, xYItemRenderer70);
        java.awt.Paint paint72 = xYPlot71.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation74 = xYPlot71.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis75 = xYPlot71.getRangeAxis();
        double double76 = xYPlot71.getRangeCrosshairValue();
        org.jfree.chart.plot.IntervalMarker intervalMarker79 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        intervalMarker79.setStartValue((double) 3);
        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent83 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) layer82);
        xYPlot71.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker79, layer82);
        java.util.Collection collection85 = categoryPlot4.getDomainMarkers(4, layer82);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource56);
        org.junit.Assert.assertNull(plot59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(plot65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertNotNull(valueAxis75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(layer82);
        org.junit.Assert.assertNull(collection85);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double2 = dateAxis1.getLowerMargin();
//        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
//        dateAxis1.setLowerMargin((double) 0);
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
//        categoryPlot6.setRangeAxisLocation((int) (byte) 100, axisLocation8);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
//        categoryPlot6.datasetChanged(datasetChangeEvent10);
//        categoryPlot6.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
//        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot6.getOrientation();
//        boolean boolean16 = dateAxis1.hasListener((java.util.EventListener) categoryPlot6);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getFirstMillisecond();
//        long long19 = day17.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot22 = dateAxis21.getPlot();
//        boolean boolean23 = dateAxis21.isNegativeArrowVisible();
//        boolean boolean24 = dateAxis21.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D28 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
//        double double30 = dateAxis26.dateToJava2D(date27, rectangle2D28, rectangleEdge29);
//        java.awt.geom.Rectangle2D rectangle2D31 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
//        double double33 = dateAxis21.dateToJava2D(date27, rectangle2D31, rectangleEdge32);
//        int int34 = day17.compareTo((java.lang.Object) date27);
//        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day17, (java.awt.Paint) color35, stroke36);
//        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double40 = dateAxis39.getLowerMargin();
//        float float41 = dateAxis39.getTickMarkOutsideLength();
//        dateAxis39.setTickLabelsVisible(true);
//        dateAxis39.setInverted(false);
//        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = null;
//        dateAxis39.setTickUnit(dateTickUnit46);
//        double double48 = dateAxis39.getFixedDimension();
//        boolean boolean49 = categoryMarker37.equals((java.lang.Object) dateAxis39);
//        categoryPlot6.addDomainMarker(categoryMarker37);
//        org.jfree.chart.plot.IntervalMarker intervalMarker53 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
//        org.jfree.chart.util.Layer layer54 = null;
//        boolean boolean55 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker53, layer54);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertNotNull(plotOrientation15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertNull(plot22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(color35);
//        org.junit.Assert.assertNotNull(stroke36);
//        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 2.0f + "'", float41 == 2.0f);
//        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) 100L, plotRenderingInfo9, point2D10);
        categoryPlot0.configureDomainAxes();
        java.awt.Paint paint13 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.dateToJava2D(date4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis9.java2DToValue((double) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis9.setTickLabelFont(font18);
        dateAxis3.setLabelFont(font18);
        org.jfree.data.Range range21 = dateAxis3.getRange();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis3.setRightArrow(shape22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot26.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot26.setRenderer(categoryItemRenderer29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot26.setDomainAxis(7, categoryAxis32, false);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int36 = color35.getAlpha();
        categoryPlot26.setRangeCrosshairPaint((java.awt.Paint) color35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = categoryPlot26.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryPlot26.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot26.getRangeAxisEdge((int) 'a');
        boolean boolean42 = categoryAxis1.equals((java.lang.Object) rectangleEdge41);
        float float43 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot47.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot47.setRenderer(categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        categoryPlot47.setDomainAxis(7, categoryAxis53, false);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int57 = color56.getAlpha();
        categoryPlot47.setRangeCrosshairPaint((java.awt.Paint) color56);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder59 = categoryPlot47.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryPlot47.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot47.getRangeAxisEdge((int) 'a');
        try {
            double double63 = categoryAxis1.getCategoryStart((int) (short) 10, (int) (short) 0, rectangle2D46, rectangleEdge62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9.223372036854776E18d) + "'", double17 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 255 + "'", int36 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 255 + "'", int57 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(rectangleEdge62);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        boolean boolean3 = numberAxis0.isTickMarksVisible();
        java.awt.Color color4 = java.awt.Color.yellow;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        double double7 = dateAxis6.getLowerMargin();
        java.awt.Color color8 = java.awt.Color.RED;
        dateAxis6.setLabelPaint((java.awt.Paint) color8);
        java.awt.Color color10 = color8.brighter();
        java.awt.Color color11 = color10.darker();
        java.awt.Color color12 = java.awt.Color.GREEN;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        float[] floatArray14 = null;
        float[] floatArray15 = color11.getColorComponents(colorSpace13, floatArray14);
        float[] floatArray16 = color4.getColorComponents(floatArray14);
        java.lang.String str17 = color4.toString();
        numberAxis0.setTickLabelPaint((java.awt.Paint) color4);
        boolean boolean19 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=255,g=255,b=0]" + "'", str17.equals("java.awt.Color[r=255,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        int int63 = xYPlot33.getSeriesCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        try {
            xYPlot33.handleClick((int) (short) 1, 2019, plotRenderingInfo66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot0.setRangeAxisLocation(7, axisLocation4);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean9 = valueMarker7.equals((java.lang.Object) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker7);
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 9, jFreeChart13, chartChangeEventType14);
        java.lang.String str16 = chartChangeEventType14.toString();
        markerChangeEvent10.setType(chartChangeEventType14);
        org.jfree.chart.plot.Marker marker18 = markerChangeEvent10.getMarker();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str16.equals("ChartChangeEventType.NEW_DATASET"));
        org.junit.Assert.assertNotNull(marker18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        xYPlot33.setDomainZeroBaselineVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        xYPlot33.setRenderer(xYItemRenderer40);
        boolean boolean42 = xYPlot33.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        int int63 = xYPlot33.getSeriesCount();
        xYPlot33.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("hi!");
        double double68 = dateAxis67.getLowerMargin();
        float float69 = dateAxis67.getTickMarkOutsideLength();
        dateAxis67.setTickLabelsVisible(true);
        dateAxis67.setInverted(false);
        xYPlot33.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis67);
        double double75 = dateAxis67.getLabelAngle();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.05d + "'", double68 == 0.05d);
        org.junit.Assert.assertTrue("'" + float69 + "' != '" + 2.0f + "'", float69 == 2.0f);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        java.util.Date date4 = dateAxis1.getMinimumDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis1.setTickUnit(dateTickUnit8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot12 = dateAxis11.getPlot();
        boolean boolean13 = dateAxis11.isNegativeArrowVisible();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis11.setTimeZone(timeZone14);
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis11.setLabelFont(font16);
        dateAxis1.setTickLabelFont(font16);
        java.lang.String str19 = dateAxis1.getLabel();
        boolean boolean21 = dateAxis1.isHiddenValue((long) 4);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        java.lang.Object obj24 = dateAxis23.clone();
        dateAxis23.setTickMarkOutsideLength((float) (byte) 1);
        java.util.Date date27 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis23.setMaximumDate(date27);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        double double31 = dateAxis30.getLowerMargin();
        float float32 = dateAxis30.getTickMarkOutsideLength();
        dateAxis30.setTickLabelsVisible(true);
        dateAxis30.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = null;
        dateAxis30.setTickUnit(dateTickUnit37);
        double double39 = dateAxis30.getLowerMargin();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition40 = dateAxis30.getTickMarkPosition();
        dateAxis23.setTickMarkPosition(dateTickMarkPosition40);
        dateAxis1.setTickMarkPosition(dateTickMarkPosition40);
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition40);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        boolean boolean3 = numberAxis0.isTickMarksVisible();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot7 = dateAxis6.getPlot();
        boolean boolean8 = dateAxis6.isNegativeArrowVisible();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis6.setTimeZone(timeZone9);
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis6.setLabelFont(font11);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = dateAxis6.valueToJava2D((double) 10.0f, rectangle2D14, rectangleEdge15);
        dateAxis6.setAutoTickUnitSelection(false, true);
        dateAxis6.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis6.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot25 = dateAxis24.getPlot();
        boolean boolean26 = dateAxis24.isNegativeArrowVisible();
        boolean boolean27 = dateAxis24.isVerticalTickLabels();
        java.util.TimeZone timeZone28 = dateAxis24.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot31 = dateAxis30.getPlot();
        boolean boolean32 = dateAxis30.isNegativeArrowVisible();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis30.setTimeZone(timeZone33);
        dateAxis24.setTimeZone(timeZone33);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer36);
        xYPlot37.configureDomainAxes();
        int int39 = xYPlot37.getDatasetCount();
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        xYPlot37.setFixedRangeAxisSpace(axisSpace40);
        java.lang.String str42 = xYPlot37.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation43 = xYPlot37.getDomainAxisLocation();
        boolean boolean44 = numberAxis0.equals((java.lang.Object) xYPlot37);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(plot31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "XY Plot" + "'", str42.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets8.calculateLeftInset((double) '#');
        categoryPlot0.setAxisOffset(rectangleInsets8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot15.setDomainAxis(7, categoryAxis21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int25 = color24.getAlpha();
        categoryPlot15.setRangeCrosshairPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = categoryPlot15.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot15.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot15.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot36 = dateAxis35.getPlot();
        boolean boolean37 = dateAxis35.isNegativeArrowVisible();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis35.setTimeZone(timeZone38);
        java.awt.Font font40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis35.setLabelFont(font40);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis35.valueToJava2D((double) 10.0f, rectangle2D43, rectangleEdge44);
        dateAxis35.setAutoTickUnitSelection(false, true);
        dateAxis35.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = dateAxis35.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot54 = dateAxis53.getPlot();
        boolean boolean55 = dateAxis53.isNegativeArrowVisible();
        boolean boolean56 = dateAxis53.isVerticalTickLabels();
        java.util.TimeZone timeZone57 = dateAxis53.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot60 = dateAxis59.getPlot();
        boolean boolean61 = dateAxis59.isNegativeArrowVisible();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis59.setTimeZone(timeZone62);
        dateAxis53.setTimeZone(timeZone62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis53, xYItemRenderer65);
        java.awt.Paint paint67 = xYPlot66.getRangeZeroBaselinePaint();
        boolean boolean68 = xYPlot66.isRangeCrosshairLockedOnData();
        java.awt.Paint paint69 = xYPlot66.getDomainGridlinePaint();
        boolean boolean70 = xYPlot66.isDomainZoomable();
        boolean boolean71 = xYPlot66.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D72 = xYPlot66.getQuadrantOrigin();
        categoryPlot15.zoomRangeAxes(2.0d, plotRenderingInfo32, point2D72);
        categoryPlot0.zoomRangeAxes(0.0d, (double) 0, plotRenderingInfo14, point2D72);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(plot60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(point2D72);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace6);
        categoryPlot0.clearRangeAxes();
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (short) -1);
        double double4 = categoryAxis0.getUpperMargin();
        double double5 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setDomainAxisLocation(0, axisLocation5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 1);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        java.awt.Paint paint6 = dateAxis1.getAxisLinePaint();
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        double double10 = dateAxis9.getLowerMargin();
        float float11 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setTickLabelsVisible(true);
        dateAxis9.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot18 = dateAxis17.getPlot();
        boolean boolean19 = dateAxis17.isNegativeArrowVisible();
        boolean boolean20 = dateAxis17.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = dateAxis22.dateToJava2D(date23, rectangle2D24, rectangleEdge25);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = dateAxis17.dateToJava2D(date23, rectangle2D27, rectangleEdge28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis17.setTickMarkStroke(stroke30);
        dateAxis9.setAxisLineStroke(stroke30);
        java.lang.Object obj33 = dateAxis9.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot34.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        categoryPlot34.setRenderer(categoryItemRenderer37);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        categoryPlot34.setDomainAxis(7, categoryAxis40, false);
        dateAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        categoryPlot34.setForegroundAlpha((float) 6);
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot34);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot34.getDomainAxisLocation(0);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(axisLocation48);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.05d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        intervalMarker2.setStartValue((double) (short) 10);
        java.lang.Object obj5 = intervalMarker2.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        java.awt.Paint paint7 = intervalMarker2.getPaint();
        java.awt.Font font8 = intervalMarker2.getLabelFont();
        double double9 = intervalMarker2.getEndValue();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleAnchor0.equals(obj1);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot6 = dateAxis5.getPlot();
        boolean boolean7 = dateAxis5.isNegativeArrowVisible();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis5.setTimeZone(timeZone8);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis5.setLabelFont(font10);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = dateAxis5.valueToJava2D((double) 10.0f, rectangle2D13, rectangleEdge14);
        dateAxis5.setAutoTickUnitSelection(false, true);
        dateAxis5.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis5.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot24 = dateAxis23.getPlot();
        boolean boolean25 = dateAxis23.isNegativeArrowVisible();
        boolean boolean26 = dateAxis23.isVerticalTickLabels();
        java.util.TimeZone timeZone27 = dateAxis23.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot30 = dateAxis29.getPlot();
        boolean boolean31 = dateAxis29.isNegativeArrowVisible();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis29.setTimeZone(timeZone32);
        dateAxis23.setTimeZone(timeZone32);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str39 = axisLocation38.toString();
        xYPlot36.setDomainAxisLocation((int) (byte) 100, axisLocation38);
        org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot36.getRangeAxis((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace43 = xYPlot36.getFixedDomainAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date47 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = dateAxis46.dateToJava2D(date47, rectangle2D48, rectangleEdge49);
        org.jfree.chart.event.AxisChangeListener axisChangeListener51 = null;
        dateAxis46.addChangeListener(axisChangeListener51);
        xYPlot36.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis46, true);
        java.util.TimeZone timeZone55 = dateAxis46.getTimeZone();
        boolean boolean56 = rectangleAnchor0.equals((java.lang.Object) dateAxis46);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(plot30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str39.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        boolean boolean63 = xYPlot33.isRangeGridlinesVisible();
        boolean boolean64 = xYPlot33.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setRangeAxisLocation((int) (byte) 100, axisLocation3);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean8 = valueMarker6.equals((java.lang.Object) 100L);
        boolean boolean10 = valueMarker6.equals((java.lang.Object) 3);
        categoryPlot1.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        java.awt.Paint paint12 = valueMarker6.getLabelPaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot15.setDomainAxis(7, categoryAxis21, false);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int25 = color24.getAlpha();
        categoryPlot15.setRangeCrosshairPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = categoryPlot15.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot15.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot15.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot36 = dateAxis35.getPlot();
        boolean boolean37 = dateAxis35.isNegativeArrowVisible();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis35.setTimeZone(timeZone38);
        java.awt.Font font40 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis35.setLabelFont(font40);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis35.valueToJava2D((double) 10.0f, rectangle2D43, rectangleEdge44);
        dateAxis35.setAutoTickUnitSelection(false, true);
        dateAxis35.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = dateAxis35.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot54 = dateAxis53.getPlot();
        boolean boolean55 = dateAxis53.isNegativeArrowVisible();
        boolean boolean56 = dateAxis53.isVerticalTickLabels();
        java.util.TimeZone timeZone57 = dateAxis53.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot60 = dateAxis59.getPlot();
        boolean boolean61 = dateAxis59.isNegativeArrowVisible();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis59.setTimeZone(timeZone62);
        dateAxis53.setTimeZone(timeZone62);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis53, xYItemRenderer65);
        java.awt.Paint paint67 = xYPlot66.getRangeZeroBaselinePaint();
        boolean boolean68 = xYPlot66.isRangeCrosshairLockedOnData();
        java.awt.Paint paint69 = xYPlot66.getDomainGridlinePaint();
        boolean boolean70 = xYPlot66.isDomainZoomable();
        boolean boolean71 = xYPlot66.isRangeZeroBaselineVisible();
        java.awt.geom.Point2D point2D72 = xYPlot66.getQuadrantOrigin();
        categoryPlot15.zoomRangeAxes(2.0d, plotRenderingInfo32, point2D72);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot15.setRangeGridlineStroke(stroke74);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10, paint12, stroke13, paint14, stroke74, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(plot36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertNull(plot54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(plot60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(point2D72);
        org.junit.Assert.assertNotNull(stroke74);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(3);
        int int2 = objectList1.size();
        objectList1.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.dateToJava2D(date4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis9.java2DToValue((double) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis9.setTickLabelFont(font18);
        dateAxis3.setLabelFont(font18);
        org.jfree.data.Range range21 = dateAxis3.getRange();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis3.setRightArrow(shape22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        categoryPlot25.setRenderer(2019, categoryItemRenderer27, true);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9.223372036854776E18d) + "'", double17 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = dateAxis1.hasListener(eventListener4);
        boolean boolean6 = dateAxis1.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot7.setRangeAxisLocation((int) (byte) 100, axisLocation9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot7.datasetChanged(datasetChangeEvent11);
        categoryPlot7.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
        double double19 = dateAxis18.getLowerMargin();
        float float20 = dateAxis18.getTickMarkOutsideLength();
        dateAxis18.setTickLabelsVisible(true);
        dateAxis18.setInverted(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = null;
        dateAxis18.setTickUnit(dateTickUnit25);
        boolean boolean27 = dateAxis1.equals((java.lang.Object) dateTickUnit25);
        dateAxis1.setFixedAutoRange((double) 192);
        boolean boolean30 = dateAxis1.isAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot33 = dateAxis32.getPlot();
        boolean boolean34 = dateAxis32.isNegativeArrowVisible();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis32.setTimeZone(timeZone35);
        org.jfree.data.Range range37 = dateAxis32.getRange();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot40 = dateAxis39.getPlot();
        boolean boolean41 = dateAxis39.isNegativeArrowVisible();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis39.setTimeZone(timeZone42);
        java.awt.Font font44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis39.setLabelFont(font44);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = dateAxis39.valueToJava2D((double) 10.0f, rectangle2D47, rectangleEdge48);
        dateAxis39.setAutoTickUnitSelection(false, true);
        dateAxis39.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource55 = dateAxis39.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date58 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = dateAxis57.dateToJava2D(date58, rectangle2D59, rectangleEdge60);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date64 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = null;
        double double67 = dateAxis63.dateToJava2D(date64, rectangle2D65, rectangleEdge66);
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = null;
        double double71 = dateAxis63.java2DToValue((double) (short) -1, rectangle2D69, rectangleEdge70);
        java.awt.Font font72 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis63.setTickLabelFont(font72);
        dateAxis57.setLabelFont(font72);
        org.jfree.data.Range range75 = dateAxis57.getRange();
        java.awt.Shape shape76 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis57.setRightArrow(shape76);
        dateAxis39.setUpArrow(shape76);
        dateAxis32.setLeftArrow(shape76);
        dateAxis1.setRightArrow(shape76);
        java.text.DateFormat dateFormat81 = null;
        dateAxis1.setDateFormatOverride(dateFormat81);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNull(plot40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource55);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + (-9.223372036854776E18d) + "'", double71 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(shape76);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(255, valueAxis7, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean11 = categoryPlot10.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot10.getRendererForDataset(categoryDataset12);
        org.jfree.chart.util.SortOrder sortOrder14 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean16 = sortOrder14.equals((java.lang.Object) 10L);
        categoryPlot10.setRowRenderingOrder(sortOrder14);
        boolean boolean18 = categoryPlot10.isDomainGridlinesVisible();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot22 = dateAxis21.getPlot();
        boolean boolean23 = dateAxis21.isNegativeArrowVisible();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis21.setTimeZone(timeZone24);
        org.jfree.data.Range range26 = dateAxis21.getRange();
        categoryPlot10.setRangeAxis(192, (org.jfree.chart.axis.ValueAxis) dateAxis21, true);
        java.awt.Stroke stroke29 = categoryPlot10.getOutlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke29);
        categoryPlot0.setRangeCrosshairValue((double) 10L, false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        boolean boolean63 = xYPlot33.isRangeGridlinesVisible();
        java.awt.Paint paint64 = xYPlot33.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(paint64);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray8 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray9 = null;
        java.awt.Stroke[] strokeArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis13.dateToJava2D(date14, rectangle2D15, rectangleEdge16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date20 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = dateAxis19.dateToJava2D(date20, rectangle2D21, rectangleEdge22);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = dateAxis19.java2DToValue((double) (short) -1, rectangle2D25, rectangleEdge26);
        java.awt.Font font28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis19.setTickLabelFont(font28);
        dateAxis13.setLabelFont(font28);
        org.jfree.data.Range range31 = dateAxis13.getRange();
        java.awt.Shape shape32 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis13.setRightArrow(shape32);
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape35 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date38 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = dateAxis37.dateToJava2D(date38, rectangle2D39, rectangleEdge40);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date44 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = dateAxis43.dateToJava2D(date44, rectangle2D45, rectangleEdge46);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = dateAxis43.java2DToValue((double) (short) -1, rectangle2D49, rectangleEdge50);
        java.awt.Font font52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis43.setTickLabelFont(font52);
        dateAxis37.setLabelFont(font52);
        org.jfree.data.Range range55 = dateAxis37.getRange();
        java.awt.Shape shape56 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis37.setRightArrow(shape56);
        java.awt.Shape shape58 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] { shape11, shape32, shape34, shape35, shape56, shape58 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray7, paintArray8, strokeArray9, strokeArray10, shapeArray59);
        java.awt.Stroke stroke61 = defaultDrawingSupplier60.getNextOutlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke61);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-9.223372036854776E18d) + "'", double27 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-9.223372036854776E18d) + "'", double51 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        categoryPlot0.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        boolean boolean13 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11);
        java.awt.Stroke stroke14 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = dateAxis3.dateToJava2D(date4, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = dateAxis9.java2DToValue((double) (short) -1, rectangle2D15, rectangleEdge16);
        java.awt.Font font18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis9.setTickLabelFont(font18);
        dateAxis3.setLabelFont(font18);
        org.jfree.data.Range range21 = dateAxis3.getRange();
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        dateAxis3.setRightArrow(shape22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, categoryItemRenderer24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot26.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot26.setRenderer(categoryItemRenderer29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot26.setDomainAxis(7, categoryAxis32, false);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int36 = color35.getAlpha();
        categoryPlot26.setRangeCrosshairPaint((java.awt.Paint) color35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = categoryPlot26.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryPlot26.getAxisOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot26.getRangeAxisEdge((int) 'a');
        boolean boolean42 = categoryAxis1.equals((java.lang.Object) rectangleEdge41);
        int int43 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 192);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean50 = categoryPlot49.isSubplot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot49.zoomDomainAxes((double) 2019, plotRenderingInfo52, point2D53, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot49.getRangeAxisEdge();
        try {
            double double57 = categoryAxis1.getCategoryStart(9, (int) (byte) 1, rectangle2D48, rectangleEdge56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9.223372036854776E18d) + "'", double17 == (-9.223372036854776E18d));
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 255 + "'", int36 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleEdge56);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double38 = rectangleInsets36.extendWidth((double) (byte) 0);
        xYPlot33.setAxisOffset(rectangleInsets36);
        double double41 = rectangleInsets36.calculateTopInset(10.0d);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            rectangleInsets36.trim(rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 16.0d + "'", double38 == 16.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.0d + "'", double41 == 4.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        java.awt.Paint paint9 = null;
        categoryPlot0.setBackgroundPaint(paint9);
        double double11 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        java.util.Date date4 = dateAxis1.getMinimumDate();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("hi!");
        double double9 = dateAxis8.getLowerMargin();
        float float10 = dateAxis8.getTickMarkOutsideLength();
        java.util.Date date11 = dateAxis8.getMinimumDate();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date4, timeZone12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        xYPlot33.setDomainZeroBaselineVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        xYPlot33.setRenderer(xYItemRenderer40);
        java.awt.Paint paint42 = xYPlot33.getBackgroundPaint();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace40 = xYPlot33.getFixedDomainAxisSpace();
        xYPlot33.clearDomainMarkers((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot33.getDomainAxisLocation(1);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(axisLocation44);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot5 = dateAxis4.getPlot();
//        boolean boolean6 = dateAxis4.isNegativeArrowVisible();
//        boolean boolean7 = dateAxis4.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date10 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D11 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
//        double double13 = dateAxis9.dateToJava2D(date10, rectangle2D11, rectangleEdge12);
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = dateAxis4.dateToJava2D(date10, rectangle2D14, rectangleEdge15);
//        int int17 = day0.compareTo((java.lang.Object) date10);
//        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color18, stroke19);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = categoryMarker20.getLabelOffsetType();
//        java.awt.Paint paint22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
//        org.jfree.data.general.Dataset dataset23 = null;
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent24 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint22, dataset23);
//        categoryMarker20.setLabelPaint(paint22);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertNull(plot5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
//        org.junit.Assert.assertNotNull(paint22);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        boolean boolean3 = numberAxis0.isTickMarksVisible();
        numberAxis0.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis0.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 2019);
        intervalMarker2.setEndValue(0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot0.setRangeAxisLocation(7, axisLocation4);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d);
        boolean boolean9 = valueMarker7.equals((java.lang.Object) 100L);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker7);
        categoryPlot0.markerChanged(markerChangeEvent10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        categoryPlot0.clearRangeMarkers((-3));
        categoryPlot0.clearDomainAxes();
        int int17 = categoryPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = dateAxis1.getPlot();
        boolean boolean3 = dateAxis1.isNegativeArrowVisible();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone4);
        dateAxis1.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot10 = dateAxis9.getPlot();
        boolean boolean11 = dateAxis9.isNegativeArrowVisible();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis9.setTimeZone(timeZone12);
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis9.setLabelFont(font14);
        dateAxis1.setLabelFont(font14);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setRangeAxisLocation((int) (byte) 100, axisLocation37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        categoryPlot35.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot35.getOrientation();
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot47 = dateAxis46.getPlot();
        boolean boolean48 = dateAxis46.isNegativeArrowVisible();
        boolean boolean49 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = dateAxis51.dateToJava2D(date52, rectangle2D53, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = dateAxis46.dateToJava2D(date52, rectangle2D56, rectangleEdge57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis46.setTickMarkStroke(stroke59);
        categoryPlot35.setRangeGridlineStroke(stroke59);
        xYPlot33.setRangeCrosshairStroke(stroke59);
        int int63 = xYPlot33.getSeriesCount();
        xYPlot33.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("hi!");
        double double68 = dateAxis67.getLowerMargin();
        float float69 = dateAxis67.getTickMarkOutsideLength();
        dateAxis67.setTickLabelsVisible(true);
        dateAxis67.setInverted(false);
        xYPlot33.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis67);
        int int75 = xYPlot33.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNull(plot47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.05d + "'", double68 == 0.05d);
        org.junit.Assert.assertTrue("'" + float69 + "' != '" + 2.0f + "'", float69 == 2.0f);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 15 + "'", int75 == 15);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        boolean boolean35 = xYPlot33.isRangeCrosshairLockedOnData();
        java.awt.Paint paint36 = xYPlot33.getDomainGridlinePaint();
        boolean boolean37 = xYPlot33.isDomainZoomable();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.util.List list40 = null;
        xYPlot33.drawDomainTickBands(graphics2D38, rectangle2D39, list40);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("hi!");
        double double45 = dateAxis44.getLowerMargin();
        float float46 = dateAxis44.getTickMarkOutsideLength();
        dateAxis44.setTickLabelsVisible(true);
        org.jfree.chart.axis.Timeline timeline49 = dateAxis44.getTimeline();
        xYPlot33.setDomainAxis(9, (org.jfree.chart.axis.ValueAxis) dateAxis44, false);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 2.0f + "'", float46 == 2.0f);
        org.junit.Assert.assertNotNull(timeline49);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis0.setNumberFormatOverride(numberFormat1);
        java.lang.Object obj3 = numberAxis0.clone();
        boolean boolean4 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        java.awt.Paint paint3 = dateAxis1.getTickMarkPaint();
        dateAxis1.setLowerMargin((double) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot6.setRangeAxisLocation((int) (byte) 100, axisLocation8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent10);
        categoryPlot6.mapDatasetToDomainAxis((int) '4', (int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = categoryPlot6.getOrientation();
        boolean boolean16 = dateAxis1.hasListener((java.util.EventListener) categoryPlot6);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = dateAxis1.draw(graphics2D17, 0.0d, rectangle2D19, rectangle2D20, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot0.setDomainAxis(7, categoryAxis6, false);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int10 = color9.getAlpha();
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = categoryPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint13 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str36 = axisLocation35.toString();
        xYPlot33.setDomainAxisLocation((int) (byte) 100, axisLocation35);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot33.getRangeAxis((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace40 = xYPlot33.getFixedDomainAxisSpace();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        xYPlot33.drawBackgroundImage(graphics2D41, rectangle2D42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot44.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier45);
        categoryPlot44.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        int int49 = categoryPlot44.getDatasetCount();
        categoryPlot44.setDomainGridlinesVisible(false);
        java.awt.Color color52 = java.awt.Color.blue;
        categoryPlot44.setOutlinePaint((java.awt.Paint) color52);
        xYPlot33.setRangeCrosshairPaint((java.awt.Paint) color52);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str36.equals("AxisLocation.BOTTOM_OR_RIGHT"));
        org.junit.Assert.assertNull(valueAxis39);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(color52);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRendererForDataset(categoryDataset2);
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean6 = sortOrder4.equals((java.lang.Object) 10L);
        categoryPlot0.setRowRenderingOrder(sortOrder4);
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 100, (double) 0.0f);
        java.awt.Stroke stroke12 = intervalMarker11.getStroke();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener13 = null;
        intervalMarker11.removeChangeListener(markerChangeListener13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot0.removeRangeMarker(10, (org.jfree.chart.plot.Marker) intervalMarker11, layer15);
        intervalMarker11.setEndValue((double) ' ');
        intervalMarker11.setEndValue(9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot3 = dateAxis2.getPlot();
        boolean boolean4 = dateAxis2.isNegativeArrowVisible();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis2.setTimeZone(timeZone5);
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        dateAxis2.setLabelFont(font7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = dateAxis2.valueToJava2D((double) 10.0f, rectangle2D10, rectangleEdge11);
        dateAxis2.setAutoTickUnitSelection(false, true);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis2.getStandardTickUnits();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot21 = dateAxis20.getPlot();
        boolean boolean22 = dateAxis20.isNegativeArrowVisible();
        boolean boolean23 = dateAxis20.isVerticalTickLabels();
        java.util.TimeZone timeZone24 = dateAxis20.getTimeZone();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot27 = dateAxis26.getPlot();
        boolean boolean28 = dateAxis26.isNegativeArrowVisible();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis26.setTimeZone(timeZone29);
        dateAxis20.setTimeZone(timeZone29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer32);
        java.awt.Paint paint34 = xYPlot33.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot33.getDomainAxisLocation((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot33.getRangeAxis();
        double double38 = xYPlot33.getRangeCrosshairValue();
        int int39 = xYPlot33.getDomainAxisCount();
        java.awt.Paint paint40 = xYPlot33.getRangeTickBandPaint();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(valueAxis37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(paint40);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        categoryPlot0.setNoDataMessage("SeriesRenderingOrder.FORWARD");
        int int5 = categoryPlot0.getDatasetCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer9 };
        categoryPlot0.setRenderers(categoryItemRendererArray10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("hi!");
        double double2 = dateAxis1.getLowerMargin();
        float float3 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setTickLabelsVisible(true);
        dateAxis1.setInverted(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("hi!");
        org.jfree.chart.plot.Plot plot10 = dateAxis9.getPlot();
        boolean boolean11 = dateAxis9.isNegativeArrowVisible();
        boolean boolean12 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("hi!");
        java.util.Date date15 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = dateAxis14.dateToJava2D(date15, rectangle2D16, rectangleEdge17);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = dateAxis9.dateToJava2D(date15, rectangle2D19, rectangleEdge20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        dateAxis9.setTickMarkStroke(stroke22);
        dateAxis1.setAxisLineStroke(stroke22);
        boolean boolean25 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisSpace axisSpace1 = null;
//        categoryPlot0.setFixedDomainAxisSpace(axisSpace1);
//        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.DESCENDING;
//        boolean boolean5 = sortOrder3.equals((java.lang.Object) 10L);
//        categoryPlot0.setRowRenderingOrder(sortOrder3);
//        java.awt.Paint paint7 = categoryPlot0.getRangeCrosshairPaint();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getFirstMillisecond();
//        long long11 = day9.getSerialIndex();
//        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("hi!");
//        org.jfree.chart.plot.Plot plot14 = dateAxis13.getPlot();
//        boolean boolean15 = dateAxis13.isNegativeArrowVisible();
//        boolean boolean16 = dateAxis13.isVerticalTickLabels();
//        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("hi!");
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.geom.Rectangle2D rectangle2D20 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
//        double double22 = dateAxis18.dateToJava2D(date19, rectangle2D20, rectangleEdge21);
//        java.awt.geom.Rectangle2D rectangle2D23 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
//        double double25 = dateAxis13.dateToJava2D(date19, rectangle2D23, rectangleEdge24);
//        int int26 = day9.compareTo((java.lang.Object) date19);
//        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day9, (java.awt.Paint) color27, stroke28);
//        org.jfree.chart.text.TextAnchor textAnchor30 = categoryMarker29.getLabelTextAnchor();
//        java.awt.Stroke stroke31 = categoryMarker29.getStroke();
//        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("hi!");
//        double double34 = dateAxis33.getLowerMargin();
//        float float35 = dateAxis33.getTickMarkOutsideLength();
//        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
//        categoryPlot36.setRangeAxisLocation((int) (byte) 100, axisLocation38);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent40 = null;
//        categoryPlot36.datasetChanged(datasetChangeEvent40);
//        boolean boolean42 = dateAxis33.hasListener((java.util.EventListener) categoryPlot36);
//        float float43 = categoryPlot36.getBackgroundAlpha();
//        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot36.getDomainAxisEdge();
//        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker(0.0d);
//        boolean boolean49 = valueMarker47.equals((java.lang.Object) 100L);
//        boolean boolean51 = valueMarker47.equals((java.lang.Object) 3);
//        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
//        boolean boolean53 = categoryPlot36.removeRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker47, layer52);
//        boolean boolean55 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) categoryMarker29, layer52, true);
//        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot0.getRangeAxisEdge();
//        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
//        categoryPlot0.setFixedDomainAxisSpace(axisSpace57);
//        org.junit.Assert.assertNotNull(sortOrder3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(paint7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43629L + "'", long11 == 43629L);
//        org.junit.Assert.assertNull(plot14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(color27);
//        org.junit.Assert.assertNotNull(stroke28);
//        org.junit.Assert.assertNotNull(textAnchor30);
//        org.junit.Assert.assertNotNull(stroke31);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
//        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 2.0f + "'", float35 == 2.0f);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
//        org.junit.Assert.assertNotNull(rectangleEdge44);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(layer52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge56);
//    }
//}

