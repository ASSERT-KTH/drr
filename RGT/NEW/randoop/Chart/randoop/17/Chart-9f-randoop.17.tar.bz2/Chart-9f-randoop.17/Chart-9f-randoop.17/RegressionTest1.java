import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date2 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getEnd();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date4, timeZone8);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date4);
//        long long12 = year11.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getLastMillisecond();
//        long long16 = fixedMillisecond14.getLastMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond14.getFirstMillisecond(calendar17);
//        java.util.Date date19 = fixedMillisecond14.getStart();
//        boolean boolean20 = year11.equals((java.lang.Object) date19);
//        boolean boolean21 = fixedMillisecond1.equals((java.lang.Object) year11);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = year11.equals(obj22);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191777164L + "'", long15 == 1560191777164L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560191777164L + "'", long16 == 1560191777164L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191777164L + "'", long18 == 1560191777164L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        java.util.Date date8 = month7.getEnd();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class11 = null;
        java.lang.Class class12 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 31, false);
        boolean boolean24 = month7.equals((java.lang.Object) timeSeries10);
        timeSeries10.setDescription("7-January-1900");
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(5, 3);
        int int30 = month29.getMonth();
        java.lang.String str31 = month29.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getEnd();
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond32, "", "Feb", class36);
        java.lang.String str38 = timeSeries37.getDescription();
        timeSeries37.fireSeriesChanged();
        int int40 = month29.compareTo((java.lang.Object) timeSeries37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) 1560191700516L);
        java.lang.Number number43 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) month29);
        try {
            timeSeries10.update((int) (short) 1, (java.lang.Number) (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 5 + "'", int30 == 5);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "May 3" + "'", str31.equals("May 3"));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 31.0d + "'", number43.equals(31.0d));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getLastMillisecond();
//        long long8 = fixedMillisecond6.getLastMillisecond();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date15, timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.getDataItem(regularTimePeriod22);
//        int int24 = timeSeries5.getIndex(regularTimePeriod22);
//        timeSeries5.setDescription("May 3");
//        java.lang.String str27 = timeSeries5.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date29 = fixedMillisecond28.getEnd();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date32 = fixedMillisecond31.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date29, timeZone33);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date29);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(5, 3);
//        java.lang.String str40 = month39.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date43 = fixedMillisecond42.getEnd();
//        java.util.Date date44 = fixedMillisecond42.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
//        java.util.Date date46 = fixedMillisecond45.getStart();
//        int int47 = month39.compareTo((java.lang.Object) date46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date46);
//        int int49 = month36.compareTo((java.lang.Object) serialDate48);
//        java.lang.Class class50 = null;
//        java.lang.Class class51 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date53, timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date53);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date53);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month36, (org.jfree.data.time.RegularTimePeriod) day59);
//        try {
//            java.lang.Number number62 = timeSeries60.getValue(6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560191779737L + "'", long7 == 1560191779737L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191779737L + "'", long8 == 1560191779737L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Feb" + "'", str27.equals("Feb"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "May 3" + "'", str40.equals("May 3"));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(timeSeries60);
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        java.lang.String str6 = timeSeries5.getDescription();
//        timeSeries5.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date11 = fixedMillisecond10.getEnd();
//        java.util.Date date12 = fixedMillisecond10.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getLastMillisecond();
//        long long15 = fixedMillisecond13.getMiddleMillisecond();
//        java.util.Date date16 = fixedMillisecond13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date18, timeZone22);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone22);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date12, timeZone22);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(8, year26);
//        java.lang.Number number28 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) year26);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560191779760L + "'", long14 == 1560191779760L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191779760L + "'", long15 == 1560191779760L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(number28);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1);
        long long9 = year8.getLastMillisecond();
        java.lang.String str10 = year8.toString();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year8.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        java.lang.String str6 = timeSeries5.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        long long8 = fixedMillisecond7.getLastMillisecond();
//        long long9 = fixedMillisecond7.getLastMillisecond();
//        int int11 = fixedMillisecond7.compareTo((java.lang.Object) true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener13);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(5, 3);
//        int int18 = month17.getMonth();
//        java.lang.String str19 = month17.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, "", "Feb", class24);
//        java.lang.String str26 = timeSeries25.getDescription();
//        timeSeries25.fireSeriesChanged();
//        int int28 = month17.compareTo((java.lang.Object) timeSeries25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) 1560191700516L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date32 = fixedMillisecond31.getEnd();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date35, timeZone36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date32, timeZone36);
//        int int39 = day38.getYear();
//        long long40 = day38.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day38, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day38.next();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month17, (org.jfree.data.time.RegularTimePeriod) day38);
//        int int45 = timeSeries44.getItemCount();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191779947L + "'", long8 == 1560191779947L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560191779947L + "'", long9 == 1560191779947L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "May 3" + "'", str19.equals("May 3"));
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date5, timeZone9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date3, timeZone9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        long long15 = fixedMillisecond14.getLastMillisecond();
//        java.util.Date date16 = fixedMillisecond14.getTime();
//        boolean boolean17 = fixedMillisecond13.equals((java.lang.Object) fixedMillisecond14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191780093L + "'", long1 == 1560191780093L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191780093L + "'", long2 == 1560191780093L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191780096L + "'", long15 == 1560191780096L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDescription();
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener15);
        java.lang.String str17 = timeSeries5.getRangeDescription();
        java.lang.Object obj18 = timeSeries5.clone();
        java.lang.Class class19 = timeSeries5.getTimePeriodClass();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(5, 3);
        int int23 = month22.getMonth();
        java.lang.String str24 = month22.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) (byte) 0);
        long long27 = month22.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, 0.0d);
        timeSeries5.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Feb" + "'", str17.equals("Feb"));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "May 3" + "'", str24.equals("May 3"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62062300800000L) + "'", long27 == (-62062300800000L));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        java.lang.String str6 = timeSeries5.getDescription();
//        timeSeries5.clear();
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date12, timeZone16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date21, timeZone25);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date12, timeZone25);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date12);
//        boolean boolean30 = spreadsheetDate10.isBefore(serialDate29);
//        boolean boolean31 = timeSeries5.equals((java.lang.Object) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate33.getPreviousDayOfWeek((int) (short) 1);
//        int int36 = spreadsheetDate33.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date38 = fixedMillisecond37.getEnd();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date41, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date38, timeZone42);
//        int int45 = day44.getYear();
//        long long46 = day44.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day44.next();
//        long long50 = day44.getLastMillisecond();
//        boolean boolean51 = spreadsheetDate33.equals((java.lang.Object) day44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate53.getPreviousDayOfWeek((int) (short) 1);
//        int int56 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean61 = spreadsheetDate58.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        boolean boolean62 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate66 = spreadsheetDate64.getPreviousDayOfWeek((int) (short) 1);
//        int int67 = spreadsheetDate64.toSerial();
//        java.lang.String str68 = spreadsheetDate64.getDescription();
//        boolean boolean70 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate64, 1900);
//        try {
//            org.jfree.data.time.SerialDate serialDate72 = spreadsheetDate64.getPreviousDayOfWeek(1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 12 + "'", int67 == 12);
//        org.junit.Assert.assertNull(str68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date6 = fixedMillisecond5.getEnd();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "", "Feb", class9);
        java.lang.String str11 = timeSeries10.getDescription();
        timeSeries10.fireSeriesChanged();
        int int13 = month2.compareTo((java.lang.Object) timeSeries10);
        boolean boolean14 = timeSeries10.getNotify();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(5, 3);
        int int18 = month17.getMonth();
        java.lang.String str19 = month17.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date21 = fixedMillisecond20.getEnd();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond20, "", "Feb", class24);
        java.lang.String str26 = timeSeries25.getDescription();
        timeSeries25.fireSeriesChanged();
        int int28 = month17.compareTo((java.lang.Object) timeSeries25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) 1560191700516L);
        java.lang.Number number31 = timeSeriesDataItem30.getValue();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(5, 3);
        int int35 = month34.getMonth();
        java.lang.String str36 = month34.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date38 = fixedMillisecond37.getEnd();
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond37, "", "Feb", class41);
        java.lang.String str43 = timeSeries42.getDescription();
        timeSeries42.fireSeriesChanged();
        int int45 = month34.compareTo((java.lang.Object) timeSeries42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 1560191700516L);
        int int48 = timeSeriesDataItem30.compareTo((java.lang.Object) 1560191700516L);
        java.lang.Number number49 = timeSeriesDataItem30.getValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date51 = fixedMillisecond50.getEnd();
        java.lang.Class class52 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date54 = fixedMillisecond53.getEnd();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date54, timeZone55);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date51, timeZone55);
        boolean boolean58 = timeSeriesDataItem30.equals((java.lang.Object) timeZone55);
        try {
            timeSeries10.add(timeSeriesDataItem30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "May 3" + "'", str19.equals("May 3"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1560191700516L + "'", number31.equals(1560191700516L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 5 + "'", int35 == 5);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "May 3" + "'", str36.equals("May 3"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 1560191700516L + "'", number49.equals(1560191700516L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
        int int4 = spreadsheetDate1.toSerial();
        java.lang.String str5 = spreadsheetDate1.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.getDayOfMonth();
        java.lang.String str6 = spreadsheetDate3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1));
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
//        int int4 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date6, timeZone10);
//        int int13 = day12.getYear();
//        long long14 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.next();
//        long long18 = day12.getLastMillisecond();
//        boolean boolean19 = spreadsheetDate1.equals((java.lang.Object) day12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate21.getPreviousDayOfWeek((int) (short) 1);
//        int int24 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.toSerial();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        java.lang.Class class11 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date10, timeZone14);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date1, timeZone14);
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
        long long20 = month17.getSerialIndex();
        java.lang.Object obj21 = null;
        boolean boolean22 = month17.equals(obj21);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24234L + "'", long20 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        long long7 = fixedMillisecond6.getLastMillisecond();
//        long long8 = fixedMillisecond6.getLastMillisecond();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 'a');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date18, timeZone19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date15, timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day21.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries13.getDataItem(regularTimePeriod22);
//        int int24 = timeSeries5.getIndex(regularTimePeriod22);
//        timeSeries5.setDescription("May 3");
//        java.lang.String str27 = timeSeries5.getRangeDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date29 = fixedMillisecond28.getEnd();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date32 = fixedMillisecond31.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date29, timeZone33);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date29);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(5, 3);
//        java.lang.String str40 = month39.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date43 = fixedMillisecond42.getEnd();
//        java.util.Date date44 = fixedMillisecond42.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
//        java.util.Date date46 = fixedMillisecond45.getStart();
//        int int47 = month39.compareTo((java.lang.Object) date46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date46);
//        int int49 = month36.compareTo((java.lang.Object) serialDate48);
//        java.lang.Class class50 = null;
//        java.lang.Class class51 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date53, timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date53);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date53);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) month36, (org.jfree.data.time.RegularTimePeriod) day59);
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(5, 3);
//        int int64 = month63.getMonth();
//        java.lang.String str65 = month63.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date67 = fixedMillisecond66.getEnd();
//        java.lang.Class class70 = null;
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond66, "", "Feb", class70);
//        java.lang.String str72 = timeSeries71.getDescription();
//        timeSeries71.fireSeriesChanged();
//        int int74 = month63.compareTo((java.lang.Object) timeSeries71);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month63, (java.lang.Number) 1560191700516L);
//        timeSeriesDataItem76.setValue((java.lang.Number) 1560191700729L);
//        boolean boolean79 = day59.equals((java.lang.Object) timeSeriesDataItem76);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560191780489L + "'", long7 == 1560191780489L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191780489L + "'", long8 == 1560191780489L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Feb" + "'", str27.equals("Feb"));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "May 3" + "'", str40.equals("May 3"));
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 5 + "'", int64 == 5);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "May 3" + "'", str65.equals("May 3"));
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNull(str72);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean5 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        int int6 = spreadsheetDate4.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "", "Feb", class11);
//        java.lang.String str13 = timeSeries12.getDescription();
//        timeSeries12.clear();
//        java.util.Collection collection15 = timeSeries12.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date19, timeZone23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getEnd();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date28, timeZone32);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date19, timeZone32);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date19);
//        boolean boolean37 = spreadsheetDate17.isBefore(serialDate36);
//        boolean boolean38 = timeSeries12.equals((java.lang.Object) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate40.getPreviousDayOfWeek((int) (short) 1);
//        int int43 = spreadsheetDate40.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date45 = fixedMillisecond44.getEnd();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date48, timeZone49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date45, timeZone49);
//        int int52 = day51.getYear();
//        long long53 = day51.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day51.next();
//        long long57 = day51.getLastMillisecond();
//        boolean boolean58 = spreadsheetDate40.equals((java.lang.Object) day51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate62 = spreadsheetDate60.getPreviousDayOfWeek((int) (short) 1);
//        int int63 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean68 = spreadsheetDate65.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
//        boolean boolean69 = spreadsheetDate60.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate73 = spreadsheetDate71.getPreviousDayOfWeek((int) (short) 1);
//        int int74 = spreadsheetDate71.toSerial();
//        java.lang.String str75 = spreadsheetDate71.getDescription();
//        boolean boolean77 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate65, (org.jfree.data.time.SerialDate) spreadsheetDate71, 1900);
//        boolean boolean78 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate82 = spreadsheetDate80.getPreviousDayOfWeek((int) (short) 1);
//        spreadsheetDate80.setDescription("December 1969");
//        boolean boolean85 = spreadsheetDate71.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate80);
//        try {
//            org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate71);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560236399999L + "'", long53 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560236399999L + "'", long57 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 12 + "'", int74 == 12);
//        org.junit.Assert.assertNull(str75);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond(date1);
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191781418L + "'", long1 == 1560191781418L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191781418L + "'", long2 == 1560191781418L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean5 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate4.getDayOfMonth();
        int int7 = spreadsheetDate4.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date11 = fixedMillisecond10.getEnd();
        java.lang.Class class12 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date11, timeZone15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        java.lang.Class class21 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date20, timeZone24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date11, timeZone24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date11);
        boolean boolean29 = spreadsheetDate9.isBefore(serialDate28);
        boolean boolean30 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        java.lang.String str6 = timeSeries5.getDescription();
//        timeSeries5.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
//        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.String str17 = timeSeries5.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries5.createCopy(1, 2019);
//        java.lang.String str21 = timeSeries20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date23 = fixedMillisecond22.getEnd();
//        java.lang.Class class24 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date26, timeZone27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date23, timeZone27);
//        long long30 = day29.getFirstMillisecond();
//        int int31 = day29.getDayOfMonth();
//        long long32 = day29.getLastMillisecond();
//        java.lang.Number number33 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day29);
//        timeSeries20.setNotify(false);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Feb" + "'", str17.equals("Feb"));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560150000000L + "'", long30 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertNull(number33);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        java.lang.String str6 = timeSeries5.getDescription();
//        timeSeries5.clear();
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date12, timeZone16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date21, timeZone25);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date12, timeZone25);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date12);
//        boolean boolean30 = spreadsheetDate10.isBefore(serialDate29);
//        boolean boolean31 = timeSeries5.equals((java.lang.Object) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate33.getPreviousDayOfWeek((int) (short) 1);
//        int int36 = spreadsheetDate33.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date38 = fixedMillisecond37.getEnd();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date41, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date38, timeZone42);
//        int int45 = day44.getYear();
//        long long46 = day44.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day44.next();
//        long long50 = day44.getLastMillisecond();
//        boolean boolean51 = spreadsheetDate33.equals((java.lang.Object) day44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate53.getPreviousDayOfWeek((int) (short) 1);
//        int int56 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean61 = spreadsheetDate58.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        boolean boolean62 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate66 = spreadsheetDate64.getPreviousDayOfWeek((int) (short) 1);
//        int int67 = spreadsheetDate64.toSerial();
//        java.lang.String str68 = spreadsheetDate64.getDescription();
//        boolean boolean70 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate64, 1900);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(8);
//        int int73 = spreadsheetDate72.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean76 = spreadsheetDate72.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
//        boolean boolean77 = spreadsheetDate58.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate75);
//        int int78 = spreadsheetDate75.getDayOfWeek();
//        java.lang.String str79 = spreadsheetDate75.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 12 + "'", int67 == 12);
//        org.junit.Assert.assertNull(str68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 8 + "'", int73 == 8);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 5 + "'", int78 == 5);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "11-January-1900" + "'", str79.equals("11-January-1900"));
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        int int6 = timeSeries5.getMaximumItemCount();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        boolean boolean8 = timeSeries5.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, "", "Feb", class13);
        java.lang.String str15 = timeSeries14.getDomainDescription();
        timeSeries14.setNotify(true);
        java.util.Collection collection18 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        java.lang.Class class21 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date20, timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getEnd();
        java.lang.Class class30 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date32 = fixedMillisecond31.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date29, timeZone33);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date20, timeZone33);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        java.lang.Class class40 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getEnd();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date42, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date39, timeZone43);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date20, timeZone43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month46, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = null;
        try {
            timeSeries5.add(regularTimePeriod49, (java.lang.Number) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Nearest");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Nearest");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray6 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("Nearest");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("Nearest");
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.Throwable[] throwableArray13 = seriesException11.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException11);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(5, 3);
        int int8 = month7.getMonth();
        java.lang.String str9 = month7.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) (byte) 0);
        java.lang.Number number12 = timeSeriesDataItem11.getValue();
        boolean boolean13 = fixedMillisecond4.equals((java.lang.Object) number12);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "May 3" + "'", str9.equals("May 3"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 0 + "'", number12.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        long long3 = fixedMillisecond2.getLastMillisecond();
//        long long4 = fixedMillisecond2.getLastMillisecond();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond2.getFirstMillisecond(calendar5);
//        long long7 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond2.previous();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond2.getMiddleMillisecond(calendar9);
//        boolean boolean11 = fixedMillisecond0.equals((java.lang.Object) fixedMillisecond2);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191782464L + "'", long3 == 1560191782464L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191782464L + "'", long4 == 1560191782464L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560191782464L + "'", long6 == 1560191782464L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560191782464L + "'", long7 == 1560191782464L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191782464L + "'", long10 == 1560191782464L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        int int6 = timeSeries5.getMaximumItemCount();
//        java.lang.String str7 = timeSeries5.getDomainDescription();
//        long long8 = timeSeries5.getMaximumItemAge();
//        java.lang.Object obj9 = timeSeries5.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getEnd();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond10, "", "Feb", class14);
//        int int16 = timeSeries15.getMaximumItemCount();
//        java.util.Collection collection17 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        long long21 = fixedMillisecond20.getLastMillisecond();
//        long long22 = fixedMillisecond20.getMiddleMillisecond();
//        java.util.Date date23 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date28, timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date25, timeZone29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getEnd();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date36, timeZone37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date33, timeZone37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date25, timeZone37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date23, timeZone37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getEnd();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond42, "", "Feb", class46);
//        java.lang.String str48 = timeSeries47.getDescription();
//        timeSeries47.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getEnd();
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond50, "", "Feb", class54);
//        int int56 = timeSeries47.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        java.beans.PropertyChangeListener propertyChangeListener57 = null;
//        timeSeries47.removePropertyChangeListener(propertyChangeListener57);
//        java.lang.String str59 = timeSeries47.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries47.createCopy(1, 2019);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date65 = fixedMillisecond64.getEnd();
//        java.util.Date date66 = fixedMillisecond64.getEnd();
//        long long67 = fixedMillisecond64.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (java.lang.Number) 1560191738099L);
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560191782488L + "'", long21 == 1560191782488L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560191782488L + "'", long22 == 1560191782488L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Feb" + "'", str59.equals("Feb"));
//        org.junit.Assert.assertNotNull(timeSeries62);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 24234L + "'", long67 == 24234L);
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//        org.junit.Assert.assertNotNull(timeSeries70);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1, timeZone5);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1560191721031L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeriesDataItem10.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1, timeZone5);
//        long long8 = day7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.previous();
//        int int10 = day7.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(5, 3);
//        int int6 = month5.getMonth();
//        java.lang.String str7 = month5.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
//        java.lang.String str14 = timeSeries13.getDescription();
//        timeSeries13.fireSeriesChanged();
//        int int16 = month5.compareTo((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) 1560191700516L);
//        java.lang.Object obj19 = timeSeriesDataItem18.clone();
//        java.lang.Class class20 = null;
//        java.lang.Class class21 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date23 = fixedMillisecond22.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone24);
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date23, timeZone26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        long long30 = day28.getSerialIndex();
//        java.lang.Object obj31 = null;
//        boolean boolean32 = day28.equals(obj31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day28.next();
//        int int34 = timeSeriesDataItem18.compareTo((java.lang.Object) day28);
//        boolean boolean35 = fixedMillisecond0.equals((java.lang.Object) timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191783632L + "'", long1 == 1560191783632L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191783632L + "'", long2 == 1560191783632L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "May 3" + "'", str7.equals("May 3"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        int int6 = timeSeries5.getMaximumItemCount();
//        java.lang.Class class7 = timeSeries5.getTimePeriodClass();
//        timeSeries5.setNotify(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getEnd();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond10, "", "Feb", class14);
//        java.lang.String str16 = timeSeries15.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getLastMillisecond();
//        long long19 = fixedMillisecond17.getLastMillisecond();
//        int int21 = fixedMillisecond17.compareTo((java.lang.Object) true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        java.util.Collection collection23 = timeSeries15.getTimePeriods();
//        java.lang.Comparable comparable24 = timeSeries15.getKey();
//        boolean boolean25 = timeSeries5.equals((java.lang.Object) comparable24);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(5, 3);
//        int int29 = month28.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.previous();
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) month28);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191783724L + "'", long18 == 1560191783724L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560191783724L + "'", long19 == 1560191783724L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNotNull(comparable24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 5 + "'", int29 == 5);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date5, timeZone9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date3, timeZone9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getEnd();
//        java.lang.Class class15 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getEnd();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date14, timeZone18);
//        int int21 = day20.getYear();
//        org.jfree.data.time.SerialDate serialDate22 = day20.getSerialDate();
//        java.lang.String str23 = serialDate22.toString();
//        boolean boolean24 = day12.equals((java.lang.Object) serialDate22);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191783789L + "'", long1 == 1560191783789L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191783789L + "'", long2 == 1560191783789L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
//        int int3 = month2.getMonth();
//        java.lang.String str4 = month2.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "", "Feb", class9);
//        java.lang.String str11 = timeSeries10.getDescription();
//        timeSeries10.fireSeriesChanged();
//        int int13 = month2.compareTo((java.lang.Object) timeSeries10);
//        java.lang.Class class14 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        long long16 = fixedMillisecond15.getLastMillisecond();
//        long long17 = fixedMillisecond15.getLastMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getFirstMillisecond(calendar18);
//        long long20 = fixedMillisecond15.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond15.previous();
//        java.lang.Number number22 = timeSeries10.getValue(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNull(class14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560191783923L + "'", long16 == 1560191783923L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560191783923L + "'", long17 == 1560191783923L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560191783923L + "'", long19 == 1560191783923L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560191783923L + "'", long20 == 1560191783923L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(number22);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.lang.Class class5 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getEnd();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date4, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        java.lang.Class class14 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date13, timeZone17);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date4, timeZone17);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean22 = spreadsheetDate2.isBefore(serialDate21);
        try {
            org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 0);
        int int7 = month2.getMonth();
        int int8 = month2.getMonth();
        long long9 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62059622400001L) + "'", long9 == (-62059622400001L));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate4.getPreviousDayOfWeek((int) (short) 1);
        boolean boolean7 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int9 = spreadsheetDate2.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 7 + "'", int9 == 7);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date2 = fixedMillisecond1.getEnd();
//        java.util.Date date3 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date5, timeZone9);
//        java.lang.Class<?> wildcardClass12 = timeZone9.getClass();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3, (java.lang.Class) wildcardClass12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond14, "", "Feb", class18);
//        int int20 = timeSeries19.getMaximumItemCount();
//        boolean boolean21 = timeSeries19.isEmpty();
//        java.lang.String str22 = timeSeries19.getDomainDescription();
//        timeSeries19.setMaximumItemCount((int) (short) 0);
//        java.lang.Class<?> wildcardClass25 = timeSeries19.getClass();
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        long long28 = fixedMillisecond27.getSerialIndex();
//        java.util.Date date29 = fixedMillisecond27.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond30, "", "Feb", class34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond30.previous();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond30.getLastMillisecond(calendar37);
//        java.util.Date date39 = fixedMillisecond30.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getEnd();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date46 = fixedMillisecond45.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date46, timeZone47);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date43, timeZone47);
//        java.lang.Class<?> wildcardClass50 = timeZone47.getClass();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond30, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date53 = fixedMillisecond52.getEnd();
//        java.lang.Class class54 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date56 = fixedMillisecond55.getEnd();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date56, timeZone57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date53, timeZone57);
//        int int60 = day59.getYear();
//        long long61 = day59.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day59, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = day59.next();
//        long long65 = day59.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date68 = fixedMillisecond67.getEnd();
//        java.util.Date date69 = fixedMillisecond67.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(date69);
//        java.lang.String str71 = fixedMillisecond70.toString();
//        boolean boolean72 = day59.equals((java.lang.Object) fixedMillisecond70);
//        java.util.Date date73 = fixedMillisecond70.getTime();
//        java.lang.Class class74 = null;
//        java.lang.Class class75 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date77 = fixedMillisecond76.getEnd();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date77, timeZone78);
//        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date77, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date73, timeZone80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date29, timeZone80);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date85 = fixedMillisecond84.getEnd();
//        java.lang.Class class86 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond87 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date88 = fixedMillisecond87.getEnd();
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class86, date88, timeZone89);
//        org.jfree.data.time.Month month91 = new org.jfree.data.time.Month(date85, timeZone89);
//        java.lang.Class<?> wildcardClass92 = timeZone89.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date29, timeZone89);
//        java.lang.Class class94 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560191784001L + "'", long28 == 1560191784001L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560191784001L + "'", long38 == 1560191784001L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560236399999L + "'", long61 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560236399999L + "'", long65 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Wed Dec 31 16:00:24 PST 1969" + "'", str71.equals("Wed Dec 31 16:00:24 PST 1969"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//        org.junit.Assert.assertNotNull(timeZone80);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(wildcardClass92);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNotNull(class94);
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        java.lang.Comparable comparable2 = timeSeries1.getKey();
//        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(5, 3);
//        long long6 = month5.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month5);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date9, timeZone13);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date9);
//        long long17 = year16.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        long long20 = fixedMillisecond19.getLastMillisecond();
//        long long21 = fixedMillisecond19.getLastMillisecond();
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond19.getFirstMillisecond(calendar22);
//        java.util.Date date24 = fixedMillisecond19.getStart();
//        boolean boolean25 = year16.equals((java.lang.Object) date24);
//        long long26 = year16.getSerialIndex();
//        java.lang.String str27 = year16.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 1560191703467L);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(5, 3);
//        int int33 = month32.getMonth();
//        java.lang.String str34 = month32.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getEnd();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, "", "Feb", class39);
//        java.lang.String str41 = timeSeries40.getDescription();
//        timeSeries40.fireSeriesChanged();
//        int int43 = month32.compareTo((java.lang.Object) timeSeries40);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date46 = fixedMillisecond45.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getEnd();
//        java.lang.Class class49 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getEnd();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date51, timeZone52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date48, timeZone52);
//        java.util.Date date55 = month54.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (org.jfree.data.time.RegularTimePeriod) month54);
//        int int57 = year16.compareTo((java.lang.Object) fixedMillisecond45);
//        java.util.Calendar calendar58 = null;
//        try {
//            long long59 = year16.getLastMillisecond(calendar58);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 1.0f + "'", comparable2.equals(1.0f));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 41L + "'", long6 == 41L);
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560191785678L + "'", long20 == 1560191785678L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560191785678L + "'", long21 == 1560191785678L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191785678L + "'", long23 == 1560191785678L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2019" + "'", str27.equals("2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "May 3" + "'", str34.equals("May 3"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        int int2 = spreadsheetDate1.getYYYY();
        int int3 = spreadsheetDate1.toSerial();
        int int4 = spreadsheetDate1.getDayOfWeek();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getMiddleMillisecond();
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getEnd();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date5, timeZone9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getEnd();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date13, timeZone17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date5, timeZone17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date3, timeZone17);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
//        java.lang.Object obj23 = seriesChangeEvent22.getSource();
//        java.lang.Object obj24 = seriesChangeEvent22.getSource();
//        java.lang.String str25 = seriesChangeEvent22.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191785715L + "'", long1 == 1560191785715L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191785715L + "'", long2 == 1560191785715L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 11:36:25 PDT 2019]" + "'", str25.equals("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 11:36:25 PDT 2019]"));
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean5 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
//        int int6 = spreadsheetDate4.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getEnd();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "", "Feb", class11);
//        java.lang.String str13 = timeSeries12.getDescription();
//        timeSeries12.clear();
//        java.util.Collection collection15 = timeSeries12.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getEnd();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date22, timeZone23);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date19, timeZone23);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getEnd();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date31, timeZone32);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date28, timeZone32);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date19, timeZone32);
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date19);
//        boolean boolean37 = spreadsheetDate17.isBefore(serialDate36);
//        boolean boolean38 = timeSeries12.equals((java.lang.Object) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate40.getPreviousDayOfWeek((int) (short) 1);
//        int int43 = spreadsheetDate40.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date45 = fixedMillisecond44.getEnd();
//        java.lang.Class class46 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date48, timeZone49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date45, timeZone49);
//        int int52 = day51.getYear();
//        long long53 = day51.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day51.next();
//        long long57 = day51.getLastMillisecond();
//        boolean boolean58 = spreadsheetDate40.equals((java.lang.Object) day51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate62 = spreadsheetDate60.getPreviousDayOfWeek((int) (short) 1);
//        int int63 = spreadsheetDate40.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean68 = spreadsheetDate65.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
//        boolean boolean69 = spreadsheetDate60.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate73 = spreadsheetDate71.getPreviousDayOfWeek((int) (short) 1);
//        int int74 = spreadsheetDate71.toSerial();
//        java.lang.String str75 = spreadsheetDate71.getDescription();
//        boolean boolean77 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate65, (org.jfree.data.time.SerialDate) spreadsheetDate71, 1900);
//        boolean boolean78 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        try {
//            org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addMonths((-460), (org.jfree.data.time.SerialDate) spreadsheetDate71);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 11 + "'", int6 == 11);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 12 + "'", int43 == 12);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560236399999L + "'", long53 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560236399999L + "'", long57 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 12 + "'", int74 == 12);
//        org.junit.Assert.assertNull(str75);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean5 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(8);
        int int8 = spreadsheetDate7.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean11 = spreadsheetDate7.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate7.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(8);
        int int15 = spreadsheetDate14.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean18 = spreadsheetDate14.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate17.getFollowingDayOfWeek(7);
        boolean boolean21 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(2, serialDate20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date24 = fixedMillisecond23.getEnd();
        java.lang.Class class25 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date27 = fixedMillisecond26.getEnd();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date27, timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date24, timeZone28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date32 = fixedMillisecond31.getEnd();
        java.lang.Class class33 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getEnd();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date35, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date32, timeZone36);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date24, timeZone36);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date24);
        org.jfree.data.time.SerialDate serialDate41 = serialDate22.getEndOfCurrentMonth(serialDate40);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(12);
        org.jfree.data.time.SerialDate serialDate44 = serialDate41.getEndOfCurrentMonth(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "7-January-1900" + "'", str12.equals("7-January-1900"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDescription();
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener15);
        long long17 = timeSeries5.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getEnd();
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, "", "Feb", class22);
        int int24 = timeSeries23.getMaximumItemCount();
        java.lang.Class class25 = timeSeries23.getTimePeriodClass();
        timeSeries23.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries5.addAndOrUpdate(timeSeries23);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertNotNull(timeSeries28);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        int int6 = timeSeries5.getMaximumItemCount();
        java.lang.Class class7 = timeSeries5.getTimePeriodClass();
        boolean boolean8 = timeSeries5.getNotify();
        boolean boolean9 = timeSeries5.getNotify();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Wednesday");
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
        long long3 = month2.getSerialIndex();
        java.util.Date date4 = month2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 41L + "'", long3 == 41L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) (byte) 0);
        int int7 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
//        int int5 = spreadsheetDate3.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond6, "", "Feb", class10);
//        java.lang.String str12 = timeSeries11.getDescription();
//        timeSeries11.clear();
//        java.util.Collection collection14 = timeSeries11.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date18, timeZone22);
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getEnd();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date27, timeZone31);
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date18, timeZone31);
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(date18);
//        boolean boolean36 = spreadsheetDate16.isBefore(serialDate35);
//        boolean boolean37 = timeSeries11.equals((java.lang.Object) spreadsheetDate16);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate39.getPreviousDayOfWeek((int) (short) 1);
//        int int42 = spreadsheetDate39.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getEnd();
//        java.lang.Class class45 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getEnd();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date47, timeZone48);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date44, timeZone48);
//        int int51 = day50.getYear();
//        long long52 = day50.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = day50.next();
//        long long56 = day50.getLastMillisecond();
//        boolean boolean57 = spreadsheetDate39.equals((java.lang.Object) day50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate61 = spreadsheetDate59.getPreviousDayOfWeek((int) (short) 1);
//        int int62 = spreadsheetDate39.compare((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean67 = spreadsheetDate64.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate66);
//        boolean boolean68 = spreadsheetDate59.isOn((org.jfree.data.time.SerialDate) spreadsheetDate64);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate72 = spreadsheetDate70.getPreviousDayOfWeek((int) (short) 1);
//        int int73 = spreadsheetDate70.toSerial();
//        java.lang.String str74 = spreadsheetDate70.getDescription();
//        boolean boolean76 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate64, (org.jfree.data.time.SerialDate) spreadsheetDate70, 1900);
//        boolean boolean77 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate70);
//        org.jfree.data.time.Month month80 = new org.jfree.data.time.Month(5, 3);
//        java.lang.String str81 = month80.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date84 = fixedMillisecond83.getEnd();
//        java.util.Date date85 = fixedMillisecond83.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond86 = new org.jfree.data.time.FixedMillisecond(date85);
//        java.util.Date date87 = fixedMillisecond86.getStart();
//        int int88 = month80.compareTo((java.lang.Object) date87);
//        org.jfree.data.time.SerialDate serialDate89 = org.jfree.data.time.SerialDate.createInstance(date87);
//        java.lang.String str90 = serialDate89.toString();
//        boolean boolean91 = spreadsheetDate3.isAfter(serialDate89);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 11 + "'", int5 == 11);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560236399999L + "'", long52 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560236399999L + "'", long56 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 12 + "'", int73 == 12);
//        org.junit.Assert.assertNull(str74);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "May 3" + "'", str81.equals("May 3"));
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//        org.junit.Assert.assertNotNull(serialDate89);
//        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "31-December-1969" + "'", str90.equals("31-December-1969"));
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date6 = fixedMillisecond5.getEnd();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "", "Feb", class9);
        java.lang.String str11 = timeSeries10.getDescription();
        timeSeries10.fireSeriesChanged();
        int int13 = month2.compareTo((java.lang.Object) timeSeries10);
        boolean boolean14 = timeSeries10.getNotify();
        java.lang.Class class15 = timeSeries10.getTimePeriodClass();
        java.lang.Object obj16 = timeSeries10.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertNotNull(obj16);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1, timeZone5);
//        int int8 = day7.getYear();
//        long long9 = day7.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem11.getPeriod();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean17 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        int int18 = spreadsheetDate16.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond19, "", "Feb", class23);
//        java.lang.String str25 = timeSeries24.getDescription();
//        timeSeries24.clear();
//        java.util.Collection collection27 = timeSeries24.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date31 = fixedMillisecond30.getEnd();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date34, timeZone35);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date31, timeZone35);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date40 = fixedMillisecond39.getEnd();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone44);
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date40, timeZone44);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date31, timeZone44);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date31);
//        boolean boolean49 = spreadsheetDate29.isBefore(serialDate48);
//        boolean boolean50 = timeSeries24.equals((java.lang.Object) spreadsheetDate29);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate52.getPreviousDayOfWeek((int) (short) 1);
//        int int55 = spreadsheetDate52.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date57 = fixedMillisecond56.getEnd();
//        java.lang.Class class58 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date60 = fixedMillisecond59.getEnd();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date60, timeZone61);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date57, timeZone61);
//        int int64 = day63.getYear();
//        long long65 = day63.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day63, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day63.next();
//        long long69 = day63.getLastMillisecond();
//        boolean boolean70 = spreadsheetDate52.equals((java.lang.Object) day63);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate72.getPreviousDayOfWeek((int) (short) 1);
//        int int75 = spreadsheetDate52.compare((org.jfree.data.time.SerialDate) spreadsheetDate72);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate79 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean80 = spreadsheetDate77.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate79);
//        boolean boolean81 = spreadsheetDate72.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate85 = spreadsheetDate83.getPreviousDayOfWeek((int) (short) 1);
//        int int86 = spreadsheetDate83.toSerial();
//        java.lang.String str87 = spreadsheetDate83.getDescription();
//        boolean boolean89 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate77, (org.jfree.data.time.SerialDate) spreadsheetDate83, 1900);
//        boolean boolean90 = spreadsheetDate16.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate83);
//        org.jfree.data.time.TimeSeries timeSeries91 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate83);
//        int int92 = timeSeriesDataItem11.compareTo((java.lang.Object) timeSeries91);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 11 + "'", int18 == 11);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertNotNull(collection27);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 12 + "'", int55 == 12);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2019 + "'", int64 == 2019);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560236399999L + "'", long65 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560236399999L + "'", long69 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 12 + "'", int86 == 12);
//        org.junit.Assert.assertNull(str87);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        org.jfree.data.time.TimeSeries timeSeries8 = timeSeries5.createCopy(7, 8);
        boolean boolean9 = timeSeries5.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(24234L);
        java.util.Date date12 = fixedMillisecond11.getEnd();
        java.util.Date date13 = fixedMillisecond11.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date13);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
        java.lang.Object obj18 = null;
        boolean boolean19 = day16.equals(obj18);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeSeries8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener7);
        java.lang.Class class9 = timeSeries5.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond12, "", "Feb", class16);
        int int18 = timeSeries17.getMaximumItemCount();
        java.lang.String str19 = timeSeries17.getDomainDescription();
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Object obj21 = timeSeries17.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "", "Feb", class26);
        int int28 = timeSeries27.getMaximumItemCount();
        java.util.Collection collection29 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries17.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries5.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date34 = fixedMillisecond33.getEnd();
        java.lang.Class class35 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getEnd();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date37, timeZone38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date34, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date43 = fixedMillisecond42.getEnd();
        java.lang.Class class44 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date46 = fixedMillisecond45.getEnd();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date46, timeZone47);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date43, timeZone47);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date34, timeZone47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date52 = fixedMillisecond51.getEnd();
        java.lang.Class class53 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date55 = fixedMillisecond54.getEnd();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date55, timeZone56);
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date52, timeZone56);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date61 = fixedMillisecond60.getEnd();
        java.lang.Class class62 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date64 = fixedMillisecond63.getEnd();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date64, timeZone65);
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date61, timeZone65);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date52, timeZone65);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance(date52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date71 = fixedMillisecond70.getEnd();
        java.lang.Class class72 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date74 = fixedMillisecond73.getEnd();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date74, timeZone75);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date71, timeZone75);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date52, timeZone75);
        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month(date34, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = month79.next();
        java.lang.Number number81 = null;
        try {
            timeSeries17.add(regularTimePeriod80, number81, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1, timeZone5);
//        int int8 = day7.getYear();
//        long long9 = day7.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.next();
//        java.util.Calendar calendar13 = null;
//        try {
//            day7.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDescription();
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Class class17 = null;
        java.lang.Class class18 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date20, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date20);
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year25);
        timeSeries5.setNotify(true);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class2 = null;
        java.lang.Class class3 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date5 = fixedMillisecond4.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date5, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day10, (double) 31, false);
        try {
            java.lang.Number number16 = timeSeries1.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
        serialDate3.setDescription("December 1969");
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
//        int int4 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date6, timeZone10);
//        int int13 = day12.getYear();
//        long long14 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.next();
//        long long18 = day12.getLastMillisecond();
//        boolean boolean19 = spreadsheetDate1.equals((java.lang.Object) day12);
//        java.lang.String str20 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate22.getPreviousDayOfWeek((int) (short) 1);
//        int int25 = spreadsheetDate22.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getEnd();
//        java.lang.Class class28 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getEnd();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date27, timeZone31);
//        int int34 = day33.getYear();
//        long long35 = day33.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day33.next();
//        long long39 = day33.getLastMillisecond();
//        boolean boolean40 = spreadsheetDate22.equals((java.lang.Object) day33);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate44 = spreadsheetDate42.getPreviousDayOfWeek((int) (short) 1);
//        int int45 = spreadsheetDate22.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
//        boolean boolean46 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560236399999L + "'", long35 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(24234L);
        java.util.Date date10 = fixedMillisecond9.getEnd();
        java.util.Date date11 = fixedMillisecond9.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        java.lang.Class class15 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date14, timeZone18);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date11, timeZone18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date1, timeZone18);
        long long23 = year22.getFirstMillisecond();
        long long24 = year22.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDescription();
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener15);
        java.lang.String str17 = timeSeries5.getRangeDescription();
        java.lang.Class<?> wildcardClass18 = timeSeries5.getClass();
        timeSeries5.setMaximumItemAge(1560191716596L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Feb" + "'", str17.equals("Feb"));
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
        java.util.Date date5 = fixedMillisecond4.getStart();
        long long6 = fixedMillisecond4.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond7, "", "Feb", class11);
        int int13 = timeSeries12.getMaximumItemCount();
        java.lang.String str14 = timeSeries12.getDomainDescription();
        long long15 = timeSeries12.getMaximumItemAge();
        java.lang.Object obj16 = timeSeries12.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, "", "Feb", class21);
        int int23 = timeSeries22.getMaximumItemCount();
        java.util.Collection collection24 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        int int25 = fixedMillisecond4.compareTo((java.lang.Object) timeSeries22);
        java.util.List list26 = timeSeries22.getItems();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate3.getPreviousDayOfWeek((int) (short) 1);
        boolean boolean6 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SerialDate serialDate7 = null;
        try {
            boolean boolean8 = spreadsheetDate3.isOn(serialDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
//        int int3 = month2.getMonth();
//        java.lang.String str4 = month2.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "", "Feb", class9);
//        java.lang.String str11 = timeSeries10.getDescription();
//        timeSeries10.fireSeriesChanged();
//        int int13 = month2.compareTo((java.lang.Object) timeSeries10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1560191700516L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getEnd();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date17, timeZone21);
//        long long24 = day23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
//        int int26 = timeSeriesDataItem15.compareTo((java.lang.Object) day23);
//        java.lang.String str27 = day23.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10-June-2019" + "'", str27.equals("10-June-2019"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        long long2 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        java.util.Date date8 = month7.getEnd();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        java.lang.Class class11 = null;
        java.lang.Class class12 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone15);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 31, false);
        boolean boolean24 = month7.equals((java.lang.Object) timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getEnd();
        java.lang.Class class27 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getEnd();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date26, timeZone30);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getEnd();
        java.lang.Class class36 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date38 = fixedMillisecond37.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date38, timeZone39);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date35, timeZone39);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date26, timeZone39);
        int int43 = month42.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month42.previous();
        long long45 = month42.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month42, 0.0d);
        int int48 = month42.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 24234L + "'", long45 == 24234L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, "", "Feb", class13);
        java.lang.String str15 = timeSeries14.getDescription();
        timeSeries14.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date18 = fixedMillisecond17.getEnd();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, "", "Feb", class21);
        int int23 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener24);
        java.lang.String str26 = timeSeries14.getRangeDescription();
        int int27 = year8.compareTo((java.lang.Object) str26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year8.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Feb" + "'", str26.equals("Feb"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDescription();
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener15);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date6 = fixedMillisecond5.getEnd();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "", "Feb", class9);
        java.lang.String str11 = timeSeries10.getDescription();
        timeSeries10.fireSeriesChanged();
        int int13 = month2.compareTo((java.lang.Object) timeSeries10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1560191700516L);
        java.lang.Number number16 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(5, 3);
        int int20 = month19.getMonth();
        java.lang.String str21 = month19.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "", "Feb", class26);
        java.lang.String str28 = timeSeries27.getDescription();
        timeSeries27.fireSeriesChanged();
        int int30 = month19.compareTo((java.lang.Object) timeSeries27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 1560191700516L);
        int int33 = timeSeriesDataItem15.compareTo((java.lang.Object) 1560191700516L);
        java.lang.Number number34 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date36 = fixedMillisecond35.getEnd();
        java.lang.Class class37 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date39, timeZone40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date36, timeZone40);
        boolean boolean43 = timeSeriesDataItem15.equals((java.lang.Object) timeZone40);
        timeSeriesDataItem15.setValue((java.lang.Number) 1560191748964L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1560191700516L + "'", number16.equals(1560191700516L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "May 3" + "'", str21.equals("May 3"));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1560191700516L + "'", number34.equals(1560191700516L));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(31, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener7);
        java.lang.Class class9 = timeSeries5.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond12, "", "Feb", class16);
        int int18 = timeSeries17.getMaximumItemCount();
        java.lang.String str19 = timeSeries17.getDomainDescription();
        long long20 = timeSeries17.getMaximumItemAge();
        java.lang.Object obj21 = timeSeries17.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "", "Feb", class26);
        int int28 = timeSeries27.getMaximumItemCount();
        java.util.Collection collection29 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries17.removeChangeListener(seriesChangeListener30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries5.addAndOrUpdate(timeSeries17);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(5, 3);
        int int36 = month35.getMonth();
        java.lang.String str37 = month35.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date39 = fixedMillisecond38.getEnd();
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond38, "", "Feb", class42);
        java.lang.String str44 = timeSeries43.getDescription();
        timeSeries43.fireSeriesChanged();
        int int46 = month35.compareTo((java.lang.Object) timeSeries43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 1560191700516L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = timeSeriesDataItem48.getPeriod();
        timeSeries17.delete(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "May 3" + "'", str37.equals("May 3"));
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date5 = fixedMillisecond4.getEnd();
        java.lang.Class class6 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date8 = fixedMillisecond7.getEnd();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date8, timeZone9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date5, timeZone9);
        java.lang.Class<?> wildcardClass12 = timeZone9.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3, (java.lang.Class) wildcardClass12);
        timeSeries13.setMaximumItemAge(1560191712918L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.lang.Class class3 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date5 = fixedMillisecond4.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date2, timeZone6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2);
        java.lang.Class class10 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone13);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(regularTimePeriod15);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDomainDescription();
        long long7 = timeSeries5.getMaximumItemAge();
        java.lang.Object obj8 = timeSeries5.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1, timeZone5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.lang.Class class10 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date9, timeZone13);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date1, timeZone13);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(serialDate17);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
//        int int4 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date6, timeZone10);
//        int int13 = day12.getYear();
//        long long14 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.next();
//        long long18 = day12.getLastMillisecond();
//        boolean boolean19 = spreadsheetDate1.equals((java.lang.Object) day12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate23 = spreadsheetDate21.getPreviousDayOfWeek((int) (short) 1);
//        int int24 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate21);
//        int int25 = spreadsheetDate21.getDayOfMonth();
//        int int26 = spreadsheetDate21.getDayOfMonth();
//        int int27 = spreadsheetDate21.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 11 + "'", int25 == 11);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 11 + "'", int26 == 11);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 11 + "'", int27 == 11);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        int int6 = timeSeries5.getMaximumItemCount();
//        boolean boolean7 = timeSeries5.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond8.previous();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond8.getLastMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond8.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date21, timeZone25);
//        java.lang.Class<?> wildcardClass28 = timeZone25.getClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass28);
//        long long30 = fixedMillisecond8.getMiddleMillisecond();
//        int int31 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.Collection collection32 = timeSeries5.getTimePeriods();
//        timeSeries5.setRangeDescription("Wednesday");
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560191792199L + "'", long16 == 1560191792199L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560191792199L + "'", long30 == 1560191792199L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(collection32);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
//        int int3 = month2.getMonth();
//        java.lang.String str4 = month2.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "", "Feb", class9);
//        java.lang.String str11 = timeSeries10.getDescription();
//        timeSeries10.fireSeriesChanged();
//        int int13 = month2.compareTo((java.lang.Object) timeSeries10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1560191700516L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getEnd();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date20 = fixedMillisecond19.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date17, timeZone21);
//        long long24 = day23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
//        int int26 = timeSeriesDataItem15.compareTo((java.lang.Object) day23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem15.getPeriod();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560150000000L + "'", long24 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        int int6 = timeSeries5.getMaximumItemCount();
//        boolean boolean7 = timeSeries5.isEmpty();
//        java.lang.String str8 = timeSeries5.getDomainDescription();
//        timeSeries5.setMaximumItemCount((int) (short) 0);
//        java.lang.Class<?> wildcardClass11 = timeSeries5.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        java.util.Date date16 = fixedMillisecond14.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getLastMillisecond();
//        long long19 = fixedMillisecond17.getMiddleMillisecond();
//        java.util.Date date20 = fixedMillisecond17.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getEnd();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date25, timeZone26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date22, timeZone26);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date20, timeZone26);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date16, timeZone26);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date33, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone34);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191792440L + "'", long18 == 1560191792440L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560191792440L + "'", long19 == 1560191792440L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        long long2 = fixedMillisecond0.getLastMillisecond();
//        int int4 = fixedMillisecond0.compareTo((java.lang.Object) true);
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getMiddleMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getFirstMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191792776L + "'", long1 == 1560191792776L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191792776L + "'", long2 == 1560191792776L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560191792776L + "'", long6 == 1560191792776L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191792776L + "'", long8 == 1560191792776L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560191792776L + "'", long10 == 1560191792776L);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        long long10 = day8.getSerialIndex();
//        int int11 = day8.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(8);
        int int7 = spreadsheetDate6.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean10 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str11 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(8);
        int int14 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean17 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getFollowingDayOfWeek(7);
        boolean boolean20 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate23.getPreviousDayOfWeek((int) (short) 1);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears(31, serialDate25);
        boolean boolean27 = spreadsheetDate6.isOn(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "7-January-1900" + "'", str11.equals("7-January-1900"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        int int6 = timeSeries5.getMaximumItemCount();
//        java.lang.String str7 = timeSeries5.getDomainDescription();
//        boolean boolean8 = timeSeries5.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, "", "Feb", class13);
//        java.lang.String str15 = timeSeries14.getDomainDescription();
//        timeSeries14.setNotify(true);
//        java.util.Collection collection18 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date22 = fixedMillisecond21.getEnd();
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond21, "", "Feb", class25);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond21.previous();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond21.getLastMillisecond(calendar28);
//        java.lang.Class<?> wildcardClass30 = fixedMillisecond21.getClass();
//        timeSeries5.setKey((java.lang.Comparable) fixedMillisecond21);
//        java.util.Date date32 = fixedMillisecond21.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560191792857L + "'", long29 == 1560191792857L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(date32);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        java.lang.String str6 = timeSeries5.getDescription();
//        timeSeries5.clear();
//        java.util.Collection collection8 = timeSeries5.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getEnd();
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone16);
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date12, timeZone16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date24 = fixedMillisecond23.getEnd();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone25);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date21, timeZone25);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date12, timeZone25);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date12);
//        boolean boolean30 = spreadsheetDate10.isBefore(serialDate29);
//        boolean boolean31 = timeSeries5.equals((java.lang.Object) spreadsheetDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate33.getPreviousDayOfWeek((int) (short) 1);
//        int int36 = spreadsheetDate33.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date38 = fixedMillisecond37.getEnd();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date41 = fixedMillisecond40.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date41, timeZone42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date38, timeZone42);
//        int int45 = day44.getYear();
//        long long46 = day44.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day44.next();
//        long long50 = day44.getLastMillisecond();
//        boolean boolean51 = spreadsheetDate33.equals((java.lang.Object) day44);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate53.getPreviousDayOfWeek((int) (short) 1);
//        int int56 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean61 = spreadsheetDate58.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        boolean boolean62 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate58);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate66 = spreadsheetDate64.getPreviousDayOfWeek((int) (short) 1);
//        int int67 = spreadsheetDate64.toSerial();
//        java.lang.String str68 = spreadsheetDate64.getDescription();
//        boolean boolean70 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate58, (org.jfree.data.time.SerialDate) spreadsheetDate64, 1900);
//        int int71 = spreadsheetDate10.getDayOfWeek();
//        int int72 = spreadsheetDate10.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 12 + "'", int36 == 12);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560236399999L + "'", long46 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560236399999L + "'", long50 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 12 + "'", int67 == 12);
//        org.junit.Assert.assertNull(str68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 7 + "'", int72 == 7);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate2.getPreviousDayOfWeek((int) (short) 1);
//        int int5 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date7, timeZone11);
//        int int14 = day13.getYear();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.next();
//        long long19 = day13.getLastMillisecond();
//        boolean boolean20 = spreadsheetDate2.equals((java.lang.Object) day13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate22.getPreviousDayOfWeek((int) (short) 1);
//        int int25 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate27.getPreviousDayOfWeek((int) (short) 1);
//        int int30 = spreadsheetDate27.toSerial();
//        java.lang.String str31 = spreadsheetDate27.getDescription();
//        boolean boolean32 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        try {
//            org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate27.getPreviousDayOfWeek(29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate33);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1);
        long long9 = year8.getLastMillisecond();
        java.lang.Number number10 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year8, number10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem11.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560191729522L);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
//        long long9 = day8.getLastMillisecond();
//        long long10 = day8.getSerialIndex();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date2 = fixedMillisecond1.getEnd();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        long long6 = year5.getLastMillisecond();
        long long7 = year5.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond6, "", "Feb", class10);
//        int int12 = timeSeries11.getMaximumItemCount();
//        java.lang.String str13 = timeSeries11.getDomainDescription();
//        boolean boolean14 = timeSeries11.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond15, "", "Feb", class19);
//        java.lang.String str21 = timeSeries20.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        long long23 = fixedMillisecond22.getLastMillisecond();
//        long long24 = fixedMillisecond22.getLastMillisecond();
//        int int26 = fixedMillisecond22.compareTo((java.lang.Object) true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries20.removePropertyChangeListener(propertyChangeListener28);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(5, 3);
//        int int33 = month32.getMonth();
//        java.lang.String str34 = month32.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date36 = fixedMillisecond35.getEnd();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, "", "Feb", class39);
//        java.lang.String str41 = timeSeries40.getDescription();
//        timeSeries40.fireSeriesChanged();
//        int int43 = month32.compareTo((java.lang.Object) timeSeries40);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 1560191700516L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getEnd();
//        java.lang.Class class48 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date50, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date47, timeZone51);
//        int int54 = day53.getYear();
//        long long55 = day53.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day53, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day53.next();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries20.createCopy((org.jfree.data.time.RegularTimePeriod) month32, (org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = day53.previous();
//        java.lang.Number number61 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day53, number61);
//        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) day53);
//        java.lang.Object obj64 = timeSeries5.clone();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560191793545L + "'", long23 == 1560191793545L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191793545L + "'", long24 == 1560191793545L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "May 3" + "'", str34.equals("May 3"));
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(str41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560236399999L + "'", long55 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(obj64);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate2.getPreviousDayOfWeek((int) (short) 1);
//        int int5 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date7, timeZone11);
//        int int14 = day13.getYear();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.next();
//        long long19 = day13.getLastMillisecond();
//        boolean boolean20 = spreadsheetDate2.equals((java.lang.Object) day13);
//        java.lang.String str21 = spreadsheetDate2.getDescription();
//        try {
//            org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(str21);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        java.lang.String str6 = timeSeries5.getDescription();
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getEnd();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.lang.String str15 = timeSeries5.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener16);
        timeSeries5.setMaximumItemAge(1560191704298L);
        int int20 = timeSeries5.getItemCount();
        timeSeries5.setDomainDescription("");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Feb" + "'", str15.equals("Feb"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        int int6 = timeSeries5.getMaximumItemCount();
//        boolean boolean7 = timeSeries5.isEmpty();
//        java.lang.String str8 = timeSeries5.getDomainDescription();
//        timeSeries5.setMaximumItemCount((int) (short) 0);
//        java.lang.Class<?> wildcardClass11 = timeSeries5.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        long long14 = fixedMillisecond13.getLastMillisecond();
//        long long15 = fixedMillisecond13.getMiddleMillisecond();
//        java.util.Date date16 = fixedMillisecond13.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getEnd();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getEnd();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date18, timeZone22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getEnd();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date29 = fixedMillisecond28.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date26, timeZone30);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date18, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone30);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560191793980L + "'", long14 == 1560191793980L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560191793980L + "'", long15 == 1560191793980L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "August" + "'", str1.equals("August"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        int int6 = timeSeries5.getMaximumItemCount();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        boolean boolean8 = timeSeries5.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, "", "Feb", class13);
        java.lang.String str15 = timeSeries14.getDomainDescription();
        timeSeries14.setNotify(true);
        java.util.Collection collection18 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        java.lang.Comparable comparable19 = timeSeries5.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getEnd();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "", "Feb", class26);
        int int28 = timeSeries27.getMaximumItemCount();
        boolean boolean29 = timeSeries27.isEmpty();
        java.lang.String str30 = timeSeries27.getDomainDescription();
        timeSeries27.setMaximumItemCount((int) (short) 0);
        java.lang.Class<?> wildcardClass33 = timeSeries27.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries(comparable19, "hi!", "org.jfree.data.general.SeriesException: Nearest", (java.lang.Class) wildcardClass33);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(comparable19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        java.lang.Class class0 = null;
//        java.lang.Class class1 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getEnd();
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone4);
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date3, timeZone6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        long long10 = day8.getSerialIndex();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = day8.equals(obj11);
//        java.util.Calendar calendar13 = null;
//        try {
//            day8.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        int int6 = timeSeries5.getMaximumItemCount();
        boolean boolean7 = timeSeries5.isEmpty();
        java.lang.String str8 = timeSeries5.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries5.createCopy(8, 100);
        java.lang.String str12 = timeSeries5.getDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 11:35:38 PDT 2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(8);
        int int7 = spreadsheetDate6.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean10 = spreadsheetDate6.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str11 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(8);
        int int14 = spreadsheetDate13.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(12);
        boolean boolean17 = spreadsheetDate13.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate16.getFollowingDayOfWeek(7);
        boolean boolean20 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate6, serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getFollowingDayOfWeek(3);
        java.lang.String str23 = serialDate22.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "7-January-1900" + "'", str11.equals("7-January-1900"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "16-January-1900" + "'", str23.equals("16-January-1900"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        java.lang.Class class11 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date10, timeZone14);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date1, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.previous();
        int int19 = month17.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:24 PST 1969");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("Nearest");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException5.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
        int int6 = timeSeries5.getMaximumItemCount();
        java.lang.String str7 = timeSeries5.getDomainDescription();
        long long8 = timeSeries5.getMaximumItemAge();
        try {
            timeSeries5.update(0, (java.lang.Number) 1560191776631L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        java.lang.Class class11 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date10, timeZone14);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date1, timeZone14);
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
        org.jfree.data.time.Year year20 = month17.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(year20);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getEnd();
        java.lang.Class class2 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date4 = fixedMillisecond3.getEnd();
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1, timeZone5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getEnd();
        java.lang.Class class11 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getEnd();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone14);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date10, timeZone14);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date1, timeZone14);
        int int18 = month17.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month17.previous();
        long long20 = month17.getSerialIndex();
        java.lang.String str21 = month17.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 24234L + "'", long20 == 24234L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date4, timeZone5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1, timeZone5);
//        int int8 = day7.getYear();
//        long long9 = day7.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (double) 1560191700753L);
//        long long12 = day7.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date14 = fixedMillisecond13.getEnd();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond13, "", "Feb", class17);
//        java.lang.String str19 = timeSeries18.getDescription();
//        timeSeries18.clear();
//        java.util.Collection collection21 = timeSeries18.getTimePeriods();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getEnd();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date28, timeZone29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date25, timeZone29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getEnd();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date37, timeZone38);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date34, timeZone38);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date25, timeZone38);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date25);
//        boolean boolean43 = spreadsheetDate23.isBefore(serialDate42);
//        boolean boolean44 = timeSeries18.equals((java.lang.Object) spreadsheetDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate46.getPreviousDayOfWeek((int) (short) 1);
//        int int49 = spreadsheetDate46.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getEnd();
//        java.lang.Class class52 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date54 = fixedMillisecond53.getEnd();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date54, timeZone55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date51, timeZone55);
//        int int58 = day57.getYear();
//        long long59 = day57.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day57, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day57.next();
//        long long63 = day57.getLastMillisecond();
//        boolean boolean64 = spreadsheetDate46.equals((java.lang.Object) day57);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate68 = spreadsheetDate66.getPreviousDayOfWeek((int) (short) 1);
//        int int69 = spreadsheetDate46.compare((org.jfree.data.time.SerialDate) spreadsheetDate66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(12);
//        boolean boolean74 = spreadsheetDate71.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
//        boolean boolean75 = spreadsheetDate66.isOn((org.jfree.data.time.SerialDate) spreadsheetDate71);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate79 = spreadsheetDate77.getPreviousDayOfWeek((int) (short) 1);
//        int int80 = spreadsheetDate77.toSerial();
//        java.lang.String str81 = spreadsheetDate77.getDescription();
//        boolean boolean83 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate71, (org.jfree.data.time.SerialDate) spreadsheetDate77, 1900);
//        int int84 = spreadsheetDate23.getDayOfWeek();
//        int int85 = day7.compareTo((java.lang.Object) int84);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560236399999L + "'", long9 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 12 + "'", int49 == 12);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1560236399999L + "'", long59 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560236399999L + "'", long63 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 12 + "'", int80 == 12);
//        org.junit.Assert.assertNull(str81);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.previous();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getLastMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getEnd();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date16, timeZone17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date13, timeZone17);
//        java.lang.Class<?> wildcardClass20 = timeZone17.getClass();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "hi!", "SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass20);
//        long long22 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("Wed Dec 31 16:00:24 PST 1969");
//        java.lang.String str25 = timePeriodFormatException24.toString();
//        java.lang.String str26 = timePeriodFormatException24.toString();
//        java.lang.String str27 = timePeriodFormatException24.toString();
//        int int28 = fixedMillisecond0.compareTo((java.lang.Object) str27);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560191795470L + "'", long8 == 1560191795470L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560191795470L + "'", long22 == 1560191795470L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969" + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969"));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
//        int int4 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getEnd();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date9, timeZone10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date6, timeZone10);
//        int int13 = day12.getYear();
//        long long14 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day12.next();
//        long long18 = day12.getLastMillisecond();
//        boolean boolean19 = spreadsheetDate1.equals((java.lang.Object) day12);
//        int int20 = day12.getMonth();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(8);
//        int int2 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate4.getPreviousDayOfWeek((int) (short) 1);
//        int int7 = spreadsheetDate4.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date9, timeZone13);
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.next();
//        long long21 = day15.getLastMillisecond();
//        boolean boolean22 = spreadsheetDate4.equals((java.lang.Object) day15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate24.getPreviousDayOfWeek((int) (short) 1);
//        int int27 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date29 = fixedMillisecond28.getEnd();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date32 = fixedMillisecond31.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date32, timeZone33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date29, timeZone33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        java.lang.Class class38 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date40 = fixedMillisecond39.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date40, timeZone41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date37, timeZone41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date29, timeZone41);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date29);
//        boolean boolean46 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate4, serialDate45);
//        int int47 = spreadsheetDate4.toSerial();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 12 + "'", int47 == 12);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        java.lang.String str6 = timeSeries5.getDescription();
//        timeSeries5.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, "", "Feb", class12);
//        int int14 = timeSeries5.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        timeSeries5.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getEnd();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond16, "", "Feb", class20);
//        java.lang.String str22 = timeSeries21.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        long long24 = fixedMillisecond23.getLastMillisecond();
//        long long25 = fixedMillisecond23.getLastMillisecond();
//        int int27 = fixedMillisecond23.compareTo((java.lang.Object) true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timeSeries21.removePropertyChangeListener(propertyChangeListener29);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(5, 3);
//        int int34 = month33.getMonth();
//        java.lang.String str35 = month33.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getEnd();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond36, "", "Feb", class40);
//        java.lang.String str42 = timeSeries41.getDescription();
//        timeSeries41.fireSeriesChanged();
//        int int44 = month33.compareTo((java.lang.Object) timeSeries41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 1560191700516L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getEnd();
//        java.lang.Class class49 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getEnd();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date51, timeZone52);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date48, timeZone52);
//        int int55 = day54.getYear();
//        long long56 = day54.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day54, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day54.next();
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month33, (org.jfree.data.time.RegularTimePeriod) day54);
//        java.lang.String str61 = day54.toString();
//        long long62 = day54.getLastMillisecond();
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(5, 3);
//        int int66 = month65.getMonth();
//        java.lang.String str67 = month65.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date69 = fixedMillisecond68.getEnd();
//        java.lang.Class class72 = null;
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond68, "", "Feb", class72);
//        java.lang.String str74 = timeSeries73.getDescription();
//        timeSeries73.fireSeriesChanged();
//        int int76 = month65.compareTo((java.lang.Object) timeSeries73);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) 1560191700516L);
//        java.lang.Number number79 = timeSeriesDataItem78.getValue();
//        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month(5, 3);
//        int int83 = month82.getMonth();
//        java.lang.String str84 = month82.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date86 = fixedMillisecond85.getEnd();
//        java.lang.Class class89 = null;
//        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond85, "", "Feb", class89);
//        java.lang.String str91 = timeSeries90.getDescription();
//        timeSeries90.fireSeriesChanged();
//        int int93 = month82.compareTo((java.lang.Object) timeSeries90);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month82, (java.lang.Number) 1560191700516L);
//        int int96 = timeSeriesDataItem78.compareTo((java.lang.Object) 1560191700516L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = timeSeriesDataItem78.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries98 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day54, regularTimePeriod97);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod99 = timeSeries5.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191795867L + "'", long24 == 1560191795867L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560191795867L + "'", long25 == 1560191795867L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "May 3" + "'", str35.equals("May 3"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(str42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560236399999L + "'", long56 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "10-June-2019" + "'", str61.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560236399999L + "'", long62 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 5 + "'", int66 == 5);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "May 3" + "'", str67.equals("May 3"));
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNull(str74);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 1560191700516L + "'", number79.equals(1560191700516L));
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 5 + "'", int83 == 5);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "May 3" + "'", str84.equals("May 3"));
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNull(str91);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod97);
//        org.junit.Assert.assertNotNull(timeSeries98);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191795910L + "'", long1 == 1560191795910L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191795910L + "'", long3 == 1560191795910L);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getEnd();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0, "", "Feb", class4);
//        int int6 = timeSeries5.getMaximumItemCount();
//        boolean boolean7 = timeSeries5.isEmpty();
//        java.lang.String str8 = timeSeries5.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries5.createCopy(8, 100);
//        timeSeries5.clear();
//        timeSeries5.setDomainDescription("7-January-1900");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        long long18 = fixedMillisecond17.getLastMillisecond();
//        long long19 = fixedMillisecond17.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond17.getFirstMillisecond(calendar20);
//        long long22 = fixedMillisecond17.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond17.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 1560191724793L);
//        java.lang.String str26 = timeSeries5.getDescription();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560191795921L + "'", long18 == 1560191795921L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560191795921L + "'", long19 == 1560191795921L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560191795921L + "'", long21 == 1560191795921L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560191795921L + "'", long22 == 1560191795921L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNull(str26);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date6 = fixedMillisecond5.getEnd();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "", "Feb", class9);
        java.lang.String str11 = timeSeries10.getDescription();
        timeSeries10.fireSeriesChanged();
        int int13 = month2.compareTo((java.lang.Object) timeSeries10);
        long long14 = month2.getLastMillisecond();
        int int15 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "May 3" + "'", str4.equals("May 3"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62059622400001L) + "'", long14 == (-62059622400001L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("May 3");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 3);
        long long3 = month2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 41L + "'", long3 == 41L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, (-1), 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate4 = spreadsheetDate2.getPreviousDayOfWeek((int) (short) 1);
//        int int5 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date7, timeZone11);
//        int int14 = day13.getYear();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) 1560191700753L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.next();
//        long long19 = day13.getLastMillisecond();
//        boolean boolean20 = spreadsheetDate2.equals((java.lang.Object) day13);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate22.getPreviousDayOfWeek((int) (short) 1);
//        int int25 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(12);
//        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate27.getPreviousDayOfWeek((int) (short) 1);
//        int int30 = spreadsheetDate27.toSerial();
//        java.lang.String str31 = spreadsheetDate27.getDescription();
//        boolean boolean32 = spreadsheetDate2.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getEnd();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date38 = fixedMillisecond37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date38, timeZone39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date35, timeZone39);
//        int int42 = day41.getYear();
//        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
//        java.lang.String str44 = serialDate43.toString();
//        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate27.getEndOfCurrentMonth(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 12 + "'", int30 == 12);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate45);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: Wed Dec 31 16:00:24 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(24234L);
//        java.util.Date date2 = fixedMillisecond1.getEnd();
//        java.util.Date date3 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getLastMillisecond();
//        long long6 = fixedMillisecond4.getMiddleMillisecond();
//        java.util.Date date7 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getEnd();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date12 = fixedMillisecond11.getEnd();
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date9, timeZone13);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date7, timeZone13);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3, timeZone13);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date3);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191796340L + "'", long5 == 1560191796340L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560191796340L + "'", long6 == 1560191796340L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//    }
//}

