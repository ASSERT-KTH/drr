import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline1.toTimelineValue(0L);
        boolean boolean5 = segmentedTimeline1.containsDomainValue((long) 7);
        long long8 = segmentedTimeline1.getExceptionSegmentCount(1L, (long) 10);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline1);
        dateAxis0.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577894400000L + "'", long3 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Jan");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            labelBlock1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer22.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
        xYStepAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator27);
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis35.setTickLabelFont(font37);
        logAxis35.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) logAxis35, categoryItemRenderer42);
        java.awt.Stroke stroke44 = categoryPlot43.getOutlineStroke();
        xYStepAreaRenderer22.setBaseStroke(stroke44, false);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) xYStepAreaRenderer22);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis51 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) day50);
        boolean boolean52 = categoryPlot18.equals((java.lang.Object) "ThreadContext");
        java.awt.Stroke stroke53 = categoryPlot18.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot18.getDomainAxisEdge(0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis3.getFirst();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) day7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis18.setTickLabelFont(font20);
        logAxis18.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) logAxis18, categoryItemRenderer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot26.getRangeAxisEdge((int) ' ');
        java.util.List list29 = periodAxis8.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge28);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray30 = null;
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray30);
        java.lang.Class class32 = periodAxis8.getMinorTickTimePeriodClass();
        periodAxis3.setAutoRangeTimePeriodClass(class32);
        boolean boolean34 = org.jfree.chart.util.SerialUtilities.isSerializable(class32);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        legendGraphic20.setShapeFilled(false);
        java.awt.Paint paint23 = legendGraphic20.getLinePaint();
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray26);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        float float31 = logAxis30.getMinorTickMarkInsideLength();
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis30.setTickLabelFont(font32);
        logAxis30.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) logAxis30, categoryItemRenderer37);
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        logAxis30.setTickMarkPaint(paint39);
        legendGraphic20.setFillPaint(paint39);
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.LogAxis logAxis48 = new org.jfree.chart.axis.LogAxis("");
        float float49 = logAxis48.getMinorTickMarkInsideLength();
        java.awt.Font font50 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis48.setTickLabelFont(font50);
        logAxis48.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) logAxis48, categoryItemRenderer55);
        java.awt.Stroke stroke57 = categoryPlot56.getOutlineStroke();
        legendGraphic20.setOutlineStroke(stroke57);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.LogAxis logAxis63 = new org.jfree.chart.axis.LogAxis("");
        float float64 = logAxis63.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset61, (org.jfree.chart.axis.ValueAxis) logAxis63, valueAxis65, xYItemRenderer66);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = xYPlot67.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer71 = null;
        java.util.Collection collection72 = xYPlot67.getDomainMarkers((int) 'a', layer71);
        org.jfree.chart.axis.LogAxis logAxis74 = new org.jfree.chart.axis.LogAxis("");
        float float75 = logAxis74.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke76 = logAxis74.getTickMarkStroke();
        xYPlot67.setRangeGridlineStroke(stroke76);
        java.awt.Paint paint78 = xYPlot67.getDomainCrosshairPaint();
        xYPlot67.mapDatasetToRangeAxis((int) '#', 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = xYPlot67.getRangeAxisEdge();
        try {
            java.lang.Object obj83 = legendGraphic20.draw(graphics2D59, rectangle2D60, (java.lang.Object) rectangleEdge82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 0.0f + "'", float64 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertNull(collection72);
        org.junit.Assert.assertTrue("'" + float75 + "' != '" + 0.0f + "'", float75 == 0.0f);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(rectangleEdge82);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray36 = null;
        try {
            categoryPlot14.setRenderers(categoryItemRendererArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        dateAxis0.setRange((double) 0L, (double) 200);
        dateAxis0.setTickMarksVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long10 = segmentedTimeline8.toTimelineValue(0L);
        boolean boolean12 = segmentedTimeline8.containsDomainValue((long) 7);
        long long15 = segmentedTimeline8.getExceptionSegmentCount(1L, (long) 10);
        dateAxis7.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline8);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline8);
        org.junit.Assert.assertNotNull(segmentedTimeline8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577894400000L + "'", long10 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        logAxis1.setUpArrow(shape7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        java.lang.Object obj3 = standardPieSectionLabelGenerator2.clone();
        org.jfree.data.xy.XYSeries xYSeries7 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection(xYSeries7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, false);
        xYSeriesCollection8.removeAllSeries();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) logAxis14, valueAxis16, xYItemRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot18.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot18.getDomainMarkers((int) 'a', layer22);
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        float float26 = logAxis25.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke27 = logAxis25.getTickMarkStroke();
        xYPlot18.setRangeGridlineStroke(stroke27);
        java.awt.Paint paint29 = xYPlot18.getDomainCrosshairPaint();
        boolean boolean30 = xYSeriesCollection8.hasListener((java.util.EventListener) xYPlot18);
        boolean boolean31 = standardPieSectionLabelGenerator2.equals((java.lang.Object) xYPlot18);
        boolean boolean32 = standardPieToolTipGenerator0.equals((java.lang.Object) standardPieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0.0f, "", "hi!", false);
        logFormat4.setMinimumIntegerDigits((int) '4');
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYStepAreaRenderer8.setBaseCreateEntities(false);
        boolean boolean11 = logFormat4.equals((java.lang.Object) xYStepAreaRenderer8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = xYSeriesCollection6.getGroup();
        java.lang.Object obj8 = xYSeriesCollection6.clone();
        boolean boolean9 = datasetRenderingOrder0.equals((java.lang.Object) xYSeriesCollection6);
        try {
            double double12 = xYSeriesCollection6.getEndYValue((int) '#', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(datasetGroup7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.util.Date date3 = year1.getEnd();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.configure();
        java.util.TimeZone timeZone6 = dateAxis4.getTimeZone();
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date3, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        boolean boolean2 = standardChartTheme1.isShadowVisible();
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ThreadContext");
        java.awt.Paint paint5 = textFragment4.getPaint();
        standardChartTheme1.setTickLabelPaint(paint5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = standardChartTheme1.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(drawingSupplier7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.lang.String str4 = standardXYToolTipGenerator3.getFormatString();
        java.lang.Object obj5 = standardXYToolTipGenerator3.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Font font2 = standardChartTheme1.getLargeFont();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj4 = defaultDrawingSupplier3.clone();
        java.awt.Stroke stroke5 = defaultDrawingSupplier3.getNextStroke();
        standardChartTheme1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier3);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ClassContext", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) logAxis42, valueAxis44, xYItemRenderer45);
        java.awt.Paint paint47 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot46.setDomainCrosshairPaint(paint47);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator51 = null;
        xYStepAreaRenderer50.setBaseToolTipGenerator(xYToolTipGenerator51);
        java.awt.Shape shape54 = xYStepAreaRenderer50.lookupLegendShape(0);
        int int55 = xYPlot46.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer50);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.LogAxis logAxis58 = new org.jfree.chart.axis.LogAxis("");
        float float59 = logAxis58.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) logAxis58, valueAxis60, xYItemRenderer61);
        java.awt.Paint paint63 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot62.setDomainCrosshairPaint(paint63);
        xYPlot46.setRangeGridlinePaint(paint63);
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray68);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.LogAxis logAxis72 = new org.jfree.chart.axis.LogAxis("");
        float float73 = logAxis72.getMinorTickMarkInsideLength();
        java.awt.Font font74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis72.setTickLabelFont(font74);
        logAxis72.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, (org.jfree.chart.axis.ValueAxis) logAxis72, categoryItemRenderer79);
        double double82 = logAxis72.calculateLog((double) (-1.0f));
        int int83 = xYPlot46.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        int int84 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        categoryPlot14.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 0.0f + "'", float73 == 0.0f);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.lang.Object obj4 = null;
        try {
            java.lang.Object obj5 = blockContainer0.draw(graphics2D2, rectangle2D3, obj4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        java.lang.String str1 = domainOrder0.toString();
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DomainOrder.NONE" + "'", str1.equals("DomainOrder.NONE"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) itemLabelAnchor1);
        boolean boolean4 = gradientPaintTransformType0.equals((java.lang.Object) "DateTickMarkPosition.END");
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot9.setDomainCrosshairPaint(paint10);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYStepAreaRenderer13.setBaseToolTipGenerator(xYToolTipGenerator14);
        java.awt.Shape shape17 = xYStepAreaRenderer13.lookupLegendShape(0);
        int int18 = xYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot9.getDomainAxisEdge((int) (byte) 100);
        try {
            double double21 = numberAxis0.valueToJava2D((double) 6, rectangle2D2, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        float float5 = logAxis4.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) logAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot8.getDomainMarkers((int) 'a', layer12);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        float float16 = logAxis15.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke17 = logAxis15.getTickMarkStroke();
        xYPlot8.setRangeGridlineStroke(stroke17);
        java.awt.Paint paint19 = xYPlot8.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint25 = standardChartTheme24.getGridBandPaint();
        xYPlot8.setRangeCrosshairPaint(paint25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        xYPlot8.setDomainAxis((int) (byte) 10, valueAxis28);
        int int30 = xYPlot8.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("Category Plot", font1, (org.jfree.chart.plot.Plot) xYPlot8, true);
        jFreeChart32.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        piePlot3D0.setSimpleLabels(false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer14.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = null;
        xYStepAreaRenderer14.setLegendItemURLGenerator(xYSeriesLabelGenerator19);
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        float float28 = logAxis27.getMinorTickMarkInsideLength();
        java.awt.Font font29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis27.setTickLabelFont(font29);
        logAxis27.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) logAxis27, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot35.getOutlineStroke();
        xYStepAreaRenderer14.setBaseStroke(stroke36, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator39 = null;
        xYStepAreaRenderer14.setBaseItemLabelGenerator(xYItemLabelGenerator39, true);
        combinedRangeXYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = null;
        combinedRangeXYPlot12.plotChanged(plotChangeEvent43);
        piePlot3D0.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot12);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator46 = piePlot3D0.getURLGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(pieURLGenerator46);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getTickLabelFont();
        java.lang.Object obj2 = dateAxis0.clone();
        dateAxis0.configure();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis0.setStandardTickUnits(tickUnitSource1);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, rectangleAnchor41, (double) 10, (double) '#');
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(shape44);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 2958465, 0.5d, (double) (byte) 0, (double) 2958465);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        legendGraphic20.setShapeFilled(false);
        java.awt.Paint paint23 = legendGraphic20.getLinePaint();
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray26);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        float float31 = logAxis30.getMinorTickMarkInsideLength();
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis30.setTickLabelFont(font32);
        logAxis30.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) logAxis30, categoryItemRenderer37);
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        logAxis30.setTickMarkPaint(paint39);
        legendGraphic20.setFillPaint(paint39);
        java.lang.Number[][] numberArray44 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray44);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.LogAxis logAxis48 = new org.jfree.chart.axis.LogAxis("");
        float float49 = logAxis48.getMinorTickMarkInsideLength();
        java.awt.Font font50 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis48.setTickLabelFont(font50);
        logAxis48.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, (org.jfree.chart.axis.ValueAxis) logAxis48, categoryItemRenderer55);
        java.awt.Stroke stroke57 = categoryPlot56.getOutlineStroke();
        legendGraphic20.setOutlineStroke(stroke57);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendGraphic20.setShapeAnchor(rectangleAnchor59);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(numberArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
        java.lang.Object obj2 = xYAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=0.0]", graphics2D1, (float) 900000L, 0.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis18.setTickLabelFont(font20);
        int int22 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis18);
        java.awt.Paint paint23 = xYPlot6.getRangeTickBandPaint();
        double double24 = xYPlot6.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        boolean boolean7 = piePlot3D0.equals((java.lang.Object) "index.html");
        java.awt.Stroke stroke8 = piePlot3D0.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        boolean boolean36 = categoryPlot14.isRangeMinorGridlinesVisible();
        categoryPlot14.zoom((double) 4);
        int int39 = categoryPlot14.getRangeAxisCount();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        boolean boolean36 = categoryPlot14.isRangeMinorGridlinesVisible();
        categoryPlot14.zoom((double) 4);
        java.awt.Color color41 = java.awt.Color.orange;
        java.awt.Color color42 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", color41);
        java.awt.Color color43 = java.awt.Color.getColor("hi!", color41);
        categoryPlot14.setRangeMinorGridlinePaint((java.awt.Paint) color41);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        try {
            xYSeries3.update((java.lang.Number) Double.NaN, (java.lang.Number) 0.5d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = NaN");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        double double7 = logAxis1.calculateValue((double) (-1.0f));
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = logAxis1.getTickUnit();
        double double9 = logAxis1.getSmallestValue();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1d + "'", double7 == 0.1d);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-100d + "'", double9 == 1.0E-100d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        java.awt.Paint paint9 = xYStepAreaRenderer1.getItemOutlinePaint((int) (byte) 0, (int) '4', false);
        java.lang.Boolean boolean11 = xYStepAreaRenderer1.getSeriesVisibleInLegend((int) (byte) 10);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot6.getDomainAxisEdge((int) (byte) 100);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot6.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        double double2 = axisSpace0.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        double double7 = logAxis1.calculateValue((double) (-1.0f));
        org.jfree.chart.plot.Plot plot8 = logAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1d + "'", double7 == 0.1d);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 3, "�", textAnchor3, textAnchor4, 8.0d);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        legendGraphic20.setShapeFilled(false);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape23, "Pie 3D Plot");
        legendGraphic20.setLine(shape23);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.lang.String str2 = gradientPaintTransformType1.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str2.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset26);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        java.awt.Stroke stroke51 = categoryPlot50.getOutlineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke51);
        org.jfree.chart.axis.LogAxis logAxis54 = new org.jfree.chart.axis.LogAxis("");
        float float55 = logAxis54.getMinorTickMarkInsideLength();
        logAxis54.centerRange((double) 15);
        boolean boolean58 = logAxis54.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double60 = rectangleInsets59.getRight();
        java.lang.String str61 = rectangleInsets59.toString();
        double double62 = rectangleInsets59.getBottom();
        logAxis54.setLabelInsets(rectangleInsets59);
        java.awt.Paint paint64 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        logAxis54.setTickMarkPaint(paint64);
        categoryPlot14.setDomainGridlinePaint(paint64);
        java.lang.Comparable comparable67 = categoryPlot14.getDomainCrosshairRowKey();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.0f + "'", float55 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str61.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + "Jan" + "'", comparable67.equals("Jan"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        boolean boolean4 = xYSeries3.getAutoSort();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        try {
            double double9 = xYSeriesCollection4.getEndXValue((-447), 500);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -447");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis2.setTickLabelFont(font4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("");
        float float9 = logAxis8.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) logAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot12.setDataset((int) (byte) 10, xYDataset14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        float float20 = logAxis19.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) logAxis19, valueAxis21, xYItemRenderer22);
        java.awt.Paint paint24 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot23.setDomainCrosshairPaint(paint24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        xYStepAreaRenderer27.setBaseToolTipGenerator(xYToolTipGenerator28);
        java.awt.Shape shape31 = xYStepAreaRenderer27.lookupLegendShape(0);
        int int32 = xYPlot23.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer27);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) logAxis35, valueAxis37, xYItemRenderer38);
        java.awt.Paint paint40 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot39.setDomainCrosshairPaint(paint40);
        xYPlot23.setRangeGridlinePaint(paint40);
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.LogAxis logAxis49 = new org.jfree.chart.axis.LogAxis("");
        float float50 = logAxis49.getMinorTickMarkInsideLength();
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis49.setTickLabelFont(font51);
        logAxis49.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) logAxis49, categoryItemRenderer56);
        double double59 = logAxis49.calculateLog((double) (-1.0f));
        int int60 = xYPlot23.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis49);
        xYPlot12.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) logAxis49, false);
        org.jfree.data.xy.XYDataset xYDataset63 = xYPlot12.getDataset();
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.axis.LogAxis logAxis66 = new org.jfree.chart.axis.LogAxis("");
        float float67 = logAxis66.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset64, (org.jfree.chart.axis.ValueAxis) logAxis66, valueAxis68, xYItemRenderer69);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = xYPlot70.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = xYPlot70.getRenderer();
        java.awt.Paint paint74 = xYPlot70.getRangeGridlinePaint();
        xYPlot12.setRangeZeroBaselinePaint(paint74);
        org.jfree.chart.block.LabelBlock labelBlock76 = new org.jfree.chart.block.LabelBlock("TextAnchor.BOTTOM_RIGHT", font4, paint74);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor77 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent78 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textBlockAnchor77);
        labelBlock76.setContentAlignmentPoint(textBlockAnchor77);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor80 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        labelBlock76.setContentAlignmentPoint(textBlockAnchor80);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.0f + "'", float50 == 0.0f);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNull(xYDataset63);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 0.0f + "'", float67 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNull(xYItemRenderer73);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(textBlockAnchor77);
        org.junit.Assert.assertNotNull(textBlockAnchor80);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        java.lang.String str41 = categoryItemEntity40.getURLText();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str41.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot22.getRangeAxisEdge((int) ' ');
        java.util.List list25 = periodAxis4.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge24);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray26 = null;
        periodAxis4.setLabelInfo(periodAxisLabelInfoArray26);
        java.lang.Class class28 = periodAxis4.getMinorTickTimePeriodClass();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) unitType0, (java.lang.Object) class28);
        java.lang.ClassLoader classLoader30 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class28);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(classLoader30);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, 100.0d, 100.0f, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible((int) ' ', true);
        java.lang.Object obj4 = xYStepRenderer0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = xYPlot6.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(drawingSupplier21);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible((int) ' ', true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYStepAreaRenderer5.setLegendItemURLGenerator(xYSeriesLabelGenerator10);
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis18.setTickLabelFont(font20);
        logAxis18.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) logAxis18, categoryItemRenderer25);
        java.awt.Stroke stroke27 = categoryPlot26.getOutlineStroke();
        xYStepAreaRenderer5.setBaseStroke(stroke27, false);
        xYStepAreaRenderer5.setShapesVisible(true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator32 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYStepAreaRenderer5.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator32);
        xYStepRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator32);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.LogAxis logAxis52 = new org.jfree.chart.axis.LogAxis("");
        float float53 = logAxis52.getMinorTickMarkInsideLength();
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis52.setTickLabelFont(font54);
        boolean boolean56 = logAxis52.isAutoRange();
        boolean boolean57 = logAxis52.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer58 = null;
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) logAxis52, polarItemRenderer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        polarPlot59.zoomRangeAxes((double) 2.0f, plotRenderingInfo61, point2D62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        java.awt.geom.Point2D point2D67 = null;
        polarPlot59.zoomRangeAxes(0.0d, (double) (short) 10, plotRenderingInfo66, point2D67);
        polarPlot59.zoom((double) (byte) -1);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.0f + "'", float53 == 0.0f);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("UnitType.ABSOLUTE", "Pie 3D Plot", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "DatasetRenderingOrder.FORWARD");
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYStepAreaRenderer1.notifyListeners(rendererChangeEvent6);
        java.lang.Boolean boolean9 = xYStepAreaRenderer1.getSeriesVisible(0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        xYStepAreaRenderer19.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer25.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer25.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition34);
        xYStepAreaRenderer19.setBaseNegativeItemLabelPosition(itemLabelPosition34);
        java.awt.Paint paint38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        xYStepAreaRenderer19.setSeriesPaint(0, paint38);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.data.time.TimeSeries timeSeries1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        double double4 = timeSeriesCollection2.getDomainUpperBound(true);
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.LogAxis logAxis11 = new org.jfree.chart.axis.LogAxis("");
        float float12 = logAxis11.getMinorTickMarkInsideLength();
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis11.setTickLabelFont(font13);
        logAxis11.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) logAxis11, categoryItemRenderer18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("");
        float float23 = logAxis22.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) logAxis22, valueAxis24, xYItemRenderer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot26.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = xYPlot26.getDomainMarkers((int) 'a', layer30);
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis("");
        float float34 = logAxis33.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke35 = logAxis33.getTickMarkStroke();
        xYPlot26.setRangeGridlineStroke(stroke35);
        categoryPlot19.setDomainCrosshairStroke(stroke35);
        org.jfree.chart.axis.LogAxis logAxis39 = new org.jfree.chart.axis.LogAxis("");
        float float40 = logAxis39.getMinorTickMarkInsideLength();
        java.awt.Font font41 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis39.setTickLabelFont(font41);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = logAxis39.getStandardTickUnits();
        int int44 = categoryPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis39);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.LogAxis logAxis47 = new org.jfree.chart.axis.LogAxis("");
        float float48 = logAxis47.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) logAxis47, valueAxis49, xYItemRenderer50);
        java.awt.Paint paint52 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot51.setDomainCrosshairPaint(paint52);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer55 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator56 = null;
        xYStepAreaRenderer55.setBaseToolTipGenerator(xYToolTipGenerator56);
        java.awt.Shape shape59 = xYStepAreaRenderer55.lookupLegendShape(0);
        int int60 = xYPlot51.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer55);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.LogAxis logAxis63 = new org.jfree.chart.axis.LogAxis("");
        float float64 = logAxis63.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot(xYDataset61, (org.jfree.chart.axis.ValueAxis) logAxis63, valueAxis65, xYItemRenderer66);
        java.awt.Paint paint68 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot67.setDomainCrosshairPaint(paint68);
        xYPlot51.setRangeGridlinePaint(paint68);
        java.lang.Number[][] numberArray73 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset74 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray73);
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = null;
        org.jfree.chart.axis.LogAxis logAxis77 = new org.jfree.chart.axis.LogAxis("");
        float float78 = logAxis77.getMinorTickMarkInsideLength();
        java.awt.Font font79 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis77.setTickLabelFont(font79);
        logAxis77.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer84 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot(categoryDataset74, categoryAxis75, (org.jfree.chart.axis.ValueAxis) logAxis77, categoryItemRenderer84);
        double double87 = logAxis77.calculateLog((double) (-1.0f));
        int int88 = xYPlot51.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis77);
        int int89 = categoryPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis77);
        java.util.List list90 = categoryPlot19.getCategories();
        org.jfree.data.time.DateRange dateRange91 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range93 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection2, list90, (org.jfree.data.Range) dateRange91, false);
        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries95 = timeSeriesCollection2.getSeries((java.lang.Comparable) day94);
        boolean boolean96 = size2D0.equals((java.lang.Object) timeSeries95);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 0.0f + "'", float40 == 0.0f);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(tickUnitSource43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.0f + "'", float48 == 0.0f);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 0.0f + "'", float64 == 0.0f);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(numberArray73);
        org.junit.Assert.assertNotNull(categoryDataset74);
        org.junit.Assert.assertTrue("'" + float78 + "' != '" + 0.0f + "'", float78 == 0.0f);
        org.junit.Assert.assertNotNull(font79);
        org.junit.Assert.assertEquals((double) double87, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
        org.junit.Assert.assertNotNull(list90);
        org.junit.Assert.assertNotNull(dateRange91);
        org.junit.Assert.assertNull(range93);
        org.junit.Assert.assertNull(timeSeries95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        xYPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot6.getRangeAxisLocation(6);
        java.awt.Paint paint19 = xYPlot6.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        java.lang.Object obj6 = null;
        boolean boolean7 = piePlot3D0.equals(obj6);
        piePlot3D0.setAutoPopulateSectionPaint(true);
        piePlot3D0.setIgnoreZeroValues(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepAreaRenderer13.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer13.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape22 = xYStepAreaRenderer13.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        float float26 = logAxis25.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) logAxis25, valueAxis27, xYItemRenderer28);
        java.awt.Paint paint30 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot29.setDomainCrosshairPaint(paint30);
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape22, paint30);
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        logAxis41.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) logAxis41, categoryItemRenderer48);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity52 = new org.jfree.chart.entity.CategoryItemEntity(shape22, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset38, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset38, 2147483647);
        piePlot3D0.setDataset(pieDataset54);
        org.jfree.data.general.PieDataset pieDataset59 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset54, (java.lang.Comparable) 100, 15.5d, 128);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(pieDataset59);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, true);
        try {
            java.lang.Number number9 = xYSeriesCollection4.getX(2958465, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.getSimpleLabels();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        float float8 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) logAxis7, valueAxis9, xYItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot11.setDomainCrosshairPaint(paint12);
        java.awt.geom.Point2D point2D14 = xYPlot11.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            piePlot1.draw(graphics2D3, rectangle2D4, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(point2D14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, true);
        try {
            xYSeriesCollection4.setSelected((int) (byte) 10, (int) '4', true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) logAxis42, valueAxis44, xYItemRenderer45);
        java.awt.Paint paint47 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot46.setDomainCrosshairPaint(paint47);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator51 = null;
        xYStepAreaRenderer50.setBaseToolTipGenerator(xYToolTipGenerator51);
        java.awt.Shape shape54 = xYStepAreaRenderer50.lookupLegendShape(0);
        int int55 = xYPlot46.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer50);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.LogAxis logAxis58 = new org.jfree.chart.axis.LogAxis("");
        float float59 = logAxis58.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) logAxis58, valueAxis60, xYItemRenderer61);
        java.awt.Paint paint63 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot62.setDomainCrosshairPaint(paint63);
        xYPlot46.setRangeGridlinePaint(paint63);
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray68);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.LogAxis logAxis72 = new org.jfree.chart.axis.LogAxis("");
        float float73 = logAxis72.getMinorTickMarkInsideLength();
        java.awt.Font font74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis72.setTickLabelFont(font74);
        logAxis72.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, (org.jfree.chart.axis.ValueAxis) logAxis72, categoryItemRenderer79);
        double double82 = logAxis72.calculateLog((double) (-1.0f));
        int int83 = xYPlot46.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        int int84 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        java.awt.Paint paint85 = categoryPlot14.getRangeZeroBaselinePaint();
        int int86 = categoryPlot14.getWeight();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 0.0f + "'", float73 == 0.0f);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        xYPlot6.clearRangeMarkers(1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = null;
        try {
            xYPlot6.rendererChanged(rendererChangeEvent18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str1 = axisSpace0.toString();
        axisSpace0.setBottom((double) (short) 0);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.TimeSeries timeSeries0 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
//        double double3 = timeSeriesCollection1.getDomainUpperBound(true);
//        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
//        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
//        float float11 = logAxis10.getMinorTickMarkInsideLength();
//        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        logAxis10.setTickLabelFont(font12);
//        logAxis10.setRange((double) 10, (double) 10);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
//        org.jfree.data.xy.XYDataset xYDataset19 = null;
//        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
//        float float22 = logAxis21.getMinorTickMarkInsideLength();
//        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
//        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) logAxis21, valueAxis23, xYItemRenderer24);
//        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot25.getRangeAxisEdge(0);
//        org.jfree.chart.util.Layer layer29 = null;
//        java.util.Collection collection30 = xYPlot25.getDomainMarkers((int) 'a', layer29);
//        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
//        float float33 = logAxis32.getMinorTickMarkInsideLength();
//        java.awt.Stroke stroke34 = logAxis32.getTickMarkStroke();
//        xYPlot25.setRangeGridlineStroke(stroke34);
//        categoryPlot18.setDomainCrosshairStroke(stroke34);
//        org.jfree.chart.axis.LogAxis logAxis38 = new org.jfree.chart.axis.LogAxis("");
//        float float39 = logAxis38.getMinorTickMarkInsideLength();
//        java.awt.Font font40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        logAxis38.setTickLabelFont(font40);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = logAxis38.getStandardTickUnits();
//        int int43 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis38);
//        org.jfree.data.xy.XYDataset xYDataset44 = null;
//        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("");
//        float float47 = logAxis46.getMinorTickMarkInsideLength();
//        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
//        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) logAxis46, valueAxis48, xYItemRenderer49);
//        java.awt.Paint paint51 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
//        xYPlot50.setDomainCrosshairPaint(paint51);
//        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
//        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator55 = null;
//        xYStepAreaRenderer54.setBaseToolTipGenerator(xYToolTipGenerator55);
//        java.awt.Shape shape58 = xYStepAreaRenderer54.lookupLegendShape(0);
//        int int59 = xYPlot50.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer54);
//        org.jfree.data.xy.XYDataset xYDataset60 = null;
//        org.jfree.chart.axis.LogAxis logAxis62 = new org.jfree.chart.axis.LogAxis("");
//        float float63 = logAxis62.getMinorTickMarkInsideLength();
//        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
//        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) logAxis62, valueAxis64, xYItemRenderer65);
//        java.awt.Paint paint67 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
//        xYPlot66.setDomainCrosshairPaint(paint67);
//        xYPlot50.setRangeGridlinePaint(paint67);
//        java.lang.Number[][] numberArray72 = new java.lang.Number[][] {};
//        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray72);
//        org.jfree.chart.axis.CategoryAxis categoryAxis74 = null;
//        org.jfree.chart.axis.LogAxis logAxis76 = new org.jfree.chart.axis.LogAxis("");
//        float float77 = logAxis76.getMinorTickMarkInsideLength();
//        java.awt.Font font78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        logAxis76.setTickLabelFont(font78);
//        logAxis76.setRange((double) 10, (double) 10);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer83 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, (org.jfree.chart.axis.ValueAxis) logAxis76, categoryItemRenderer83);
//        double double86 = logAxis76.calculateLog((double) (-1.0f));
//        int int87 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
//        int int88 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
//        java.util.List list89 = categoryPlot18.getCategories();
//        org.jfree.data.time.DateRange dateRange90 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
//        org.jfree.data.Range range92 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list89, (org.jfree.data.Range) dateRange90, false);
//        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeries timeSeries94 = timeSeriesCollection1.getSeries((java.lang.Comparable) day93);
//        long long95 = day93.getLastMillisecond();
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(numberArray6);
//        org.junit.Assert.assertNotNull(categoryDataset7);
//        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
//        org.junit.Assert.assertNotNull(font12);
//        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
//        org.junit.Assert.assertNotNull(rectangleEdge27);
//        org.junit.Assert.assertNull(collection30);
//        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
//        org.junit.Assert.assertNotNull(stroke34);
//        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
//        org.junit.Assert.assertNotNull(font40);
//        org.junit.Assert.assertNotNull(tickUnitSource42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
//        org.junit.Assert.assertNotNull(paint51);
//        org.junit.Assert.assertNotNull(shape58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 0.0f + "'", float63 == 0.0f);
//        org.junit.Assert.assertNotNull(paint67);
//        org.junit.Assert.assertNotNull(numberArray72);
//        org.junit.Assert.assertNotNull(categoryDataset73);
//        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.0f + "'", float77 == 0.0f);
//        org.junit.Assert.assertNotNull(font78);
//        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
//        org.junit.Assert.assertNotNull(list89);
//        org.junit.Assert.assertNotNull(dateRange90);
//        org.junit.Assert.assertNull(range92);
//        org.junit.Assert.assertNull(timeSeries94);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 1560495599999L + "'", long95 == 1560495599999L);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer22.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
        xYStepAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator27);
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis35.setTickLabelFont(font37);
        logAxis35.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) logAxis35, categoryItemRenderer42);
        java.awt.Stroke stroke44 = categoryPlot43.getOutlineStroke();
        xYStepAreaRenderer22.setBaseStroke(stroke44, false);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) xYStepAreaRenderer22);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis51 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) day50);
        boolean boolean52 = categoryPlot18.equals((java.lang.Object) "ThreadContext");
        java.awt.Color color53 = java.awt.Color.magenta;
        categoryPlot18.setRangeZeroBaselinePaint((java.awt.Paint) color53);
        org.jfree.chart.LegendItemCollection legendItemCollection55 = categoryPlot18.getLegendItems();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(legendItemCollection55);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        try {
            int int3 = timeSeriesCollection1.indexOf(timeSeries2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        boolean boolean36 = categoryPlot14.isRangeMinorGridlinesVisible();
        java.util.List list37 = categoryPlot14.getCategories();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Paint paint4 = xYStepAreaRenderer1.getBasePaint();
        java.lang.Boolean boolean6 = xYStepAreaRenderer1.getSeriesCreateEntities(3);
        java.awt.Paint paint8 = xYStepAreaRenderer1.getSeriesItemLabelPaint((int) ' ');
        xYStepAreaRenderer1.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) waferMapPlot1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis3.getFirst();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = null;
        xYStepAreaRenderer6.setLegendItemURLGenerator(xYSeriesLabelGenerator11);
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        float float20 = logAxis19.getMinorTickMarkInsideLength();
        java.awt.Font font21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis19.setTickLabelFont(font21);
        logAxis19.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) logAxis19, categoryItemRenderer26);
        java.awt.Stroke stroke28 = categoryPlot27.getOutlineStroke();
        xYStepAreaRenderer6.setBaseStroke(stroke28, false);
        xYStepAreaRenderer6.setShapesVisible(true);
        boolean boolean33 = periodAxis3.equals((java.lang.Object) true);
        periodAxis3.setMinorTickMarksVisible(false);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("�");
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline0.toTimelineValue(0L);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) 7);
        long long7 = segmentedTimeline0.getExceptionSegmentCount(1L, (long) 10);
        long long9 = segmentedTimeline0.toTimelineValue((long) (short) 1);
        java.util.Date date11 = segmentedTimeline0.getDate((long) (short) 1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577894400000L + "'", long2 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577894400001L + "'", long9 == 1577894400001L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline0.toTimelineValue(0L);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) 7);
        long long7 = segmentedTimeline0.getExceptionSegmentCount(1L, (long) 10);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) day10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis21.setTickLabelFont(font23);
        logAxis21.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) logAxis21, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getRangeAxisEdge((int) ' ');
        java.util.List list32 = periodAxis11.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge31);
        segmentedTimeline0.setExceptionSegments(list32);
        try {
            segmentedTimeline0.addException((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577894400000L + "'", long2 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = categoryPlot14.getDomainAxisForDataset((int) (byte) 100);
        int int44 = categoryPlot14.getDatasetCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder45 = categoryPlot14.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNull(categoryAxis43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder45);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis3.getFirst();
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo5 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray6 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo5 };
        periodAxis3.setLabelInfo(periodAxisLabelInfoArray6);
        java.util.TimeZone timeZone8 = null;
        try {
            periodAxis3.setTimeZone(timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray6);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double4 = xYSeries3.getMaxY();
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries3.addOrUpdate((java.lang.Number) 100, (java.lang.Number) 100L);
        boolean boolean8 = xYSeries3.isEmpty();
        xYSeries3.setDescription("RectangleEdge.TOP");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot14.setRenderer((int) (short) 1, categoryItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot14.setDomainAxisLocation(axisLocation19, false);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        xYPlot6.mapDatasetToRangeAxis((int) '#', 0);
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        boolean boolean25 = logAxis23.isAxisLineVisible();
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis32.setTickLabelFont(font34);
        logAxis32.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) logAxis32, categoryItemRenderer39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot40.getRangeAxis();
        logAxis23.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot40);
        categoryPlot40.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray45 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot40.setRenderers(categoryItemRendererArray45);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = xYStepAreaRenderer51.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator56 = null;
        xYStepAreaRenderer51.setLegendItemURLGenerator(xYSeriesLabelGenerator56);
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray60);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.LogAxis logAxis64 = new org.jfree.chart.axis.LogAxis("");
        float float65 = logAxis64.getMinorTickMarkInsideLength();
        java.awt.Font font66 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis64.setTickLabelFont(font66);
        logAxis64.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, (org.jfree.chart.axis.ValueAxis) logAxis64, categoryItemRenderer71);
        java.awt.Stroke stroke73 = categoryPlot72.getOutlineStroke();
        xYStepAreaRenderer51.setBaseStroke(stroke73, false);
        xYStepAreaRenderer51.setShapesVisible(true);
        java.awt.Paint paint78 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer51.setBaseOutlinePaint(paint78);
        org.jfree.chart.plot.PiePlot3D piePlot3D80 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double82 = rectangleInsets81.getRight();
        java.lang.String str83 = rectangleInsets81.toString();
        piePlot3D80.setSimpleLabelOffset(rectangleInsets81);
        java.awt.Stroke stroke85 = piePlot3D80.getBaseSectionOutlineStroke();
        java.awt.Paint paint86 = null;
        java.awt.Stroke stroke87 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker89 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint78, stroke85, paint86, stroke87, (float) (byte) 1);
        org.jfree.chart.util.Layer layer90 = null;
        boolean boolean91 = categoryPlot40.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker89, layer90);
        java.lang.String str92 = intervalMarker89.getLabel();
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addRangeMarker(10, (org.jfree.chart.plot.Marker) intervalMarker89, layer93);
        java.lang.Object obj95 = intervalMarker89.clone();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertNotNull(categoryItemRendererArray45);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertTrue("'" + float65 + "' != '" + 0.0f + "'", float65 == 0.0f);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(rectangleInsets81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str83.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(str92);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertNotNull(obj95);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = piePlot3D0.getLegendItems();
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        float float13 = logAxis12.getMinorTickMarkInsideLength();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis12.setTickLabelFont(font14);
        logAxis12.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) logAxis12, categoryItemRenderer19);
        java.lang.String str21 = categoryPlot20.getPlotType();
        java.awt.Paint paint22 = categoryPlot20.getRangeGridlinePaint();
        java.awt.Stroke stroke23 = categoryPlot20.getRangeZeroBaselineStroke();
        piePlot3D0.setLabelOutlineStroke(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Category Plot" + "'", str21.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getRangeAxisEdge((int) ' ');
        java.util.List list24 = periodAxis3.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge23);
        boolean boolean25 = periodAxis3.isMinorTickMarksVisible();
        periodAxis3.setMinorTickMarksVisible(true);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot6.getRenderer();
        java.awt.Paint paint10 = xYPlot6.getRangeGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot6.getLegendItems();
        boolean boolean12 = xYPlot6.canSelectByPoint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset8);
        java.awt.geom.GeneralPath generalPath10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.RenderingSource renderingSource12 = null;
        xYPlot6.select(generalPath10, rectangle2D11, renderingSource12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYStepAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator8);
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis16.setTickLabelFont(font18);
        logAxis16.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getOutlineStroke();
        xYStepAreaRenderer3.setBaseStroke(stroke25, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = null;
        xYStepAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator28, true);
        combinedRangeXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation33 = combinedRangeXYPlot1.getRangeAxisLocation(128);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        java.awt.geom.Point2D point2D9 = xYPlot6.getQuadrantOrigin();
        java.lang.String str10 = xYPlot6.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(point2D9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setInfo("hi!");
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getLibraries();
        basicProjectInfo0.setLicenceName("hi!");
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 'a');
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double4 = xYSeries3.getMaxY();
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries3.addOrUpdate((java.lang.Number) 100, (java.lang.Number) 100L);
        xYSeries3.add((double) 0, (java.lang.Number) (-1.0f), true);
        double double12 = xYSeries3.getMinY();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        xYPlot6.mapDatasetToRangeAxis((int) '#', 0);
        xYPlot6.setRangeCrosshairValue((double) 10);
        xYPlot6.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        java.lang.String str41 = categoryItemEntity40.getShapeCoords();
        categoryItemEntity40.setToolTipText("");
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "-3,-3,3,3" + "'", str41.equals("-3,-3,3,3"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getRangeAxisEdge((int) ' ');
        java.util.List list24 = periodAxis3.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge23);
        boolean boolean25 = periodAxis3.isMinorTickMarksVisible();
        boolean boolean26 = periodAxis3.isAxisLineVisible();
        double double27 = periodAxis3.getLowerBound();
        java.awt.Paint paint28 = periodAxis3.getTickLabelPaint();
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        logAxis2.setRangeAboutValue((double) (byte) 100, (double) 200);
        logAxis2.setInverted(false);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.LogAxis logAxis52 = new org.jfree.chart.axis.LogAxis("");
        float float53 = logAxis52.getMinorTickMarkInsideLength();
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis52.setTickLabelFont(font54);
        boolean boolean56 = logAxis52.isAutoRange();
        boolean boolean57 = logAxis52.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer58 = null;
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) logAxis52, polarItemRenderer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        polarPlot59.zoomRangeAxes((double) 2.0f, plotRenderingInfo61, point2D62);
        java.awt.Paint paint64 = polarPlot59.getNoDataMessagePaint();
        java.awt.Paint paint65 = polarPlot59.getRadiusGridlinePaint();
        java.awt.Paint paint66 = polarPlot59.getAngleLabelPaint();
        org.jfree.data.general.DatasetGroup datasetGroup67 = polarPlot59.getDatasetGroup();
        java.lang.String str68 = polarPlot59.getPlotType();
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.0f + "'", float53 == 0.0f);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNull(datasetGroup67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Polar Plot" + "'", str68.equals("Polar Plot"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) logAxis42, valueAxis44, xYItemRenderer45);
        java.awt.Paint paint47 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot46.setDomainCrosshairPaint(paint47);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator51 = null;
        xYStepAreaRenderer50.setBaseToolTipGenerator(xYToolTipGenerator51);
        java.awt.Shape shape54 = xYStepAreaRenderer50.lookupLegendShape(0);
        int int55 = xYPlot46.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer50);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.LogAxis logAxis58 = new org.jfree.chart.axis.LogAxis("");
        float float59 = logAxis58.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) logAxis58, valueAxis60, xYItemRenderer61);
        java.awt.Paint paint63 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot62.setDomainCrosshairPaint(paint63);
        xYPlot46.setRangeGridlinePaint(paint63);
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray68);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.LogAxis logAxis72 = new org.jfree.chart.axis.LogAxis("");
        float float73 = logAxis72.getMinorTickMarkInsideLength();
        java.awt.Font font74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis72.setTickLabelFont(font74);
        logAxis72.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, (org.jfree.chart.axis.ValueAxis) logAxis72, categoryItemRenderer79);
        double double82 = logAxis72.calculateLog((double) (-1.0f));
        int int83 = xYPlot46.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        int int84 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        java.util.List list85 = categoryPlot14.getCategories();
        boolean boolean86 = categoryPlot14.isOutlineVisible();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent87 = null;
        categoryPlot14.datasetChanged(datasetChangeEvent87);
        boolean boolean89 = categoryPlot14.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 0.0f + "'", float73 == 0.0f);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(list85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot3D0.getLegendItems();
        piePlot3D0.setSectionOutlinesVisible(true);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(0);
        piePlot3D0.setExplodePercent((java.lang.Comparable) year13, 3.0d);
        piePlot3D0.setStartAngle((double) 3);
        try {
            piePlot3D0.setExplodePercent((java.lang.Comparable) 1.0d, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Year cannot be cast to java.lang.Double");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getGridBandPaint();
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        standardChartTheme1.setShadowPaint(paint3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Font font3 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint5 = xYStepAreaRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        java.awt.Shape shape9 = xYStepAreaRenderer0.getItemShape((int) (byte) -1, 6, false);
        xYStepAreaRenderer0.setShapesFilled(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = periodAxis4.getFirst();
        java.awt.Stroke stroke6 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) regularTimePeriod5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        float float7 = logAxis1.getMinorTickMarkOutsideLength();
        java.awt.Paint paint8 = logAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        boolean boolean17 = xYPlot6.isDomainCrosshairVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = xYPlot6.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYStepAreaRenderer2.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer2.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape11 = xYStepAreaRenderer2.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) logAxis14, valueAxis16, xYItemRenderer17);
        java.awt.Paint paint19 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot18.setDomainCrosshairPaint(paint19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape11, paint19);
        boolean boolean22 = standardXYToolTipGenerator0.equals((java.lang.Object) shape11);
        java.text.DateFormat dateFormat23 = standardXYToolTipGenerator0.getYDateFormat();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(dateFormat23);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj52 = defaultDrawingSupplier51.clone();
        categoryPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51);
        java.awt.Paint paint54 = defaultDrawingSupplier51.getNextPaint();
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.setSeriesLinesVisible((int) ' ', true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYStepRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) "Jan");
        java.lang.Comparable comparable3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) logAxis6, valueAxis8, xYItemRenderer9);
        java.lang.Object obj11 = xYPlot10.clone();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day15, (org.jfree.data.time.RegularTimePeriod) day16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.axis.AxisState axisState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.lang.Number[][] numberArray23 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        float float28 = logAxis27.getMinorTickMarkInsideLength();
        java.awt.Font font29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis27.setTickLabelFont(font29);
        logAxis27.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) logAxis27, categoryItemRenderer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot35.getRangeAxisEdge((int) ' ');
        java.util.List list38 = periodAxis17.refreshTicks(graphics2D18, axisState19, rectangle2D20, rectangleEdge37);
        xYPlot10.drawDomainTickBands(graphics2D12, rectangle2D13, list38);
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot10.setRangeGridlinePaint(paint40);
        try {
            paintMap0.put(comparable3, paint40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        xYStepAreaRenderer1.notifyListeners(rendererChangeEvent6);
        java.awt.Paint paint9 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (short) 100);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline1.toTimelineValue(0L);
        boolean boolean5 = segmentedTimeline1.containsDomainValue((long) 7);
        long long8 = segmentedTimeline1.getExceptionSegmentCount(1L, (long) 10);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline1);
        dateAxis0.setUpperBound(1.0E-5d);
        java.awt.Font font12 = null;
        try {
            dateAxis0.setLabelFont(font12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577894400000L + "'", long3 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot22.getRangeAxisEdge((int) ' ');
        java.util.List list25 = periodAxis4.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge24);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray26 = null;
        periodAxis4.setLabelInfo(periodAxisLabelInfoArray26);
        java.lang.Class class28 = periodAxis4.getMinorTickTimePeriodClass();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) unitType0, (java.lang.Object) class28);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize(class28);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(class30);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        float float5 = logAxis4.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) logAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot8.getDomainMarkers((int) 'a', layer12);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        float float16 = logAxis15.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke17 = logAxis15.getTickMarkStroke();
        xYPlot8.setRangeGridlineStroke(stroke17);
        java.awt.Paint paint19 = xYPlot8.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint25 = standardChartTheme24.getGridBandPaint();
        xYPlot8.setRangeCrosshairPaint(paint25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        xYPlot8.setDomainAxis((int) (byte) 10, valueAxis28);
        int int30 = xYPlot8.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("Category Plot", font1, (org.jfree.chart.plot.Plot) xYPlot8, true);
        java.awt.image.BufferedImage bufferedImage35 = jFreeChart32.createBufferedImage((int) (short) 100, 1);
        java.awt.Color color36 = java.awt.Color.orange;
        int int37 = color36.getGreen();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        boolean boolean39 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color36, (java.awt.Paint) color38);
        try {
            jFreeChart32.setTextAntiAlias((java.lang.Object) color38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.Color[r=128,g=0,b=0] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(bufferedImage35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 200 + "'", int37 == 200);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("Jan");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = labelBlock2.getContentAlignmentPoint();
        boolean boolean4 = day0.equals((java.lang.Object) labelBlock2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.util.Date date3 = year1.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        java.util.Date date7 = year5.getEnd();
        org.jfree.data.time.DateRange dateRange8 = new org.jfree.data.time.DateRange(date3, date7);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        java.awt.Stroke stroke23 = categoryPlot22.getOutlineStroke();
        xYStepAreaRenderer1.setBaseStroke(stroke23, false);
        xYStepAreaRenderer1.setShapesVisible(true);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape28, "Pie 3D Plot");
        xYStepAreaRenderer1.setBaseShape(shape28);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation33 = null;
        boolean boolean34 = xYStepAreaRenderer32.removeAnnotation(xYAnnotation33);
        java.awt.Font font35 = xYStepAreaRenderer32.getBaseItemLabelFont();
        java.awt.Paint paint37 = xYStepAreaRenderer32.getSeriesOutlinePaint((int) (byte) 100);
        org.jfree.chart.StandardChartTheme standardChartTheme40 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint41 = standardChartTheme40.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.LogAxis logAxis44 = new org.jfree.chart.axis.LogAxis("");
        float float45 = logAxis44.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) logAxis44, valueAxis46, xYItemRenderer47);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot48.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = xYPlot48.getRenderer();
        java.awt.Paint paint52 = xYPlot48.getRangeGridlinePaint();
        standardChartTheme40.setTickLabelPaint(paint52);
        xYStepAreaRenderer32.setSeriesPaint((int) (byte) 1, paint52);
        xYStepAreaRenderer1.setBaseFillPaint(paint52, true);
        java.awt.Font font60 = xYStepAreaRenderer1.getItemLabelFont(10, (int) '#', false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer1.setBasePositiveItemLabelPosition(itemLabelPosition61);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNull(xYItemRenderer51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(font60);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        float float5 = logAxis4.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) logAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot8.getDomainMarkers((int) 'a', layer12);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        float float16 = logAxis15.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke17 = logAxis15.getTickMarkStroke();
        xYPlot8.setRangeGridlineStroke(stroke17);
        java.awt.Paint paint19 = xYPlot8.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint25 = standardChartTheme24.getGridBandPaint();
        xYPlot8.setRangeCrosshairPaint(paint25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        xYPlot8.setDomainAxis((int) (byte) 10, valueAxis28);
        int int30 = xYPlot8.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("Category Plot", font1, (org.jfree.chart.plot.Plot) xYPlot8, true);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int34 = color33.getBlue();
        jFreeChart32.setBackgroundPaint((java.awt.Paint) color33);
        jFreeChart32.setAntiAlias(false);
        float float38 = jFreeChart32.getBackgroundImageAlpha();
        jFreeChart32.setNotify(false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 128 + "'", int34 == 128);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.5f + "'", float38 == 0.5f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        float float8 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) logAxis7, valueAxis9, xYItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot11.setDomainCrosshairPaint(paint12);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        xYStepAreaRenderer15.setBaseToolTipGenerator(xYToolTipGenerator16);
        java.awt.Shape shape19 = xYStepAreaRenderer15.lookupLegendShape(0);
        int int20 = xYPlot11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer15);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) logAxis23, valueAxis25, xYItemRenderer26);
        java.awt.Paint paint28 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot27.setDomainCrosshairPaint(paint28);
        xYPlot11.setRangeGridlinePaint(paint28);
        piePlot3D0.setLabelLinkPaint(paint28);
        double double32 = piePlot3D0.getShadowXOffset();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 4.0d + "'", double32 == 4.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        xYPlot6.mapDatasetToRangeAxis((int) '#', 0);
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        boolean boolean25 = logAxis23.isAxisLineVisible();
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis32.setTickLabelFont(font34);
        logAxis32.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) logAxis32, categoryItemRenderer39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot40.getRangeAxis();
        logAxis23.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot40);
        categoryPlot40.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray45 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot40.setRenderers(categoryItemRendererArray45);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition55 = xYStepAreaRenderer51.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator56 = null;
        xYStepAreaRenderer51.setLegendItemURLGenerator(xYSeriesLabelGenerator56);
        java.lang.Number[][] numberArray60 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset61 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray60);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        org.jfree.chart.axis.LogAxis logAxis64 = new org.jfree.chart.axis.LogAxis("");
        float float65 = logAxis64.getMinorTickMarkInsideLength();
        java.awt.Font font66 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis64.setTickLabelFont(font66);
        logAxis64.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, (org.jfree.chart.axis.ValueAxis) logAxis64, categoryItemRenderer71);
        java.awt.Stroke stroke73 = categoryPlot72.getOutlineStroke();
        xYStepAreaRenderer51.setBaseStroke(stroke73, false);
        xYStepAreaRenderer51.setShapesVisible(true);
        java.awt.Paint paint78 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer51.setBaseOutlinePaint(paint78);
        org.jfree.chart.plot.PiePlot3D piePlot3D80 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double82 = rectangleInsets81.getRight();
        java.lang.String str83 = rectangleInsets81.toString();
        piePlot3D80.setSimpleLabelOffset(rectangleInsets81);
        java.awt.Stroke stroke85 = piePlot3D80.getBaseSectionOutlineStroke();
        java.awt.Paint paint86 = null;
        java.awt.Stroke stroke87 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker89 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint78, stroke85, paint86, stroke87, (float) (byte) 1);
        org.jfree.chart.util.Layer layer90 = null;
        boolean boolean91 = categoryPlot40.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker89, layer90);
        java.lang.String str92 = intervalMarker89.getLabel();
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addRangeMarker(10, (org.jfree.chart.plot.Marker) intervalMarker89, layer93);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType95 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        intervalMarker89.setLabelOffsetType(lengthAdjustmentType95);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(valueAxis41);
        org.junit.Assert.assertNotNull(categoryItemRendererArray45);
        org.junit.Assert.assertNotNull(itemLabelPosition55);
        org.junit.Assert.assertNotNull(numberArray60);
        org.junit.Assert.assertNotNull(categoryDataset61);
        org.junit.Assert.assertTrue("'" + float65 + "' != '" + 0.0f + "'", float65 == 0.0f);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(rectangleInsets81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.0d + "'", double82 == 1.0d);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str83.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(str92);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertNotNull(lengthAdjustmentType95);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot6.getRenderer();
        java.awt.Paint paint10 = xYPlot6.getRangeGridlinePaint();
        java.awt.Image image11 = xYPlot6.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(image11);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.awt.Paint paint8 = piePlot3D0.getSectionPaint((java.lang.Comparable) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double5 = categoryAxis0.getCategoryEnd(5, 10, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("gray", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) logAxis18, valueAxis20, xYItemRenderer21);
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot22.setDomainCrosshairPaint(paint23);
        xYPlot6.setRangeGridlinePaint(paint23);
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis32.setTickLabelFont(font34);
        logAxis32.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) logAxis32, categoryItemRenderer39);
        double double42 = logAxis32.calculateLog((double) (-1.0f));
        int int43 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis32);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        legendTitle44.setVisible(false);
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement48 = blockContainer47.getArrangement();
        org.jfree.data.xy.XYSeries xYSeries52 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection53 = new org.jfree.data.xy.XYSeriesCollection(xYSeries52);
        org.jfree.data.general.DatasetGroup datasetGroup54 = xYSeriesCollection53.getGroup();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer56 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement48, (org.jfree.data.general.Dataset) xYSeriesCollection53, (java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable57 = legendItemBlockContainer56.getSeriesKey();
        legendTitle44.setWrapper((org.jfree.chart.block.BlockContainer) legendItemBlockContainer56);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(arrangement48);
        org.junit.Assert.assertNotNull(datasetGroup54);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + (short) -1 + "'", comparable57.equals((short) -1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        try {
            java.lang.Number number2 = numberFormat0.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"hi!\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeStickyZero(false);
        numberAxis0.resizeRange((double) 255);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline1.toTimelineValue(0L);
        boolean boolean5 = segmentedTimeline1.containsDomainValue((long) 7);
        long long8 = segmentedTimeline1.getExceptionSegmentCount(1L, (long) 10);
        dateAxis0.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline1);
        boolean boolean11 = dateAxis0.isHiddenValue((long) '4');
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType12 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType12, (int) '4');
        java.util.Date date15 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit14);
        java.lang.String str17 = dateTickUnit14.valueToString(0.0d);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577894400000L + "'", long3 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTickUnitType12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "12/31/69" + "'", str17.equals("12/31/69"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("UnitType.ABSOLUTE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint3 = standardChartTheme1.getBaselinePaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer5.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape14 = xYStepAreaRenderer5.lookupSeriesShape(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        boolean boolean16 = xYStepAreaRenderer5.removeAnnotation(xYAnnotation15);
        xYStepAreaRenderer5.setBaseCreateEntities(false, false);
        int int20 = xYStepAreaRenderer5.getPassCount();
        java.awt.Paint paint21 = xYStepAreaRenderer5.getBasePaint();
        standardChartTheme1.setPlotOutlinePaint(paint21);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 500, (double) 200, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.awt.Paint paint15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        logAxis6.setTickMarkPaint(paint15);
        logAxis6.configure();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        boolean boolean6 = xYStepAreaRenderer1.getAutoPopulateSeriesStroke();
        xYStepAreaRenderer1.setBaseSeriesVisibleInLegend(false);
        java.awt.Paint paint10 = xYStepAreaRenderer1.getSeriesPaint(2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) str1, true);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("");
        float float9 = logAxis8.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) logAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot12.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot12.getDomainMarkers((int) 'a', layer16);
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        float float20 = logAxis19.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke21 = logAxis19.getTickMarkStroke();
        xYPlot12.setRangeGridlineStroke(stroke21);
        java.awt.Paint paint23 = xYPlot12.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot12.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer25);
        org.jfree.chart.StandardChartTheme standardChartTheme28 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint29 = standardChartTheme28.getGridBandPaint();
        xYPlot12.setRangeCrosshairPaint(paint29);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        xYPlot12.setDomainAxis((int) (byte) 10, valueAxis32);
        int int34 = xYPlot12.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("Category Plot", font5, (org.jfree.chart.plot.Plot) xYPlot12, true);
        java.awt.image.BufferedImage bufferedImage39 = jFreeChart36.createBufferedImage((int) (short) 100, 1);
        rendererChangeEvent3.setChart(jFreeChart36);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str1.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(bufferedImage39);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot3D0.getLegendItems();
        piePlot3D0.setSectionOutlinesVisible(true);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(0);
        piePlot3D0.setExplodePercent((java.lang.Comparable) year13, 3.0d);
        piePlot3D0.setStartAngle((double) 3);
        java.awt.Font font18 = piePlot3D0.getLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline0.toTimelineValue(0L);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) 7);
        long long7 = segmentedTimeline0.getExceptionSegmentCount(1L, (long) 10);
        long long9 = segmentedTimeline0.toTimelineValue(1577894400000L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = segmentedTimeline0.getBaseTimeline();
        try {
            long long11 = segmentedTimeline10.getSegmentsIncludedSize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577894400000L + "'", long2 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2704953600000L + "'", long9 == 2704953600000L);
        org.junit.Assert.assertNull(segmentedTimeline10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        xYPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot6.getRangeAxisLocation(6);
        try {
            java.awt.Paint paint20 = xYPlot6.getQuadrantPaint((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        long long1 = dateRange0.getUpperMillis();
        double double3 = dateRange0.constrain((double) 6);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.LogAxis logAxis52 = new org.jfree.chart.axis.LogAxis("");
        float float53 = logAxis52.getMinorTickMarkInsideLength();
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis52.setTickLabelFont(font54);
        boolean boolean56 = logAxis52.isAutoRange();
        boolean boolean57 = logAxis52.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer58 = null;
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) logAxis52, polarItemRenderer58);
        double double60 = polarPlot59.getMaxRadius();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier61 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape62 = defaultDrawingSupplier61.getNextShape();
        polarPlot59.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier61);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.0f + "'", float53 == 0.0f);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.258925411794167d + "'", double60 == 1.258925411794167d);
        org.junit.Assert.assertNotNull(shape62);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 'a', "NOID", "", true);
        java.text.ParsePosition parsePosition6 = null;
        java.lang.Object obj7 = logFormat4.parseObject("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", parsePosition6);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double10 = rectangleInsets9.getRight();
        java.lang.String str11 = rectangleInsets9.toString();
        java.lang.String str12 = rectangleInsets9.toString();
        double double13 = rectangleInsets9.getLeft();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets9);
        double double15 = piePlot3D0.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator22 = null;
        xYStepAreaRenderer21.setBaseToolTipGenerator(xYToolTipGenerator22);
        java.awt.Shape shape25 = xYStepAreaRenderer21.lookupLegendShape(0);
        int int26 = xYPlot17.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) logAxis29, valueAxis31, xYItemRenderer32);
        java.awt.Paint paint34 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot33.setDomainCrosshairPaint(paint34);
        xYPlot17.setRangeGridlinePaint(paint34);
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.LogAxis logAxis43 = new org.jfree.chart.axis.LogAxis("");
        float float44 = logAxis43.getMinorTickMarkInsideLength();
        java.awt.Font font45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis43.setTickLabelFont(font45);
        logAxis43.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) logAxis43, categoryItemRenderer50);
        double double53 = logAxis43.calculateLog((double) (-1.0f));
        int int54 = xYPlot17.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis43);
        xYPlot6.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) logAxis43, false);
        org.jfree.data.xy.XYDataset xYDataset57 = xYPlot6.getDataset();
        org.jfree.data.xy.XYDataset xYDataset58 = null;
        org.jfree.chart.axis.LogAxis logAxis60 = new org.jfree.chart.axis.LogAxis("");
        float float61 = logAxis60.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset58, (org.jfree.chart.axis.ValueAxis) logAxis60, valueAxis62, xYItemRenderer63);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot64.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = xYPlot64.getRenderer();
        java.awt.Paint paint68 = xYPlot64.getRangeGridlinePaint();
        xYPlot6.setRangeZeroBaselinePaint(paint68);
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        xYPlot6.setRangeAxis(valueAxis70);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNull(xYDataset57);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 0.0f + "'", float61 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertNull(xYItemRenderer67);
        org.junit.Assert.assertNotNull(paint68);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot6.getRenderer();
        java.awt.Paint paint10 = xYPlot6.getRangeGridlinePaint();
        xYPlot6.setDomainCrosshairLockedOnData(false);
        xYPlot6.setRangePannable(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot6.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        logAxis1.pan(0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("ClassContext", "UnitType.ABSOLUTE");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis0.setMarkerBand(markerAxisBand2);
        java.awt.Shape shape4 = numberAxis0.getRightArrow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double4 = xYSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        xYSeries3.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        double double9 = timeSeriesCollection6.getDomainLowerBound(false);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = null;
        timeSeriesCollection6.seriesChanged(seriesChangeEvent10);
        try {
            timeSeriesCollection6.setSelected(2147483647, (int) (byte) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (2147483647).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) '4');
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (-1), dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.lang.Object obj7 = xYPlot6.clone();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis13 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day11, (org.jfree.data.time.RegularTimePeriod) day12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis23.setTickLabelFont(font25);
        logAxis23.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) logAxis23, categoryItemRenderer30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot31.getRangeAxisEdge((int) ' ');
        java.util.List list34 = periodAxis13.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge33);
        xYPlot6.drawDomainTickBands(graphics2D8, rectangle2D9, list34);
        java.awt.Paint paint36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot6.setRangeGridlinePaint(paint36);
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker(8.0d, 0.0d);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker40);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainUpperBound(true);
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) logAxis21, valueAxis23, xYItemRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot25.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot25.getDomainMarkers((int) 'a', layer29);
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke34 = logAxis32.getTickMarkStroke();
        xYPlot25.setRangeGridlineStroke(stroke34);
        categoryPlot18.setDomainCrosshairStroke(stroke34);
        org.jfree.chart.axis.LogAxis logAxis38 = new org.jfree.chart.axis.LogAxis("");
        float float39 = logAxis38.getMinorTickMarkInsideLength();
        java.awt.Font font40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis38.setTickLabelFont(font40);
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = logAxis38.getStandardTickUnits();
        int int43 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis38);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("");
        float float47 = logAxis46.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) logAxis46, valueAxis48, xYItemRenderer49);
        java.awt.Paint paint51 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot50.setDomainCrosshairPaint(paint51);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator55 = null;
        xYStepAreaRenderer54.setBaseToolTipGenerator(xYToolTipGenerator55);
        java.awt.Shape shape58 = xYStepAreaRenderer54.lookupLegendShape(0);
        int int59 = xYPlot50.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer54);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.LogAxis logAxis62 = new org.jfree.chart.axis.LogAxis("");
        float float63 = logAxis62.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) logAxis62, valueAxis64, xYItemRenderer65);
        java.awt.Paint paint67 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot66.setDomainCrosshairPaint(paint67);
        xYPlot50.setRangeGridlinePaint(paint67);
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray72);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = null;
        org.jfree.chart.axis.LogAxis logAxis76 = new org.jfree.chart.axis.LogAxis("");
        float float77 = logAxis76.getMinorTickMarkInsideLength();
        java.awt.Font font78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis76.setTickLabelFont(font78);
        logAxis76.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer83 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, (org.jfree.chart.axis.ValueAxis) logAxis76, categoryItemRenderer83);
        double double86 = logAxis76.calculateLog((double) (-1.0f));
        int int87 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
        int int88 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
        java.util.List list89 = categoryPlot18.getCategories();
        org.jfree.data.time.DateRange dateRange90 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range92 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list89, (org.jfree.data.Range) dateRange90, false);
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeriesCollection1.getSeries((java.lang.Comparable) ' ');
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 0.0f + "'", float63 == 0.0f);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.0f + "'", float77 == 0.0f);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertNotNull(list89);
        org.junit.Assert.assertNotNull(dateRange90);
        org.junit.Assert.assertNull(range92);
        org.junit.Assert.assertNull(timeSeries94);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = xYSeriesCollection4.getRangeBounds(false);
        int int7 = xYSeriesCollection4.getSeriesCount();
        org.jfree.data.time.TimeSeries timeSeries8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeSeries8);
        double double11 = timeSeriesCollection9.getDomainUpperBound(true);
        boolean boolean12 = xYSeriesCollection4.hasListener((java.util.EventListener) timeSeriesCollection9);
        try {
            int int16 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) xYSeriesCollection4, 0, (double) 'a', (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter(0.0d, 100.0d, (double) 1L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long4 = segmentedTimeline2.toTimelineValue(0L);
        boolean boolean6 = segmentedTimeline2.containsDomainValue((long) 7);
        long long9 = segmentedTimeline2.getExceptionSegmentCount(1L, (long) 10);
        dateAxis1.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline2);
        dateAxis1.setUpperBound(1.0E-5d);
        boolean boolean13 = categoryAxis0.equals((java.lang.Object) 1.0E-5d);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577894400000L + "'", long4 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getRangeAxisEdge((int) ' ');
        java.util.List list24 = periodAxis3.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge23);
        boolean boolean25 = periodAxis3.isMinorTickMarksVisible();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis31);
        org.jfree.chart.entity.EntityCollection entityCollection34 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = new org.jfree.chart.ChartRenderingInfo(entityCollection34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = chartRenderingInfo35.getPlotInfo();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.LogAxis logAxis39 = new org.jfree.chart.axis.LogAxis("");
        float float40 = logAxis39.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset37, (org.jfree.chart.axis.ValueAxis) logAxis39, valueAxis41, xYItemRenderer42);
        java.awt.Paint paint44 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot43.setDomainCrosshairPaint(paint44);
        java.awt.geom.Point2D point2D46 = xYPlot43.getQuadrantOrigin();
        combinedRangeXYPlot32.zoomDomainAxes((double) 4, plotRenderingInfo36, point2D46, true);
        try {
            org.jfree.chart.axis.AxisState axisState49 = periodAxis3.draw(graphics2D26, (double) (short) 100, rectangle2D28, rectangle2D29, rectangleEdge30, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(plotRenderingInfo36);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 0.0f + "'", float40 == 0.0f);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        double double2 = axisSpace0.getRight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = chartRenderingInfo1.getPlotInfo();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot9.setDomainCrosshairPaint(paint10);
        java.awt.geom.Point2D point2D12 = xYPlot9.getQuadrantOrigin();
        int int13 = plotRenderingInfo2.getSubplotIndex(point2D12);
        org.junit.Assert.assertNotNull(plotRenderingInfo2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        boolean boolean4 = xYStepAreaRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepAreaRenderer1.setBaseOutlineStroke(stroke5, false);
        boolean boolean9 = xYStepAreaRenderer1.isSeriesVisible(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        java.awt.Color color36 = java.awt.Color.CYAN;
        categoryPlot14.setRangeMinorGridlinePaint((java.awt.Paint) color36);
        categoryPlot14.setRangePannable(true);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        try {
            java.lang.Comparable comparable52 = xYSeriesCollection4.getSeriesKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer22.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
        xYStepAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator27);
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis35.setTickLabelFont(font37);
        logAxis35.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) logAxis35, categoryItemRenderer42);
        java.awt.Stroke stroke44 = categoryPlot43.getOutlineStroke();
        xYStepAreaRenderer22.setBaseStroke(stroke44, false);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) xYStepAreaRenderer22);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis51 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) day50);
        boolean boolean52 = categoryPlot18.equals((java.lang.Object) "ThreadContext");
        java.awt.Color color53 = java.awt.Color.magenta;
        categoryPlot18.setRangeZeroBaselinePaint((java.awt.Paint) color53);
        java.awt.color.ColorSpace colorSpace55 = null;
        float[] floatArray60 = new float[] { (short) 100, 100.0f, 'a', 2704953600000L };
        try {
            float[] floatArray61 = color53.getComponents(colorSpace55, floatArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(floatArray60);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("�");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name �, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        categoryPlot18.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepAreaRenderer29.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator34 = null;
        xYStepAreaRenderer29.setLegendItemURLGenerator(xYSeriesLabelGenerator34);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        java.awt.Stroke stroke51 = categoryPlot50.getOutlineStroke();
        xYStepAreaRenderer29.setBaseStroke(stroke51, false);
        xYStepAreaRenderer29.setShapesVisible(true);
        java.awt.Paint paint56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer29.setBaseOutlinePaint(paint56);
        org.jfree.chart.plot.PiePlot3D piePlot3D58 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double60 = rectangleInsets59.getRight();
        java.lang.String str61 = rectangleInsets59.toString();
        piePlot3D58.setSimpleLabelOffset(rectangleInsets59);
        java.awt.Stroke stroke63 = piePlot3D58.getBaseSectionOutlineStroke();
        java.awt.Paint paint64 = null;
        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker67 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint56, stroke63, paint64, stroke65, (float) (byte) 1);
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean69 = categoryPlot18.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker67, layer68);
        float float70 = intervalMarker67.getAlpha();
        double double71 = intervalMarker67.getEndValue();
        java.lang.String str72 = intervalMarker67.getLabel();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str61.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 200.0d + "'", double71 == 200.0d);
        org.junit.Assert.assertNull(str72);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) logAxis42, valueAxis44, xYItemRenderer45);
        java.awt.Paint paint47 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot46.setDomainCrosshairPaint(paint47);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator51 = null;
        xYStepAreaRenderer50.setBaseToolTipGenerator(xYToolTipGenerator51);
        java.awt.Shape shape54 = xYStepAreaRenderer50.lookupLegendShape(0);
        int int55 = xYPlot46.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer50);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.LogAxis logAxis58 = new org.jfree.chart.axis.LogAxis("");
        float float59 = logAxis58.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) logAxis58, valueAxis60, xYItemRenderer61);
        java.awt.Paint paint63 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot62.setDomainCrosshairPaint(paint63);
        xYPlot46.setRangeGridlinePaint(paint63);
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray68);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.LogAxis logAxis72 = new org.jfree.chart.axis.LogAxis("");
        float float73 = logAxis72.getMinorTickMarkInsideLength();
        java.awt.Font font74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis72.setTickLabelFont(font74);
        logAxis72.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, (org.jfree.chart.axis.ValueAxis) logAxis72, categoryItemRenderer79);
        double double82 = logAxis72.calculateLog((double) (-1.0f));
        int int83 = xYPlot46.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        int int84 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        java.awt.Paint paint85 = categoryPlot14.getRangeZeroBaselinePaint();
        categoryPlot14.clearAnnotations();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 0.0f + "'", float73 == 0.0f);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(paint85);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        java.lang.String str41 = categoryItemEntity40.getShapeCoords();
        java.lang.Class<?> wildcardClass42 = categoryItemEntity40.getClass();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "-3,-3,3,3" + "'", str41.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        xYPlot6.mapDatasetToRangeAxis((int) '#', 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot6.getRangeMarkers(layer21);
        org.jfree.chart.plot.PiePlot3D piePlot3D23 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double25 = rectangleInsets24.getRight();
        java.lang.String str26 = rectangleInsets24.toString();
        piePlot3D23.setSimpleLabelOffset(rectangleInsets24);
        java.awt.Stroke stroke28 = piePlot3D23.getBaseSectionOutlineStroke();
        piePlot3D23.setDarkerSides(false);
        java.awt.Paint paint31 = piePlot3D23.getShadowPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = piePlot3D23.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = piePlot3D23.getSimpleLabelOffset();
        xYPlot6.setInsets(rectangleInsets33, true);
        xYPlot6.clearDomainMarkers(0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str26.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        xYPlot6.clearRangeMarkers(1);
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot6.getDomainAxisLocation();
        java.awt.Paint paint19 = xYPlot6.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot9.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getDomainMarkers((int) 'a', layer13);
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke18 = logAxis16.getTickMarkStroke();
        xYPlot9.setRangeGridlineStroke(stroke18);
        java.awt.Paint paint20 = xYPlot9.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot9.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer22);
        org.jfree.chart.StandardChartTheme standardChartTheme25 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint26 = standardChartTheme25.getGridBandPaint();
        xYPlot9.setRangeCrosshairPaint(paint26);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        xYPlot9.setDomainAxis((int) (byte) 10, valueAxis29);
        int int31 = xYPlot9.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart("Category Plot", font2, (org.jfree.chart.plot.Plot) xYPlot9, true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = xYStepAreaRenderer35.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer35.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape44 = xYStepAreaRenderer35.lookupSeriesShape(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation45 = null;
        boolean boolean46 = xYStepAreaRenderer35.removeAnnotation(xYAnnotation45);
        xYStepAreaRenderer35.setBaseCreateEntities(false, false);
        int int50 = xYStepAreaRenderer35.getPassCount();
        java.awt.Paint paint51 = xYStepAreaRenderer35.getBasePaint();
        org.jfree.chart.text.TextLine textLine52 = new org.jfree.chart.text.TextLine("DomainOrder.NONE", font2, paint51);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.text.TextAnchor textAnchor56 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            textLine52.draw(graphics2D53, (float) 255, (float) (byte) 0, textAnchor56, (float) 0L, 1.0f, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(textAnchor56);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getRight();
        java.lang.String str5 = rectangleInsets3.toString();
        piePlot3D2.setSimpleLabelOffset(rectangleInsets3);
        java.awt.Stroke stroke7 = piePlot3D2.getBaseSectionOutlineStroke();
        java.lang.Object obj8 = null;
        boolean boolean9 = piePlot3D2.equals(obj8);
        piePlot3D2.setAutoPopulateSectionPaint(true);
        piePlot3D2.setIgnoreZeroValues(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYStepAreaRenderer15.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer15.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape24 = xYStepAreaRenderer15.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        float float28 = logAxis27.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) logAxis27, valueAxis29, xYItemRenderer30);
        java.awt.Paint paint32 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape24, paint32);
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.LogAxis logAxis43 = new org.jfree.chart.axis.LogAxis("");
        float float44 = logAxis43.getMinorTickMarkInsideLength();
        java.awt.Font font45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis43.setTickLabelFont(font45);
        logAxis43.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) logAxis43, categoryItemRenderer50);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset40, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset40, 2147483647);
        piePlot3D2.setDataset(pieDataset56);
        java.text.AttributedString attributedString59 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset56, (java.lang.Comparable) 12);
        org.jfree.chart.plot.RingPlot ringPlot60 = new org.jfree.chart.plot.RingPlot(pieDataset56);
        double double61 = ringPlot60.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(pieDataset56);
        org.junit.Assert.assertNull(attributedString59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.2d + "'", double61 == 0.2d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double4 = xYSeries3.getMaxY();
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries3.addOrUpdate((java.lang.Number) 86400000L, (java.lang.Number) 0L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        categoryPlot18.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepAreaRenderer29.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator34 = null;
        xYStepAreaRenderer29.setLegendItemURLGenerator(xYSeriesLabelGenerator34);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        java.awt.Stroke stroke51 = categoryPlot50.getOutlineStroke();
        xYStepAreaRenderer29.setBaseStroke(stroke51, false);
        xYStepAreaRenderer29.setShapesVisible(true);
        java.awt.Paint paint56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer29.setBaseOutlinePaint(paint56);
        org.jfree.chart.plot.PiePlot3D piePlot3D58 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double60 = rectangleInsets59.getRight();
        java.lang.String str61 = rectangleInsets59.toString();
        piePlot3D58.setSimpleLabelOffset(rectangleInsets59);
        java.awt.Stroke stroke63 = piePlot3D58.getBaseSectionOutlineStroke();
        java.awt.Paint paint64 = null;
        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker67 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint56, stroke63, paint64, stroke65, (float) (byte) 1);
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean69 = categoryPlot18.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker67, layer68);
        categoryPlot18.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str61.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getRight();
        java.lang.String str5 = rectangleInsets3.toString();
        piePlot3D2.setSimpleLabelOffset(rectangleInsets3);
        java.awt.Stroke stroke7 = piePlot3D2.getBaseSectionOutlineStroke();
        java.lang.Object obj8 = null;
        boolean boolean9 = piePlot3D2.equals(obj8);
        piePlot3D2.setAutoPopulateSectionPaint(true);
        piePlot3D2.setIgnoreZeroValues(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYStepAreaRenderer15.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer15.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape24 = xYStepAreaRenderer15.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        float float28 = logAxis27.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) logAxis27, valueAxis29, xYItemRenderer30);
        java.awt.Paint paint32 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape24, paint32);
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.LogAxis logAxis43 = new org.jfree.chart.axis.LogAxis("");
        float float44 = logAxis43.getMinorTickMarkInsideLength();
        java.awt.Font font45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis43.setTickLabelFont(font45);
        logAxis43.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) logAxis43, categoryItemRenderer50);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset40, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset40, 2147483647);
        piePlot3D2.setDataset(pieDataset56);
        java.text.AttributedString attributedString59 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset56, (java.lang.Comparable) 12);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset60 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) pieDataset56);
        try {
            defaultPieDataset60.remove((java.lang.Comparable) 3600000L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (3600000) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(pieDataset56);
        org.junit.Assert.assertNull(attributedString59);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection9, true);
        int[] intArray15 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) xYSeriesCollection9, 0, (double) (byte) 0, (double) 1);
        java.lang.Object obj16 = xYSeriesCollection9.clone();
        try {
            java.lang.String str19 = standardXYToolTipGenerator3.generateLabelString((org.jfree.data.xy.XYDataset) xYSeriesCollection9, (int) '4', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis3.getFirst();
        periodAxis3.setLabel("Jan");
        java.lang.Class class7 = periodAxis3.getMinorTickTimePeriodClass();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.awt.Shape shape21 = legendGraphic20.getLine();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(shape21);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0.0f, "", "hi!", false);
        logFormat4.setMinimumIntegerDigits((int) '4');
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("");
        float float9 = logAxis8.getMinorTickMarkInsideLength();
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis8.setTickLabelFont(font10);
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = logAxis8.getStandardTickUnits();
        java.text.NumberFormat numberFormat13 = java.text.NumberFormat.getIntegerInstance();
        numberFormat13.setMaximumFractionDigits(1);
        logAxis8.setNumberFormatOverride(numberFormat13);
        logFormat4.setExponentFormat(numberFormat13);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(tickUnitSource12);
        org.junit.Assert.assertNotNull(numberFormat13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot3D0.getLegendItems();
        piePlot3D0.setSectionOutlinesVisible(true);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(0);
        piePlot3D0.setExplodePercent((java.lang.Comparable) year13, 3.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year13.previous();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getRight();
        java.lang.String str5 = rectangleInsets3.toString();
        piePlot3D2.setSimpleLabelOffset(rectangleInsets3);
        java.awt.Stroke stroke7 = piePlot3D2.getBaseSectionOutlineStroke();
        java.lang.Object obj8 = null;
        boolean boolean9 = piePlot3D2.equals(obj8);
        piePlot3D2.setAutoPopulateSectionPaint(true);
        piePlot3D2.setIgnoreZeroValues(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYStepAreaRenderer15.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer15.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape24 = xYStepAreaRenderer15.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        float float28 = logAxis27.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) logAxis27, valueAxis29, xYItemRenderer30);
        java.awt.Paint paint32 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape24, paint32);
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.LogAxis logAxis43 = new org.jfree.chart.axis.LogAxis("");
        float float44 = logAxis43.getMinorTickMarkInsideLength();
        java.awt.Font font45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis43.setTickLabelFont(font45);
        logAxis43.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) logAxis43, categoryItemRenderer50);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset40, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset40, 2147483647);
        piePlot3D2.setDataset(pieDataset56);
        java.text.AttributedString attributedString59 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset56, (java.lang.Comparable) 12);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset60 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) pieDataset56);
        java.lang.Object obj61 = defaultPieDataset60.clone();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(pieDataset56);
        org.junit.Assert.assertNull(attributedString59);
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYStepAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator8);
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis16.setTickLabelFont(font18);
        logAxis16.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getOutlineStroke();
        xYStepAreaRenderer3.setBaseStroke(stroke25, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = null;
        xYStepAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator28, true);
        combinedRangeXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer3);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = combinedRangeXYPlot1.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = piePlot3D0.getLegendItems();
        piePlot3D0.setIgnoreNullValues(false);
        double double8 = piePlot3D0.getShadowXOffset();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        float float5 = logAxis4.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) logAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot8.getDomainMarkers((int) 'a', layer12);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        float float16 = logAxis15.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke17 = logAxis15.getTickMarkStroke();
        xYPlot8.setRangeGridlineStroke(stroke17);
        java.awt.Paint paint19 = xYPlot8.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint25 = standardChartTheme24.getGridBandPaint();
        xYPlot8.setRangeCrosshairPaint(paint25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        xYPlot8.setDomainAxis((int) (byte) 10, valueAxis28);
        int int30 = xYPlot8.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("Category Plot", font1, (org.jfree.chart.plot.Plot) xYPlot8, true);
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        try {
            java.awt.image.BufferedImage bufferedImage37 = jFreeChart32.createBufferedImage(15, (-1), chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (15) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.LogAxis logAxis52 = new org.jfree.chart.axis.LogAxis("");
        float float53 = logAxis52.getMinorTickMarkInsideLength();
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis52.setTickLabelFont(font54);
        boolean boolean56 = logAxis52.isAutoRange();
        boolean boolean57 = logAxis52.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer58 = null;
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) logAxis52, polarItemRenderer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        polarPlot59.zoomRangeAxes((double) 2.0f, plotRenderingInfo61, point2D62);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        java.awt.geom.Point2D point2D67 = null;
        polarPlot59.zoomRangeAxes(0.0d, (double) (short) 10, plotRenderingInfo66, point2D67);
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str70 = axisLocation69.toString();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent72 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) str70, true);
        polarPlot59.rendererChanged(rendererChangeEvent72);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.0f + "'", float53 == 0.0f);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str70.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) logAxis42, valueAxis44, xYItemRenderer45);
        java.awt.Paint paint47 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot46.setDomainCrosshairPaint(paint47);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator51 = null;
        xYStepAreaRenderer50.setBaseToolTipGenerator(xYToolTipGenerator51);
        java.awt.Shape shape54 = xYStepAreaRenderer50.lookupLegendShape(0);
        int int55 = xYPlot46.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer50);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.LogAxis logAxis58 = new org.jfree.chart.axis.LogAxis("");
        float float59 = logAxis58.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) logAxis58, valueAxis60, xYItemRenderer61);
        java.awt.Paint paint63 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot62.setDomainCrosshairPaint(paint63);
        xYPlot46.setRangeGridlinePaint(paint63);
        java.lang.Number[][] numberArray68 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray68);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.LogAxis logAxis72 = new org.jfree.chart.axis.LogAxis("");
        float float73 = logAxis72.getMinorTickMarkInsideLength();
        java.awt.Font font74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis72.setTickLabelFont(font74);
        logAxis72.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, categoryAxis70, (org.jfree.chart.axis.ValueAxis) logAxis72, categoryItemRenderer79);
        double double82 = logAxis72.calculateLog((double) (-1.0f));
        int int83 = xYPlot46.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        int int84 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis72);
        java.awt.Paint paint85 = categoryPlot14.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(numberArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 0.0f + "'", float73 == 0.0f);
        org.junit.Assert.assertNotNull(font74);
        org.junit.Assert.assertEquals((double) double82, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(paint85);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6, false);
        xYSeriesCollection6.removeAllSeries();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        float float13 = logAxis12.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) logAxis12, valueAxis14, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = xYPlot16.getDomainMarkers((int) 'a', layer20);
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke25 = logAxis23.getTickMarkStroke();
        xYPlot16.setRangeGridlineStroke(stroke25);
        java.awt.Paint paint27 = xYPlot16.getDomainCrosshairPaint();
        boolean boolean28 = xYSeriesCollection6.hasListener((java.util.EventListener) xYPlot16);
        boolean boolean29 = xYPlot16.isNotify();
        xYPlot16.clearAnnotations();
        combinedRangeXYPlot1.add(xYPlot16);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        periodAxis3.setLabelFont(font4);
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        float float13 = logAxis12.getMinorTickMarkInsideLength();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis12.setTickLabelFont(font14);
        logAxis12.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) logAxis12, categoryItemRenderer19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) logAxis23, valueAxis25, xYItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot27.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getDomainMarkers((int) 'a', layer31);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke36 = logAxis34.getTickMarkStroke();
        xYPlot27.setRangeGridlineStroke(stroke36);
        categoryPlot20.setDomainCrosshairStroke(stroke36);
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("");
        float float41 = logAxis40.getMinorTickMarkInsideLength();
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis40.setTickLabelFont(font42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = logAxis40.getStandardTickUnits();
        int int45 = categoryPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis40);
        categoryPlot20.setDrawSharedDomainAxis(false);
        boolean boolean48 = periodAxis3.hasListener((java.util.EventListener) categoryPlot20);
        java.awt.Paint paint49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot20.setDomainCrosshairPaint(paint49);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        java.awt.Paint paint40 = logAxis34.getTickLabelPaint();
        float float41 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.LogAxis logAxis50 = new org.jfree.chart.axis.LogAxis("");
        float float51 = logAxis50.getMinorTickMarkInsideLength();
        java.awt.Font font52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis50.setTickLabelFont(font52);
        logAxis50.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) logAxis50, categoryItemRenderer57);
        java.lang.Object obj59 = categoryPlot58.clone();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray60 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot58.setDomainAxes(categoryAxisArray60);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = categoryPlot58.getDomainAxisEdge();
        try {
            double double63 = logAxis34.lengthToJava2D((double) 1560452399999L, rectangle2D43, rectangleEdge62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 0.0f + "'", float51 == 0.0f);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(categoryAxisArray60);
        org.junit.Assert.assertNotNull(rectangleEdge62);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot6.getRenderer();
        java.awt.Paint paint10 = xYPlot6.getRangeGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot6.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot6.getAxisOffset();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
        boolean boolean2 = xYAreaRenderer1.getPlotArea();
        java.lang.Object obj3 = xYAreaRenderer1.clone();
        java.lang.Object obj4 = xYAreaRenderer1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) -1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        categoryPlot14.setDrawSharedDomainAxis(false);
        categoryPlot14.setRangeMinorGridlinesVisible(false);
        boolean boolean44 = categoryPlot14.isRangeMinorGridlinesVisible();
        java.lang.Comparable comparable45 = categoryPlot14.getDomainCrosshairRowKey();
        java.awt.Paint paint46 = categoryPlot14.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(comparable45);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (short) 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.Object obj15 = categoryPlot14.clone();
        java.awt.Stroke stroke16 = categoryPlot14.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        xYPlot6.mapDatasetToRangeAxis((int) '#', 0);
        java.lang.String str21 = xYPlot6.getPlotType();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("");
        float float4 = logAxis3.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) logAxis3, valueAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot7.setDomainCrosshairPaint(paint8);
        java.awt.Paint paint11 = null;
        xYPlot7.setQuadrantPaint((int) (short) 0, paint11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("12/31/69", (org.jfree.chart.plot.Plot) xYPlot7);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        dateAxis0.setRange((double) 0L, (double) 200);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType5 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType5, (int) '4');
        double double8 = dateTickUnit7.getSize();
        java.util.Date date9 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit7);
        org.junit.Assert.assertNotNull(dateTickUnitType5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.4928E9d + "'", double8 == 4.4928E9d);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer22.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
        xYStepAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator27);
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis35.setTickLabelFont(font37);
        logAxis35.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) logAxis35, categoryItemRenderer42);
        java.awt.Stroke stroke44 = categoryPlot43.getOutlineStroke();
        xYStepAreaRenderer22.setBaseStroke(stroke44, false);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) xYStepAreaRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = categoryPlot18.getDomainAxisForDataset(12);
        org.jfree.chart.entity.EntityCollection entityCollection52 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = new org.jfree.chart.ChartRenderingInfo(entityCollection52);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo53.getPlotInfo();
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.LogAxis logAxis57 = new org.jfree.chart.axis.LogAxis("");
        float float58 = logAxis57.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) logAxis57, valueAxis59, xYItemRenderer60);
        java.awt.Paint paint62 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot61.setDomainCrosshairPaint(paint62);
        java.awt.geom.Point2D point2D64 = xYPlot61.getQuadrantOrigin();
        categoryPlot18.zoomDomainAxes((double) 2147483647, (double) (short) 10, plotRenderingInfo54, point2D64);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(categoryAxis49);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.0f + "'", float58 == 0.0f);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(point2D64);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Font font3 = standardChartTheme1.getExtraLargeFont();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter7 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (byte) 100, (double) 100.0f, (double) (short) 100);
        standardChartTheme1.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYStepRenderer0.setBaseItemLabelFont(font1, false);
        xYStepRenderer0.setSeriesShapesVisible(10, false);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        xYPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot6.getRangeAxisLocation(6);
        xYPlot6.mapDatasetToRangeAxis(0, (int) '4');
        java.lang.Number[][] numberArray24 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Font font30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis28.setTickLabelFont(font30);
        logAxis28.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) logAxis28, categoryItemRenderer35);
        java.lang.String str37 = categoryPlot36.getPlotType();
        java.awt.Paint paint38 = categoryPlot36.getRangeGridlinePaint();
        java.awt.Stroke stroke39 = categoryPlot36.getRangeZeroBaselineStroke();
        xYPlot6.setDomainZeroBaselineStroke(stroke39);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Category Plot" + "'", str37.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        xYPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot6.getRangeAxisLocation(6);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset42 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset26, 2147483647);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset26, Double.NaN);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(pieDataset42);
        org.junit.Assert.assertNull(range44);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape18 = defaultDrawingSupplier17.getNextShape();
        xYPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17, false);
        xYPlot6.clearAnnotations();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) (short) 10, "-3,-3,3,3", "ThreadContext", false);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection9, true);
        int[] intArray15 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) xYSeriesCollection9, 0, (double) (byte) 0, (double) 1);
        java.lang.Object obj16 = xYSeriesCollection9.clone();
        double double17 = xYSeriesCollection9.getIntervalWidth();
        boolean boolean18 = logFormat4.equals((java.lang.Object) xYSeriesCollection9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot9.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot9.getRenderer();
        java.awt.Paint paint13 = xYPlot9.getRangeGridlinePaint();
        standardChartTheme1.setTickLabelPaint(paint13);
        org.jfree.data.xy.XYSeries xYSeries18 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection(xYSeries18);
        boolean boolean20 = standardChartTheme1.equals((java.lang.Object) xYSeries18);
        org.jfree.data.xy.XYSeries xYSeries24 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double25 = xYSeries24.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries26 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection(timeSeries26);
        xYSeries24.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection27);
        xYSeries18.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection27);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection30 = new org.jfree.data.xy.XYSeriesCollection(xYSeries18);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.awt.Paint paint8 = piePlot3D0.getSectionPaint((java.lang.Comparable) year6);
        float float9 = piePlot3D0.getForegroundAlpha();
        piePlot3D0.setMaximumLabelWidth((double) 0L);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        double double1 = xYCrosshairState0.getCrosshairDistance();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYStepAreaRenderer1.setLegendTextFont((int) 'a', font7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYStepAreaRenderer10.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = null;
        xYStepAreaRenderer10.setLegendItemURLGenerator(xYSeriesLabelGenerator15);
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis23.setTickLabelFont(font25);
        logAxis23.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) logAxis23, categoryItemRenderer30);
        java.awt.Stroke stroke32 = categoryPlot31.getOutlineStroke();
        xYStepAreaRenderer10.setBaseStroke(stroke32, false);
        xYStepAreaRenderer10.setShapesVisible(true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator37 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYStepAreaRenderer10.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator37);
        xYStepAreaRenderer1.setLegendItemURLGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator37);
        org.jfree.data.xy.XYSeries xYSeries43 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection44 = new org.jfree.data.xy.XYSeriesCollection(xYSeries43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection44, false);
        xYSeriesCollection44.removeAllSeries();
        org.jfree.data.xy.XYDataset xYDataset48 = null;
        org.jfree.chart.axis.LogAxis logAxis50 = new org.jfree.chart.axis.LogAxis("");
        float float51 = logAxis50.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset48, (org.jfree.chart.axis.ValueAxis) logAxis50, valueAxis52, xYItemRenderer53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = xYPlot54.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer58 = null;
        java.util.Collection collection59 = xYPlot54.getDomainMarkers((int) 'a', layer58);
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("");
        float float62 = logAxis61.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke63 = logAxis61.getTickMarkStroke();
        xYPlot54.setRangeGridlineStroke(stroke63);
        java.awt.Paint paint65 = xYPlot54.getDomainCrosshairPaint();
        boolean boolean66 = xYSeriesCollection44.hasListener((java.util.EventListener) xYPlot54);
        try {
            java.lang.String str68 = standardXYSeriesLabelGenerator37.generateLabel((org.jfree.data.xy.XYDataset) xYSeriesCollection44, 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 0.0f + "'", float51 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 0.0f + "'", float62 == 0.0f);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        xYItemRendererState1.startSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection6, 7, 0, (int) (byte) 100, (int) 'a', (int) '4');
        org.jfree.data.general.DatasetGroup datasetGroup13 = xYSeriesCollection6.getGroup();
        org.junit.Assert.assertNotNull(datasetGroup13);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        logAxis1.centerRange((double) 15);
        boolean boolean5 = logAxis1.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets6.getRight();
        java.lang.String str8 = rectangleInsets6.toString();
        double double9 = rectangleInsets6.getBottom();
        logAxis1.setLabelInsets(rectangleInsets6);
        java.awt.Paint paint11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        logAxis1.setTickMarkPaint(paint11);
        java.lang.String str13 = logAxis1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str8.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = xYStepAreaRenderer41.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer41.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape50 = xYStepAreaRenderer41.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.LogAxis logAxis53 = new org.jfree.chart.axis.LogAxis("");
        float float54 = logAxis53.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) logAxis53, valueAxis55, xYItemRenderer56);
        java.awt.Paint paint58 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot57.setDomainCrosshairPaint(paint58);
        org.jfree.chart.title.LegendGraphic legendGraphic60 = new org.jfree.chart.title.LegendGraphic(shape50, paint58);
        logAxis34.setDownArrow(shape50);
        try {
            logAxis34.setBase(1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'base' > 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 0.0f + "'", float54 == 0.0f);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        java.awt.Color color36 = java.awt.Color.CYAN;
        categoryPlot14.setRangeMinorGridlinePaint((java.awt.Paint) color36);
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot14.getDataset(52);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(categoryDataset39);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getThermometerPaint();
        java.awt.Paint paint3 = standardChartTheme1.getChartBackgroundPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = xYStepAreaRenderer1.getSeriesURLGenerator(7);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(xYURLGenerator10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        java.awt.Paint paint9 = piePlot3D0.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        float float5 = logAxis4.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) logAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot8.getDomainMarkers((int) 'a', layer12);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        float float16 = logAxis15.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke17 = logAxis15.getTickMarkStroke();
        xYPlot8.setRangeGridlineStroke(stroke17);
        java.awt.Paint paint19 = xYPlot8.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint25 = standardChartTheme24.getGridBandPaint();
        xYPlot8.setRangeCrosshairPaint(paint25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        xYPlot8.setDomainAxis((int) (byte) 10, valueAxis28);
        int int30 = xYPlot8.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("Category Plot", font1, (org.jfree.chart.plot.Plot) xYPlot8, true);
        java.lang.Object obj33 = jFreeChart32.clone();
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.entity.EntityCollection entityCollection36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = new org.jfree.chart.ChartRenderingInfo(entityCollection36);
        try {
            jFreeChart32.draw(graphics2D34, rectangle2D35, chartRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getTickLabelFont();
        float float2 = dateAxis0.getMinorTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection9, false);
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis18.setTickLabelFont(font20);
        logAxis18.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) logAxis18, categoryItemRenderer25);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) logAxis29, valueAxis31, xYItemRenderer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot33.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = xYPlot33.getDomainMarkers((int) 'a', layer37);
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("");
        float float41 = logAxis40.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke42 = logAxis40.getTickMarkStroke();
        xYPlot33.setRangeGridlineStroke(stroke42);
        categoryPlot26.setDomainCrosshairStroke(stroke42);
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("");
        float float47 = logAxis46.getMinorTickMarkInsideLength();
        java.awt.Font font48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis46.setTickLabelFont(font48);
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = logAxis46.getStandardTickUnits();
        int int51 = categoryPlot26.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis46);
        org.jfree.chart.axis.AxisSpace axisSpace52 = null;
        categoryPlot26.setFixedRangeAxisSpace(axisSpace52, false);
        boolean boolean55 = xYSeriesCollection9.hasListener((java.util.EventListener) categoryPlot26);
        org.jfree.chart.axis.LogAxis logAxis57 = new org.jfree.chart.axis.LogAxis("");
        float float58 = logAxis57.getMinorTickMarkInsideLength();
        java.awt.Font font59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis57.setTickLabelFont(font59);
        boolean boolean61 = logAxis57.isAutoRange();
        boolean boolean62 = logAxis57.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = null;
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection9, (org.jfree.chart.axis.ValueAxis) logAxis57, polarItemRenderer63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        java.awt.geom.Point2D point2D67 = null;
        polarPlot64.zoomRangeAxes((double) 2.0f, plotRenderingInfo66, point2D67);
        java.awt.Paint paint69 = polarPlot64.getNoDataMessagePaint();
        java.awt.Paint paint70 = polarPlot64.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState72 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo71);
        org.jfree.data.xy.XYSeries xYSeries76 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection77 = new org.jfree.data.xy.XYSeriesCollection(xYSeries76);
        org.jfree.data.general.DatasetGroup datasetGroup78 = xYSeriesCollection77.getGroup();
        java.lang.Object obj79 = xYSeriesCollection77.clone();
        boolean boolean80 = xYSeriesCollection77.isAutoWidth();
        xYItemRendererState72.endSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection77, 3, (int) (byte) 1, 4, (int) ' ', (int) (short) 100);
        polarPlot64.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection77);
        boolean boolean88 = multiplePiePlot4.equals((java.lang.Object) xYSeriesCollection77);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier89 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint90 = defaultDrawingSupplier89.getNextFillPaint();
        multiplePiePlot4.setAggregatedItemsPaint(paint90);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(tickUnitSource50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.0f + "'", float58 == 0.0f);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(datasetGroup78);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(paint90);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange1, true, false);
        org.junit.Assert.assertNotNull(dateRange1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        java.awt.Stroke stroke51 = categoryPlot50.getOutlineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke51);
        org.jfree.chart.axis.AxisLocation axisLocation54 = categoryPlot14.getDomainAxisLocation((int) ' ');
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer6.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape15 = xYStepAreaRenderer6.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) logAxis18, valueAxis20, xYItemRenderer21);
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot22.setDomainCrosshairPaint(paint23);
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape15, paint23);
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        logAxis34.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) logAxis34, categoryItemRenderer41);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity45 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset31, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        multiplePiePlot4.setLegendItemShape(shape15);
        org.jfree.chart.axis.LogAxis logAxis48 = new org.jfree.chart.axis.LogAxis("");
        float float49 = logAxis48.getMinorTickMarkInsideLength();
        logAxis48.centerRange((double) 15);
        boolean boolean52 = logAxis48.isPositiveArrowVisible();
        int int53 = logAxis48.getMinorTickCount();
        org.jfree.chart.entity.AxisEntity axisEntity56 = new org.jfree.chart.entity.AxisEntity(shape15, (org.jfree.chart.axis.Axis) logAxis48, "gray", "TextAnchor.BOTTOM_RIGHT");
        java.lang.String str57 = axisEntity56.toString();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "AxisEntity: tooltip = gray" + "'", str57.equals("AxisEntity: tooltip = gray"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState((double) (byte) -1);
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset7);
        org.jfree.data.time.TimeSeries timeSeries11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeSeries11);
        double double14 = timeSeriesCollection12.getDomainUpperBound(true);
        java.util.List list15 = timeSeriesCollection12.getSeries();
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset7, list15, true);
        axisState3.setTicks(list15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str20 = rectangleConstraint19.toString();
        org.jfree.data.time.DateRange dateRange21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range24 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange21, (double) 2, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint19.toRangeWidth(range24);
        org.jfree.data.Range range27 = timeSeriesCollection1.getRangeBounds(list15, range24, true);
        try {
            int[] intArray30 = timeSeriesCollection1.getSurroundingItems(9, (long) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (9).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str20.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(dateRange21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint3 = standardChartTheme2.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) logAxis6, valueAxis8, xYItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot10.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot10.getRenderer();
        java.awt.Paint paint14 = xYPlot10.getRangeGridlinePaint();
        standardChartTheme2.setTickLabelPaint(paint14);
        java.awt.Paint paint16 = standardChartTheme2.getTitlePaint();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int18 = color17.getBlue();
        standardChartTheme2.setGridBandPaint((java.awt.Paint) color17);
        java.awt.Color color20 = java.awt.Color.getColor("GradientPaintTransformType.VERTICAL", color17);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 128 + "'", int18 == 128);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("");
        float float4 = logAxis3.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) logAxis3, valueAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot7.setDomainCrosshairPaint(paint8);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator12 = null;
        xYStepAreaRenderer11.setBaseToolTipGenerator(xYToolTipGenerator12);
        java.awt.Shape shape15 = xYStepAreaRenderer11.lookupLegendShape(0);
        int int16 = xYPlot7.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer11);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        float float20 = logAxis19.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) logAxis19, valueAxis21, xYItemRenderer22);
        java.awt.Paint paint24 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot23.setDomainCrosshairPaint(paint24);
        xYPlot7.setRangeGridlinePaint(paint24);
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis("");
        float float34 = logAxis33.getMinorTickMarkInsideLength();
        java.awt.Font font35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis33.setTickLabelFont(font35);
        logAxis33.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) logAxis33, categoryItemRenderer40);
        double double43 = logAxis33.calculateLog((double) (-1.0f));
        int int44 = xYPlot7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis33);
        logAxis33.setTickMarkInsideLength((float) 15);
        boolean boolean47 = blockContainer0.equals((java.lang.Object) 15);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator1 = piePlot0.getToolTipGenerator();
        org.junit.Assert.assertNull(pieToolTipGenerator1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        categoryPlot14.setCrosshairDatasetIndex(0, true);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) '4');
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType4, (int) '4');
        java.text.DateFormat dateFormat8 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 0, dateTickUnitType4, (int) (byte) 1, dateFormat8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double10 = rectangleInsets9.getRight();
        java.lang.String str11 = rectangleInsets9.toString();
        java.lang.String str12 = rectangleInsets9.toString();
        double double13 = rectangleInsets9.getLeft();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets9);
        piePlot3D0.setSectionOutlinesVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean18 = numberAxis17.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        double double21 = numberAxis17.getLowerBound();
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        numberAxis17.setTickLabelPaint(paint22);
        piePlot3D0.setLabelOutlinePaint(paint22);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        legendGraphic20.setShapeFilled(false);
        boolean boolean24 = legendGraphic20.equals((java.lang.Object) "SeriesRenderingOrder.FORWARD");
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.LogAxis logAxis4 = new org.jfree.chart.axis.LogAxis("");
        float float5 = logAxis4.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) logAxis4, valueAxis6, xYItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = xYPlot8.getDomainMarkers((int) 'a', layer12);
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        float float16 = logAxis15.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke17 = logAxis15.getTickMarkStroke();
        xYPlot8.setRangeGridlineStroke(stroke17);
        java.awt.Paint paint19 = xYPlot8.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot8.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        org.jfree.chart.StandardChartTheme standardChartTheme24 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint25 = standardChartTheme24.getGridBandPaint();
        xYPlot8.setRangeCrosshairPaint(paint25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        xYPlot8.setDomainAxis((int) (byte) 10, valueAxis28);
        int int30 = xYPlot8.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("Category Plot", font1, (org.jfree.chart.plot.Plot) xYPlot8, true);
        java.awt.RenderingHints renderingHints33 = jFreeChart32.getRenderingHints();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(renderingHints33);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        xYStepAreaRenderer1.setSeriesVisibleInLegend(9999, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = periodAxis4.getFirst();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day7, (org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleEdge.TOP", regularTimePeriod5, (org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.data.Range range11 = periodAxis10.getRange();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        float float10 = logAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) logAxis9, valueAxis11, xYItemRenderer12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot13.setDomainCrosshairPaint(paint14);
        java.awt.Paint paint17 = null;
        xYPlot13.setQuadrantPaint((int) (short) 0, paint17);
        combinedDomainXYPlot6.remove(xYPlot13);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double21 = rectangleInsets20.getRight();
        double double23 = rectangleInsets20.calculateRightInset((double) 2147483647);
        combinedDomainXYPlot6.setInsets(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) logAxis18, valueAxis20, xYItemRenderer21);
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot22.setDomainCrosshairPaint(paint23);
        xYPlot6.setRangeGridlinePaint(paint23);
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis32.setTickLabelFont(font34);
        logAxis32.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) logAxis32, categoryItemRenderer39);
        double double42 = logAxis32.calculateLog((double) (-1.0f));
        int int43 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis32);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = legendTitle44.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = legendTitle44.getHorizontalAlignment();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertNotNull(horizontalAlignment46);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Font font3 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint5 = xYStepAreaRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.DARK_GRAY;
        xYStepAreaRenderer0.setBaseOutlinePaint((java.awt.Paint) color6);
        xYStepAreaRenderer0.setItemLabelAnchorOffset((double) 1560452399999L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Font font3 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint5 = xYStepAreaRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        org.jfree.chart.StandardChartTheme standardChartTheme8 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint9 = standardChartTheme8.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        float float13 = logAxis12.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) logAxis12, valueAxis14, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot16.getRenderer();
        java.awt.Paint paint20 = xYPlot16.getRangeGridlinePaint();
        standardChartTheme8.setTickLabelPaint(paint20);
        xYStepAreaRenderer0.setSeriesPaint((int) (byte) 1, paint20);
        java.awt.Stroke stroke24 = xYStepAreaRenderer0.lookupSeriesStroke((-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.setWidth((double) 10.0f);
        java.lang.Object obj3 = size2D0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator3 = null;
        xYStepAreaRenderer2.setBaseToolTipGenerator(xYToolTipGenerator3);
        boolean boolean5 = xYStepAreaRenderer2.getBaseSeriesVisibleInLegend();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator7 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYStepAreaRenderer2.setSeriesURLGenerator(9999, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator7);
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer9 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator7);
        java.text.DateFormat dateFormat10 = standardXYToolTipGenerator0.getXDateFormat();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateFormat10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        float float10 = logAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) logAxis9, valueAxis11, xYItemRenderer12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot13.setDomainCrosshairPaint(paint14);
        java.awt.Paint paint17 = null;
        xYPlot13.setQuadrantPaint((int) (short) 0, paint17);
        combinedDomainXYPlot6.remove(xYPlot13);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = combinedDomainXYPlot6.getFixedLegendItems();
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("");
        float float23 = logAxis22.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke24 = logAxis22.getTickMarkStroke();
        logAxis22.setMinorTickMarksVisible(false);
        org.jfree.data.Range range27 = combinedDomainXYPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis22);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ThreadContext");
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getRight();
        java.lang.String str5 = rectangleInsets3.toString();
        piePlot3D2.setSimpleLabelOffset(rectangleInsets3);
        java.awt.Stroke stroke7 = piePlot3D2.getBaseSectionOutlineStroke();
        java.lang.Object obj8 = null;
        boolean boolean9 = piePlot3D2.equals(obj8);
        piePlot3D2.setAutoPopulateSectionPaint(true);
        piePlot3D2.setIgnoreZeroValues(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = xYStepAreaRenderer15.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer15.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape24 = xYStepAreaRenderer15.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.LogAxis logAxis27 = new org.jfree.chart.axis.LogAxis("");
        float float28 = logAxis27.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) logAxis27, valueAxis29, xYItemRenderer30);
        java.awt.Paint paint32 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot31.setDomainCrosshairPaint(paint32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape24, paint32);
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.LogAxis logAxis43 = new org.jfree.chart.axis.LogAxis("");
        float float44 = logAxis43.getMinorTickMarkInsideLength();
        java.awt.Font font45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis43.setTickLabelFont(font45);
        logAxis43.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) logAxis43, categoryItemRenderer50);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity54 = new org.jfree.chart.entity.CategoryItemEntity(shape24, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset40, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset40, 2147483647);
        piePlot3D2.setDataset(pieDataset56);
        java.text.AttributedString attributedString59 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset56, (java.lang.Comparable) 12);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset60 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) pieDataset56);
        java.lang.Number number62 = defaultPieDataset60.getValue(255);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(pieDataset56);
        org.junit.Assert.assertNull(attributedString59);
        org.junit.Assert.assertNull(number62);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        double double6 = rectangleInsets1.calculateRightInset(4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        java.awt.Stroke stroke23 = categoryPlot22.getOutlineStroke();
        xYStepAreaRenderer1.setBaseStroke(stroke23, false);
        xYStepAreaRenderer1.setShapesVisible(true);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape28, "Pie 3D Plot");
        xYStepAreaRenderer1.setBaseShape(shape28);
        java.awt.Paint paint33 = xYStepAreaRenderer1.lookupSeriesOutlinePaint((int) (short) 1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) -1);
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset5, false);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset5);
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9);
        double double12 = timeSeriesCollection10.getDomainUpperBound(true);
        java.util.List list13 = timeSeriesCollection10.getSeries();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset5, list13, true);
        axisState1.setTicks(list13);
        double double17 = axisState1.getMax();
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        float float8 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) logAxis7, valueAxis9, xYItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot11.setDomainCrosshairPaint(paint12);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        xYStepAreaRenderer15.setBaseToolTipGenerator(xYToolTipGenerator16);
        java.awt.Shape shape19 = xYStepAreaRenderer15.lookupLegendShape(0);
        int int20 = xYPlot11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer15);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) logAxis23, valueAxis25, xYItemRenderer26);
        java.awt.Paint paint28 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot27.setDomainCrosshairPaint(paint28);
        xYPlot11.setRangeGridlinePaint(paint28);
        piePlot3D0.setLabelLinkPaint(paint28);
        piePlot3D0.setShadowYOffset((double) 3600000L);
        org.jfree.data.general.PieDataset pieDataset34 = piePlot3D0.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(pieDataset34);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Paint paint4 = xYStepAreaRenderer0.getSeriesPaint((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        xYItemRendererState1.startSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection6, 7, 0, (int) (byte) 100, (int) 'a', (int) '4');
        int int13 = xYItemRendererState1.getLastItemIndex();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.LogAxis logAxis52 = new org.jfree.chart.axis.LogAxis("");
        float float53 = logAxis52.getMinorTickMarkInsideLength();
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis52.setTickLabelFont(font54);
        boolean boolean56 = logAxis52.isAutoRange();
        boolean boolean57 = logAxis52.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer58 = null;
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) logAxis52, polarItemRenderer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        polarPlot59.zoomRangeAxes((double) 2.0f, plotRenderingInfo61, point2D62);
        java.awt.Paint paint64 = polarPlot59.getNoDataMessagePaint();
        java.awt.Paint paint65 = polarPlot59.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState67 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo66);
        org.jfree.data.xy.XYSeries xYSeries71 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection72 = new org.jfree.data.xy.XYSeriesCollection(xYSeries71);
        org.jfree.data.general.DatasetGroup datasetGroup73 = xYSeriesCollection72.getGroup();
        java.lang.Object obj74 = xYSeriesCollection72.clone();
        boolean boolean75 = xYSeriesCollection72.isAutoWidth();
        xYItemRendererState67.endSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection72, 3, (int) (byte) 1, 4, (int) ' ', (int) (short) 100);
        polarPlot59.setDataset((org.jfree.data.xy.XYDataset) xYSeriesCollection72);
        java.util.List list83 = xYSeriesCollection72.getSeries();
        xYSeriesCollection72.setIntervalWidth((double) 3600000L);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.0f + "'", float53 == 0.0f);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(datasetGroup73);
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(list83);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "Pie 3D Plot");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = periodAxis6.getFirst();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) day10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis21.setTickLabelFont(font23);
        logAxis21.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) logAxis21, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getRangeAxisEdge((int) ' ');
        java.util.List list32 = periodAxis11.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge31);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray33 = null;
        periodAxis11.setLabelInfo(periodAxisLabelInfoArray33);
        java.lang.Class class35 = periodAxis11.getMinorTickTimePeriodClass();
        periodAxis6.setAutoRangeTimePeriodClass(class35);
        double double37 = periodAxis6.getAutoRangeMinimumSize();
        org.jfree.chart.entity.AxisEntity axisEntity39 = new org.jfree.chart.entity.AxisEntity(shape0, (org.jfree.chart.axis.Axis) periodAxis6, "-3,-3,3,3");
        java.awt.Shape shape40 = axisEntity39.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0E-8d + "'", double37 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape40);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        java.lang.Object obj6 = null;
        boolean boolean7 = piePlot3D0.equals(obj6);
        piePlot3D0.setMaximumLabelWidth((double) (-1));
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot3D0.getURLGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(pieURLGenerator10);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = periodAxis4.getFirst();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day7, (org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("RectangleEdge.TOP", regularTimePeriod5, (org.jfree.data.time.RegularTimePeriod) day8);
        java.awt.Graphics2D graphics2D11 = null;
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset15);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYStepAreaRenderer18.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer18.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape27 = xYStepAreaRenderer18.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        float float31 = logAxis30.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) logAxis30, valueAxis32, xYItemRenderer33);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot34.setDomainCrosshairPaint(paint35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape27, paint35);
        java.lang.Number[][] numberArray42 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("");
        float float47 = logAxis46.getMinorTickMarkInsideLength();
        java.awt.Font font48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis46.setTickLabelFont(font48);
        logAxis46.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, (org.jfree.chart.axis.ValueAxis) logAxis46, categoryItemRenderer53);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity57 = new org.jfree.chart.entity.CategoryItemEntity(shape27, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset43, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        multiplePiePlot16.setLegendItemShape(shape27);
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        multiplePiePlot16.drawBackgroundImage(graphics2D59, rectangle2D60);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis66 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day64, (org.jfree.data.time.RegularTimePeriod) day65);
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.axis.AxisState axisState68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray72);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = null;
        org.jfree.chart.axis.LogAxis logAxis76 = new org.jfree.chart.axis.LogAxis("");
        float float77 = logAxis76.getMinorTickMarkInsideLength();
        java.awt.Font font78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis76.setTickLabelFont(font78);
        logAxis76.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer83 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, (org.jfree.chart.axis.ValueAxis) logAxis76, categoryItemRenderer83);
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = categoryPlot84.getRangeAxisEdge((int) ' ');
        java.util.List list87 = periodAxis66.refreshTicks(graphics2D67, axisState68, rectangle2D69, rectangleEdge86);
        org.jfree.chart.axis.AxisSpace axisSpace88 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str89 = axisSpace88.toString();
        axisSpace88.setBottom((double) (byte) 100);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace92 = periodAxis10.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) multiplePiePlot16, rectangle2D62, rectangleEdge86, axisSpace88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(numberArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.0f + "'", float77 == 0.0f);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertNotNull(list87);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        double double7 = xYSeriesCollection6.getIntervalWidth();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) logAxis18, valueAxis20, xYItemRenderer21);
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot22.setDomainCrosshairPaint(paint23);
        xYPlot6.setRangeGridlinePaint(paint23);
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis32.setTickLabelFont(font34);
        logAxis32.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) logAxis32, categoryItemRenderer39);
        double double42 = logAxis32.calculateLog((double) (-1.0f));
        int int43 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis32);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = legendTitle44.getVerticalAlignment();
        legendTitle44.setNotify(true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(verticalAlignment45);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        float float8 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) logAxis7, valueAxis9, xYItemRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot11.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot11.getDomainMarkers((int) 'a', layer15);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke20 = logAxis18.getTickMarkStroke();
        xYPlot11.setRangeGridlineStroke(stroke20);
        java.awt.Paint paint22 = xYPlot11.getDomainCrosshairPaint();
        xYPlot11.mapDatasetToRangeAxis((int) '#', 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot11.getRangeAxisEdge();
        boolean boolean27 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge26);
        org.jfree.chart.entity.EntityCollection entityCollection28 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo(entityCollection28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = chartRenderingInfo29.getPlotInfo();
        org.jfree.chart.renderer.RendererState rendererState31 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo30);
        try {
            org.jfree.chart.axis.AxisState axisState32 = categoryAxis0.draw(graphics2D1, (double) 0.5f, rectangle2D3, rectangle2D4, rectangleEdge26, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo30);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Paint paint4 = xYStepAreaRenderer1.getBasePaint();
        java.lang.Boolean boolean6 = xYStepAreaRenderer1.getSeriesCreateEntities(3);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) logAxis10, valueAxis12, xYItemRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers((int) 'a', layer18);
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke23 = logAxis21.getTickMarkStroke();
        xYPlot14.setRangeGridlineStroke(stroke23);
        java.awt.Paint paint25 = xYPlot14.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot14.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer27);
        xYStepAreaRenderer27.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer33 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = xYStepAreaRenderer33.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer33.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer33.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition42);
        xYStepAreaRenderer27.setBaseNegativeItemLabelPosition(itemLabelPosition42);
        java.lang.Object obj45 = null;
        boolean boolean46 = itemLabelPosition42.equals(obj45);
        xYStepAreaRenderer1.setSeriesPositiveItemLabelPosition(9999, itemLabelPosition42, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        strokeMap0.clear();
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0.0f, "", "hi!", false);
        int int5 = logFormat4.getMinimumFractionDigits();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.LogAxis logAxis3 = new org.jfree.chart.axis.LogAxis("");
        float float4 = logAxis3.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) logAxis3, valueAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot7.setDomainCrosshairPaint(paint8);
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean11 = org.jfree.chart.util.PaintUtilities.equal(paint8, paint10);
        boolean boolean12 = textAnchor0.equals((java.lang.Object) paint10);
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        float float20 = logAxis19.getMinorTickMarkInsideLength();
        java.awt.Font font21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis19.setTickLabelFont(font21);
        logAxis19.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) logAxis19, categoryItemRenderer26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        float float31 = logAxis30.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) logAxis30, valueAxis32, xYItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot34.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer38 = null;
        java.util.Collection collection39 = xYPlot34.getDomainMarkers((int) 'a', layer38);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke43 = logAxis41.getTickMarkStroke();
        xYPlot34.setRangeGridlineStroke(stroke43);
        categoryPlot27.setDomainCrosshairStroke(stroke43);
        org.jfree.chart.axis.LogAxis logAxis47 = new org.jfree.chart.axis.LogAxis("");
        float float48 = logAxis47.getMinorTickMarkInsideLength();
        java.awt.Font font49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis47.setTickLabelFont(font49);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = logAxis47.getStandardTickUnits();
        int int52 = categoryPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis47);
        categoryPlot27.setDrawSharedDomainAxis(false);
        boolean boolean55 = textAnchor0.equals((java.lang.Object) categoryPlot27);
        org.jfree.data.xy.XYSeries xYSeries59 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection60 = new org.jfree.data.xy.XYSeriesCollection(xYSeries59);
        boolean boolean61 = textAnchor0.equals((java.lang.Object) xYSeries59);
        java.util.List list62 = xYSeries59.getItems();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(collection39);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.0f + "'", float48 == 0.0f);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(list62);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        int int2 = timeSeriesCollection1.getSeriesCount();
        org.jfree.data.xy.XYSeries xYSeries6 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection(xYSeries6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = xYSeriesCollection7.getGroup();
        timeSeriesCollection1.setGroup(datasetGroup8);
        try {
            timeSeriesCollection1.removeSeries((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(datasetGroup8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.LogAxis logAxis52 = new org.jfree.chart.axis.LogAxis("");
        float float53 = logAxis52.getMinorTickMarkInsideLength();
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis52.setTickLabelFont(font54);
        boolean boolean56 = logAxis52.isAutoRange();
        boolean boolean57 = logAxis52.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer58 = null;
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) logAxis52, polarItemRenderer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        polarPlot59.zoomRangeAxes((double) 2.0f, plotRenderingInfo61, point2D62);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer64 = null;
        polarPlot59.setRenderer(polarItemRenderer64);
        polarPlot59.clearCornerTextItems();
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.0f + "'", float53 == 0.0f);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        boolean boolean4 = xYStepAreaRenderer1.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.StandardChartTheme standardChartTheme6 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint7 = standardChartTheme6.getThermometerPaint();
        java.awt.Paint paint8 = standardChartTheme6.getBaselinePaint();
        xYStepAreaRenderer1.setBaseOutlinePaint(paint8);
        java.awt.Paint paint11 = xYStepAreaRenderer1.lookupSeriesFillPaint(12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        java.lang.Object obj6 = null;
        boolean boolean7 = piePlot3D0.equals(obj6);
        piePlot3D0.setAutoPopulateSectionPaint(true);
        piePlot3D0.setIgnoreZeroValues(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepAreaRenderer13.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer13.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape22 = xYStepAreaRenderer13.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        float float26 = logAxis25.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) logAxis25, valueAxis27, xYItemRenderer28);
        java.awt.Paint paint30 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot29.setDomainCrosshairPaint(paint30);
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape22, paint30);
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        logAxis41.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) logAxis41, categoryItemRenderer48);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity52 = new org.jfree.chart.entity.CategoryItemEntity(shape22, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset38, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset38, 2147483647);
        piePlot3D0.setDataset(pieDataset54);
        java.awt.Paint paint56 = piePlot3D0.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(paint56);
    }
}

