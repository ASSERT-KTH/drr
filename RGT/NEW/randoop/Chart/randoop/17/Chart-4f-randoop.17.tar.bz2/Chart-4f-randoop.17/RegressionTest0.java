import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) (short) 100, "", textAnchor3, textAnchor4, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        java.text.NumberFormat numberFormat2 = logAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity2 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            xYPlot6.zoomDomainAxes((double) (byte) 1, (double) (short) 0, plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.2589254117941675) <= upper (0.00794328234724282).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 0, (float) (byte) 1, (double) 1.0f, (float) 0L, (float) ' ');
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 60000L, range1, lengthConstraintType2, (double) (-1L), range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.util.List list15 = null;
        try {
            org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3, list15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray16 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot14.setDomainAxes(categoryAxisArray16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            categoryPlot14.drawBackground(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(categoryAxisArray16);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = null;
        try {
            long long2 = segmentedTimeline0.toTimelineValue(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder9 = null;
        try {
            xYPlot6.setSeriesRenderingOrder(seriesRenderingOrder9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot6.getRenderer();
        java.util.List list11 = null;
        try {
            xYPlot6.mapDatasetToDomainAxes((int) (byte) 0, list11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot14.getRangeAxisEdge((int) ' ');
        org.jfree.chart.util.SortOrder sortOrder17 = null;
        try {
            categoryPlot14.setColumnRenderingOrder(sortOrder17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        try {
            int int17 = categoryPlot14.getDomainAxisIndex(categoryAxis16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            xYPlot6.addRangeMarker((int) (byte) 10, marker17, layer18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.util.SortOrder sortOrder33 = null;
        try {
            categoryPlot14.setColumnRenderingOrder(sortOrder33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline0.toTimelineValue(0L);
        java.util.List list3 = null;
        try {
            segmentedTimeline0.addExceptions(list3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577894400000L + "'", long2 == 1577894400000L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jan" + "'", str2.equals("Jan"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getOutlineStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        float float20 = logAxis19.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) logAxis19, valueAxis21, xYItemRenderer22);
        java.lang.Object obj24 = xYPlot23.clone();
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.LogAxis logAxis31 = new org.jfree.chart.axis.LogAxis("");
        float float32 = logAxis31.getMinorTickMarkInsideLength();
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis31.setTickLabelFont(font33);
        logAxis31.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) logAxis31, categoryItemRenderer38);
        org.jfree.chart.axis.ValueAxis valueAxis40 = categoryPlot39.getRangeAxis();
        xYPlot23.setRangeAxis(valueAxis40);
        try {
            categoryPlot14.setRangeAxis((int) (byte) -1, valueAxis40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(valueAxis40);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot6.handleClick(0, 0, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYStepAreaRenderer5.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer5.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape14 = xYStepAreaRenderer5.lookupSeriesShape(0);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYStepAreaRenderer16.setBaseToolTipGenerator(xYToolTipGenerator17);
        java.awt.Paint paint19 = xYStepAreaRenderer16.getBasePaint();
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("");
        float float27 = logAxis26.getMinorTickMarkInsideLength();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis26.setTickLabelFont(font28);
        logAxis26.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) logAxis26, categoryItemRenderer33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.LogAxis logAxis37 = new org.jfree.chart.axis.LogAxis("");
        float float38 = logAxis37.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) logAxis37, valueAxis39, xYItemRenderer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = xYPlot41.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = xYPlot41.getDomainMarkers((int) 'a', layer45);
        org.jfree.chart.axis.LogAxis logAxis48 = new org.jfree.chart.axis.LogAxis("");
        float float49 = logAxis48.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke50 = logAxis48.getTickMarkStroke();
        xYPlot41.setRangeGridlineStroke(stroke50);
        categoryPlot34.setRangeZeroBaselineStroke(stroke50);
        java.awt.Paint paint53 = null;
        try {
            org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem(attributedString0, "", "ThreadContext", "Jan", shape14, paint19, stroke50, paint53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.0f + "'", float38 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            logAxis1.setTickLabelInsets(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.data.Range range21 = null;
        try {
            logAxis1.setRange(range21, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity13 = new org.jfree.chart.entity.JFreeChartEntity(shape10, jFreeChart11, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("Jan", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        java.awt.Paint paint9 = xYStepAreaRenderer1.getItemOutlinePaint((int) (byte) 0, (int) '4', false);
        boolean boolean11 = xYStepAreaRenderer1.isSeriesVisible((int) (short) 1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Paint paint4 = xYStepAreaRenderer1.getBasePaint();
        try {
            xYStepAreaRenderer1.setSeriesCreateEntities((int) (short) -1, (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline0.toTimelineValue(0L);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) 7);
        long long7 = segmentedTimeline0.getExceptionSegmentCount(1L, (long) 10);
        java.util.Date date8 = null;
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline0.getSegment(date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577894400000L + "'", long2 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-447) + "'", int1 == (-447));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        try {
            boolean boolean35 = categoryPlot14.removeRangeMarker(marker33, layer34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            xYPlot6.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.chart.util.TableOrder tableOrder5 = null;
        try {
            multiplePiePlot4.setDataExtractOrder(tableOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getRangeAxisEdge((int) ' ');
        java.util.List list24 = periodAxis3.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge23);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray25 = null;
        periodAxis3.setLabelInfo(periodAxisLabelInfoArray25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.LogAxis logAxis30 = new org.jfree.chart.axis.LogAxis("");
        float float31 = logAxis30.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) logAxis30, valueAxis32, xYItemRenderer33);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot34.setDomainCrosshairPaint(paint35);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer38 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator39 = null;
        xYStepAreaRenderer38.setBaseToolTipGenerator(xYToolTipGenerator39);
        java.awt.Shape shape42 = xYStepAreaRenderer38.lookupLegendShape(0);
        int int43 = xYPlot34.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer38);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot34.getDomainAxisEdge((int) (byte) 100);
        boolean boolean46 = xYPlot34.isRangeGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.LogAxis logAxis54 = new org.jfree.chart.axis.LogAxis("");
        float float55 = logAxis54.getMinorTickMarkInsideLength();
        java.awt.Font font56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis54.setTickLabelFont(font56);
        logAxis54.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) logAxis54, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getRangeAxisEdge((int) ' ');
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace66 = periodAxis3.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) xYPlot34, rectangle2D47, rectangleEdge64, axisSpace65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.0f + "'", float55 == 0.0f);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = categoryPlot14.getOrientation();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        try {
            boolean boolean38 = categoryPlot14.removeRangeMarker((int) '4', marker35, layer36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(plotOrientation33);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("");
        float float9 = logAxis8.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) logAxis8, valueAxis10, xYItemRenderer11);
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot12.setDomainCrosshairPaint(paint13);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYStepAreaRenderer16.setBaseToolTipGenerator(xYToolTipGenerator17);
        java.awt.Shape shape20 = xYStepAreaRenderer16.lookupLegendShape(0);
        int int21 = xYPlot12.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot12.getDomainAxisEdge((int) (byte) 100);
        boolean boolean24 = xYPlot12.isRangeGridlinesVisible();
        xYStepAreaRenderer1.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot12);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.data.Range range21 = null;
        try {
            logAxis1.setDefaultAutoRange(range21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        logAxis1.centerRange((double) 15);
        double double5 = logAxis1.getUpperBound();
        logAxis1.setUpperBound((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 15.5d + "'", double5 == 15.5d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) -1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        logAxis1.centerRange((double) 15);
        double double5 = logAxis1.getUpperBound();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double9 = logAxis1.valueToJava2D((double) 60000L, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 15.5d + "'", double5 == 15.5d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Jan", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        try {
            java.lang.Number number7 = xYSeriesCollection4.getEndY(10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        boolean boolean12 = xYStepAreaRenderer1.removeAnnotation(xYAnnotation11);
        xYStepAreaRenderer1.setBaseCreateEntities(false, false);
        int int16 = xYStepAreaRenderer1.getPassCount();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) logAxis21, valueAxis23, xYItemRenderer24);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot25.setDataset((int) (byte) 10, xYDataset27);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) logAxis32, valueAxis34, xYItemRenderer35);
        java.awt.Paint paint37 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot36.setDomainCrosshairPaint(paint37);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer40 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator41 = null;
        xYStepAreaRenderer40.setBaseToolTipGenerator(xYToolTipGenerator41);
        java.awt.Shape shape44 = xYStepAreaRenderer40.lookupLegendShape(0);
        int int45 = xYPlot36.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer40);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.LogAxis logAxis48 = new org.jfree.chart.axis.LogAxis("");
        float float49 = logAxis48.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) logAxis48, valueAxis50, xYItemRenderer51);
        java.awt.Paint paint53 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot52.setDomainCrosshairPaint(paint53);
        xYPlot36.setRangeGridlinePaint(paint53);
        java.lang.Number[][] numberArray58 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset59 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray58);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.LogAxis logAxis62 = new org.jfree.chart.axis.LogAxis("");
        float float63 = logAxis62.getMinorTickMarkInsideLength();
        java.awt.Font font64 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis62.setTickLabelFont(font64);
        logAxis62.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis60, (org.jfree.chart.axis.ValueAxis) logAxis62, categoryItemRenderer69);
        double double72 = logAxis62.calculateLog((double) (-1.0f));
        int int73 = xYPlot36.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis62);
        xYPlot25.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) logAxis62, false);
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        try {
            xYStepAreaRenderer1.drawDomainGridLine(graphics2D17, xYPlot18, (org.jfree.chart.axis.ValueAxis) logAxis62, rectangle2D76, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(numberArray58);
        org.junit.Assert.assertNotNull(categoryDataset59);
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 0.0f + "'", float63 == 0.0f);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertEquals((double) double72, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset8);
        org.jfree.chart.plot.Marker marker10 = null;
        try {
            xYPlot6.addDomainMarker(marker10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.expand(range0, 0.1d, (double) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            legendGraphic20.draw(graphics2D21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        java.lang.Object obj5 = standardXYToolTipGenerator3.clone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot6.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) xYItemRenderer9, jFreeChart10, 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        float float40 = logAxis34.getMinorTickMarkInsideLength();
        logAxis34.setRange((double) (byte) -1, 0.05d);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 0.0f + "'", float40 == 0.0f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot21.getRangeAxisEdge((int) ' ');
        java.util.List list24 = periodAxis3.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge23);
        java.lang.Class class25 = null;
        try {
            periodAxis3.setMinorTickTimePeriodClass(class25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(list24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline0.toTimelineValue(0L);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) 7);
        long long7 = segmentedTimeline0.getExceptionSegmentCount(1L, (long) 10);
        long long9 = segmentedTimeline0.toTimelineValue(1577894400000L);
        int int10 = segmentedTimeline0.getSegmentsExcluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577894400000L + "'", long2 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2704953600000L + "'", long9 == 2704953600000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightOutset(Double.NaN);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        org.jfree.chart.block.Arrangement arrangement2 = blockContainer0.getArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double4 = rectangleInsets3.getRight();
        java.lang.String str5 = rectangleInsets3.toString();
        java.lang.String str6 = rectangleInsets3.toString();
        blockContainer0.setMargin(rectangleInsets3);
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.add((org.jfree.chart.block.Block) blockContainer8);
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertNotNull(arrangement2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str6.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        java.lang.String str2 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str2.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        java.awt.Stroke stroke16 = xYPlot6.getDomainGridlineStroke();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot6.getDomainAxisForDataset((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray16 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot14.setDomainAxes(categoryAxisArray16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = null;
        categoryPlot14.setFixedLegendItems(legendItemCollection18);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            categoryPlot14.addDomainMarker(categoryMarker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(categoryAxisArray16);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot14.getRendererForDataset(categoryDataset19);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        try {
            categoryPlot14.addRangeMarker(10, marker22, layer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ThreadContext");
        java.awt.Font font2 = textFragment1.getFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        try {
            logAxis1.setAutoRangeMinimumSize((double) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        float float10 = logAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) logAxis9, valueAxis11, xYItemRenderer12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot13.setDomainCrosshairPaint(paint14);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer17 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator18 = null;
        xYStepAreaRenderer17.setBaseToolTipGenerator(xYToolTipGenerator18);
        java.awt.Shape shape21 = xYStepAreaRenderer17.lookupLegendShape(0);
        int int22 = xYPlot13.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer17);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot13.getDomainAxisEdge((int) (byte) 100);
        try {
            gradientXYBarPainter0.paintBarShadow(graphics2D1, xYBarRenderer2, (int) (byte) 0, 1, true, rectangularShape6, rectangleEdge24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        try {
            java.lang.Number number4 = timeSeriesCollection1.getEndX(200, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 200, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis23.setTickLabelFont(font25);
        logAxis23.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) logAxis23, categoryItemRenderer30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) logAxis34, valueAxis36, xYItemRenderer37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot38.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer42 = null;
        java.util.Collection collection43 = xYPlot38.getDomainMarkers((int) 'a', layer42);
        org.jfree.chart.axis.LogAxis logAxis45 = new org.jfree.chart.axis.LogAxis("");
        float float46 = logAxis45.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke47 = logAxis45.getTickMarkStroke();
        xYPlot38.setRangeGridlineStroke(stroke47);
        categoryPlot31.setDomainCrosshairStroke(stroke47);
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = categoryPlot31.getOrientation();
        xYPlot6.setOrientation(plotOrientation50);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNull(collection43);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.0f + "'", float46 == 0.0f);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(plotOrientation50);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) 0, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        categoryItemEntity40.setURLText("Category Plot");
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        try {
            timeSeriesCollection1.addSeries(timeSeries2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray16 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot14.setDomainAxes(categoryAxisArray16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot14.getDomainAxisEdge();
        categoryPlot14.setRangeCrosshairValue((double) 2704953600000L, true);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(categoryAxisArray16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot14.getRangeAxisEdge((int) ' ');
        boolean boolean17 = categoryPlot14.isDomainPannable();
        org.jfree.chart.plot.Marker marker18 = null;
        try {
            categoryPlot14.addRangeMarker(marker18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day38, (org.jfree.data.time.RegularTimePeriod) day39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.AxisState axisState42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.lang.Number[][] numberArray46 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray46);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.LogAxis logAxis50 = new org.jfree.chart.axis.LogAxis("");
        float float51 = logAxis50.getMinorTickMarkInsideLength();
        java.awt.Font font52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis50.setTickLabelFont(font52);
        logAxis50.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, (org.jfree.chart.axis.ValueAxis) logAxis50, categoryItemRenderer57);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = categoryPlot58.getRangeAxisEdge((int) ' ');
        java.util.List list61 = periodAxis40.refreshTicks(graphics2D41, axisState42, rectangle2D43, rectangleEdge60);
        try {
            categoryPlot14.mapDatasetToDomainAxes((int) (short) 1, list61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(numberArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 0.0f + "'", float51 == 0.0f);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(list61);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.lang.Object obj7 = xYPlot6.clone();
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot22.getRangeAxis();
        xYPlot6.setRangeAxis(valueAxis23);
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.LogAxis logAxis31 = new org.jfree.chart.axis.LogAxis("");
        float float32 = logAxis31.getMinorTickMarkInsideLength();
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis31.setTickLabelFont(font33);
        logAxis31.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) logAxis31, categoryItemRenderer38);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset40, (org.jfree.chart.axis.ValueAxis) logAxis42, valueAxis44, xYItemRenderer45);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = xYPlot46.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer50 = null;
        java.util.Collection collection51 = xYPlot46.getDomainMarkers((int) 'a', layer50);
        org.jfree.chart.axis.LogAxis logAxis53 = new org.jfree.chart.axis.LogAxis("");
        float float54 = logAxis53.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke55 = logAxis53.getTickMarkStroke();
        xYPlot46.setRangeGridlineStroke(stroke55);
        categoryPlot39.setDomainCrosshairStroke(stroke55);
        valueAxis23.setAxisLineStroke(stroke55);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 0.0f + "'", float54 == 0.0f);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        boolean boolean36 = categoryPlot14.isRangeMinorGridlinesVisible();
        categoryPlot14.zoom((double) 4);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot14.getDomainAxisForDataset(4);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryAxis40);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke3 = logAxis1.getTickMarkStroke();
        logAxis1.setLabelURL("hi!");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        boolean boolean17 = xYPlot6.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        java.awt.Paint paint9 = xYStepAreaRenderer1.getItemOutlinePaint((int) (byte) 0, (int) '4', false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            xYStepAreaRenderer1.addAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, true);
        try {
            java.lang.Number number9 = xYSeriesCollection4.getY((int) (byte) 0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("Category Plot");
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset26);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.lang.Object obj7 = xYPlot6.clone();
        xYPlot6.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        try {
            xYPlot6.setRangeAxisLocation(axisLocation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = xYPlot6.getDomainMarkers(1, layer8);
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis16.setTickLabelFont(font18);
        logAxis16.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryItemRenderer23);
        java.awt.Paint paint25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        logAxis16.setTickMarkPaint(paint25);
        xYPlot6.setDomainZeroBaselinePaint(paint25);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        logAxis1.setBase((double) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        try {
            logAxis1.setAutoRangeMinimumSize(0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) logAxis10, valueAxis12, xYItemRenderer13);
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot14.setDomainCrosshairPaint(paint15);
        java.awt.geom.Point2D point2D17 = xYPlot14.getQuadrantOrigin();
        try {
            org.jfree.chart.plot.XYPlot xYPlot18 = combinedDomainXYPlot6.findSubplot(plotRenderingInfo7, point2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(point2D17);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        double double15 = logAxis6.getSmallestValue();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-100d + "'", double15 == 1.0E-100d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        logAxis1.centerRange((double) 15);
        boolean boolean5 = logAxis1.isPositiveArrowVisible();
        logAxis1.resizeRange((double) 15);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator22 = null;
        xYStepAreaRenderer21.setBaseToolTipGenerator(xYToolTipGenerator22);
        java.awt.Shape shape25 = xYStepAreaRenderer21.lookupLegendShape(0);
        int int26 = xYPlot17.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer21);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) logAxis29, valueAxis31, xYItemRenderer32);
        java.awt.Paint paint34 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot33.setDomainCrosshairPaint(paint34);
        xYPlot17.setRangeGridlinePaint(paint34);
        java.lang.Number[][] numberArray39 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray39);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.LogAxis logAxis43 = new org.jfree.chart.axis.LogAxis("");
        float float44 = logAxis43.getMinorTickMarkInsideLength();
        java.awt.Font font45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis43.setTickLabelFont(font45);
        logAxis43.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, (org.jfree.chart.axis.ValueAxis) logAxis43, categoryItemRenderer50);
        double double53 = logAxis43.calculateLog((double) (-1.0f));
        int int54 = xYPlot17.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis43);
        xYPlot6.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) logAxis43, false);
        java.awt.Paint paint57 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setRangeGridlinePaint(paint57);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(numberArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 0.0f + "'", float44 == 0.0f);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(paint57);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparable0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        double double7 = logAxis1.calculateValue((double) (-1.0f));
        try {
            logAxis1.setSmallestValue(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'value' > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1d + "'", double7 == 0.1d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        boolean boolean12 = xYStepAreaRenderer1.removeAnnotation(xYAnnotation11);
        java.awt.Font font14 = xYStepAreaRenderer1.lookupLegendTextFont((int) (short) 0);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(font14);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        logAxis1.setTickLabelFont(font6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis16.setTickLabelFont(font18);
        logAxis16.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryItemRenderer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot24.getRangeAxisEdge((int) ' ');
        java.util.List list27 = periodAxis6.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge26);
        try {
            double double28 = dateAxis0.valueToJava2D(0.0d, rectangle2D2, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.lang.Object obj7 = xYPlot6.clone();
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot22.getRangeAxis();
        xYPlot6.setRangeAxis(valueAxis23);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
        xYPlot6.setDrawingSupplier(drawingSupplier25);
        xYPlot6.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(valueAxis23);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYStepAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator8);
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis16.setTickLabelFont(font18);
        logAxis16.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getOutlineStroke();
        xYStepAreaRenderer3.setBaseStroke(stroke25, false);
        xYStepAreaRenderer3.setShapesVisible(true);
        java.awt.Paint paint30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer3.setBaseOutlinePaint(paint30);
        org.jfree.chart.plot.PiePlot3D piePlot3D32 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double34 = rectangleInsets33.getRight();
        java.lang.String str35 = rectangleInsets33.toString();
        piePlot3D32.setSimpleLabelOffset(rectangleInsets33);
        java.awt.Stroke stroke37 = piePlot3D32.getBaseSectionOutlineStroke();
        java.awt.Paint paint38 = null;
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint30, stroke37, paint38, stroke39, (float) (byte) 1);
        java.awt.Paint paint42 = null;
        try {
            intervalMarker41.setPaint(paint42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str35.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        java.awt.Shape shape41 = categoryItemEntity40.getArea();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(shape41);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        logAxis1.setFixedDimension((double) 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer22.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
        xYStepAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator27);
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis35.setTickLabelFont(font37);
        logAxis35.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) logAxis35, categoryItemRenderer42);
        java.awt.Stroke stroke44 = categoryPlot43.getOutlineStroke();
        xYStepAreaRenderer22.setBaseStroke(stroke44, false);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) xYStepAreaRenderer22);
        org.jfree.chart.util.SortOrder sortOrder48 = null;
        try {
            categoryPlot18.setColumnRenderingOrder(sortOrder48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-447), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) 1, 0.0d, (double) (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) textBlockAnchor0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("ClassContext", "DatasetRenderingOrder.FORWARD", "Jan", "hi!");
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            labelBlock1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        state1.setLastPointGood(false);
        java.awt.geom.GeneralPath generalPath4 = state1.seriesPath;
        org.junit.Assert.assertNull(generalPath4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        java.lang.String str2 = rectangleInsets0.toString();
        java.lang.String str3 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createOutsetRectangle(rectangle2D4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str2.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray2 = new float[] { 3600000L };
        try {
            float[] floatArray3 = color0.getRGBComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        xYPlot6.mapDatasetToRangeAxis((int) '#', 0);
        xYPlot6.setRangeCrosshairValue((double) 10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder23 = xYPlot6.getSeriesRenderingOrder();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder23);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        periodAxis3.setLabelFont(font4);
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        float float13 = logAxis12.getMinorTickMarkInsideLength();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis12.setTickLabelFont(font14);
        logAxis12.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) logAxis12, categoryItemRenderer19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) logAxis23, valueAxis25, xYItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot27.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getDomainMarkers((int) 'a', layer31);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke36 = logAxis34.getTickMarkStroke();
        xYPlot27.setRangeGridlineStroke(stroke36);
        categoryPlot20.setDomainCrosshairStroke(stroke36);
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("");
        float float41 = logAxis40.getMinorTickMarkInsideLength();
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis40.setTickLabelFont(font42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = logAxis40.getStandardTickUnits();
        int int45 = categoryPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis40);
        categoryPlot20.setDrawSharedDomainAxis(false);
        boolean boolean48 = periodAxis3.hasListener((java.util.EventListener) categoryPlot20);
        try {
            periodAxis3.setAutoRangeMinimumSize((double) (-1.0f), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double10 = rectangleInsets9.getRight();
        java.lang.String str11 = rectangleInsets9.toString();
        java.lang.String str12 = rectangleInsets9.toString();
        double double13 = rectangleInsets9.getLeft();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets9);
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("");
        float float23 = logAxis22.getMinorTickMarkInsideLength();
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis22.setTickLabelFont(font24);
        logAxis22.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) logAxis22, categoryItemRenderer29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis("");
        float float34 = logAxis33.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) logAxis33, valueAxis35, xYItemRenderer36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot37.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot37.getDomainMarkers((int) 'a', layer41);
        org.jfree.chart.axis.LogAxis logAxis44 = new org.jfree.chart.axis.LogAxis("");
        float float45 = logAxis44.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke46 = logAxis44.getTickMarkStroke();
        xYPlot37.setRangeGridlineStroke(stroke46);
        categoryPlot30.setRangeZeroBaselineStroke(stroke46);
        categoryPlot30.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.LogAxis logAxis58 = new org.jfree.chart.axis.LogAxis("");
        float float59 = logAxis58.getMinorTickMarkInsideLength();
        java.awt.Font font60 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis58.setTickLabelFont(font60);
        logAxis58.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) logAxis58, categoryItemRenderer65);
        java.awt.Stroke stroke67 = categoryPlot66.getOutlineStroke();
        categoryPlot30.setDomainGridlineStroke(stroke67);
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 6, stroke67);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeries3.clear();
        xYSeries3.add(0.0d, (java.lang.Number) 0L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        state1.setLastPointGood(false);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState4 = null;
        state1.setCrosshairState(xYCrosshairState4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        xYSeriesCollection4.removeAllSeries();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) logAxis10, valueAxis12, xYItemRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers((int) 'a', layer18);
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke23 = logAxis21.getTickMarkStroke();
        xYPlot14.setRangeGridlineStroke(stroke23);
        java.awt.Paint paint25 = xYPlot14.getDomainCrosshairPaint();
        boolean boolean26 = xYSeriesCollection4.hasListener((java.util.EventListener) xYPlot14);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot14.setDataset(xYDataset27);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        logAxis1.centerRange((double) 15);
        boolean boolean5 = logAxis1.isPositiveArrowVisible();
        logAxis1.zoomRange(0.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator21 = null;
        xYStepAreaRenderer19.setBaseURLGenerator(xYURLGenerator21);
        java.awt.Paint paint24 = xYStepAreaRenderer19.getLegendTextPaint((int) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(paint24);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity40 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset26, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.chart.title.Title title41 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity44 = new org.jfree.chart.entity.TitleEntity(shape10, title41, "AxisLocation.TOP_OR_RIGHT", "AxisLocation.TOP_OR_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainUpperBound(true);
        try {
            timeSeriesCollection1.setSelected(0, (int) (short) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = xYSeriesCollection6.getGroup();
        java.lang.Object obj8 = xYSeriesCollection6.clone();
        boolean boolean9 = datasetRenderingOrder0.equals((java.lang.Object) xYSeriesCollection6);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean21 = org.jfree.chart.util.PaintUtilities.equal(paint18, paint20);
        boolean boolean22 = textAnchor10.equals((java.lang.Object) paint20);
        java.lang.Number[][] numberArray25 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis29.setTickLabelFont(font31);
        logAxis29.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, (org.jfree.chart.axis.ValueAxis) logAxis29, categoryItemRenderer36);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("");
        float float41 = logAxis40.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) logAxis40, valueAxis42, xYItemRenderer43);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot44.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = xYPlot44.getDomainMarkers((int) 'a', layer48);
        org.jfree.chart.axis.LogAxis logAxis51 = new org.jfree.chart.axis.LogAxis("");
        float float52 = logAxis51.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke53 = logAxis51.getTickMarkStroke();
        xYPlot44.setRangeGridlineStroke(stroke53);
        categoryPlot37.setDomainCrosshairStroke(stroke53);
        org.jfree.chart.axis.LogAxis logAxis57 = new org.jfree.chart.axis.LogAxis("");
        float float58 = logAxis57.getMinorTickMarkInsideLength();
        java.awt.Font font59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis57.setTickLabelFont(font59);
        org.jfree.chart.axis.TickUnitSource tickUnitSource61 = logAxis57.getStandardTickUnits();
        int int62 = categoryPlot37.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis57);
        categoryPlot37.setDrawSharedDomainAxis(false);
        boolean boolean65 = textAnchor10.equals((java.lang.Object) categoryPlot37);
        boolean boolean66 = datasetRenderingOrder0.equals((java.lang.Object) boolean65);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(datasetGroup7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.0f + "'", float52 == 0.0f);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.0f + "'", float58 == 0.0f);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(tickUnitSource61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0.0f, "", "hi!", false);
        logFormat4.setParseIntegerOnly(false);
        java.text.ParsePosition parsePosition8 = null;
        java.lang.Number number9 = logFormat4.parse("ThreadContext", parsePosition8);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        boolean boolean17 = xYPlot6.isDomainCrosshairVisible();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer22.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
        xYStepAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator27);
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis35.setTickLabelFont(font37);
        logAxis35.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) logAxis35, categoryItemRenderer42);
        java.awt.Stroke stroke44 = categoryPlot43.getOutlineStroke();
        xYStepAreaRenderer22.setBaseStroke(stroke44, false);
        xYStepAreaRenderer22.setShapesVisible(true);
        java.awt.Paint paint49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer22.setBaseOutlinePaint(paint49);
        org.jfree.chart.plot.PiePlot3D piePlot3D51 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double53 = rectangleInsets52.getRight();
        java.lang.String str54 = rectangleInsets52.toString();
        piePlot3D51.setSimpleLabelOffset(rectangleInsets52);
        java.awt.Stroke stroke56 = piePlot3D51.getBaseSectionOutlineStroke();
        java.awt.Paint paint57 = null;
        java.awt.Stroke stroke58 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint49, stroke56, paint57, stroke58, (float) (byte) 1);
        org.jfree.chart.util.Layer layer61 = null;
        try {
            xYPlot6.addDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) intervalMarker60, layer61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str54.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("AxisLocation.TOP_OR_RIGHT");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        boolean boolean12 = xYStepAreaRenderer1.removeAnnotation(xYAnnotation11);
        boolean boolean13 = xYStepAreaRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        boolean boolean12 = xYStepAreaRenderer1.removeAnnotation(xYAnnotation11);
        xYStepAreaRenderer1.setBaseCreateEntities(false, false);
        xYStepAreaRenderer1.setSeriesVisible(6, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double4 = xYSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        xYSeries3.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        double double8 = xYSeries3.getMaxY();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray16 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot14.setDomainAxes(categoryAxisArray16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot14.getDomainAxisEdge();
        categoryPlot14.setWeight((int) (byte) 100);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(categoryAxisArray16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            xYPlot6.addAnnotation(xYAnnotation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double10 = rectangleInsets9.getRight();
        java.lang.String str11 = rectangleInsets9.toString();
        java.lang.String str12 = rectangleInsets9.toString();
        double double13 = rectangleInsets9.getLeft();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets9);
        double double16 = rectangleInsets9.extendHeight((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 12.0d + "'", double16 == 12.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        xYSeries3.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        try {
            xYSeries3.updateByIndex((int) (byte) 1, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint8 = null;
        xYPlot6.setQuadrantPaint(1, paint8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        float float8 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) logAxis7, valueAxis9, xYItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot11.setDomainCrosshairPaint(paint12);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        xYStepAreaRenderer15.setBaseToolTipGenerator(xYToolTipGenerator16);
        java.awt.Shape shape19 = xYStepAreaRenderer15.lookupLegendShape(0);
        int int20 = xYPlot11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer15);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) logAxis23, valueAxis25, xYItemRenderer26);
        java.awt.Paint paint28 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot27.setDomainCrosshairPaint(paint28);
        xYPlot11.setRangeGridlinePaint(paint28);
        piePlot3D0.setLabelLinkPaint(paint28);
        java.awt.Stroke stroke32 = null;
        try {
            piePlot3D0.setLabelLinkStroke(stroke32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(function2D0, 0.0d, (double) 200, 3, (java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.lang.String str3 = rectangleEdge2.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.reserved(rectangle2D1, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.TOP" + "'", str3.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        java.awt.Paint paint2 = xYStepAreaRenderer1.getBaseFillPaint();
        java.awt.Paint paint3 = null;
        try {
            xYStepAreaRenderer1.setBaseOutlinePaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.CrosshairState crosshairState14 = null;
        boolean boolean15 = xYPlot6.render(graphics2D10, rectangle2D11, (int) '#', plotRenderingInfo13, crosshairState14);
        xYPlot6.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        boolean boolean36 = categoryPlot14.isRangeMinorGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("");
        float float41 = logAxis40.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset38, (org.jfree.chart.axis.ValueAxis) logAxis40, valueAxis42, xYItemRenderer43);
        java.lang.Object obj45 = xYPlot44.clone();
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis51 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day49, (org.jfree.data.time.RegularTimePeriod) day50);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.AxisState axisState53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        java.lang.Number[][] numberArray57 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray57);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.LogAxis logAxis61 = new org.jfree.chart.axis.LogAxis("");
        float float62 = logAxis61.getMinorTickMarkInsideLength();
        java.awt.Font font63 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis61.setTickLabelFont(font63);
        logAxis61.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer68 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, (org.jfree.chart.axis.ValueAxis) logAxis61, categoryItemRenderer68);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = categoryPlot69.getRangeAxisEdge((int) ' ');
        java.util.List list72 = periodAxis51.refreshTicks(graphics2D52, axisState53, rectangle2D54, rectangleEdge71);
        xYPlot44.drawDomainTickBands(graphics2D46, rectangle2D47, list72);
        try {
            categoryPlot14.mapDatasetToRangeAxes(4, list72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 0.0f + "'", float62 == 0.0f);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertNotNull(list72);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.lang.Object obj4 = standardXYToolTipGenerator3.clone();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        try {
            java.lang.String str8 = standardXYToolTipGenerator3.generateLabelString(xYDataset5, 15, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.Object obj15 = categoryPlot14.clone();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray16 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot14.setDomainAxes(categoryAxisArray16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot14.getDomainAxisEdge();
        boolean boolean19 = categoryPlot14.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(categoryAxisArray16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 0L;
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.lang.Comparable comparable1 = null;
        try {
            java.awt.Stroke stroke2 = strokeMap0.getStroke(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        piePlot3D0.setSimpleLabels(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double12 = rectangleInsets11.getRight();
        java.lang.String str13 = rectangleInsets11.toString();
        java.lang.String str14 = rectangleInsets11.toString();
        double double15 = rectangleInsets11.getLeft();
        piePlot3D0.setLabelPadding(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str13.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str14.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYStepAreaRenderer1.drawRangeMarker(graphics2D8, xYPlot9, valueAxis10, marker11, rectangle2D12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot21.setDomainCrosshairPaint(paint22);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYStepAreaRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26);
        java.awt.Shape shape29 = xYStepAreaRenderer25.lookupLegendShape(0);
        int int30 = xYPlot21.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer25);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis("");
        float float34 = logAxis33.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) logAxis33, valueAxis35, xYItemRenderer36);
        java.awt.Paint paint38 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot37.setDomainCrosshairPaint(paint38);
        xYPlot21.setRangeGridlinePaint(paint38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.AxisState axisState46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.LogAxis logAxis54 = new org.jfree.chart.axis.LogAxis("");
        float float55 = logAxis54.getMinorTickMarkInsideLength();
        java.awt.Font font56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis54.setTickLabelFont(font56);
        logAxis54.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) logAxis54, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getRangeAxisEdge((int) ' ');
        java.util.List list65 = periodAxis44.refreshTicks(graphics2D45, axisState46, rectangle2D47, rectangleEdge64);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray66 = null;
        periodAxis44.setLabelInfo(periodAxisLabelInfoArray66);
        java.lang.Class class68 = periodAxis44.getMinorTickTimePeriodClass();
        org.jfree.chart.plot.Marker marker69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYStepAreaRenderer1.drawRangeMarker(graphics2D14, xYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis44, marker69, rectangle2D70);
        org.jfree.chart.axis.AxisLocation axisLocation73 = xYPlot21.getDomainAxisLocation(4);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = xYPlot21.getRenderer();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.0f + "'", float55 == 0.0f);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertNotNull(axisLocation73);
        org.junit.Assert.assertNull(xYItemRenderer74);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = logAxis1.getStandardTickUnits();
        java.awt.Stroke stroke6 = null;
        try {
            logAxis1.setAxisLineStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        logAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis3.getFirst();
        periodAxis3.setLabel("Jan");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot17.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            org.jfree.chart.axis.AxisState axisState21 = periodAxis3.draw(graphics2D7, (double) 1, rectangle2D9, rectangle2D10, rectangleEdge19, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = xYSeriesCollection4.getGroup();
        java.lang.String str6 = datasetGroup5.getID();
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "NOID" + "'", str6.equals("NOID"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("Category Plot");
        java.lang.String str3 = basicProjectInfo0.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Category Plot" + "'", str3.equals("Category Plot"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.LogAxis logAxis52 = new org.jfree.chart.axis.LogAxis("");
        float float53 = logAxis52.getMinorTickMarkInsideLength();
        java.awt.Font font54 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis52.setTickLabelFont(font54);
        boolean boolean56 = logAxis52.isAutoRange();
        boolean boolean57 = logAxis52.isTickMarksVisible();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer58 = null;
        org.jfree.chart.plot.PolarPlot polarPlot59 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection4, (org.jfree.chart.axis.ValueAxis) logAxis52, polarItemRenderer58);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer60 = null;
        polarPlot59.setRenderer(polarItemRenderer60);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 0.0f + "'", float53 == 0.0f);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) boolean2, (java.lang.Object) timeSeries3);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        xYPlot6.mapDatasetToRangeAxis((int) '#', 0);
        xYPlot6.setRangeCrosshairValue((double) 10);
        xYPlot6.setNotify(true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long3 = segmentedTimeline1.toTimelineValue(0L);
        boolean boolean5 = segmentedTimeline1.containsDomainValue((long) 7);
        boolean boolean6 = itemLabelAnchor0.equals((java.lang.Object) 7);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577894400000L + "'", long3 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.END" + "'", str1.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long2 = segmentedTimeline0.toTimelineValue(0L);
        boolean boolean4 = segmentedTimeline0.containsDomainValue((long) 7);
        java.util.Date date5 = null;
        try {
            long long6 = segmentedTimeline0.toTimelineValue(date5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577894400000L + "'", long2 == 1577894400000L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0.0f, "", "hi!", false);
        int int5 = logFormat4.getMinimumIntegerDigits();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        java.awt.Paint paint40 = logAxis34.getTickLabelPaint();
        logAxis34.resizeRange2((double) (short) -1, (double) 2.0f);
        logAxis34.configure();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getTickLabelFont();
        try {
            dateAxis0.zoomRange((double) 128, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (128.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getLibraries();
        basicProjectInfo0.setInfo("TextAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        xYStepAreaRenderer19.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer25.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer25.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition34);
        xYStepAreaRenderer19.setBaseNegativeItemLabelPosition(itemLabelPosition34);
        java.awt.Paint paint38 = null;
        xYStepAreaRenderer19.setSeriesPaint(9999, paint38);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYStepAreaRenderer1.drawRangeMarker(graphics2D8, xYPlot9, valueAxis10, marker11, rectangle2D12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot21.setDomainCrosshairPaint(paint22);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYStepAreaRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26);
        java.awt.Shape shape29 = xYStepAreaRenderer25.lookupLegendShape(0);
        int int30 = xYPlot21.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer25);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis("");
        float float34 = logAxis33.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) logAxis33, valueAxis35, xYItemRenderer36);
        java.awt.Paint paint38 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot37.setDomainCrosshairPaint(paint38);
        xYPlot21.setRangeGridlinePaint(paint38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.AxisState axisState46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.LogAxis logAxis54 = new org.jfree.chart.axis.LogAxis("");
        float float55 = logAxis54.getMinorTickMarkInsideLength();
        java.awt.Font font56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis54.setTickLabelFont(font56);
        logAxis54.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) logAxis54, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getRangeAxisEdge((int) ' ');
        java.util.List list65 = periodAxis44.refreshTicks(graphics2D45, axisState46, rectangle2D47, rectangleEdge64);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray66 = null;
        periodAxis44.setLabelInfo(periodAxisLabelInfoArray66);
        java.lang.Class class68 = periodAxis44.getMinorTickTimePeriodClass();
        org.jfree.chart.plot.Marker marker69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYStepAreaRenderer1.drawRangeMarker(graphics2D14, xYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis44, marker69, rectangle2D70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = periodAxis44.getFirst();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.0f + "'", float55 == 0.0f);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        java.lang.String str2 = rectangleInsets0.toString();
        java.lang.String str3 = rectangleInsets0.toString();
        double double4 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createOutsetRectangle(rectangle2D5, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str2.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.text.DateFormat dateFormat6 = null;
        java.text.DateFormat dateFormat7 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat6, dateFormat7);
        try {
            xYStepAreaRenderer1.setSeriesToolTipGenerator((int) (short) -1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        categoryPlot18.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepAreaRenderer29.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator34 = null;
        xYStepAreaRenderer29.setLegendItemURLGenerator(xYSeriesLabelGenerator34);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        java.awt.Stroke stroke51 = categoryPlot50.getOutlineStroke();
        xYStepAreaRenderer29.setBaseStroke(stroke51, false);
        xYStepAreaRenderer29.setShapesVisible(true);
        java.awt.Paint paint56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer29.setBaseOutlinePaint(paint56);
        org.jfree.chart.plot.PiePlot3D piePlot3D58 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double60 = rectangleInsets59.getRight();
        java.lang.String str61 = rectangleInsets59.toString();
        piePlot3D58.setSimpleLabelOffset(rectangleInsets59);
        java.awt.Stroke stroke63 = piePlot3D58.getBaseSectionOutlineStroke();
        java.awt.Paint paint64 = null;
        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker67 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint56, stroke63, paint64, stroke65, (float) (byte) 1);
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean69 = categoryPlot18.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker67, layer68);
        float float70 = intervalMarker67.getAlpha();
        org.jfree.data.xy.XYDataset xYDataset71 = null;
        org.jfree.chart.axis.LogAxis logAxis73 = new org.jfree.chart.axis.LogAxis("");
        float float74 = logAxis73.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer76 = null;
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot(xYDataset71, (org.jfree.chart.axis.ValueAxis) logAxis73, valueAxis75, xYItemRenderer76);
        java.awt.Paint paint78 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot77.setDomainCrosshairPaint(paint78);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer81 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator82 = null;
        xYStepAreaRenderer81.setBaseToolTipGenerator(xYToolTipGenerator82);
        java.awt.Shape shape85 = xYStepAreaRenderer81.lookupLegendShape(0);
        int int86 = xYPlot77.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer81);
        java.awt.Stroke stroke87 = xYPlot77.getDomainGridlineStroke();
        intervalMarker67.setOutlineStroke(stroke87);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str61.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 0.0f + "'", float74 == 0.0f);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
        org.junit.Assert.assertNotNull(stroke87);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer1.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition10);
        java.awt.Paint paint15 = xYStepAreaRenderer1.getItemOutlinePaint((int) (byte) 1, 12, true);
        java.lang.Boolean boolean17 = xYStepAreaRenderer1.getSeriesVisible((int) (short) 100);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeries3.clear();
        double[][] doubleArray6 = xYSeries3.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        categoryPlot14.setFixedRangeAxisSpace(axisSpace40, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation43 = null;
        try {
            categoryPlot14.addAnnotation(categoryAnnotation43, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot3D0.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D0.getSimpleLabelOffset();
        java.lang.Comparable comparable11 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        float float16 = logAxis15.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) logAxis15, valueAxis17, xYItemRenderer18);
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot19.setDomainCrosshairPaint(paint20);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean23 = org.jfree.chart.util.PaintUtilities.equal(paint20, paint22);
        boolean boolean24 = textAnchor12.equals((java.lang.Object) paint22);
        try {
            piePlot3D0.setSectionOutlinePaint(comparable11, paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainUpperBound(true);
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) logAxis21, valueAxis23, xYItemRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot25.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot25.getDomainMarkers((int) 'a', layer29);
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke34 = logAxis32.getTickMarkStroke();
        xYPlot25.setRangeGridlineStroke(stroke34);
        categoryPlot18.setDomainCrosshairStroke(stroke34);
        org.jfree.chart.axis.LogAxis logAxis38 = new org.jfree.chart.axis.LogAxis("");
        float float39 = logAxis38.getMinorTickMarkInsideLength();
        java.awt.Font font40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis38.setTickLabelFont(font40);
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = logAxis38.getStandardTickUnits();
        int int43 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis38);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("");
        float float47 = logAxis46.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) logAxis46, valueAxis48, xYItemRenderer49);
        java.awt.Paint paint51 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot50.setDomainCrosshairPaint(paint51);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator55 = null;
        xYStepAreaRenderer54.setBaseToolTipGenerator(xYToolTipGenerator55);
        java.awt.Shape shape58 = xYStepAreaRenderer54.lookupLegendShape(0);
        int int59 = xYPlot50.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer54);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.LogAxis logAxis62 = new org.jfree.chart.axis.LogAxis("");
        float float63 = logAxis62.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) logAxis62, valueAxis64, xYItemRenderer65);
        java.awt.Paint paint67 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot66.setDomainCrosshairPaint(paint67);
        xYPlot50.setRangeGridlinePaint(paint67);
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray72);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = null;
        org.jfree.chart.axis.LogAxis logAxis76 = new org.jfree.chart.axis.LogAxis("");
        float float77 = logAxis76.getMinorTickMarkInsideLength();
        java.awt.Font font78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis76.setTickLabelFont(font78);
        logAxis76.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer83 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, (org.jfree.chart.axis.ValueAxis) logAxis76, categoryItemRenderer83);
        double double86 = logAxis76.calculateLog((double) (-1.0f));
        int int87 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
        int int88 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
        java.util.List list89 = categoryPlot18.getCategories();
        org.jfree.data.time.DateRange dateRange90 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range92 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list89, (org.jfree.data.Range) dateRange90, false);
        try {
            timeSeriesCollection1.setSelected(9999, 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (9999).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 0.0f + "'", float63 == 0.0f);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.0f + "'", float77 == 0.0f);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertNotNull(list89);
        org.junit.Assert.assertNotNull(dateRange90);
        org.junit.Assert.assertNull(range92);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1577894400000L);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYStepAreaRenderer8.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer8.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape17 = xYStepAreaRenderer8.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        float float21 = logAxis20.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) logAxis20, valueAxis22, xYItemRenderer23);
        java.awt.Paint paint25 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot24.setDomainCrosshairPaint(paint25);
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape17, paint25);
        java.lang.Number[][] numberArray32 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.LogAxis logAxis36 = new org.jfree.chart.axis.LogAxis("");
        float float37 = logAxis36.getMinorTickMarkInsideLength();
        java.awt.Font font38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis36.setTickLabelFont(font38);
        logAxis36.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) logAxis36, categoryItemRenderer43);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity47 = new org.jfree.chart.entity.CategoryItemEntity(shape17, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset33, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        boolean boolean48 = org.jfree.chart.util.ShapeUtilities.equal(shape6, shape17);
        multiplePiePlot4.setLegendItemShape(shape6);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.0f + "'", float37 == 0.0f);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.util.PaintMap paintMap0 = new org.jfree.chart.util.PaintMap();
        boolean boolean2 = paintMap0.containsKey((java.lang.Comparable) "Jan");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day4, (org.jfree.data.time.RegularTimePeriod) day5);
        int int7 = day5.getMonth();
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot12 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset11);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYStepAreaRenderer14.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer14.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape23 = xYStepAreaRenderer14.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("");
        float float27 = logAxis26.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) logAxis26, valueAxis28, xYItemRenderer29);
        java.awt.Paint paint31 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot30.setDomainCrosshairPaint(paint31);
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape23, paint31);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity53 = new org.jfree.chart.entity.CategoryItemEntity(shape23, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset39, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        multiplePiePlot12.setLegendItemShape(shape23);
        java.awt.Paint paint55 = multiplePiePlot12.getAggregatedItemsPaint();
        paintMap0.put((java.lang.Comparable) int7, paint55);
        java.awt.Color color60 = java.awt.Color.orange;
        java.awt.Color color61 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", color60);
        java.awt.Color color62 = java.awt.Color.getColor("hi!", color60);
        paintMap0.put((java.lang.Comparable) 8.0d, (java.awt.Paint) color62);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        java.awt.Paint paint40 = logAxis34.getTickLabelPaint();
        logAxis34.resizeRange2((double) (short) -1, (double) 2.0f);
        double double44 = logAxis34.getFixedAutoRange();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition();
        double double17 = itemLabelPosition16.getAngle();
        xYStepAreaRenderer10.setBaseNegativeItemLabelPosition(itemLabelPosition16, false);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = null;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = periodAxis25.getFirst();
        periodAxis25.setLabel("Jan");
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        xYStepAreaRenderer10.drawDomainGridLine(graphics2D20, xYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis25, rectangle2D29, (double) 12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        float float8 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) logAxis7, valueAxis9, xYItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot11.setDomainCrosshairPaint(paint12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean15 = org.jfree.chart.util.PaintUtilities.equal(paint12, paint14);
        boolean boolean16 = textAnchor4.equals((java.lang.Object) paint14);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) logAxis21, valueAxis23, xYItemRenderer24);
        java.awt.Paint paint26 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot25.setDomainCrosshairPaint(paint26);
        java.awt.Paint paint28 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean29 = org.jfree.chart.util.PaintUtilities.equal(paint26, paint28);
        boolean boolean30 = textAnchor18.equals((java.lang.Object) paint28);
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.LogAxis logAxis37 = new org.jfree.chart.axis.LogAxis("");
        float float38 = logAxis37.getMinorTickMarkInsideLength();
        java.awt.Font font39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis37.setTickLabelFont(font39);
        logAxis37.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) logAxis37, categoryItemRenderer44);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.LogAxis logAxis48 = new org.jfree.chart.axis.LogAxis("");
        float float49 = logAxis48.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) logAxis48, valueAxis50, xYItemRenderer51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot52.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = xYPlot52.getDomainMarkers((int) 'a', layer56);
        org.jfree.chart.axis.LogAxis logAxis59 = new org.jfree.chart.axis.LogAxis("");
        float float60 = logAxis59.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke61 = logAxis59.getTickMarkStroke();
        xYPlot52.setRangeGridlineStroke(stroke61);
        categoryPlot45.setDomainCrosshairStroke(stroke61);
        org.jfree.chart.axis.LogAxis logAxis65 = new org.jfree.chart.axis.LogAxis("");
        float float66 = logAxis65.getMinorTickMarkInsideLength();
        java.awt.Font font67 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis65.setTickLabelFont(font67);
        org.jfree.chart.axis.TickUnitSource tickUnitSource69 = logAxis65.getStandardTickUnits();
        int int70 = categoryPlot45.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis65);
        categoryPlot45.setDrawSharedDomainAxis(false);
        boolean boolean73 = textAnchor18.equals((java.lang.Object) categoryPlot45);
        java.lang.String str74 = textAnchor18.toString();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", graphics2D1, (float) (-2208960000000L), (float) '#', textAnchor4, 0.05d, textAnchor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.0f + "'", float38 == 0.0f);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 0.0f + "'", float49 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.0f + "'", float60 == 0.0f);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 0.0f + "'", float66 == 0.0f);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(tickUnitSource69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str74.equals("TextAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        categoryPlot14.setDrawSharedDomainAxis(false);
        categoryPlot14.setRangeMinorGridlinesVisible(false);
        boolean boolean44 = categoryPlot14.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        java.lang.Object obj6 = null;
        boolean boolean7 = piePlot3D0.equals(obj6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState13 = piePlot3D0.initialise(graphics2D8, rectangle2D9, piePlot10, (java.lang.Integer) 200, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        try {
            combinedDomainXYPlot6.zoomRangeAxes((double) (-1), (double) (short) 100, plotRenderingInfo9, point2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Font font3 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint5 = xYStepAreaRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.DARK_GRAY;
        xYStepAreaRenderer0.setBaseOutlinePaint((java.awt.Paint) color6);
        float[] floatArray10 = new float[] { (byte) 100, 1577894400000L };
        try {
            float[] floatArray11 = color6.getRGBColorComponents(floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str1 = rectangleConstraint0.toString();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range5 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange2, (double) 2, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint0.toRangeWidth(range5);
        java.lang.String str7 = rectangleConstraint6.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str1.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=0.0]" + "'", str7.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=0.0]"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        java.awt.Stroke stroke23 = categoryPlot22.getOutlineStroke();
        xYStepAreaRenderer1.setBaseStroke(stroke23, false);
        xYStepAreaRenderer1.setShapesVisible(true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator28 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYStepAreaRenderer1.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator28);
        java.awt.Shape shape31 = xYStepAreaRenderer1.getLegendShape(10);
        boolean boolean33 = xYStepAreaRenderer1.isSeriesVisible(3);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator21 = null;
        xYStepAreaRenderer19.setBaseURLGenerator(xYURLGenerator21);
        java.awt.Paint paint24 = null;
        xYStepAreaRenderer19.setSeriesFillPaint(200, paint24, true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        xYPlot6.mapDatasetToRangeAxis((int) '#', 0);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = xYPlot6.getRangeMarkers(layer21);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot6.getRangeAxisForDataset(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 9999 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.awt.Paint paint8 = piePlot3D0.getSectionPaint((java.lang.Comparable) year6);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D0.setSectionOutlineStroke((java.lang.Comparable) 0.05d, stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str1 = rectangleConstraint0.toString();
        org.jfree.data.Range range2 = rectangleConstraint0.getWidthRange();
        double double3 = rectangleConstraint0.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str1.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        boolean boolean21 = legendGraphic20.isShapeFilled();
        double double22 = legendGraphic20.getContentXOffset();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = null;
        xYStepAreaRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator8, false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis13.setTickLabelFont(font15);
        logAxis13.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) logAxis13, categoryItemRenderer20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.LogAxis logAxis24 = new org.jfree.chart.axis.LogAxis("");
        float float25 = logAxis24.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) logAxis24, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = xYPlot28.getDomainMarkers((int) 'a', layer32);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke37 = logAxis35.getTickMarkStroke();
        xYPlot28.setRangeGridlineStroke(stroke37);
        categoryPlot21.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        org.jfree.chart.axis.TickUnitSource tickUnitSource45 = logAxis41.getStandardTickUnits();
        int int46 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis41);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace47, false);
        boolean boolean50 = xYSeriesCollection4.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.AxisSpace axisSpace51 = new org.jfree.chart.axis.AxisSpace();
        java.lang.String str52 = axisSpace51.toString();
        categoryPlot21.setFixedDomainAxisSpace(axisSpace51, true);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(tickUnitSource45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.POSITIVE" + "'", str1.equals("RangeType.POSITIVE"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getXFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "Pie 3D Plot");
        java.lang.String str3 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0.0f, "", "hi!", false);
        logFormat4.setMinimumIntegerDigits((int) '4');
        java.awt.Paint[] paintArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        try {
            java.lang.StringBuffer stringBuffer10 = logFormat4.format((java.lang.Object) paintArray7, stringBuffer8, fieldPosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paintArray7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Paint paint4 = xYStepAreaRenderer1.getBasePaint();
        java.lang.Boolean boolean6 = xYStepAreaRenderer1.getSeriesCreateEntities(3);
        xYStepAreaRenderer1.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) '4');
        int int3 = dateTickUnit2.getRollMultiple();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = dateTickUnit2.getRollUnitType();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) '4', dateTickUnitType2, (int) (byte) 10, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        int int2 = objectList1.size();
        int int3 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        numberFormat0.setMaximumFractionDigits(1);
        java.math.RoundingMode roundingMode3 = null;
        try {
            numberFormat0.setRoundingMode(roundingMode3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        java.awt.Paint paint2 = xYStepAreaRenderer1.getBaseFillPaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot9.setDomainCrosshairPaint(paint10);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator14 = null;
        xYStepAreaRenderer13.setBaseToolTipGenerator(xYToolTipGenerator14);
        java.awt.Shape shape17 = xYStepAreaRenderer13.lookupLegendShape(0);
        int int18 = xYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        double double20 = itemLabelPosition19.getAngle();
        xYStepAreaRenderer13.setBaseNegativeItemLabelPosition(itemLabelPosition19, false);
        xYStepAreaRenderer1.setBaseNegativeItemLabelPosition(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYStepAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator8);
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis16.setTickLabelFont(font18);
        logAxis16.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getOutlineStroke();
        xYStepAreaRenderer3.setBaseStroke(stroke25, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = null;
        xYStepAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator28, true);
        combinedRangeXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer3);
        double double32 = combinedRangeXYPlot1.getGap();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 5.0d + "'", double32 == 5.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
        java.text.DateFormat dateFormat4 = standardXYToolTipGenerator3.getXDateFormat();
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        java.awt.Stroke stroke23 = categoryPlot22.getOutlineStroke();
        xYStepAreaRenderer1.setBaseStroke(stroke23, false);
        xYStepAreaRenderer1.setShapesVisible(true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator28 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYStepAreaRenderer1.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator28);
        java.awt.Shape shape31 = xYStepAreaRenderer1.getLegendShape(10);
        xYStepAreaRenderer1.setBaseItemLabelsVisible(true, true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(shape31);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainUpperBound(true);
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) logAxis21, valueAxis23, xYItemRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot25.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot25.getDomainMarkers((int) 'a', layer29);
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke34 = logAxis32.getTickMarkStroke();
        xYPlot25.setRangeGridlineStroke(stroke34);
        categoryPlot18.setDomainCrosshairStroke(stroke34);
        org.jfree.chart.axis.LogAxis logAxis38 = new org.jfree.chart.axis.LogAxis("");
        float float39 = logAxis38.getMinorTickMarkInsideLength();
        java.awt.Font font40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis38.setTickLabelFont(font40);
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = logAxis38.getStandardTickUnits();
        int int43 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis38);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("");
        float float47 = logAxis46.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) logAxis46, valueAxis48, xYItemRenderer49);
        java.awt.Paint paint51 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot50.setDomainCrosshairPaint(paint51);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator55 = null;
        xYStepAreaRenderer54.setBaseToolTipGenerator(xYToolTipGenerator55);
        java.awt.Shape shape58 = xYStepAreaRenderer54.lookupLegendShape(0);
        int int59 = xYPlot50.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer54);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.LogAxis logAxis62 = new org.jfree.chart.axis.LogAxis("");
        float float63 = logAxis62.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) logAxis62, valueAxis64, xYItemRenderer65);
        java.awt.Paint paint67 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot66.setDomainCrosshairPaint(paint67);
        xYPlot50.setRangeGridlinePaint(paint67);
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray72);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = null;
        org.jfree.chart.axis.LogAxis logAxis76 = new org.jfree.chart.axis.LogAxis("");
        float float77 = logAxis76.getMinorTickMarkInsideLength();
        java.awt.Font font78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis76.setTickLabelFont(font78);
        logAxis76.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer83 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, (org.jfree.chart.axis.ValueAxis) logAxis76, categoryItemRenderer83);
        double double86 = logAxis76.calculateLog((double) (-1.0f));
        int int87 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
        int int88 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
        java.util.List list89 = categoryPlot18.getCategories();
        org.jfree.data.time.DateRange dateRange90 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range92 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list89, (org.jfree.data.Range) dateRange90, false);
        java.util.Date date93 = dateRange90.getUpperDate();
        long long94 = dateRange90.getUpperMillis();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 0.0f + "'", float63 == 0.0f);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.0f + "'", float77 == 0.0f);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertNotNull(list89);
        org.junit.Assert.assertNotNull(dateRange90);
        org.junit.Assert.assertNull(range92);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 1L + "'", long94 == 1L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = xYSeriesCollection4.getGroup();
        java.lang.Object obj6 = xYSeriesCollection4.clone();
        double double7 = xYSeriesCollection4.getIntervalPositionFactor();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        xYItemRendererState1.startSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection6, 7, 0, (int) (byte) 100, (int) 'a', (int) '4');
        org.jfree.data.xy.XYSeries xYSeries16 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double17 = xYSeries16.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeSeries18);
        xYSeries16.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection19);
        xYItemRendererState1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection19);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState22 = null;
        xYItemRendererState1.setSelectionState(xYDatasetSelectionState22);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = xYSeriesCollection4.getRangeBounds(false);
        xYSeriesCollection4.setIntervalWidth(2.0d);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        categoryPlot18.setDomainCrosshairRowKey((java.lang.Comparable) 1, true);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        xYStepAreaRenderer19.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer25.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer25.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition34);
        xYStepAreaRenderer19.setBaseNegativeItemLabelPosition(itemLabelPosition34);
        java.lang.Object obj37 = null;
        boolean boolean38 = itemLabelPosition34.equals(obj37);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor39 = itemLabelPosition34.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor39);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        dateAxis0.setRange((double) 0L, (double) 200);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.Comparable comparable2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        java.lang.Object obj10 = xYPlot9.clone();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis16 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day14, (org.jfree.data.time.RegularTimePeriod) day15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("");
        float float27 = logAxis26.getMinorTickMarkInsideLength();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis26.setTickLabelFont(font28);
        logAxis26.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) logAxis26, categoryItemRenderer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getRangeAxisEdge((int) ' ');
        java.util.List list37 = periodAxis16.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge36);
        xYPlot9.drawDomainTickBands(graphics2D11, rectangle2D12, list37);
        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYPlot9.setRangeGridlinePaint(paint39);
        try {
            piePlot1.setSectionOutlinePaint(comparable2, paint39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, false);
        xYSeriesCollection4.removeAllSeries();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) logAxis10, valueAxis12, xYItemRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot14.getDomainMarkers((int) 'a', layer18);
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke23 = logAxis21.getTickMarkStroke();
        xYPlot14.setRangeGridlineStroke(stroke23);
        java.awt.Paint paint25 = xYPlot14.getDomainCrosshairPaint();
        boolean boolean26 = xYSeriesCollection4.hasListener((java.util.EventListener) xYPlot14);
        org.jfree.data.general.DatasetGroup datasetGroup27 = xYSeriesCollection4.getGroup();
        java.lang.String str28 = datasetGroup27.getID();
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetGroup27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "NOID" + "'", str28.equals("NOID"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.lang.String str15 = categoryPlot14.getPlotType();
        java.awt.Paint paint16 = categoryPlot14.getRangeGridlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean18 = categoryPlot14.removeAnnotation(categoryAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot6.setDataset((int) (byte) 10, xYDataset8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.CrosshairState crosshairState14 = null;
        boolean boolean15 = xYPlot6.render(graphics2D10, rectangle2D11, (int) '#', plotRenderingInfo13, crosshairState14);
        boolean boolean16 = xYPlot6.canSelectByRegion();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        int int2 = objectList1.size();
        java.lang.Object obj4 = objectList1.get((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = categoryPlot14.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset43 = categoryPlot14.getDataset();
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset43, 0.0d);
        java.lang.Number number46 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset43);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertNull(number46);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState1 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState2 = xYItemRendererState1.getCrosshairState();
        org.junit.Assert.assertNull(xYCrosshairState2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        numberFormat0.setParseIntegerOnly(true);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("ThreadContext", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.text.NumberFormat numberFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", numberFormat1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'xFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.util.Date date0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.configure();
        java.util.TimeZone timeZone3 = dateAxis1.getTimeZone();
        java.util.Locale locale4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date0, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        java.awt.Color color36 = java.awt.Color.CYAN;
        categoryPlot14.setRangeMinorGridlinePaint((java.awt.Paint) color36);
        java.lang.Number[][] numberArray40 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray40);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset41, false);
        int int44 = categoryPlot14.indexOf(categoryDataset41);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(numberArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Paint paint4 = xYStepAreaRenderer1.getBasePaint();
        java.lang.Boolean boolean6 = xYStepAreaRenderer1.getSeriesCreateEntities(3);
        java.lang.Object obj7 = null;
        boolean boolean8 = xYStepAreaRenderer1.equals(obj7);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.shrink(rectangle2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double4 = xYSeries3.getMaxY();
        xYSeries3.add((java.lang.Number) 1, (java.lang.Number) 1L, false);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        categoryPlot18.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepAreaRenderer29.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator34 = null;
        xYStepAreaRenderer29.setLegendItemURLGenerator(xYSeriesLabelGenerator34);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        java.awt.Stroke stroke51 = categoryPlot50.getOutlineStroke();
        xYStepAreaRenderer29.setBaseStroke(stroke51, false);
        xYStepAreaRenderer29.setShapesVisible(true);
        java.awt.Paint paint56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer29.setBaseOutlinePaint(paint56);
        org.jfree.chart.plot.PiePlot3D piePlot3D58 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double60 = rectangleInsets59.getRight();
        java.lang.String str61 = rectangleInsets59.toString();
        piePlot3D58.setSimpleLabelOffset(rectangleInsets59);
        java.awt.Stroke stroke63 = piePlot3D58.getBaseSectionOutlineStroke();
        java.awt.Paint paint64 = null;
        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker67 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint56, stroke63, paint64, stroke65, (float) (byte) 1);
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean69 = categoryPlot18.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker67, layer68);
        float float70 = intervalMarker67.getAlpha();
        java.lang.String str71 = intervalMarker67.getLabel();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str61.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNull(str71);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 0.0f, "", "hi!", false);
        java.lang.Object obj5 = logFormat4.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        java.awt.Font font2 = null;
        xYStepAreaRenderer1.setBaseLegendTextFont(font2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainUpperBound(true);
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) logAxis21, valueAxis23, xYItemRenderer24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot25.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = xYPlot25.getDomainMarkers((int) 'a', layer29);
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke34 = logAxis32.getTickMarkStroke();
        xYPlot25.setRangeGridlineStroke(stroke34);
        categoryPlot18.setDomainCrosshairStroke(stroke34);
        org.jfree.chart.axis.LogAxis logAxis38 = new org.jfree.chart.axis.LogAxis("");
        float float39 = logAxis38.getMinorTickMarkInsideLength();
        java.awt.Font font40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis38.setTickLabelFont(font40);
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = logAxis38.getStandardTickUnits();
        int int43 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis38);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.LogAxis logAxis46 = new org.jfree.chart.axis.LogAxis("");
        float float47 = logAxis46.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) logAxis46, valueAxis48, xYItemRenderer49);
        java.awt.Paint paint51 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot50.setDomainCrosshairPaint(paint51);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer54 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator55 = null;
        xYStepAreaRenderer54.setBaseToolTipGenerator(xYToolTipGenerator55);
        java.awt.Shape shape58 = xYStepAreaRenderer54.lookupLegendShape(0);
        int int59 = xYPlot50.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer54);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.LogAxis logAxis62 = new org.jfree.chart.axis.LogAxis("");
        float float63 = logAxis62.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset60, (org.jfree.chart.axis.ValueAxis) logAxis62, valueAxis64, xYItemRenderer65);
        java.awt.Paint paint67 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot66.setDomainCrosshairPaint(paint67);
        xYPlot50.setRangeGridlinePaint(paint67);
        java.lang.Number[][] numberArray72 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray72);
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = null;
        org.jfree.chart.axis.LogAxis logAxis76 = new org.jfree.chart.axis.LogAxis("");
        float float77 = logAxis76.getMinorTickMarkInsideLength();
        java.awt.Font font78 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis76.setTickLabelFont(font78);
        logAxis76.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer83 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, (org.jfree.chart.axis.ValueAxis) logAxis76, categoryItemRenderer83);
        double double86 = logAxis76.calculateLog((double) (-1.0f));
        int int87 = xYPlot50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
        int int88 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis76);
        java.util.List list89 = categoryPlot18.getCategories();
        org.jfree.data.time.DateRange dateRange90 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range92 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list89, (org.jfree.data.Range) dateRange90, false);
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeries timeSeries94 = timeSeriesCollection1.getSeries((java.lang.Comparable) day93);
        java.util.Calendar calendar95 = null;
        try {
            long long96 = day93.getFirstMillisecond(calendar95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.0f + "'", float39 == 0.0f);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.0f + "'", float47 == 0.0f);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + float63 + "' != '" + 0.0f + "'", float63 == 0.0f);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(numberArray72);
        org.junit.Assert.assertNotNull(categoryDataset73);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 0.0f + "'", float77 == 0.0f);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertNotNull(list89);
        org.junit.Assert.assertNotNull(dateRange90);
        org.junit.Assert.assertNull(range92);
        org.junit.Assert.assertNull(timeSeries94);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainUpperBound(true);
        try {
            timeSeriesCollection1.setSelected(15, (int) ' ', false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (15).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateRightInset((double) 2147483647);
        double double4 = rectangleInsets0.getTop();
        double double6 = rectangleInsets0.calculateBottomOutset((double) 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
        java.awt.Stroke stroke2 = strokeMap0.getStroke((java.lang.Comparable) "RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=0.0]");
        boolean boolean4 = strokeMap0.containsKey((java.lang.Comparable) "Pie 3D Plot");
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.awt.Stroke stroke2 = combinedRangeXYPlot1.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        categoryPlot14.setDrawSharedDomainAxis(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = categoryPlot14.getOrientation();
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot14.getDomainMarkers((int) '#', layer44);
        categoryPlot14.setRangeCrosshairVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent48 = null;
        categoryPlot14.rendererChanged(rendererChangeEvent48);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNull(collection45);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraint[RectangleConstraintType.RANGE: width=1.0, height=0.0]");
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 2704953600000L);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        xYStepAreaRenderer19.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        xYStepAreaRenderer19.setRangeBase((double) 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Paint paint3 = standardChartTheme1.getAxisLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis3.getFirst();
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo5 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray6 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo5 };
        periodAxis3.setLabelInfo(periodAxisLabelInfoArray6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) day10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis21.setTickLabelFont(font23);
        logAxis21.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) logAxis21, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getRangeAxisEdge((int) ' ');
        java.util.List list32 = periodAxis11.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge31);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray33 = null;
        periodAxis11.setLabelInfo(periodAxisLabelInfoArray33);
        java.lang.Class class35 = periodAxis11.getMinorTickTimePeriodClass();
        periodAxis3.setMinorTickTimePeriodClass(class35);
        double double37 = periodAxis3.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray6);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0E-8d + "'", double37 == 1.0E-8d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setRangeZeroBaselineStroke(stroke30);
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        java.awt.Stroke stroke51 = categoryPlot50.getOutlineStroke();
        categoryPlot14.setDomainGridlineStroke(stroke51);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent53 = null;
        categoryPlot14.axisChanged(axisChangeEvent53);
        int int55 = categoryPlot14.getDatasetCount();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimeSeries timeSeries0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeSeries0);
        double double3 = timeSeriesCollection1.getDomainUpperBound(true);
        java.util.List list4 = timeSeriesCollection1.getSeries();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState5 = timeSeriesCollection1.getSelectionState();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        java.lang.Comparable comparable1 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, comparable1, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot9.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot9.getRenderer();
        java.awt.Paint paint13 = xYPlot9.getRangeGridlinePaint();
        standardChartTheme1.setTickLabelPaint(paint13);
        java.awt.Paint paint15 = standardChartTheme1.getTitlePaint();
        java.awt.Paint paint16 = standardChartTheme1.getGridBandPaint();
        java.awt.Paint paint17 = standardChartTheme1.getGridBandAlternatePaint();
        java.awt.Paint paint18 = standardChartTheme1.getCrosshairPaint();
        java.awt.Font font19 = standardChartTheme1.getRegularFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot3D0.getLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D0.getSimpleLabelOffset();
        piePlot3D0.setLabelLinksVisible(false);
        java.awt.Stroke stroke13 = piePlot3D0.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        categoryPlot18.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot18.getRangeAxis();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(valueAxis25);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYStepAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator8);
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis16.setTickLabelFont(font18);
        logAxis16.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getOutlineStroke();
        xYStepAreaRenderer3.setBaseStroke(stroke25, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = null;
        xYStepAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator28, true);
        combinedRangeXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer3);
        combinedRangeXYPlot1.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        float float2 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5f + "'", float2 == 0.5f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = xYSeriesCollection6.getGroup();
        java.lang.Object obj8 = xYSeriesCollection6.clone();
        boolean boolean9 = datasetRenderingOrder0.equals((java.lang.Object) xYSeriesCollection6);
        java.awt.Paint[] paintArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean11 = datasetRenderingOrder0.equals((java.lang.Object) paintArray10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(datasetGroup7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        float float10 = logAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) logAxis9, valueAxis11, xYItemRenderer12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot13.setDomainCrosshairPaint(paint14);
        java.awt.Paint paint17 = null;
        xYPlot13.setQuadrantPaint((int) (short) 0, paint17);
        combinedDomainXYPlot6.remove(xYPlot13);
        java.lang.String str20 = xYPlot13.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        java.lang.Object obj6 = null;
        boolean boolean7 = piePlot3D0.equals(obj6);
        piePlot3D0.setAutoPopulateSectionPaint(true);
        piePlot3D0.setIgnoreZeroValues(true);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot3D0.getLabelGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str1.equals("SeriesRenderingOrder.FORWARD"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        xYStepAreaRenderer19.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer25.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer25.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition34);
        xYStepAreaRenderer19.setBaseNegativeItemLabelPosition(itemLabelPosition34);
        java.awt.Paint paint37 = null;
        try {
            xYStepAreaRenderer19.setBaseOutlinePaint(paint37, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.BOTTOM_RIGHT", graphics2D1, 100.0f, (float) 100L, textAnchor4, 0.0d, (float) 60000L, (float) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYStepAreaRenderer4.setBaseToolTipGenerator(xYToolTipGenerator5);
        java.awt.Shape shape8 = xYStepAreaRenderer4.lookupLegendShape(0);
        java.awt.Paint paint12 = xYStepAreaRenderer4.getItemOutlinePaint((int) (byte) 0, (int) '4', false);
        standardChartTheme1.setSubtitlePaint(paint12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator6);
        double double9 = piePlot3D0.getExplodePercent((java.lang.Comparable) 1.258925411794167d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setInfo("hi!");
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getLibraries();
        java.lang.String str4 = basicProjectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (-447), dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double4 = xYSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        xYSeries3.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        double double9 = timeSeriesCollection6.getDomainLowerBound(false);
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeriesCollection6.getSeries((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        logAxis1.centerRange((double) 15);
        boolean boolean5 = logAxis1.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets6.getRight();
        java.lang.String str8 = rectangleInsets6.toString();
        double double9 = rectangleInsets6.getBottom();
        logAxis1.setLabelInsets(rectangleInsets6);
        double double12 = rectangleInsets6.trimWidth((double) (byte) 10);
        double double14 = rectangleInsets6.calculateBottomInset(8.0d);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            rectangleInsets6.trim(rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str8.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = xYStepAreaRenderer22.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
        xYStepAreaRenderer22.setLegendItemURLGenerator(xYSeriesLabelGenerator27);
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis35.setTickLabelFont(font37);
        logAxis35.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, (org.jfree.chart.axis.ValueAxis) logAxis35, categoryItemRenderer42);
        java.awt.Stroke stroke44 = categoryPlot43.getOutlineStroke();
        xYStepAreaRenderer22.setBaseStroke(stroke44, false);
        boolean boolean47 = categoryPlot18.equals((java.lang.Object) xYStepAreaRenderer22);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot18.setDomainAxis(15, categoryAxis49, false);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYStepAreaRenderer3.setLegendItemURLGenerator(xYSeriesLabelGenerator8);
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.LogAxis logAxis16 = new org.jfree.chart.axis.LogAxis("");
        float float17 = logAxis16.getMinorTickMarkInsideLength();
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis16.setTickLabelFont(font18);
        logAxis16.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, (org.jfree.chart.axis.ValueAxis) logAxis16, categoryItemRenderer23);
        java.awt.Stroke stroke25 = categoryPlot24.getOutlineStroke();
        xYStepAreaRenderer3.setBaseStroke(stroke25, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = null;
        xYStepAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator28, true);
        combinedRangeXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer3);
        xYStepAreaRenderer3.removeAnnotations();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        try {
            xYSeries3.delete((int) (short) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 101");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = xYPlot21.getDomainMarkers((int) 'a', layer25);
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis("");
        float float29 = logAxis28.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke30 = logAxis28.getTickMarkStroke();
        xYPlot21.setRangeGridlineStroke(stroke30);
        categoryPlot14.setDomainCrosshairStroke(stroke30);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = logAxis34.getStandardTickUnits();
        int int39 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis34);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer41 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = xYStepAreaRenderer41.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer41.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape50 = xYStepAreaRenderer41.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.LogAxis logAxis53 = new org.jfree.chart.axis.LogAxis("");
        float float54 = logAxis53.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) logAxis53, valueAxis55, xYItemRenderer56);
        java.awt.Paint paint58 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot57.setDomainCrosshairPaint(paint58);
        org.jfree.chart.title.LegendGraphic legendGraphic60 = new org.jfree.chart.title.LegendGraphic(shape50, paint58);
        logAxis34.setDownArrow(shape50);
        java.awt.Paint paint62 = logAxis34.getLabelPaint();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.0f + "'", float29 == 0.0f);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 0.0f + "'", float54 == 0.0f);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(paint62);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape10 = xYStepAreaRenderer1.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) logAxis13, valueAxis15, xYItemRenderer16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot17.setDomainCrosshairPaint(paint18);
        org.jfree.chart.title.LegendGraphic legendGraphic20 = new org.jfree.chart.title.LegendGraphic(shape10, paint18);
        boolean boolean21 = legendGraphic20.isShapeFilled();
        org.jfree.chart.StandardChartTheme standardChartTheme23 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint24 = standardChartTheme23.getAxisLabelPaint();
        legendGraphic20.setOutlinePaint(paint24);
        org.jfree.chart.block.BlockFrame blockFrame26 = legendGraphic20.getFrame();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(blockFrame26);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Color color3 = java.awt.Color.orange;
        try {
            blockContainer0.add((org.jfree.chart.block.Block) labelBlock2, (java.lang.Object) color3);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.Color cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        piePlot3D0.setSimpleLabels(false);
        piePlot3D0.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot6.getDomainAxisEdge((int) (byte) 100);
        java.awt.Paint paint18 = xYPlot6.getDomainMinorGridlinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("TextAnchor.BOTTOM_RIGHT");
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("AxisLocation.TOP_OR_RIGHT");
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("ThreadContext");
        java.awt.Paint paint4 = textFragment3.getPaint();
        textLine1.addFragment(textFragment3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot9.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot9.getRenderer();
        java.awt.Paint paint13 = xYPlot9.getRangeGridlinePaint();
        standardChartTheme1.setTickLabelPaint(paint13);
        java.awt.Paint paint15 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Paint paint16 = standardChartTheme1.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Font font3 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint5 = xYStepAreaRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        org.jfree.chart.StandardChartTheme standardChartTheme8 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint9 = standardChartTheme8.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        float float13 = logAxis12.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) logAxis12, valueAxis14, xYItemRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot16.getRenderer();
        java.awt.Paint paint20 = xYPlot16.getRangeGridlinePaint();
        standardChartTheme8.setTickLabelPaint(paint20);
        xYStepAreaRenderer0.setSeriesPaint((int) (byte) 1, paint20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis23);
        xYStepAreaRenderer0.setPlot((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot24);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        periodAxis3.setLabelFont(font4);
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.LogAxis logAxis12 = new org.jfree.chart.axis.LogAxis("");
        float float13 = logAxis12.getMinorTickMarkInsideLength();
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis12.setTickLabelFont(font14);
        logAxis12.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) logAxis12, categoryItemRenderer19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) logAxis23, valueAxis25, xYItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot27.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = xYPlot27.getDomainMarkers((int) 'a', layer31);
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke36 = logAxis34.getTickMarkStroke();
        xYPlot27.setRangeGridlineStroke(stroke36);
        categoryPlot20.setDomainCrosshairStroke(stroke36);
        org.jfree.chart.axis.LogAxis logAxis40 = new org.jfree.chart.axis.LogAxis("");
        float float41 = logAxis40.getMinorTickMarkInsideLength();
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis40.setTickLabelFont(font42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = logAxis40.getStandardTickUnits();
        int int45 = categoryPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis40);
        categoryPlot20.setDrawSharedDomainAxis(false);
        boolean boolean48 = periodAxis3.hasListener((java.util.EventListener) categoryPlot20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        categoryPlot20.setRenderer(0, categoryItemRenderer50, true);
        boolean boolean53 = categoryPlot20.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset3, false);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset3);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot22.getRangeAxisEdge((int) ' ');
        java.util.List list25 = periodAxis4.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge24);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray26 = null;
        periodAxis4.setLabelInfo(periodAxisLabelInfoArray26);
        java.lang.Class class28 = periodAxis4.getMinorTickTimePeriodClass();
        boolean boolean29 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) unitType0, (java.lang.Object) class28);
        java.lang.String str30 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "UnitType.ABSOLUTE" + "'", str30.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = xYSeriesCollection4.getGroup();
        try {
            java.lang.Number number8 = xYSeriesCollection4.getY(100, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        java.awt.Paint paint9 = xYStepAreaRenderer1.getItemOutlinePaint((int) (byte) 0, (int) '4', false);
        xYStepAreaRenderer1.setItemLabelAnchorOffset(8.0d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        xYStepAreaRenderer0.setBaseShape(shape1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        boolean boolean2 = standardGradientPaintTransformer0.equals((java.lang.Object) 2);
        java.awt.GradientPaint gradientPaint3 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "Pie 3D Plot");
        try {
            java.awt.GradientPaint gradientPaint7 = standardGradientPaintTransformer0.transform(gradientPaint3, shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement1 = blockContainer0.getArrangement();
        org.jfree.data.xy.XYSeries xYSeries5 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection(xYSeries5);
        org.jfree.data.general.DatasetGroup datasetGroup7 = xYSeriesCollection6.getGroup();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer9 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement1, (org.jfree.data.general.Dataset) xYSeriesCollection6, (java.lang.Comparable) (short) -1);
        java.lang.Comparable comparable10 = legendItemBlockContainer9.getSeriesKey();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement12 = blockContainer11.getArrangement();
        org.jfree.chart.block.Arrangement arrangement13 = blockContainer11.getArrangement();
        org.jfree.data.xy.XYSeries xYSeries17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection(xYSeries17);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18, false);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer22 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement13, (org.jfree.data.general.Dataset) xYSeriesCollection18, (java.lang.Comparable) (-1.0d));
        legendItemBlockContainer9.add((org.jfree.chart.block.Block) legendItemBlockContainer22);
        org.junit.Assert.assertNotNull(arrangement1);
        org.junit.Assert.assertNotNull(datasetGroup7);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) -1 + "'", comparable10.equals((short) -1));
        org.junit.Assert.assertNotNull(arrangement12);
        org.junit.Assert.assertNotNull(arrangement13);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Paint paint7 = xYStepAreaRenderer1.getItemFillPaint((int) (short) 10, (int) (short) 0, true);
        boolean boolean8 = xYStepAreaRenderer1.getAutoPopulateSeriesShape();
        double double9 = xYStepAreaRenderer1.getRangeBase();
        java.lang.Boolean boolean11 = xYStepAreaRenderer1.getSeriesItemLabelsVisible(1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot14.getRangeAxis();
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot14.getRendererForDataset(categoryDataset19);
        boolean boolean21 = categoryPlot14.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(valueAxis15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        xYPlot6.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot6.getRangeAxisLocation(6);
        xYPlot6.setDomainGridlinesVisible(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        try {
            xYPlot6.addAnnotation(xYAnnotation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot14.getRangeAxisEdge((int) ' ');
        boolean boolean17 = categoryPlot14.isDomainPannable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot14.setRenderer(categoryItemRenderer18);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        float float8 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) logAxis7, valueAxis9, xYItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot11.setDomainCrosshairPaint(paint12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean15 = org.jfree.chart.util.PaintUtilities.equal(paint12, paint14);
        boolean boolean16 = textAnchor4.equals((java.lang.Object) paint14);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Jan", graphics2D1, (float) ' ', (float) (byte) 10, textAnchor4, 0.05d, (float) (byte) 100, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis3.getFirst();
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo5 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray6 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo5 };
        periodAxis3.setLabelInfo(periodAxisLabelInfoArray6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis11 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) day10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.lang.Number[][] numberArray17 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.LogAxis logAxis21 = new org.jfree.chart.axis.LogAxis("");
        float float22 = logAxis21.getMinorTickMarkInsideLength();
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis21.setTickLabelFont(font23);
        logAxis21.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, (org.jfree.chart.axis.ValueAxis) logAxis21, categoryItemRenderer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getRangeAxisEdge((int) ' ');
        java.util.List list32 = periodAxis11.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge31);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray33 = null;
        periodAxis11.setLabelInfo(periodAxisLabelInfoArray33);
        java.lang.Class class35 = periodAxis11.getMinorTickTimePeriodClass();
        periodAxis3.setMinorTickTimePeriodClass(class35);
        org.jfree.chart.plot.PiePlot3D piePlot3D37 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double39 = rectangleInsets38.getRight();
        java.lang.String str40 = rectangleInsets38.toString();
        piePlot3D37.setSimpleLabelOffset(rectangleInsets38);
        periodAxis3.setLabelInsets(rectangleInsets38);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray6);
        org.junit.Assert.assertNotNull(numberArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str40.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4, true);
        int[] intArray10 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) xYSeriesCollection4, 0, (double) (byte) 0, (double) 1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = null;
        xYSeriesCollection4.seriesChanged(seriesChangeEvent11);
        try {
            xYSeriesCollection4.setSelected((-447), 15, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Jan");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = labelBlock1.getContentAlignmentPoint();
        java.awt.Paint paint3 = labelBlock1.getPaint();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("index.html");
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Font font3 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint5 = xYStepAreaRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.DARK_GRAY;
        xYStepAreaRenderer0.setBaseOutlinePaint((java.awt.Paint) color6);
        java.awt.color.ColorSpace colorSpace8 = null;
        float[] floatArray12 = new float[] { 1, 52, 1560452399999L };
        try {
            float[] floatArray13 = color6.getComponents(colorSpace8, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            lineBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = null;
        try {
            org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        boolean boolean3 = logAxis1.isAxisLineVisible();
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis10.setTickLabelFont(font12);
        logAxis10.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, (org.jfree.chart.axis.ValueAxis) logAxis10, categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot18.getRangeAxis();
        logAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        categoryPlot18.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot18.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYStepAreaRenderer29.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator34 = null;
        xYStepAreaRenderer29.setLegendItemURLGenerator(xYSeriesLabelGenerator34);
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.LogAxis logAxis42 = new org.jfree.chart.axis.LogAxis("");
        float float43 = logAxis42.getMinorTickMarkInsideLength();
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis42.setTickLabelFont(font44);
        logAxis42.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) logAxis42, categoryItemRenderer49);
        java.awt.Stroke stroke51 = categoryPlot50.getOutlineStroke();
        xYStepAreaRenderer29.setBaseStroke(stroke51, false);
        xYStepAreaRenderer29.setShapesVisible(true);
        java.awt.Paint paint56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer29.setBaseOutlinePaint(paint56);
        org.jfree.chart.plot.PiePlot3D piePlot3D58 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double60 = rectangleInsets59.getRight();
        java.lang.String str61 = rectangleInsets59.toString();
        piePlot3D58.setSimpleLabelOffset(rectangleInsets59);
        java.awt.Stroke stroke63 = piePlot3D58.getBaseSectionOutlineStroke();
        java.awt.Paint paint64 = null;
        java.awt.Stroke stroke65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker67 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint56, stroke63, paint64, stroke65, (float) (byte) 1);
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean69 = categoryPlot18.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker67, layer68);
        float float70 = intervalMarker67.getAlpha();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent71 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker67);
        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        intervalMarker67.setOutlineStroke(stroke72);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(valueAxis19);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(numberArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.0f + "'", float43 == 0.0f);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str61.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) logAxis18, valueAxis20, xYItemRenderer21);
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot22.setDomainCrosshairPaint(paint23);
        xYPlot6.setRangeGridlinePaint(paint23);
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis32.setTickLabelFont(font34);
        logAxis32.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) logAxis32, categoryItemRenderer39);
        double double42 = logAxis32.calculateLog((double) (-1.0f));
        int int43 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis32);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation45 = null;
        try {
            boolean boolean47 = xYPlot6.removeAnnotation(xYAnnotation45, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = null;
        java.awt.geom.RectangularShape rectangularShape6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        float float10 = logAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) logAxis9, valueAxis11, xYItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot13.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot13.getDomainMarkers((int) 'a', layer17);
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        float float21 = logAxis20.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke22 = logAxis20.getTickMarkStroke();
        xYPlot13.setRangeGridlineStroke(stroke22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot13.getDomainAxisEdge(500);
        try {
            gradientBarPainter0.paintBarShadow(graphics2D1, barRenderer2, (int) 'a', 9999, true, rectangularShape6, rectangleEdge25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        java.awt.Paint paint2 = xYStepAreaRenderer1.getBaseFillPaint();
        try {
            xYStepAreaRenderer1.setSeriesItemLabelsVisible(2147483647, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.lang.String str2 = combinedRangeXYPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Combined Range XYPlot" + "'", str2.equals("Combined Range XYPlot"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot6.setRangeAxisLocation(axisLocation7, true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        java.awt.Shape shape5 = xYStepAreaRenderer1.lookupLegendShape(0);
        java.awt.Paint paint9 = xYStepAreaRenderer1.getItemOutlinePaint((int) (byte) 0, (int) '4', false);
        boolean boolean10 = xYStepAreaRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 1577894400000L);
        xYStepAreaRenderer1.setLegendShape((int) '#', shape13);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = null;
        xYStepAreaRenderer1.setBaseToolTipGenerator(xYToolTipGenerator2);
        boolean boolean4 = xYStepAreaRenderer1.getBaseSeriesVisibleInLegend();
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        xYStepAreaRenderer1.setBaseOutlineStroke(stroke5, false);
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke5, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis1.setTickLabelFont(font3);
        boolean boolean5 = logAxis1.isAutoRange();
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) logAxis1);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        float float10 = logAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) logAxis9, valueAxis11, xYItemRenderer12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot13.setDomainCrosshairPaint(paint14);
        java.awt.Paint paint17 = null;
        xYPlot13.setQuadrantPaint((int) (short) 0, paint17);
        combinedDomainXYPlot6.remove(xYPlot13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        float float26 = logAxis25.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) logAxis25, valueAxis27, xYItemRenderer28);
        java.awt.Paint paint30 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot29.setDomainCrosshairPaint(paint30);
        java.awt.geom.Point2D point2D32 = xYPlot29.getQuadrantOrigin();
        try {
            combinedDomainXYPlot6.zoomRangeAxes(0.0d, (double) 60000L, plotRenderingInfo22, point2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(point2D32);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.String str1 = standardXYToolTipGenerator0.getNullYString();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null" + "'", str1.equals("null"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.configure();
        java.util.TimeZone timeZone3 = dateAxis1.getTimeZone();
        java.util.Locale locale4 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("index.html", timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.LogAxis logAxis6 = new org.jfree.chart.axis.LogAxis("");
        float float7 = logAxis6.getMinorTickMarkInsideLength();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis6.setTickLabelFont(font8);
        logAxis6.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) logAxis6, categoryItemRenderer13);
        java.awt.Stroke stroke15 = categoryPlot14.getOutlineStroke();
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        boolean boolean19 = logAxis17.isAxisLineVisible();
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.LogAxis logAxis26 = new org.jfree.chart.axis.LogAxis("");
        float float27 = logAxis26.getMinorTickMarkInsideLength();
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis26.setTickLabelFont(font28);
        logAxis26.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) logAxis26, categoryItemRenderer33);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot34.getRangeAxis();
        logAxis17.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        categoryPlot34.setAnchorValue((double) (-1.0f));
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray39 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot34.setRenderers(categoryItemRendererArray39);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer45 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = xYStepAreaRenderer45.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator50 = null;
        xYStepAreaRenderer45.setLegendItemURLGenerator(xYSeriesLabelGenerator50);
        java.lang.Number[][] numberArray54 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray54);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.LogAxis logAxis58 = new org.jfree.chart.axis.LogAxis("");
        float float59 = logAxis58.getMinorTickMarkInsideLength();
        java.awt.Font font60 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis58.setTickLabelFont(font60);
        logAxis58.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) logAxis58, categoryItemRenderer65);
        java.awt.Stroke stroke67 = categoryPlot66.getOutlineStroke();
        xYStepAreaRenderer45.setBaseStroke(stroke67, false);
        xYStepAreaRenderer45.setShapesVisible(true);
        java.awt.Paint paint72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer45.setBaseOutlinePaint(paint72);
        org.jfree.chart.plot.PiePlot3D piePlot3D74 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double76 = rectangleInsets75.getRight();
        java.lang.String str77 = rectangleInsets75.toString();
        piePlot3D74.setSimpleLabelOffset(rectangleInsets75);
        java.awt.Stroke stroke79 = piePlot3D74.getBaseSectionOutlineStroke();
        java.awt.Paint paint80 = null;
        java.awt.Stroke stroke81 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker83 = new org.jfree.chart.plot.IntervalMarker((double) 1577894400001L, (double) 200, paint72, stroke79, paint80, stroke81, (float) (byte) 1);
        org.jfree.chart.util.Layer layer84 = null;
        boolean boolean85 = categoryPlot34.removeDomainMarker(12, (org.jfree.chart.plot.Marker) intervalMarker83, layer84);
        float float86 = intervalMarker83.getAlpha();
        double double87 = intervalMarker83.getEndValue();
        org.jfree.chart.util.Layer layer88 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean89 = categoryPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker83, layer88);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(valueAxis35);
        org.junit.Assert.assertNotNull(categoryItemRendererArray39);
        org.junit.Assert.assertNotNull(itemLabelPosition49);
        org.junit.Assert.assertNotNull(numberArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str77.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + float86 + "' != '" + 1.0f + "'", float86 == 1.0f);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 200.0d + "'", double87 == 200.0d);
        org.junit.Assert.assertNotNull(layer88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Font font3 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint5 = xYStepAreaRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.DARK_GRAY;
        xYStepAreaRenderer0.setBaseOutlinePaint((java.awt.Paint) color6);
        xYStepAreaRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        java.awt.Paint paint6 = xYStepAreaRenderer1.getBaseLegendTextPaint();
        java.awt.Paint paint7 = xYStepAreaRenderer1.getBaseLegendTextPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = piePlot3D0.getLegendItems();
        org.jfree.chart.LegendItem legendItem6 = null;
        legendItemCollection5.add(legendItem6);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (-1.0f), 0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState6 = new org.jfree.chart.renderer.xy.XYItemRendererState(plotRenderingInfo5);
        org.jfree.data.xy.XYSeries xYSeries10 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection(xYSeries10);
        xYItemRendererState6.startSeriesPass((org.jfree.data.xy.XYDataset) xYSeriesCollection11, 7, 0, (int) (byte) 100, (int) 'a', (int) '4');
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.data.general.Dataset) xYSeriesCollection11, (java.lang.Comparable) (byte) 10);
        org.jfree.chart.block.BlockContainer blockContainer20 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Arrangement arrangement21 = blockContainer20.getArrangement();
        org.jfree.data.xy.XYSeries xYSeries25 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection(xYSeries25);
        org.jfree.data.general.DatasetGroup datasetGroup27 = xYSeriesCollection26.getGroup();
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer29 = new org.jfree.chart.title.LegendItemBlockContainer(arrangement21, (org.jfree.data.general.Dataset) xYSeriesCollection26, (java.lang.Comparable) (short) -1);
        org.jfree.chart.block.Arrangement arrangement30 = legendItemBlockContainer29.getArrangement();
        double double31 = legendItemBlockContainer29.getHeight();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str34 = rectangleConstraint33.toString();
        org.jfree.data.time.DateRange dateRange35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range38 = org.jfree.data.Range.expand((org.jfree.data.Range) dateRange35, (double) 2, (double) (byte) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = rectangleConstraint33.toRangeWidth(range38);
        double double40 = rectangleConstraint39.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D41 = columnArrangement4.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer29, graphics2D32, rectangleConstraint39);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(arrangement21);
        org.junit.Assert.assertNotNull(datasetGroup27);
        org.junit.Assert.assertNotNull(arrangement30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str34.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(dateRange35);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation1 = null;
        boolean boolean2 = xYStepAreaRenderer0.removeAnnotation(xYAnnotation1);
        java.awt.Font font3 = xYStepAreaRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint5 = xYStepAreaRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        try {
            xYStepAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis2.setTickLabelFont(font4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.LogAxis logAxis8 = new org.jfree.chart.axis.LogAxis("");
        float float9 = logAxis8.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) logAxis8, valueAxis10, xYItemRenderer11);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        xYPlot12.setDataset((int) (byte) 10, xYDataset14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.LogAxis logAxis19 = new org.jfree.chart.axis.LogAxis("");
        float float20 = logAxis19.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) logAxis19, valueAxis21, xYItemRenderer22);
        java.awt.Paint paint24 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot23.setDomainCrosshairPaint(paint24);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer27 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator28 = null;
        xYStepAreaRenderer27.setBaseToolTipGenerator(xYToolTipGenerator28);
        java.awt.Shape shape31 = xYStepAreaRenderer27.lookupLegendShape(0);
        int int32 = xYPlot23.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer27);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis("");
        float float36 = logAxis35.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) logAxis35, valueAxis37, xYItemRenderer38);
        java.awt.Paint paint40 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot39.setDomainCrosshairPaint(paint40);
        xYPlot23.setRangeGridlinePaint(paint40);
        java.lang.Number[][] numberArray45 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray45);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.LogAxis logAxis49 = new org.jfree.chart.axis.LogAxis("");
        float float50 = logAxis49.getMinorTickMarkInsideLength();
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis49.setTickLabelFont(font51);
        logAxis49.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, (org.jfree.chart.axis.ValueAxis) logAxis49, categoryItemRenderer56);
        double double59 = logAxis49.calculateLog((double) (-1.0f));
        int int60 = xYPlot23.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis49);
        xYPlot12.setDomainAxis(10, (org.jfree.chart.axis.ValueAxis) logAxis49, false);
        org.jfree.data.xy.XYDataset xYDataset63 = xYPlot12.getDataset();
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.axis.LogAxis logAxis66 = new org.jfree.chart.axis.LogAxis("");
        float float67 = logAxis66.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset64, (org.jfree.chart.axis.ValueAxis) logAxis66, valueAxis68, xYItemRenderer69);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = xYPlot70.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = xYPlot70.getRenderer();
        java.awt.Paint paint74 = xYPlot70.getRangeGridlinePaint();
        xYPlot12.setRangeZeroBaselinePaint(paint74);
        org.jfree.chart.block.LabelBlock labelBlock76 = new org.jfree.chart.block.LabelBlock("TextAnchor.BOTTOM_RIGHT", font4, paint74);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor77 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent78 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) textBlockAnchor77);
        labelBlock76.setContentAlignmentPoint(textBlockAnchor77);
        java.awt.Graphics2D graphics2D80 = null;
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        try {
            java.lang.Object obj83 = labelBlock76.draw(graphics2D80, rectangle2D81, (java.lang.Object) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(numberArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 0.0f + "'", float50 == 0.0f);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNull(xYDataset63);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 0.0f + "'", float67 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNull(xYItemRenderer73);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(textBlockAnchor77);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYStepAreaRenderer6.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer6.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape15 = xYStepAreaRenderer6.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) logAxis18, valueAxis20, xYItemRenderer21);
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot22.setDomainCrosshairPaint(paint23);
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape15, paint23);
        java.lang.Number[][] numberArray30 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.LogAxis logAxis34 = new org.jfree.chart.axis.LogAxis("");
        float float35 = logAxis34.getMinorTickMarkInsideLength();
        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis34.setTickLabelFont(font36);
        logAxis34.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) logAxis34, categoryItemRenderer41);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity45 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset31, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        multiplePiePlot4.setLegendItemShape(shape15);
        java.awt.Paint paint47 = multiplePiePlot4.getAggregatedItemsPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection48 = multiplePiePlot4.getLegendItems();
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(legendItemCollection48);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        java.lang.Object obj6 = null;
        boolean boolean7 = piePlot3D0.equals(obj6);
        piePlot3D0.setAutoPopulateSectionPaint(true);
        piePlot3D0.setIgnoreZeroValues(true);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = xYStepAreaRenderer13.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer13.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape22 = xYStepAreaRenderer13.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.LogAxis logAxis25 = new org.jfree.chart.axis.LogAxis("");
        float float26 = logAxis25.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) logAxis25, valueAxis27, xYItemRenderer28);
        java.awt.Paint paint30 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot29.setDomainCrosshairPaint(paint30);
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape22, paint30);
        java.lang.Number[][] numberArray37 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.LogAxis logAxis41 = new org.jfree.chart.axis.LogAxis("");
        float float42 = logAxis41.getMinorTickMarkInsideLength();
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis41.setTickLabelFont(font43);
        logAxis41.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) logAxis41, categoryItemRenderer48);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity52 = new org.jfree.chart.entity.CategoryItemEntity(shape22, "ClassContext", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset38, (java.lang.Comparable) (-1), (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset38, 2147483647);
        piePlot3D0.setDataset(pieDataset54);
        double double56 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset54);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis4 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day2, (org.jfree.data.time.RegularTimePeriod) day3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = periodAxis4.getFirst();
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo6 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray7 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo6 };
        periodAxis4.setLabelInfo(periodAxisLabelInfoArray7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.lang.Number[][] numberArray18 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.LogAxis logAxis22 = new org.jfree.chart.axis.LogAxis("");
        float float23 = logAxis22.getMinorTickMarkInsideLength();
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis22.setTickLabelFont(font24);
        logAxis22.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, (org.jfree.chart.axis.ValueAxis) logAxis22, categoryItemRenderer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot30.getRangeAxisEdge((int) ' ');
        java.util.List list33 = periodAxis12.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge32);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray34 = null;
        periodAxis12.setLabelInfo(periodAxisLabelInfoArray34);
        java.lang.Class class36 = periodAxis12.getMinorTickTimePeriodClass();
        periodAxis4.setMinorTickTimePeriodClass(class36);
        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleEdge.TOP", class36);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray7);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.0f + "'", float23 == 0.0f);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNull(obj38);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        xYPlot6.clearRangeMarkers(1);
        xYPlot6.configureRangeAxes();
        xYPlot6.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries3);
        xYSeries3.clear();
        xYSeries3.setDescription("ThreadContext");
        int int8 = xYSeries3.getMaximumItemCount();
        java.lang.Object obj9 = xYSeries3.clone();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", numberArray4);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(categoryDataset6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        java.awt.Stroke stroke5 = piePlot3D0.getBaseSectionOutlineStroke();
        piePlot3D0.setDarkerSides(false);
        java.awt.Paint paint8 = piePlot3D0.getShadowPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double10 = rectangleInsets9.getRight();
        java.lang.String str11 = rectangleInsets9.toString();
        java.lang.String str12 = rectangleInsets9.toString();
        double double13 = rectangleInsets9.getLeft();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets9);
        piePlot3D0.setMinimumArcAngleToDraw((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str12.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        float float10 = logAxis9.getMinorTickMarkInsideLength();
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis9.setTickLabelFont(font11);
        logAxis9.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) logAxis9, categoryItemRenderer16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        float float21 = logAxis20.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) logAxis20, valueAxis22, xYItemRenderer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot24.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = xYPlot24.getDomainMarkers((int) 'a', layer28);
        org.jfree.chart.axis.LogAxis logAxis31 = new org.jfree.chart.axis.LogAxis("");
        float float32 = logAxis31.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke33 = logAxis31.getTickMarkStroke();
        xYPlot24.setRangeGridlineStroke(stroke33);
        categoryPlot17.setRangeZeroBaselineStroke(stroke33);
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) "Jan", true);
        boolean boolean39 = categoryPlot17.isRangeMinorGridlinesVisible();
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.LogAxis logAxis45 = new org.jfree.chart.axis.LogAxis("");
        float float46 = logAxis45.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) logAxis45, valueAxis47, xYItemRenderer48);
        java.awt.Paint paint50 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot49.setDomainCrosshairPaint(paint50);
        java.awt.geom.Point2D point2D52 = xYPlot49.getQuadrantOrigin();
        categoryPlot17.zoomRangeAxes((double) 6, plotRenderingInfo42, point2D52);
        try {
            combinedRangeXYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo2, point2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.0f + "'", float46 == 0.0f);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(point2D52);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        boolean boolean0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.lang.String str1 = org.jfree.chart.util.PaintUtilities.colorToString(color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "gray" + "'", str1.equals("gray"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot6.getRenderer();
        java.awt.Paint paint10 = xYPlot6.getRangeGridlinePaint();
        xYPlot6.setDomainCrosshairLockedOnData(false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot6.getRangeAxisForDataset(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 9 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot6.setDomainCrosshairPaint(paint7);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYStepAreaRenderer10.setBaseToolTipGenerator(xYToolTipGenerator11);
        java.awt.Shape shape14 = xYStepAreaRenderer10.lookupLegendShape(0);
        int int15 = xYPlot6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer10);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) logAxis18, valueAxis20, xYItemRenderer21);
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot22.setDomainCrosshairPaint(paint23);
        xYPlot6.setRangeGridlinePaint(paint23);
        java.lang.Number[][] numberArray28 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.LogAxis logAxis32 = new org.jfree.chart.axis.LogAxis("");
        float float33 = logAxis32.getMinorTickMarkInsideLength();
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis32.setTickLabelFont(font34);
        logAxis32.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) logAxis32, categoryItemRenderer39);
        double double42 = logAxis32.calculateLog((double) (-1.0f));
        int int43 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis32);
        org.jfree.chart.title.LegendTitle legendTitle44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = legendTitle44.getVerticalAlignment();
        java.lang.Object obj46 = null;
        boolean boolean47 = legendTitle44.equals(obj46);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(verticalAlignment45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer1.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        boolean boolean9 = xYStepAreaRenderer1.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis("");
        float float2 = logAxis1.getMinorTickMarkInsideLength();
        logAxis1.centerRange((double) 15);
        boolean boolean5 = logAxis1.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double7 = rectangleInsets6.getRight();
        java.lang.String str8 = rectangleInsets6.toString();
        double double9 = rectangleInsets6.getBottom();
        logAxis1.setLabelInsets(rectangleInsets6);
        double double12 = rectangleInsets6.trimWidth((double) (byte) 10);
        double double14 = rectangleInsets6.calculateBottomInset(8.0d);
        double double16 = rectangleInsets6.calculateBottomInset((double) 1577894400001L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str8.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        java.awt.Paint paint17 = xYPlot6.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer19 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        xYPlot6.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer19);
        xYStepAreaRenderer19.setSeriesCreateEntities((int) '#', (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = xYStepAreaRenderer25.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer25.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = new org.jfree.chart.labels.ItemLabelPosition();
        xYStepAreaRenderer25.setSeriesPositiveItemLabelPosition((int) 'a', itemLabelPosition34);
        xYStepAreaRenderer19.setBaseNegativeItemLabelPosition(itemLabelPosition34);
        double double37 = xYStepAreaRenderer19.getRangeBase();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ThreadContext");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYStepAreaRenderer3.getNegativeItemLabelPosition((int) 'a', 0, false);
        xYStepAreaRenderer3.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) true);
        java.awt.Shape shape12 = xYStepAreaRenderer3.lookupSeriesShape(0);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.LogAxis logAxis15 = new org.jfree.chart.axis.LogAxis("");
        float float16 = logAxis15.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) logAxis15, valueAxis17, xYItemRenderer18);
        java.awt.Paint paint20 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot19.setDomainCrosshairPaint(paint20);
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape12, paint20);
        legendGraphic22.setShapeFilled(false);
        boolean boolean25 = textFragment1.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis3 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day1, (org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = periodAxis3.getFirst();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis8 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) day7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis18.setTickLabelFont(font20);
        logAxis18.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) logAxis18, categoryItemRenderer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot26.getRangeAxisEdge((int) ' ');
        java.util.List list29 = periodAxis8.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge28);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray30 = null;
        periodAxis8.setLabelInfo(periodAxisLabelInfoArray30);
        java.lang.Class class32 = periodAxis8.getMinorTickTimePeriodClass();
        periodAxis3.setAutoRangeTimePeriodClass(class32);
        double double34 = periodAxis3.getFixedDimension();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis("");
        float float3 = logAxis2.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) logAxis2, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = xYPlot6.getDomainMarkers((int) 'a', layer10);
        org.jfree.chart.axis.LogAxis logAxis13 = new org.jfree.chart.axis.LogAxis("");
        float float14 = logAxis13.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke15 = logAxis13.getTickMarkStroke();
        xYPlot6.setRangeGridlineStroke(stroke15);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis("");
        float float19 = logAxis18.getMinorTickMarkInsideLength();
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis18.setTickLabelFont(font20);
        int int22 = xYPlot6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis18);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = xYPlot6.getFixedLegendItems();
        org.jfree.chart.StandardChartTheme standardChartTheme25 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint26 = standardChartTheme25.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis("");
        float float30 = logAxis29.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) logAxis29, valueAxis31, xYItemRenderer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot33.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = xYPlot33.getRenderer();
        java.awt.Paint paint37 = xYPlot33.getRangeGridlinePaint();
        standardChartTheme25.setTickLabelPaint(paint37);
        java.awt.Paint paint39 = standardChartTheme25.getTitlePaint();
        java.awt.Paint paint40 = standardChartTheme25.getThermometerPaint();
        xYPlot6.setRangeCrosshairPaint(paint40);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.0f + "'", float30 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(xYItemRenderer36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Font font1 = dateAxis0.getTickLabelFont();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        java.util.Date date5 = year3.getEnd();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.LogAxis logAxis9 = new org.jfree.chart.axis.LogAxis("");
        float float10 = logAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) logAxis9, valueAxis11, xYItemRenderer12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot13.getRangeAxisEdge(0);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = xYPlot13.getDomainMarkers((int) 'a', layer17);
        org.jfree.chart.axis.LogAxis logAxis20 = new org.jfree.chart.axis.LogAxis("");
        float float21 = logAxis20.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke22 = logAxis20.getTickMarkStroke();
        xYPlot13.setRangeGridlineStroke(stroke22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot13.getDomainAxisEdge(500);
        try {
            double double26 = dateAxis0.dateToJava2D(date5, rectangle2D6, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYStepAreaRenderer1.drawRangeMarker(graphics2D8, xYPlot9, valueAxis10, marker11, rectangle2D12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.LogAxis logAxis17 = new org.jfree.chart.axis.LogAxis("");
        float float18 = logAxis17.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) logAxis17, valueAxis19, xYItemRenderer20);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot21.setDomainCrosshairPaint(paint22);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer25 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator26 = null;
        xYStepAreaRenderer25.setBaseToolTipGenerator(xYToolTipGenerator26);
        java.awt.Shape shape29 = xYStepAreaRenderer25.lookupLegendShape(0);
        int int30 = xYPlot21.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer25);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis("");
        float float34 = logAxis33.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) logAxis33, valueAxis35, xYItemRenderer36);
        java.awt.Paint paint38 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot37.setDomainCrosshairPaint(paint38);
        xYPlot21.setRangeGridlinePaint(paint38);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("ThreadContext", (org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day43);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.AxisState axisState46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.lang.Number[][] numberArray50 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset51 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        org.jfree.chart.axis.LogAxis logAxis54 = new org.jfree.chart.axis.LogAxis("");
        float float55 = logAxis54.getMinorTickMarkInsideLength();
        java.awt.Font font56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis54.setTickLabelFont(font56);
        logAxis54.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, (org.jfree.chart.axis.ValueAxis) logAxis54, categoryItemRenderer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot62.getRangeAxisEdge((int) ' ');
        java.util.List list65 = periodAxis44.refreshTicks(graphics2D45, axisState46, rectangle2D47, rectangleEdge64);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray66 = null;
        periodAxis44.setLabelInfo(periodAxisLabelInfoArray66);
        java.lang.Class class68 = periodAxis44.getMinorTickTimePeriodClass();
        org.jfree.chart.plot.Marker marker69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        xYStepAreaRenderer1.drawRangeMarker(graphics2D14, xYPlot21, (org.jfree.chart.axis.ValueAxis) periodAxis44, marker69, rectangle2D70);
        java.awt.Paint paint73 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        xYStepAreaRenderer1.setSeriesItemLabelPaint((int) (byte) 10, paint73);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition76 = null;
        xYStepAreaRenderer1.setSeriesPositiveItemLabelPosition(4, itemLabelPosition76, false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.0f + "'", float34 == 0.0f);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(numberArray50);
        org.junit.Assert.assertNotNull(categoryDataset51);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.0f + "'", float55 == 0.0f);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertNotNull(paint73);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) 2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = xYStepAreaRenderer1.getNegativeItemLabelPosition((int) 'a', 0, false);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator6 = null;
        xYStepAreaRenderer1.setLegendItemURLGenerator(xYSeriesLabelGenerator6);
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.LogAxis logAxis14 = new org.jfree.chart.axis.LogAxis("");
        float float15 = logAxis14.getMinorTickMarkInsideLength();
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        logAxis14.setTickLabelFont(font16);
        logAxis14.setRange((double) 10, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) logAxis14, categoryItemRenderer21);
        java.awt.Stroke stroke23 = categoryPlot22.getOutlineStroke();
        xYStepAreaRenderer1.setBaseStroke(stroke23, false);
        xYStepAreaRenderer1.setShapesVisible(true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator28 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
        xYStepAreaRenderer1.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator28);
        java.awt.Paint paint31 = xYStepAreaRenderer1.lookupLegendTextPaint((int) (byte) 10);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.awt.Paint paint2 = standardChartTheme1.getAxisLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis("");
        float float6 = logAxis5.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) logAxis5, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot9.getRangeAxisEdge(0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot9.getRenderer();
        java.awt.Paint paint13 = xYPlot9.getRangeGridlinePaint();
        standardChartTheme1.setTickLabelPaint(paint13);
        org.jfree.data.xy.XYSeries xYSeries18 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection19 = new org.jfree.data.xy.XYSeriesCollection(xYSeries18);
        boolean boolean20 = standardChartTheme1.equals((java.lang.Object) xYSeries18);
        java.awt.Paint paint21 = standardChartTheme1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets1.getRight();
        java.lang.String str3 = rectangleInsets1.toString();
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.LogAxis logAxis7 = new org.jfree.chart.axis.LogAxis("");
        float float8 = logAxis7.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) logAxis7, valueAxis9, xYItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot11.setDomainCrosshairPaint(paint12);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(0);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator16 = null;
        xYStepAreaRenderer15.setBaseToolTipGenerator(xYToolTipGenerator16);
        java.awt.Shape shape19 = xYStepAreaRenderer15.lookupLegendShape(0);
        int int20 = xYPlot11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepAreaRenderer15);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.LogAxis logAxis23 = new org.jfree.chart.axis.LogAxis("");
        float float24 = logAxis23.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset21, (org.jfree.chart.axis.ValueAxis) logAxis23, valueAxis25, xYItemRenderer26);
        java.awt.Paint paint28 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot27.setDomainCrosshairPaint(paint28);
        xYPlot11.setRangeGridlinePaint(paint28);
        piePlot3D0.setLabelLinkPaint(paint28);
        piePlot3D0.setShadowYOffset((double) 3600000L);
        piePlot3D0.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str3.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true, false);
        double double4 = xYSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeSeries5);
        xYSeries3.removeChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection6);
        double double9 = timeSeriesCollection6.getDomainLowerBound(false);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = null;
        timeSeriesCollection6.seriesChanged(seriesChangeEvent10);
        try {
            timeSeriesCollection6.setSelected((int) ' ', (-447), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (32).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.util.LogFormat logFormat5 = new org.jfree.chart.util.LogFormat((double) 0.0f, "", "hi!", false);
        logFormat5.setParseIntegerOnly(false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) 2704953600000L, (java.text.NumberFormat) logFormat5);
        org.jfree.chart.axis.LogAxis logAxis10 = new org.jfree.chart.axis.LogAxis("");
        float float11 = logAxis10.getMinorTickMarkInsideLength();
        logAxis10.centerRange((double) 15);
        boolean boolean14 = logAxis10.isPositiveArrowVisible();
        int int15 = logAxis10.getMinorTickCount();
        java.lang.String str16 = logFormat5.format((java.lang.Object) int15);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "�" + "'", str16.equals("�"));
    }
}

