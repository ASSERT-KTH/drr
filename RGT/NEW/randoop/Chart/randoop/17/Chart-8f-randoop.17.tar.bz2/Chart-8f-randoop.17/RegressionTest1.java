import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test01");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int3 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getYearValue();
//        int int7 = week5.getWeek();
//        java.util.Date date8 = week5.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date8);
//        java.lang.Class<?> wildcardClass12 = week11.getClass();
//        java.lang.Class<?> wildcardClass13 = week11.getClass();
//        java.util.Date date14 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (byte) 1, 4);
//        long long18 = week17.getLastMillisecond();
//        java.util.Date date19 = week17.getStart();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        int int22 = week21.getYearValue();
//        int int23 = week21.getWeek();
//        java.util.Date date24 = week21.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24);
//        java.util.Date date28 = week27.getEnd();
//        java.util.Date date29 = week27.getEnd();
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        int int32 = week31.getYearValue();
//        int int33 = week31.getWeek();
//        java.util.Date date34 = week31.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date34, timeZone35);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        int int38 = week37.getYearValue();
//        int int40 = week37.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass41 = week37.getClass();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        int int43 = week42.getYearValue();
//        int int44 = week42.getWeek();
//        java.util.Date date45 = week42.getStart();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date45, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date34, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date29, timeZone46);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date19, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date14, timeZone46);
//        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62040700800001L) + "'", long18 == (-62040700800001L));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 24 + "'", int44 == 24);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(class52);
//    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test02");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
//        int int11 = week9.getWeek();
//        int int12 = week9.getYearValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) 100);
        java.lang.String str3 = week2.toString();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 100" + "'", str3.equals("Week 0, 100"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5300L + "'", long4 == 5300L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 0, 100" + "'", str5.equals("Week 0, 100"));
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getYearValue();
//        int int5 = week3.getWeek();
//        org.jfree.data.time.Year year6 = week3.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(4, year6);
//        java.util.Date date8 = year6.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test05");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getWeek();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.util.Date date6 = week0.getStart();
//        int int7 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str13 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.String str28 = timePeriodFormatException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException30.getSuppressed();
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException30.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray37 = timePeriodFormatException36.getSuppressed();
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException40 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray43 = timePeriodFormatException42.getSuppressed();
        timePeriodFormatException40.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException40);
        java.lang.Throwable[] throwableArray46 = timePeriodFormatException34.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException48 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray51 = timePeriodFormatException50.getSuppressed();
        timePeriodFormatException48.addSuppressed((java.lang.Throwable) timePeriodFormatException50);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException54 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException56 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray57 = timePeriodFormatException56.getSuppressed();
        timePeriodFormatException54.addSuppressed((java.lang.Throwable) timePeriodFormatException56);
        timePeriodFormatException50.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        java.lang.String str62 = timePeriodFormatException54.toString();
        java.lang.Throwable[] throwableArray63 = timePeriodFormatException54.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException54);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str62.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray63);
    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test07");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        long long5 = week1.getSerialIndex();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, year6);
//        java.lang.Class<?> wildcardClass8 = year6.getClass();
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(class9);
//    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test08");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone8);
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.previous();
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        long long5 = week1.getSerialIndex();
//        org.jfree.data.time.Year year6 = week1.getYear();
//        java.lang.Class<?> wildcardClass7 = year6.getClass();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        long long9 = week8.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1552204799999L + "'", long9 == 1552204799999L);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test10");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone8);
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getStart();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int14 = week13.getYearValue();
//        int int15 = week13.getWeek();
//        java.util.Date date16 = week13.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date16, timeZone20);
//        long long22 = week21.getSerialIndex();
//        java.util.Date date23 = week21.getStart();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        int int25 = week24.getYearValue();
//        int int27 = week24.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass28 = week24.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        int int30 = week29.getYearValue();
//        int int31 = week29.getWeek();
//        java.util.Date date32 = week29.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone33);
//        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        int int38 = week37.getYearValue();
//        int int40 = week37.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass41 = week37.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week37.next();
//        long long43 = week37.getLastMillisecond();
//        java.lang.Class class44 = null;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        int int46 = week45.getYearValue();
//        int int47 = week45.getWeek();
//        java.util.Date date48 = week45.getStart();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date48);
//        boolean boolean52 = week37.equals((java.lang.Object) week51);
//        java.util.Date date53 = week37.getStart();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        int int55 = week54.getYearValue();
//        int int57 = week54.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass58 = week54.getClass();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        int int60 = week59.getYearValue();
//        int int61 = week59.getWeek();
//        java.util.Date date62 = week59.getStart();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date62, timeZone63);
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        java.lang.Class class66 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        java.lang.Class class67 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass58);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        int int69 = week68.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = week68.next();
//        long long71 = week68.getLastMillisecond();
//        long long72 = week68.getMiddleMillisecond();
//        java.util.Date date73 = week68.getStart();
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        int int75 = week74.getYearValue();
//        int int77 = week74.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass78 = week74.getClass();
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week();
//        int int80 = week79.getYearValue();
//        int int81 = week79.getWeek();
//        java.util.Date date82 = week79.getStart();
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass78, date82, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date73, timeZone83);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date53, timeZone83);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date23, timeZone83);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date11, timeZone83);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 107031L + "'", long22 == 107031L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(class35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560668399999L + "'", long43 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 24 + "'", int47 == 24);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 24 + "'", int61 == 24);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNotNull(class66);
//        org.junit.Assert.assertNotNull(class67);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2019 + "'", int69 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560668399999L + "'", long71 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560365999999L + "'", long72 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 2019 + "'", int75 == 2019);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass78);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 2019 + "'", int80 == 2019);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 24 + "'", int81 == 24);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//    }

//    @Test
//    public void test11() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test11");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone8);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getYearValue();
//        int int13 = week11.getWeek();
//        java.util.Date date14 = week11.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone15);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date14);
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date14, timeZone18);
//        long long20 = week19.getSerialIndex();
//        java.util.Date date21 = week19.getStart();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        int int23 = week22.getYearValue();
//        int int25 = week22.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass26 = week22.getClass();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        int int28 = week27.getYearValue();
//        int int29 = week27.getWeek();
//        java.util.Date date30 = week27.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getYearValue();
//        int int38 = week35.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass39 = week35.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week35.next();
//        long long41 = week35.getLastMillisecond();
//        java.lang.Class class42 = null;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        int int44 = week43.getYearValue();
//        int int45 = week43.getWeek();
//        java.util.Date date46 = week43.getStart();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date46, timeZone47);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date46);
//        boolean boolean50 = week35.equals((java.lang.Object) week49);
//        java.util.Date date51 = week35.getStart();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        int int53 = week52.getYearValue();
//        int int55 = week52.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass56 = week52.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        int int58 = week57.getYearValue();
//        int int59 = week57.getWeek();
//        java.util.Date date60 = week57.getStart();
//        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone61);
//        java.lang.Class class63 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        java.lang.Class class64 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week();
//        int int67 = week66.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week66.next();
//        long long69 = week66.getLastMillisecond();
//        long long70 = week66.getMiddleMillisecond();
//        java.util.Date date71 = week66.getStart();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week();
//        int int73 = week72.getYearValue();
//        int int75 = week72.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass76 = week72.getClass();
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week();
//        int int78 = week77.getYearValue();
//        int int79 = week77.getWeek();
//        java.util.Date date80 = week77.getStart();
//        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass76, date80, timeZone81);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date71, timeZone81);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date51, timeZone81);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date21, timeZone81);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date4, timeZone81);
//        java.lang.Class<?> wildcardClass87 = week86.getClass();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560668399999L + "'", long41 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 24 + "'", int45 == 24);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2019 + "'", int58 == 2019);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 24 + "'", int59 == 24);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(timeZone61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(class63);
//        org.junit.Assert.assertNotNull(class64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560668399999L + "'", long69 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560365999999L + "'", long70 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass76);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 2019 + "'", int78 == 2019);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 24 + "'", int79 == 24);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(timeZone81);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(wildcardClass87);
//    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test12");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getWeek();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.lang.String str5 = week0.toString();
//        long long6 = week0.getSerialIndex();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getYearValue();
//        int int9 = week7.getWeek();
//        int int10 = week7.getWeek();
//        java.util.Date date11 = week7.getStart();
//        boolean boolean12 = week0.equals((java.lang.Object) week7);
//        int int13 = week7.getWeek();
//        java.util.Date date14 = week7.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int1 = week0.getYearValue();
        int int2 = week0.getYearValue();
        java.util.Calendar calendar3 = null;
        try {
            week0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test15");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getYearValue();
//        int int4 = week2.getWeek();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(4, year5);
//        java.util.Date date7 = year5.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) -1, year5);
//        int int9 = week8.getYearValue();
//        org.jfree.data.time.Year year10 = week8.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(year10);
//    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test16");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getWeek();
//        int int3 = week0.getWeek();
//        java.util.Date date4 = week0.getStart();
//        java.lang.String str5 = week0.toString();
//        int int6 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test17");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        long long1 = week0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = week0.getYear();
//        long long3 = week0.getSerialIndex();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560063600000L + "'", long1 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test18");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 4);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getMiddleMillisecond();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getYearValue();
//        int int8 = week5.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week5.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week5.previous();
//        boolean boolean12 = week2.equals((java.lang.Object) week5);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int14 = week13.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        long long16 = week13.getLastMillisecond();
//        long long17 = week13.getMiddleMillisecond();
//        boolean boolean18 = week2.equals((java.lang.Object) week13);
//        long long19 = week13.getFirstMillisecond();
//        long long20 = week13.getSerialIndex();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        int int22 = week21.getYearValue();
//        int int24 = week21.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass25 = week21.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week21.next();
//        long long27 = week21.getLastMillisecond();
//        java.util.Date date28 = week21.getStart();
//        boolean boolean29 = week13.equals((java.lang.Object) date28);
//        java.lang.Class<?> wildcardClass30 = date28.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        int int36 = week35.getYearValue();
//        int int37 = week35.getWeek();
//        java.util.Date date38 = week35.getStart();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date38, timeZone39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        int int42 = week41.getYearValue();
//        int int44 = week41.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass45 = week41.getClass();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        int int47 = week46.getYearValue();
//        int int48 = week46.getWeek();
//        java.util.Date date49 = week46.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date38, timeZone50);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.next();
//        java.util.Date date54 = regularTimePeriod53.getEnd();
//        java.util.TimeZone timeZone55 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date54, timeZone55);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62041003200001L) + "'", long4 == (-62041003200001L));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560668399999L + "'", long16 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560365999999L + "'", long17 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560668399999L + "'", long27 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 24 + "'", int37 == 24);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str13 = timePeriodFormatException7.toString();
        java.lang.String str14 = timePeriodFormatException7.toString();
        java.lang.String str15 = timePeriodFormatException7.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test20");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getYearValue();
//        int int5 = week3.getWeek();
//        java.util.Date date6 = week3.getStart();
//        org.jfree.data.time.Year year7 = week3.getYear();
//        java.util.Date date8 = year7.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(11, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(7, year7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(0, year7);
//        int int12 = week11.getWeek();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int3 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getYearValue();
//        int int7 = week5.getWeek();
//        java.util.Date date8 = week5.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        int int15 = week14.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
//        long long17 = week14.getLastMillisecond();
//        long long18 = week14.getMiddleMillisecond();
//        java.util.Date date19 = week14.getStart();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week();
//        int int21 = week20.getYearValue();
//        int int23 = week20.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass24 = week20.getClass();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        int int26 = week25.getYearValue();
//        int int27 = week25.getWeek();
//        java.util.Date date28 = week25.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date19, timeZone29);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        int int33 = week32.getYearValue();
//        int int35 = week32.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass36 = week32.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week32.next();
//        long long38 = week32.getLastMillisecond();
//        java.lang.Class class39 = null;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int41 = week40.getYearValue();
//        int int42 = week40.getWeek();
//        java.util.Date date43 = week40.getStart();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date43, timeZone44);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date43);
//        boolean boolean47 = week32.equals((java.lang.Object) week46);
//        java.util.Date date48 = week32.getStart();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        int int50 = week49.getYearValue();
//        int int51 = week49.getWeek();
//        java.util.Date date52 = week49.getStart();
//        long long53 = week49.getSerialIndex();
//        java.util.Date date54 = week49.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week49.next();
//        java.util.Date date56 = week49.getEnd();
//        java.lang.Class class57 = null;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        int int59 = week58.getYearValue();
//        int int60 = week58.getWeek();
//        java.util.Date date61 = week58.getStart();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date61, timeZone62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        int int65 = week64.getYearValue();
//        int int67 = week64.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass68 = week64.getClass();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        int int70 = week69.getYearValue();
//        int int71 = week69.getWeek();
//        java.util.Date date72 = week69.getStart();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date72, timeZone73);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date61, timeZone73);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date56, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date48, timeZone73);
//        java.lang.Class class78 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class79 = org.jfree.data.time.RegularTimePeriod.downsize(class78);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668399999L + "'", long17 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560365999999L + "'", long18 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 24 + "'", int27 == 24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560668399999L + "'", long38 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 24 + "'", int42 == 24);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 24 + "'", int51 == 24);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 107031L + "'", long53 == 107031L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 24 + "'", int60 == 24);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 2019 + "'", int65 == 2019);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2019 + "'", int70 == 2019);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 24 + "'", int71 == 24);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(class78);
//        org.junit.Assert.assertNotNull(class79);
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 1);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str10 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException15.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.String str24 = timePeriodFormatException15.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str26 = timePeriodFormatException15.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 53);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str10 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str14 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException25.getSuppressed();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException23.getSuppressed();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.String str32 = timePeriodFormatException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test26");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getYearValue();
//        int int4 = week2.getWeek();
//        java.util.Date date5 = week2.getStart();
//        org.jfree.data.time.Year year6 = week2.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(11, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(7, year6);
//        long long10 = week9.getLastMillisecond();
//        java.util.Date date11 = week9.getEnd();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1550390399999L + "'", long10 == 1550390399999L);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test27");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getYearValue();
//        int int6 = week4.getWeek();
//        java.util.Date date7 = week4.getStart();
//        org.jfree.data.time.Year year8 = week4.getYear();
//        java.util.Date date9 = year8.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(11, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(7, year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(0, year8);
//        java.lang.Class<?> wildcardClass13 = year8.getClass();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (byte) 1, year8);
//        long long15 = week14.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546156800000L + "'", long15 == 1546156800000L);
//    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test28");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int3 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int9 = week8.getYearValue();
//        int int10 = week8.getWeek();
//        java.util.Date date11 = week8.getStart();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date11, timeZone12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11);
//        boolean boolean15 = week0.equals((java.lang.Object) week14);
//        java.util.Date date16 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week0.next();
//        int int18 = week0.getYearValue();
//        long long19 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560668399999L + "'", long19 == 1560668399999L);
//    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test29");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int3 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int9 = week8.getYearValue();
//        int int10 = week8.getWeek();
//        java.util.Date date11 = week8.getStart();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date11, timeZone12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11);
//        boolean boolean15 = week0.equals((java.lang.Object) week14);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        int int18 = week17.getYearValue();
//        int int19 = week17.getWeek();
//        java.util.Date date20 = week17.getStart();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date20, timeZone21);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int24 = week23.getYearValue();
//        int int26 = week23.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass27 = week23.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getYearValue();
//        int int30 = week28.getWeek();
//        java.util.Date date31 = week28.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date31, timeZone32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date20, timeZone32);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        long long36 = week35.getMiddleMillisecond();
//        java.util.Date date37 = week35.getEnd();
//        boolean boolean38 = week34.equals((java.lang.Object) date37);
//        int int39 = week14.compareTo((java.lang.Object) week34);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 24 + "'", int30 == 24);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560365999999L + "'", long36 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test30");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int3 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getLastMillisecond();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int9 = week8.getYearValue();
//        int int10 = week8.getWeek();
//        java.util.Date date11 = week8.getStart();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date11, timeZone12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date11);
//        boolean boolean15 = week0.equals((java.lang.Object) week14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        long long17 = week16.getMiddleMillisecond();
//        boolean boolean18 = week14.equals((java.lang.Object) long17);
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = week14.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560365999999L + "'", long17 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test32");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        long long10 = regularTimePeriod9.getMiddleMillisecond();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = regularTimePeriod9.getMiddleMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560970799999L + "'", long10 == 1560970799999L);
//    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test34");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date4);
//        int int11 = week10.getYearValue();
//        org.jfree.data.time.Year year12 = week10.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(year12);
//    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test35");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int3 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getYearValue();
//        int int7 = week5.getWeek();
//        java.util.Date date8 = week5.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        java.util.Date date14 = null;
//        java.lang.Class class15 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int17 = week16.getYearValue();
//        int int18 = week16.getWeek();
//        java.util.Date date19 = week16.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date19, timeZone20);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date19);
//        java.util.Date date23 = week22.getEnd();
//        java.util.Date date24 = week22.getEnd();
//        java.lang.Class class25 = null;
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        int int27 = week26.getYearValue();
//        int int28 = week26.getWeek();
//        java.util.Date date29 = week26.getStart();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        int int33 = week32.getYearValue();
//        int int35 = week32.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass36 = week32.getClass();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        int int38 = week37.getYearValue();
//        int int39 = week37.getWeek();
//        java.util.Date date40 = week37.getStart();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date29, timeZone41);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date24, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone41);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 24 + "'", int28 == 24);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 24 + "'", int39 == 24);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test36");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getYearValue();
//        int int6 = week4.getWeek();
//        java.util.Date date7 = week4.getStart();
//        long long8 = week4.getSerialIndex();
//        org.jfree.data.time.Year year9 = week4.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(2019, year9);
//        java.util.Date date12 = year9.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(5, year9);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(4, year9);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test37() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test37");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getYearValue();
//        int int3 = week1.getWeek();
//        java.util.Date date4 = week1.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone8);
//        long long10 = week9.getSerialIndex();
//        java.util.Date date11 = week9.getStart();
//        java.util.Date date12 = week9.getStart();
//        java.util.Date date13 = week9.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week -29, 6");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week -29, 6" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week -29, 6"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week -29, 6" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Week -29, 6"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week -29, 6" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: Week -29, 6"));
    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test39");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getYearValue();
//        int int5 = week3.getWeek();
//        org.jfree.data.time.Year year6 = week3.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(4, year6);
//        java.util.Date date8 = year6.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((-2015), year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 10, year6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 24);
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test41");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getWeek();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getSerialIndex();
//        java.lang.String str5 = week0.toString();
//        int int7 = week0.compareTo((java.lang.Object) 3);
//        long long8 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560063600000L + "'", long8 == 1560063600000L);
//    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test42");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getYearValue();
//        int int5 = week3.getWeek();
//        java.util.Date date6 = week3.getStart();
//        long long7 = week3.getSerialIndex();
//        org.jfree.data.time.Year year8 = week3.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(2019, year8);
//        java.util.Date date11 = year8.getStart();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) 'a', year8);
//        java.util.Date date13 = year8.getEnd();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date13);
//    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test43");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, 24);
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getYearValue();
//        int int5 = week3.getWeek();
//        java.util.Date date6 = week3.getStart();
//        boolean boolean7 = week2.equals((java.lang.Object) week3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week3.previous();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week3.getFirstMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 10, 10");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 10, 10" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 10, 10"));
    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test45");
//        java.lang.Class class2 = null;
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getYearValue();
//        int int5 = week3.getWeek();
//        java.util.Date date6 = week3.getStart();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date6);
//        org.jfree.data.time.Year year10 = week9.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (short) 0, year10);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(53, year10);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(year10);
//    }

//    @Test
//    public void test46() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test46");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int3 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getLastMillisecond();
//        java.util.Date date8 = week0.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        long long11 = week9.getFirstMillisecond();
//        java.util.Date date12 = week9.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560063600000L + "'", long11 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test47");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getWeek();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        int int6 = week0.getWeek();
//        long long7 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, 2);
    }

//    @Test
//    public void test49() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test49");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int3 = week0.compareTo((java.lang.Object) (-1.0f));
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getYearValue();
//        int int7 = week5.getWeek();
//        java.util.Date date8 = week5.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date8);
//        java.lang.Class<?> wildcardClass12 = week11.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int14 = week13.getYearValue();
//        int int15 = week13.getWeek();
//        java.util.Date date16 = week13.getStart();
//        long long17 = week13.getLastMillisecond();
//        int int18 = week11.compareTo((java.lang.Object) long17);
//        java.util.Date date19 = week11.getEnd();
//        java.lang.Class class20 = null;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        int int22 = week21.getYearValue();
//        int int23 = week21.getWeek();
//        java.util.Date date24 = week21.getStart();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date24);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date24, timeZone28);
//        long long30 = week29.getSerialIndex();
//        java.util.Date date31 = week29.getStart();
//        java.util.Date date32 = week29.getStart();
//        int int33 = week11.compareTo((java.lang.Object) week29);
//        long long34 = week11.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668399999L + "'", long17 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 24 + "'", int23 == 24);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 107031L + "'", long30 == 107031L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560063600000L + "'", long34 == 1560063600000L);
//    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test50");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getLastMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        long long7 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week0.previous();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getYearValue();
//        int int11 = week9.getWeek();
//        int int12 = week9.getWeek();
//        java.util.Date date13 = week9.getStart();
//        java.lang.String str14 = week9.toString();
//        int int15 = week0.compareTo((java.lang.Object) week9);
//        long long16 = week9.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week9.previous();
//        long long18 = regularTimePeriod17.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1559761199999L + "'", long18 == 1559761199999L);
//    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test51");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getWeek();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        int int6 = week0.getWeek();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getYearValue();
//        int int9 = week7.getWeek();
//        java.util.Date date10 = week7.getStart();
//        long long11 = week7.getSerialIndex();
//        java.util.Date date12 = week7.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
//        boolean boolean14 = week0.equals((java.lang.Object) week13);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test52");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getYearValue();
//        int int2 = week0.getWeek();
//        int int3 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.lang.String str5 = week0.toString();
//        int int6 = week0.getWeek();
//        long long7 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560365999999L + "'", long7 == 1560365999999L);
//    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException17.getSuppressed();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException23.getSuppressed();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray30 = timePeriodFormatException29.getSuppressed();
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException29.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException35.getSuppressed();
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException41.getSuppressed();
        timePeriodFormatException39.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.Throwable[] throwableArray45 = timePeriodFormatException33.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray50 = timePeriodFormatException49.getSuppressed();
        timePeriodFormatException47.addSuppressed((java.lang.Throwable) timePeriodFormatException49);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException53 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray56 = timePeriodFormatException55.getSuppressed();
        timePeriodFormatException53.addSuppressed((java.lang.Throwable) timePeriodFormatException55);
        timePeriodFormatException49.addSuppressed((java.lang.Throwable) timePeriodFormatException53);
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException53);
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException53);
        java.lang.Class<?> wildcardClass61 = timePeriodFormatException29.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException65 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray66 = timePeriodFormatException65.getSuppressed();
        timePeriodFormatException63.addSuppressed((java.lang.Throwable) timePeriodFormatException65);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException69 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException71 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray72 = timePeriodFormatException71.getSuppressed();
        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException71);
        timePeriodFormatException63.addSuppressed((java.lang.Throwable) timePeriodFormatException69);
        java.lang.String str75 = timePeriodFormatException69.toString();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException69);
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str75.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }
}

