import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 'a', (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            piePlot1.drawBackground(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("hi!", "hi!", "", "hi!");
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            piePlot1.setInsets(rectangleInsets4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        piePlot1.drawBackgroundImage(graphics2D3, rectangle2D4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        java.lang.Comparable comparable4 = null;
        try {
            piePlot1.setExplodePercent(comparable4, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Stroke stroke4 = null;
        try {
            piePlot1.setLabelLinkStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 10.0d, (double) 100L, (int) ' ', comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState11 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot8, (java.lang.Integer) 0, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.util.List list6 = null;
        try {
            jFreeChart5.setSubtitles(list6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((double) 100.0f, (-1.0d), (double) (byte) 1, (double) (byte) -1, paint9);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) (-1.0f), (double) (byte) 0, (double) (short) -1, (double) 1.0f, paint8);
        double[][] doubleArray12 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray12);
        boolean boolean14 = blockBorder9.equals((java.lang.Object) categoryDataset13);
        org.jfree.data.KeyToGroupMap keyToGroupMap15 = null;
        try {
            org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset13, keyToGroupMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = org.jfree.chart.block.RectangleConstraint.NONE;
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle6.arrange(graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        boolean boolean10 = piePlot1.equals((java.lang.Object) piePlot5);
        piePlot5.setCircular(true, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj6 = jFreeChart5.clone();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        try {
            jFreeChart5.draw(graphics2D7, rectangle2D8, point2D9, chartRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", graphics2D1, 0.0f, 100.0f, textAnchor4, (double) 100L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Font font1 = null;
        java.awt.Color color5 = java.awt.Color.getHSBColor((float) (short) 0, (float) '4', (float) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Paint paint12 = piePlot11.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot11.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot11);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getMargin();
        try {
            org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("", font1, (java.awt.Paint) color5, rectangleEdge6, horizontalAlignment7, verticalAlignment8, rectangleInsets16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textTitle6.arrange(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            piePlot1.drawBackground(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean9 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        try {
            java.util.List list10 = categoryAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot7 = jFreeChart5.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.Object obj5 = null;
        boolean boolean6 = textAnchor4.equals(obj5);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.TOP_RIGHT", graphics2D1, (float) 15, 10.0f, textAnchor4, 1.0d, 100.0f, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj6 = jFreeChart5.clone();
        org.jfree.chart.event.ChartChangeListener chartChangeListener7 = null;
        try {
            jFreeChart5.removeChangeListener(chartChangeListener7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot1.getLegendLabelGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        java.awt.Shape shape6 = piePlot1.getLegendItemShape();
        java.lang.String str7 = piePlot1.getPlotType();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie Plot" + "'", str7.equals("Pie Plot"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot1.getLegendLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        double double5 = rectangleInsets3.extendWidth((double) (byte) -1);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getShadowXOffset();
        java.awt.Stroke stroke4 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader3);
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color1 = java.awt.Color.cyan;
        java.awt.Color color2 = java.awt.Color.getColor("VerticalAlignment.CENTER", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.Object obj5 = null;
        boolean boolean6 = textAnchor4.equals(obj5);
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.text.TextUtilities.drawAlignedString("ThreadContext", graphics2D1, 0.0f, (float) (short) -1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.Object obj5 = null;
        boolean boolean6 = textAnchor4.equals(obj5);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            java.awt.Shape shape9 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", graphics2D1, (float) 100, 0.0f, textAnchor4, 0.05d, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        categoryAxis1.setTickMarksVisible(false);
        java.lang.Comparable comparable5 = null;
        try {
            java.awt.Font font6 = categoryAxis1.getTickLabelFont(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
        pieLabelDistributor1.clear();
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = blockContainer1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        piePlot1.setForegroundAlpha((float) 0L);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
        size2D2.setHeight((double) '4');
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.lang.String str10 = projectInfo7.toString();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str10.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke3);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        piePlot1.axisChanged(axisChangeEvent5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.TOP_RIGHT", graphics2D1, (float) (byte) 1, 0.0f, (double) (short) 1, (float) (-1L), (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { (-1.0d), 100L, false, 0.2d };
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 0 };
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray9);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray6, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TextAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TextAnchor.TOP_RIGHT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart5.setBorderPaint((java.awt.Paint) color7);
        int int9 = jFreeChart5.getBackgroundImageAlignment();
        jFreeChart5.fireChartChanged();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.plot.Marker marker3 = null;
        try {
            xYPlot0.addRangeMarker(marker3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        boolean boolean10 = jFreeChart8.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis1, jFreeChart8);
        org.jfree.chart.event.ChartProgressListener chartProgressListener12 = null;
        jFreeChart8.addProgressListener(chartProgressListener12);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.block.Arrangement arrangement7 = null;
        try {
            blockContainer1.setArrangement(arrangement7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(size2D6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = color3.brighter();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        piePlot1.setLabelPaint(paint6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (java.lang.Comparable) (-1L));
        boolean boolean6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart5.setBorderPaint((java.awt.Paint) color7);
        int int9 = jFreeChart5.getBackgroundImageAlignment();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = null;
        try {
            jFreeChart5.titleChanged(titleChangeEvent10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.util.List list10 = projectInfo7.getContributors();
        java.lang.String str11 = projectInfo7.getInfo();
        java.lang.String str12 = projectInfo7.getInfo();
        java.lang.String str13 = projectInfo7.toString();
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str13.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color0 = java.awt.Color.yellow;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj6 = jFreeChart5.clone();
        java.awt.RenderingHints renderingHints7 = jFreeChart5.getRenderingHints();
        java.lang.Object obj8 = jFreeChart5.getTextAntiAlias();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(renderingHints7);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getShadowXOffset();
        java.lang.Object obj3 = piePlot1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font2, (java.awt.Paint) color3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.text.TextMeasurer textMeasurer7 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("TextBlockAnchor.TOP_RIGHT", font2, (java.awt.Paint) color5, 0.0f, textMeasurer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        categoryAxis1.setTickMarksVisible(false);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getDomainAxisEdge((int) (short) 10);
        try {
            double double11 = categoryAxis1.getCategoryEnd((int) (short) 0, 1, rectangle2D7, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        java.lang.Object obj6 = piePlot1.clone();
        piePlot1.setExplodePercent((java.lang.Comparable) (-1.0f), (double) (short) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot12 = categoryAxis11.getPlot();
        java.awt.Paint paint13 = categoryAxis11.getTickMarkPaint();
        java.awt.Paint paint14 = categoryAxis11.getLabelPaint();
        piePlot1.setLabelShadowPaint(paint14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean9 = projectInfo7.equals((java.lang.Object) true);
        java.lang.String str10 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        boolean boolean10 = jFreeChart8.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis1, jFreeChart8);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            jFreeChart8.draw(graphics2D12, rectangle2D13, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, (int) (byte) 10, (int) (short) 10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets5.getUnitType();
        double double8 = rectangleInsets5.trimWidth((double) (short) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-4.0d) + "'", double8 == (-4.0d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        java.awt.Paint paint8 = ringPlot7.getSeparatorPaint();
        valueMarker5.setLabelPaint(paint8);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(1.0d, (double) 'a', (double) 1L, 0.0d, paint8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D18 = blockContainer13.arrange(graphics2D14, rectangleConstraint17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D22 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D18, 0.025d, 0.05d, rectangleAnchor21);
        try {
            blockBorder10.draw(graphics2D11, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Image image7 = null;
        jFreeChart5.setBackgroundImage(image7);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Paint paint13 = piePlot12.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot12.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.title.TextTitle textTitle16 = jFreeChart15.getTitle();
        textTitle16.setText("");
        try {
            jFreeChart5.addSubtitle((int) 'a', (org.jfree.chart.title.Title) textTitle16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(textTitle16);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.lang.Object obj7 = textTitle6.clone();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        textTitle6.draw(graphics2D8, rectangle2D9);
        boolean boolean11 = textTitle6.getNotify();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.Object obj7 = null;
        boolean boolean8 = textAnchor6.equals(obj7);
        try {
            float float9 = textFragment3.calculateBaselineOffset(graphics2D5, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Color color0 = java.awt.Color.black;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        double double5 = piePlot2.getLabelLinkMargin();
        boolean boolean6 = color0.equals((java.lang.Object) double5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean9 = projectInfo7.equals((java.lang.Object) true);
        java.lang.String str10 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str10.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        textTitle6.setText("Pie Plot");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setInnerSeparatorExtension(3.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (java.lang.Comparable) (-1L));
        org.jfree.data.KeyToGroupMap keyToGroupMap6 = null;
        try {
            org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, keyToGroupMap6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation2 = null;
        try {
            boolean boolean3 = xYPlot0.removeAnnotation(xYAnnotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) 10, (float) 100L, (float) 100);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot6 = categoryAxis5.getPlot();
        java.awt.Paint paint7 = categoryAxis5.getTickMarkPaint();
        xYPlot0.setRangeTickBandPaint(paint7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot4 = categoryAxis3.getPlot();
        categoryAxis3.setTickMarksVisible(false);
        boolean boolean7 = horizontalAlignment0.equals((java.lang.Object) categoryAxis3);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.LEFT" + "'", str1.equals("HorizontalAlignment.LEFT"));
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color0 = java.awt.Color.black;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.util.List list10 = projectInfo7.getContributors();
        java.lang.String str11 = projectInfo7.getInfo();
        projectInfo7.setLicenceName("TextAnchor.TOP_RIGHT");
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        boolean boolean15 = xYPlot14.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot14.getDomainAxis((int) (byte) 1);
        xYPlot14.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.RingPlot ringPlot22 = new org.jfree.chart.plot.RingPlot(pieDataset21);
        java.awt.Paint paint23 = ringPlot22.getSeparatorPaint();
        valueMarker20.setLabelPaint(paint23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker20.setOutlineStroke(stroke25);
        xYPlot14.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.util.Layer layer28 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker20, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.lang.Class class0 = null;
        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
        java.util.ResourceBundle.clearCache(classLoader1);
        org.junit.Assert.assertNotNull(classLoader1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int1 = color0.getTransparency();
        java.awt.color.ColorSpace colorSpace2 = null;
        java.awt.Color color3 = java.awt.Color.WHITE;
        float[] floatArray9 = new float[] { (-1.0f), (short) 0, 0.0f, (-1L), (-1) };
        float[] floatArray10 = color3.getRGBColorComponents(floatArray9);
        try {
            float[] floatArray11 = color0.getColorComponents(colorSpace2, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart5.createBufferedImage((int) (byte) -1, (int) (byte) 100, (int) (byte) 1, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(legendTitle7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            textFragment3.draw(graphics2D4, (float) 205, 0.0f, textAnchor7, (float) 1, (-1.0f), 0.14d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        valueMarker6.setPaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        java.awt.Shape shape6 = piePlot1.getLegendItemShape();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Paint paint9 = piePlot8.getShadowPaint();
        double double10 = piePlot8.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        piePlot8.markerChanged(markerChangeEvent11);
        java.awt.Shape shape13 = piePlot8.getLegendItemShape();
        double double14 = piePlot8.getShadowXOffset();
        boolean boolean15 = piePlot1.equals((java.lang.Object) double14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint4 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        ringPlot1.setLabelShadowPaint(paint6);
        ringPlot1.setStartAngle((double) 10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot1.getLegendLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot1.getLabelPadding();
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        java.lang.Object obj5 = null;
        boolean boolean6 = textAnchor4.equals(obj5);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", graphics2D1, (float) (byte) 0, (float) 1L, textAnchor4, (double) (short) 10, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        java.lang.Object obj6 = piePlot1.clone();
        boolean boolean7 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        java.lang.String str5 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = null;
        try {
            jFreeChart5.titleChanged(titleChangeEvent7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart5.setBorderPaint((java.awt.Paint) color7);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = null;
        try {
            jFreeChart5.titleChanged(titleChangeEvent9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.jfree.chart.text.TextLine textLine2 = textBlock0.getLastLine();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(textLine2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend();
        java.awt.Stroke stroke8 = jFreeChart5.getBorderStroke();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Paint paint12 = piePlot11.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot11.getLabelGenerator();
        java.awt.Paint paint14 = piePlot11.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot18 = categoryAxis17.getPlot();
        java.awt.Paint paint19 = categoryAxis17.getLabelPaint();
        legendTitle15.setItemPaint(paint19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendTitle15.getMargin();
        try {
            jFreeChart5.addSubtitle((int) (byte) -1, (org.jfree.chart.title.Title) legendTitle15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint3 = ringPlot1.getSectionOutlinePaint((java.lang.Comparable) 1L);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        try {
            valueMarker1.setAlpha((float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(100);
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        java.awt.Font font9 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color10 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font9, (java.awt.Paint) color10);
        boolean boolean12 = objectList7.equals((java.lang.Object) color10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot(pieDataset15);
        java.awt.Paint paint17 = ringPlot16.getSeparatorPaint();
        valueMarker14.setLabelPaint(paint17);
        java.lang.Object obj19 = valueMarker14.clone();
        boolean boolean20 = objectList7.equals((java.lang.Object) valueMarker14);
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14, layer21);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot0.getDomainAxisForDataset(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 100 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        xYPlot2.clearRangeMarkers();
        java.lang.String str4 = xYPlot2.getPlotType();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = xYPlot2.getDomainMarkers((int) (short) -1, layer6);
        boolean boolean8 = textBlockAnchor0.equals((java.lang.Object) collection7);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str1.equals("TextBlockAnchor.TOP_RIGHT"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XY Plot" + "'", str4.equals("XY Plot"));
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Size2D[width=-1.0, height=205.0]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint(range2, range3);
        try {
            org.jfree.chart.util.Size2D size2D5 = textTitle0.arrange(graphics2D1, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        java.util.TimeZone timeZone2 = null;
        try {
            dateAxis1.setTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 205);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 10);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0.0f, (double) (-1L), 0.0d, (double) 0L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        java.awt.Paint paint8 = ringPlot7.getSeparatorPaint();
        valueMarker5.setLabelPaint(paint8);
        java.awt.Stroke stroke10 = valueMarker5.getStroke();
        boolean boolean12 = valueMarker5.equals((java.lang.Object) 0);
        double double13 = valueMarker5.getValue();
        org.jfree.chart.util.Layer layer14 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker5, layer14);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        double double7 = piePlot2.getExplodePercent((java.lang.Comparable) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = piePlot2.getLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot2.axisChanged(axisChangeEvent9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot8 = categoryAxis7.getPlot();
        java.awt.Paint paint9 = categoryAxis7.getLabelPaint();
        legendTitle5.setItemPaint(paint9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle5.getMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle5.arrange(graphics2D12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray14 = new org.jfree.chart.LegendItemSource[] {};
        legendTitle5.setSources(legendItemSourceArray14);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(legendItemSourceArray14);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.lang.Object obj7 = textTitle6.clone();
        java.awt.Color color8 = java.awt.Color.black;
        textTitle6.setPaint((java.awt.Paint) color8);
        int int10 = color8.getAlpha();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
        pieLabelDistributor1.distributeLabels((double) (-1), 10.0d);
        pieLabelDistributor1.sort();
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.RingPlot ringPlot4 = new org.jfree.chart.plot.RingPlot(pieDataset3);
        java.awt.Paint paint5 = ringPlot4.getSeparatorPaint();
        valueMarker2.setLabelPaint(paint5);
        java.lang.Object obj7 = valueMarker2.clone();
        org.jfree.chart.util.Layer layer8 = null;
        try {
            boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker2, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart5.setBorderPaint((java.awt.Paint) color7);
        int int9 = jFreeChart5.getBackgroundImageAlignment();
        boolean boolean10 = jFreeChart5.getAntiAlias();
        java.awt.Paint paint11 = jFreeChart5.getBorderPaint();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            jFreeChart5.handleClick((int) (short) 10, 1, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart5.setBorderPaint((java.awt.Paint) color7);
        int int9 = jFreeChart5.getBackgroundImageAlignment();
        try {
            org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart5.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend();
        java.awt.Paint paint8 = jFreeChart5.getBorderPaint();
        java.util.List list9 = null;
        try {
            jFreeChart5.setSubtitles(list9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        double double7 = piePlot2.getExplodePercent((java.lang.Comparable) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = piePlot2.getLegendItems();
        java.awt.Paint paint10 = piePlot2.getSectionPaint((java.lang.Comparable) 0.14d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.Object obj1 = null;
        boolean boolean2 = rotation0.equals(obj1);
        double double3 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Font font10 = piePlot6.getLabelFont();
        java.awt.Paint paint12 = piePlot6.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Paint paint15 = piePlot14.getShadowPaint();
        double double16 = piePlot14.getShadowXOffset();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getParent();
        java.awt.Paint paint18 = piePlot14.getBaseSectionOutlinePaint();
        piePlot6.setLabelBackgroundPaint(paint18);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Stroke stroke21 = xYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TextAnchor.TOP_RIGHT", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "VerticalAlignment.CENTER", "TextAnchor.TOP_RIGHT");
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.Color color4 = color3.brighter();
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color3);
        piePlot1.setStartAngle((double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Font font6 = piePlot2.getLabelFont();
        java.awt.Paint paint8 = piePlot2.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Paint paint11 = piePlot10.getShadowPaint();
        double double12 = piePlot10.getShadowXOffset();
        org.jfree.chart.plot.Plot plot13 = piePlot10.getParent();
        java.awt.Paint paint14 = piePlot10.getBaseSectionOutlinePaint();
        piePlot2.setLabelBackgroundPaint(paint14);
        piePlot2.setMinimumArcAngleToDraw((double) (short) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        piePlotState1.setPieWRadius((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = piePlotState1.getInfo();
        piePlotState1.setLatestAngle((double) 'a');
        org.junit.Assert.assertNull(plotRenderingInfo4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean9 = projectInfo7.equals((java.lang.Object) true);
        projectInfo7.setVersion("");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(100);
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            xYPlot0.addRangeMarker(255, marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        java.awt.Font font6 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color7 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font6, (java.awt.Paint) color7);
        boolean boolean9 = legendItemCollection4.equals((java.lang.Object) "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.Color color7 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        double double10 = piePlot9.getStartAngle();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot9.setBaseSectionOutlineStroke(stroke11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Paint paint15 = piePlot14.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot14.getLabelGenerator();
        java.awt.Paint paint17 = piePlot14.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot14.getLabelPadding();
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets18.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke11, rectangleInsets18);
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D27 = blockContainer22.arrange(graphics2D23, rectangleConstraint26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D27, 0.025d, 0.05d, rectangleAnchor30);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D31);
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets18.createOutsetRectangle(rectangle2D31, false, false);
        try {
            piePlot2.drawBackground(graphics2D6, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(unitType19);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.Color color12 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        double double15 = piePlot14.getStartAngle();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot14.setBaseSectionOutlineStroke(stroke16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Paint paint20 = piePlot19.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = piePlot19.getLabelGenerator();
        java.awt.Paint paint22 = piePlot19.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = piePlot19.getLabelPadding();
        org.jfree.chart.util.UnitType unitType24 = rectangleInsets23.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color12, stroke16, rectangleInsets23);
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D32 = blockContainer27.arrange(graphics2D28, rectangleConstraint31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D36 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, 0.025d, 0.05d, rectangleAnchor35);
        org.jfree.chart.entity.ChartEntity chartEntity37 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D36);
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets23.createOutsetRectangle(rectangle2D36, false, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean42 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        try {
            org.jfree.chart.axis.AxisState axisState44 = dateAxis1.draw(graphics2D9, 1.0E-5d, rectangle2D11, rectangle2D36, rectangleEdge41, plotRenderingInfo43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 90.0d + "'", double15 == 90.0d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(unitType24);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        xYPlot0.setNoDataMessage("TextAnchor.TOP_RIGHT");
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        try {
            valueMarker1.setAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(100);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Color color1 = java.awt.Color.getColor("ThreadContext");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str1.equals("TextBlockAnchor.TOP_LEFT"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        boolean boolean2 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot8 = categoryAxis7.getPlot();
        java.awt.Paint paint9 = categoryAxis7.getLabelPaint();
        legendTitle5.setItemPaint(paint9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle5.getMargin();
        double double13 = rectangleInsets11.calculateRightInset(0.0d);
        double double15 = rectangleInsets11.calculateTopOutset(2.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextBlockAnchor.TOP_RIGHT", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker7.getLabelOffsetType();
        org.jfree.chart.util.Layer layer10 = null;
        try {
            boolean boolean11 = xYPlot0.removeRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker7, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.data.Range range7 = rectangleConstraint5.getWidthRange();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Font font10 = piePlot6.getLabelFont();
        java.awt.Paint paint12 = piePlot6.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.awt.Paint paint15 = piePlot14.getShadowPaint();
        double double16 = piePlot14.getShadowXOffset();
        org.jfree.chart.plot.Plot plot17 = piePlot14.getParent();
        java.awt.Paint paint18 = piePlot14.getBaseSectionOutlinePaint();
        piePlot6.setLabelBackgroundPaint(paint18);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Stroke stroke4 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        piePlot1.markerChanged(markerChangeEvent5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        double double9 = dateAxis1.getAutoRangeMinimumSize();
        try {
            dateAxis1.zoomRange(0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("TextBlockAnchor.TOP_RIGHT", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.RingPlot ringPlot7 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        java.awt.Paint paint8 = ringPlot7.getSeparatorPaint();
        valueMarker5.setLabelPaint(paint8);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker5.setOutlineStroke(stroke10);
        categoryAxis1.setTickMarkStroke(stroke10);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toRangeWidth(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend();
        java.awt.Stroke stroke8 = jFreeChart5.getBorderStroke();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot9 = jFreeChart5.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("TextAnchor.TOP_RIGHT", graphics2D1, (float) 0, (-1.0f), 0.4d, (float) (byte) 100, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint4 = categoryAxis1.getLabelPaint();
        java.lang.String str5 = categoryAxis1.getLabelToolTip();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.Layer layer6 = null;
        try {
            boolean boolean7 = xYPlot0.removeDomainMarker((int) (short) 10, (org.jfree.chart.plot.Marker) valueMarker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D13 = blockContainer8.arrange(graphics2D9, rectangleConstraint12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, 0.025d, 0.05d, rectangleAnchor16);
        try {
            jFreeChart5.draw(graphics2D6, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.util.List list10 = projectInfo7.getContributors();
        java.lang.String str11 = projectInfo7.getInfo();
        java.lang.String str12 = projectInfo7.getInfo();
        org.jfree.chart.text.TextBlock textBlock13 = new org.jfree.chart.text.TextBlock();
        java.util.List list14 = textBlock13.getLines();
        java.util.List list15 = textBlock13.getLines();
        projectInfo7.setContributors(list15);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        xYPlot0.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        xYPlot10.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis13 = xYPlot10.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D14 = xYPlot10.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) (short) 0, plotRenderingInfo9, point2D14, false);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace17, false);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis13);
        org.junit.Assert.assertNotNull(point2D14);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        boolean boolean6 = dateAxis1.isHiddenValue((long) 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        boolean boolean11 = jFreeChart9.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis2, jFreeChart9);
        boolean boolean13 = strokeMap0.equals((java.lang.Object) jFreeChart9);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.awt.Paint paint18 = piePlot17.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = piePlot17.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot17);
        org.jfree.chart.title.TextTitle textTitle21 = jFreeChart20.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = textTitle21.getMargin();
        textTitle21.setWidth(90.0d);
        textTitle21.setNotify(false);
        java.awt.geom.Rectangle2D rectangle2D27 = textTitle21.getBounds();
        try {
            jFreeChart9.addSubtitle(255, (org.jfree.chart.title.Title) textTitle21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(textTitle21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot1.markerChanged(markerChangeEvent4);
        boolean boolean6 = piePlot1.getIgnoreNullValues();
        java.lang.Object obj7 = null;
        boolean boolean8 = piePlot1.equals(obj7);
        double double9 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font2, (java.awt.Paint) color3);
        boolean boolean5 = objectList0.equals((java.lang.Object) color3);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        java.awt.Paint paint10 = piePlot7.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = legendTitle11.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle11.setLegendItemGraphicAnchor(rectangleAnchor13);
        legendTitle11.setNotify(false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = legendTitle11.getHorizontalAlignment();
        java.awt.Paint paint18 = legendTitle11.getItemPaint();
        boolean boolean19 = objectList0.equals((java.lang.Object) paint18);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        blockContainer1.add((org.jfree.chart.block.Block) textTitle2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = textTitle10.getMargin();
        textTitle10.setWidth(90.0d);
        textTitle10.setNotify(false);
        java.awt.Paint paint16 = textTitle10.getPaint();
        java.awt.Paint paint17 = textTitle10.getPaint();
        blockContainer1.add((org.jfree.chart.block.Block) textTitle10);
        blockContainer1.setHeight((double) (short) 10);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        piePlot1.setCircular(true);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        java.awt.Paint paint9 = piePlot6.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset10 = piePlot6.getDataset();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.plot.Plot plot12 = plotChangeEvent11.getPlot();
        piePlot1.notifyListeners(plotChangeEvent11);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        boolean boolean4 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setLabel("ThreadContext");
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
        double double3 = size2D2.getWidth();
        size2D2.width = '#';
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Paint paint4 = null;
        try {
            xYPlot0.setNoDataMessagePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        int int16 = xYPlot0.getDatasetCount();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            boolean boolean19 = xYPlot0.removeRangeMarker(marker17, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint4 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = piePlot7.getLabelOutlinePaint();
        java.awt.Paint paint11 = piePlot7.getNoDataMessagePaint();
        boolean boolean12 = piePlot3.equals((java.lang.Object) piePlot7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot3.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.title.LegendTitle legendTitle16 = null;
        try {
            jFreeChart15.addLegend(legendTitle16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        double double6 = piePlot3.getLabelLinkMargin();
        java.lang.String str7 = piePlot3.getNoDataMessage();
        boolean boolean8 = textBlock0.equals((java.lang.Object) piePlot3);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        piePlot1.setCircular(true);
        java.lang.String str5 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getShadowXOffset();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot4);
        float float7 = piePlot4.getForegroundAlpha();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        boolean boolean10 = piePlot1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot5.getLabelPadding();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        java.awt.Paint paint3 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            xYPlot0.addDomainMarker(0, marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset3);
        java.lang.Comparable comparable5 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset3, comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker12.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor13);
        legendTitle5.setHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        java.awt.Image image7 = null;
        jFreeChart5.setBackgroundImage(image7);
        org.jfree.chart.event.ChartChangeListener chartChangeListener9 = null;
        try {
            jFreeChart5.removeChangeListener(chartChangeListener9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot0.getDomainMarkers(layer16);
        double double18 = xYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range8);
        org.jfree.data.Range range10 = dateAxis5.getDefaultAutoRange();
        java.awt.Shape shape11 = dateAxis5.getRightArrow();
        dateAxis5.setInverted(false);
        int int14 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        dateAxis5.setAutoRangeMinimumSize(1.0d, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        piePlot1.setSimpleLabels(false);
        java.awt.Stroke stroke8 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) 0L);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(stroke8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker12.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean16 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge15);
        legendTitle5.setLegendItemGraphicEdge(rectangleEdge15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle5.getVerticalAlignment();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(verticalAlignment18);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getParent();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        java.awt.Paint paint9 = legendTitle5.getItemPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        float float5 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.configure();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 2.0f + "'", float5 == 2.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        int int8 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(layer9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Paint paint13 = piePlot12.getShadowPaint();
        double double14 = piePlot12.getShadowXOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        piePlot12.markerChanged(markerChangeEvent15);
        boolean boolean17 = piePlot12.getIgnoreNullValues();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot12.setBaseSectionOutlineStroke(stroke18);
        xYPlot0.setDomainGridlineStroke(stroke18);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str2.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] ().\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke4);
        java.awt.Stroke stroke6 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font2, (java.awt.Paint) color3);
        boolean boolean5 = objectList0.equals((java.lang.Object) color3);
        objectList0.clear();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font3, (java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = piePlot7.getLabelOutlinePaint();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font3, paint10);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("Pie Plot", font3);
        float float13 = textFragment12.getBaselineOffset();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            float float16 = textFragment12.calculateBaselineOffset(graphics2D14, textAnchor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "", doubleArray2);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double7 = piePlot1.getExplodePercent((java.lang.Comparable) 1.0f);
        java.awt.Color color8 = java.awt.Color.cyan;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) (short) 0);
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getShadowXOffset();
        java.awt.Paint paint5 = null;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 10L, paint5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getStartAngle();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot2.setBaseSectionOutlineStroke(stroke4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        java.awt.Paint paint10 = piePlot7.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot7.getLabelPadding();
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke4, rectangleInsets11);
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D20 = blockContainer15.arrange(graphics2D16, rectangleConstraint19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D24 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 0.025d, 0.05d, rectangleAnchor23);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets11.createOutsetRectangle(rectangle2D24, false, false);
        double double30 = rectangleInsets11.calculateRightOutset(0.2d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("Multiple Pie Plot", (int) (short) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) (short) 0);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str10 = rectangleConstraint9.toString();
        try {
            org.jfree.chart.util.Size2D size2D11 = flowArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str10.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        boolean boolean10 = jFreeChart8.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis1, jFreeChart8);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) 0);
        categoryAxis1.configure();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        boolean boolean10 = piePlot1.equals((java.lang.Object) piePlot5);
        java.awt.Paint paint11 = null;
        try {
            piePlot5.setBaseSectionPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = legendTitle5.getLegendItemGraphicPadding();
        double double8 = rectangleInsets6.trimWidth(10.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.0d + "'", double8 == 6.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
        pieLabelDistributor1.distributeLabels((double) (-1), 10.0d);
        pieLabelDistributor1.clear();
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace4, true);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        double double9 = piePlot8.getStartAngle();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot8.setBaseSectionOutlineStroke(stroke10);
        xYPlot0.setDomainCrosshairStroke(stroke10);
        int int13 = xYPlot0.getSeriesCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.0d + "'", double9 == 90.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        java.lang.Object obj6 = valueMarker1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = null;
        try {
            valueMarker1.setLabelOffset(rectangleInsets7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getFixedDimension();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot9 = categoryAxis8.getPlot();
        java.awt.Paint paint10 = categoryAxis8.getTickMarkPaint();
        piePlot4.setSectionOutlinePaint((java.lang.Comparable) 90.0d, paint10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint1 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot4.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        jFreeChart7.setBorderPaint((java.awt.Paint) color9);
        int int11 = jFreeChart7.getBackgroundImageAlignment();
        boolean boolean12 = jFreeChart7.getAntiAlias();
        java.awt.Paint paint13 = jFreeChart7.getBorderPaint();
        multiplePiePlot0.setPieChart(jFreeChart7);
        java.awt.Paint paint15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            jFreeChart7.setTextAntiAlias((java.lang.Object) paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.Color[r=128,g=128,b=128] incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer(xYItemRenderer2);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getShadowXOffset();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot4);
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryAxis1.setTickLabelFont(font7);
        java.lang.Object obj9 = categoryAxis1.clone();
        categoryAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        java.util.Date date9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot10.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine();
        boolean boolean14 = rectangleEdge12.equals((java.lang.Object) textLine13);
        java.awt.Color color15 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        double double18 = piePlot17.getStartAngle();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot17.setBaseSectionOutlineStroke(stroke19);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        java.awt.Paint paint23 = piePlot22.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator24 = piePlot22.getLabelGenerator();
        java.awt.Paint paint25 = piePlot22.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = piePlot22.getLabelPadding();
        org.jfree.chart.util.UnitType unitType27 = rectangleInsets26.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color15, stroke19, rectangleInsets26);
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer30 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D35 = blockContainer30.arrange(graphics2D31, rectangleConstraint34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D39 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, 0.025d, 0.05d, rectangleAnchor38);
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets26.createOutsetRectangle(rectangle2D39, false, false);
        boolean boolean44 = textLine13.equals((java.lang.Object) rectangle2D39);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        try {
            double double46 = dateAxis1.dateToJava2D(date9, rectangle2D39, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 90.0d + "'", double18 == 90.0d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(unitType27);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        piePlot1.setShadowXOffset((double) 15);
        boolean boolean6 = piePlot1.isCircular();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color3 = java.awt.Color.WHITE;
        float[] floatArray9 = new float[] { (-1.0f), (short) 0, 0.0f, (-1L), (-1) };
        float[] floatArray10 = color3.getRGBColorComponents(floatArray9);
        float[] floatArray11 = color2.getRGBComponents(floatArray10);
        try {
            float[] floatArray12 = color0.getComponents(colorSpace1, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        try {
            dateAxis1.setRange((double) 10L, 2.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        textTitle6.setWidth(90.0d);
        textTitle6.setNotify(false);
        java.awt.Paint paint12 = textTitle6.getPaint();
        java.awt.Paint paint13 = textTitle6.getPaint();
        java.lang.String str14 = textTitle6.getURLText();
        textTitle6.setID("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        double double9 = rectangleInsets7.calculateLeftInset((double) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 205);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset3, true);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset3, false);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset3, 0.05d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setDepthFactor((-1.0d));
        piePlot3D0.setDarkerSides(true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint4 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        ringPlot1.setLabelShadowPaint(paint6);
        double double9 = ringPlot1.getExplodePercent((java.lang.Comparable) "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        double double10 = ringPlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14d + "'", double10 == 0.14d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        double double7 = piePlot2.getExplodePercent((java.lang.Comparable) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = piePlot2.getLegendItems();
        int int9 = legendItemCollection8.getItemCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightInset((double) 255);
        double double4 = rectangleInsets0.calculateBottomInset(90.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker12.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle5.getLegendItemGraphicLocation();
        legendTitle5.setWidth((double) 0.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D13 = blockContainer8.arrange(graphics2D9, rectangleConstraint12);
        legendTitle6.setWrapper(blockContainer8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle6.getLegendItemGraphicLocation();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        java.awt.Stroke stroke3 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.data.general.PieDataset pieDataset6 = piePlot1.getDataset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(pieDataset6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        java.awt.Paint paint5 = null;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "", paint5);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend();
        jFreeChart5.setAntiAlias(false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot10 = jFreeChart5.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(legendTitle7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10);
        java.lang.String str12 = chartEntity11.getShapeCoords();
        java.awt.Shape shape13 = chartEntity11.getArea();
        java.lang.Object obj14 = chartEntity11.clone();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0,-49,1,51" + "'", str12.equals("0,-49,1,51"));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textFragment3.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleAnchor.RIGHT", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke4);
        xYPlot0.setRangeCrosshairValue((double) 10, true);
        xYPlot0.mapDatasetToDomainAxis((int) (short) 100, (int) (short) 0);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, range8);
        org.jfree.data.Range range10 = org.jfree.data.Range.combine(range6, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range6, (double) 10);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        java.lang.Object obj7 = jFreeChart5.getTextAntiAlias();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot8 = jFreeChart5.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 205);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset3, true);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset3, (int) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        double double4 = piePlot2.getShadowXOffset();
        org.jfree.chart.plot.Plot plot5 = piePlot2.getParent();
        java.awt.Paint paint6 = piePlot2.getBaseSectionOutlinePaint();
        double double7 = piePlot2.getMaximumLabelWidth();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("ClassContext", (org.jfree.chart.plot.Plot) piePlot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14d + "'", double7 == 0.14d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        double double2 = ringPlot1.getSectionDepth();
        java.awt.Color color3 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getStartAngle();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot5.setBaseSectionOutlineStroke(stroke7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.awt.Paint paint11 = piePlot10.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot10.getLabelGenerator();
        java.awt.Paint paint13 = piePlot10.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot10.getLabelPadding();
        org.jfree.chart.util.UnitType unitType15 = rectangleInsets14.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color3, stroke7, rectangleInsets14);
        java.awt.Paint paint17 = lineBorder16.getPaint();
        ringPlot1.setLabelLinkPaint(paint17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker1.setOutlineStroke(stroke6);
        java.lang.Object obj8 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        objectList0.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getMargin();
        textTitle9.setWidth(90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle9.getPadding();
        int int14 = objectList0.indexOf((java.lang.Object) textTitle9);
        java.awt.Paint paint15 = textTitle9.getBackgroundPaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.lang.Object obj3 = categoryAxis1.clone();
        categoryAxis1.setLabelURL("hi!");
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        java.awt.Paint paint10 = piePlot7.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot14 = categoryAxis13.getPlot();
        java.awt.Paint paint15 = categoryAxis13.getLabelPaint();
        legendTitle11.setItemPaint(paint15);
        categoryAxis1.setAxisLinePaint(paint15);
        boolean boolean18 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getOutlinePaint();
        java.awt.Paint paint5 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        double double7 = rectangleConstraint5.getWidth();
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        double double3 = piePlot2.getStartAngle();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot2.setBaseSectionOutlineStroke(stroke4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        java.awt.Paint paint10 = piePlot7.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot7.getLabelPadding();
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke4, rectangleInsets11);
        float[] floatArray14 = null;
        float[] floatArray15 = color0.getComponents(floatArray14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        java.lang.Object obj7 = jFreeChart5.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeListener chartChangeListener8 = null;
        try {
            jFreeChart5.addChangeListener(chartChangeListener8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis5.setLowerMargin(0.0d);
        int int8 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = xYPlot0.getRangeMarkers(layer9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset11);
        java.awt.Paint paint13 = ringPlot12.getSeparatorPaint();
        xYPlot0.setRangeTickBandPaint(paint13);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getRangeAxis((int) 'a');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder8 = null;
        try {
            xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        boolean boolean10 = piePlot1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot1.getLabelGenerator();
        piePlot1.setShadowYOffset(100.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart5.clearSubtitles();
        org.jfree.chart.title.LegendTitle legendTitle7 = jFreeChart5.getLegend();
        java.awt.Stroke stroke8 = jFreeChart5.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener9 = null;
        jFreeChart5.removeProgressListener(chartProgressListener9);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNull(legendTitle7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine();
        boolean boolean4 = rectangleEdge2.equals((java.lang.Object) textLine3);
        org.jfree.chart.text.TextFragment textFragment5 = textLine3.getFirstTextFragment();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(textFragment5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Other");
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        try {
            categoryPlot0.setRangeAxisLocation((-1), axisLocation5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis1.getTickUnit();
        java.awt.Stroke stroke6 = dateAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        java.awt.Paint paint4 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.TOP_RIGHT", "TextAnchor.TOP_RIGHT", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, 205);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke3);
        java.awt.Paint paint5 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(range1, range2);
        boolean boolean5 = range2.contains((double) (short) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, range9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str14 = rectangleConstraint13.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint13.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((-35.57979797979798d), range2, lengthConstraintType6, (double) 100L, range9, lengthConstraintType15);
        double double17 = range9.getCentralValue();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str14.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        java.awt.Paint paint4 = categoryAxis2.getTickMarkPaint();
        java.awt.Font font6 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 15);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        java.awt.Paint paint8 = multiplePiePlot7.getAggregatedItemsPaint();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        xYPlot9.clearRangeMarkers();
        java.lang.String str11 = xYPlot9.getPlotType();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot9.getDomainMarkers((int) (short) -1, layer13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot9);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle15.getItemLabelPadding();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Paint paint19 = piePlot18.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = piePlot18.getLabelGenerator();
        java.awt.Paint paint21 = piePlot18.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot18);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle22.setLegendItemGraphicAnchor(rectangleAnchor24);
        legendTitle22.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker29.getLabelAnchor();
        legendTitle22.setLegendItemGraphicAnchor(rectangleAnchor30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge32);
        legendTitle22.setLegendItemGraphicEdge(rectangleEdge32);
        legendTitle15.setLegendItemGraphicEdge(rectangleEdge32);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        try {
            org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("TextAnchor.TOP_RIGHT", font6, paint8, rectangleEdge32, horizontalAlignment36, verticalAlignment37, rectangleInsets38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "XY Plot" + "'", str11.equals("XY Plot"));
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(verticalAlignment37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot4.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        java.lang.Object obj9 = textTitle8.clone();
        java.awt.Color color10 = java.awt.Color.black;
        textTitle8.setPaint((java.awt.Paint) color10);
        int int12 = objectList0.indexOf((java.lang.Object) textTitle8);
        textTitle8.setURLText("");
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker1.getLabelOffsetType();
        java.lang.String str7 = valueMarker1.getLabel();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        piePlot1.setCircular(true);
        boolean boolean5 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        boolean boolean9 = projectInfo7.equals((java.lang.Object) true);
        java.awt.Image image13 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image13, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo17);
        java.util.List list19 = projectInfo17.getContributors();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(list19);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        java.awt.Paint paint3 = ringPlot1.getSeparatorPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(2.0d, (double) 100L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        double double4 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        double double11 = categoryPlot0.getAnchorValue();
        java.awt.Stroke stroke12 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getFixedDimension();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot4);
        int int6 = piePlot4.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Stroke stroke4 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieSectionLabelGenerator5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke4);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation6 = null;
        try {
            boolean boolean7 = xYPlot0.removeAnnotation(xYAnnotation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.text.DateFormat dateFormat4 = dateAxis1.getDateFormatOverride();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        xYPlot6.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot6.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D10 = xYPlot6.getQuadrantOrigin();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D17 = blockContainer12.arrange(graphics2D13, rectangleConstraint16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D17, 0.025d, 0.05d, rectangleAnchor20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot22.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextLine textLine25 = new org.jfree.chart.text.TextLine();
        boolean boolean26 = rectangleEdge24.equals((java.lang.Object) textLine25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace28 = dateAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) xYPlot6, rectangle2D21, rectangleEdge24, axisSpace27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        xYPlot0.clearRangeMarkers();
        xYPlot0.setNoDataMessage("TextAnchor.TOP_RIGHT");
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot0.getRangeAxisEdge((int) (short) 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.lang.String str1 = blockContainer0.getID();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Stroke stroke2 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", image3, "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setLicenceName("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setCopyright("");
        projectInfo7.setCopyright("Pie Plot");
        org.jfree.chart.ui.Library[] libraryArray14 = projectInfo7.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray14);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addDomainMarker(0, categoryMarker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 0);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 15);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        java.lang.Object obj1 = paintMap0.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot5 = categoryAxis4.getPlot();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        double double8 = piePlot7.getShadowXOffset();
        categoryAxis4.setPlot((org.jfree.chart.plot.Plot) piePlot7);
        java.awt.Paint paint10 = piePlot7.getLabelBackgroundPaint();
        paintMap0.put((java.lang.Comparable) "HorizontalAlignment.LEFT", paint10);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        double double4 = dateAxis1.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis6.setLowerMargin(0.0d);
        java.awt.Shape shape9 = dateAxis6.getLeftArrow();
        org.jfree.data.Range range10 = dateAxis6.getRange();
        dateAxis1.setDefaultAutoRange(range10);
        dateAxis1.zoomRange((double) (-1L), (double) (byte) 10);
        dateAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot0.getRangeAxisEdge();
        try {
            xYPlot0.setBackgroundImageAlpha((float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        double double5 = piePlot4.getShadowXOffset();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        piePlot4.setDataset(pieDataset6);
        boolean boolean8 = categoryAxis1.hasListener((java.util.EventListener) piePlot4);
        double double9 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font5 = categoryAxis1.getLabelFont();
        categoryAxis1.setTickMarkInsideLength((float) 205);
        categoryAxis1.configure();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot6 = categoryAxis5.getPlot();
        java.awt.Paint paint7 = categoryAxis5.getTickMarkPaint();
        xYPlot0.setRangeTickBandPaint(paint7);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke11 = xYPlot10.getRangeCrosshairStroke();
        boolean boolean12 = xYPlot10.isDomainGridlinesVisible();
        xYPlot10.configureRangeAxes();
        int int14 = xYPlot10.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        xYPlot10.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis17, true);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis21.setLowerMargin(0.0d);
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRange(range24);
        org.jfree.data.Range range26 = dateAxis21.getDefaultAutoRange();
        org.jfree.data.Range range27 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range28 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range27, range28);
        org.jfree.data.Range range30 = org.jfree.data.Range.combine(range26, range28);
        dateAxis17.setRange(range26, false, false);
        xYPlot0.setRangeAxis((int) '4', (org.jfree.chart.axis.ValueAxis) dateAxis17, true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        xYPlot0.rendererChanged(rendererChangeEvent5);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = xYPlot0.getLegendItems();
        java.awt.Font font6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("VerticalAlignment.CENTER", font6, (java.awt.Paint) color7);
        boolean boolean9 = legendItemCollection4.equals((java.lang.Object) "VerticalAlignment.CENTER");
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine();
        boolean boolean4 = rectangleEdge2.equals((java.lang.Object) textLine3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot7 = categoryAxis6.getPlot();
        categoryAxis6.setTickMarksVisible(false);
        java.awt.Font font10 = categoryAxis6.getLabelFont();
        categoryAxis6.setTickMarkInsideLength((float) 205);
        categoryAxis6.setUpperMargin((double) 'a');
        boolean boolean15 = textLine3.equals((java.lang.Object) 'a');
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.awt.Shape shape26 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D20, (float) (-1L), (float) '#', textAnchor23, 10.0d, textAnchor25);
        textLine3.draw(graphics2D16, (float) 1L, (float) 1L, textAnchor23, 0.0f, (float) 1, 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(plot7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNull(shape26);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D16 = blockContainer11.arrange(graphics2D12, rectangleConstraint15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D20 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D16, 0.025d, 0.05d, rectangleAnchor19);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20);
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        try {
            java.lang.Object obj23 = legendTitle5.draw(graphics2D9, rectangle2D20, (java.lang.Object) strokeArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(strokeArray22);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Paint paint13 = piePlot10.getLabelOutlinePaint();
        org.jfree.chart.plot.Plot plot14 = piePlot10.getParent();
        java.awt.Stroke stroke15 = piePlot10.getLabelOutlineStroke();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) piePlot10);
        boolean boolean17 = piePlot10.isSubplot();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        paintMap0.clear();
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.Object obj1 = null;
        boolean boolean2 = rotation0.equals(obj1);
        java.lang.String str3 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Rotation.CLOCKWISE" + "'", str3.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        java.lang.Object obj4 = size2D3.clone();
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setFixedDimension(0.0d);
        double double9 = dateAxis1.getAutoRangeMinimumSize();
        dateAxis1.setAutoRangeMinimumSize((double) 10L);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(2.0d, (double) 100L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);
        double double7 = size2D6.getWidth();
        org.jfree.chart.util.Size2D size2D8 = rectangleConstraint3.calculateConstrainedSize(size2D6);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(size2D8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
        objectList0.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getMargin();
        textTitle9.setWidth(90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = textTitle9.getPadding();
        int int14 = objectList0.indexOf((java.lang.Object) textTitle9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.PiePlotState piePlotState16 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo15);
        piePlotState16.setPieWRadius((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = piePlotState16.getInfo();
        int int20 = objectList0.indexOf((java.lang.Object) piePlotState16);
        java.lang.Object obj21 = objectList0.clone();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(plotRenderingInfo19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", graphics2D1, (float) 10, (float) (short) 1, textAnchor4, (double) 1L, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_RIGHT" + "'", str5.equals("TextAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.jfree.data.Range range5 = dateAxis1.getRange();
        boolean boolean6 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Paint paint8 = piePlot5.getLabelOutlinePaint();
        java.awt.Paint paint9 = piePlot5.getNoDataMessagePaint();
        boolean boolean10 = piePlot1.equals((java.lang.Object) piePlot5);
        org.jfree.data.general.PieDataset pieDataset11 = piePlot5.getDataset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = null;
        piePlot5.setURLGenerator(pieURLGenerator12);
        java.awt.Paint paint14 = piePlot5.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(pieDataset11);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray1 = null;
        try {
            categoryPlot0.setDomainAxes(categoryAxisArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        double double7 = rectangleInsets5.calculateRightInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        xYPlot0.setRenderer((int) '#', xYItemRenderer2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        java.awt.Paint paint8 = piePlot5.getBackgroundPaint();
        xYPlot0.setOutlinePaint(paint8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot0.getDomainMarkers((int) (byte) 0, layer11);
        java.lang.Object obj13 = xYPlot0.clone();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 0);
        categoryAxis1.setLabelURL("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        categoryAxis1.setCategoryLabelPositionOffset(100);
        categoryAxis1.setLowerMargin(2.0d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        categoryAxis1.removeChangeListener(axisChangeListener12);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.Plot plot5 = piePlot1.getParent();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot7.getLegendLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator8);
        double double10 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = xYPlot0.getDomainMarkers(layer16);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation18 = null;
        try {
            boolean boolean19 = xYPlot0.removeAnnotation(xYAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Color color0 = java.awt.Color.GREEN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5);
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) '#');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D11 = blockContainer6.arrange(graphics2D7, rectangleConstraint10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, 0.025d, 0.05d, rectangleAnchor14);
        try {
            categoryPlot0.drawBackground(graphics2D4, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        java.awt.Font font5 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 15);
        java.awt.Paint paint6 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis1.setLabelPaint(paint6);
        java.lang.Comparable comparable8 = null;
        try {
            categoryAxis1.removeCategoryLabelToolTip(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        textBlock0.setLineAlignment(horizontalAlignment2);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.yellow;
        textBlock0.addLine("TextBlockAnchor.TOP_RIGHT", font5, (java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textBlock0.calculateDimensions(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.RingPlot ringPlot3 = new org.jfree.chart.plot.RingPlot(pieDataset2);
        java.awt.Paint paint4 = ringPlot3.getSeparatorPaint();
        valueMarker1.setLabelPaint(paint4);
        java.lang.Object obj6 = valueMarker1.clone();
        valueMarker1.setLabel("ThreadContext");
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = valueMarker10.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker10.getLabelOffsetType();
        valueMarker1.setLabelOffsetType(lengthAdjustmentType12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot14.setRenderer((int) '#', xYItemRenderer16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot14.setDomainGridlineStroke(stroke18);
        xYPlot14.setRangeCrosshairValue((double) 10, true);
        java.awt.Font font23 = xYPlot14.getNoDataMessageFont();
        valueMarker1.setLabelFont(font23);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getDomainAxis((int) (byte) 1);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        valueMarker6.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        valueMarker6.setOutlineStroke(stroke11);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        int int16 = xYPlot0.getDatasetCount();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextStroke();
        xYPlot0.setDomainCrosshairStroke(stroke18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        double double6 = piePlot5.getShadowXOffset();
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) piePlot5);
        int int8 = categoryPlot0.getDomainAxisIndex(categoryAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        double double11 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabelToolTip("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        org.jfree.data.Range range15 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis12);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("HorizontalAlignment.LEFT");
        float float2 = textFragment1.getBaselineOffset();
        java.awt.Paint paint3 = textFragment1.getPaint();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj2 = new java.lang.Object();
        boolean boolean3 = verticalAlignment1.equals(obj2);
        java.lang.String str4 = verticalAlignment1.toString();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot7);
        java.awt.Font font11 = piePlot7.getLabelFont();
        java.awt.Paint paint13 = piePlot7.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Paint paint16 = piePlot15.getShadowPaint();
        double double17 = piePlot15.getShadowXOffset();
        org.jfree.chart.plot.Plot plot18 = piePlot15.getParent();
        java.awt.Paint paint19 = piePlot15.getBaseSectionOutlinePaint();
        piePlot7.setLabelBackgroundPaint(paint19);
        boolean boolean21 = verticalAlignment1.equals((java.lang.Object) piePlot7);
        java.lang.String str22 = verticalAlignment1.toString();
        boolean boolean23 = multiplePiePlot0.equals((java.lang.Object) verticalAlignment1);
        java.lang.String str24 = multiplePiePlot0.getPlotType();
        java.lang.Comparable comparable25 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot26.getDomainAxisEdge((int) (short) 10);
        boolean boolean29 = multiplePiePlot0.equals((java.lang.Object) rectangleEdge28);
        java.awt.Paint paint30 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "VerticalAlignment.CENTER" + "'", str22.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Multiple Pie Plot" + "'", str24.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + "Other" + "'", comparable25.equals("Other"));
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        double double3 = piePlot1.getShadowXOffset();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getParent();
        java.awt.Paint paint5 = piePlot1.getBaseSectionOutlinePaint();
        double double6 = piePlot1.getMaximumLabelWidth();
        boolean boolean7 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj2 = new java.lang.Object();
        boolean boolean3 = verticalAlignment1.equals(obj2);
        java.lang.String str4 = verticalAlignment1.toString();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot7);
        java.awt.Font font11 = piePlot7.getLabelFont();
        java.awt.Paint paint13 = piePlot7.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Paint paint16 = piePlot15.getShadowPaint();
        double double17 = piePlot15.getShadowXOffset();
        org.jfree.chart.plot.Plot plot18 = piePlot15.getParent();
        java.awt.Paint paint19 = piePlot15.getBaseSectionOutlinePaint();
        piePlot7.setLabelBackgroundPaint(paint19);
        boolean boolean21 = verticalAlignment1.equals((java.lang.Object) piePlot7);
        java.lang.String str22 = verticalAlignment1.toString();
        boolean boolean23 = multiplePiePlot0.equals((java.lang.Object) verticalAlignment1);
        java.lang.String str24 = multiplePiePlot0.getPlotType();
        multiplePiePlot0.setLimit(100.0d);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "VerticalAlignment.CENTER" + "'", str22.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Multiple Pie Plot" + "'", str24.equals("Multiple Pie Plot"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) (short) 0);
        java.lang.String str5 = verticalAlignment1.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "VerticalAlignment.CENTER" + "'", str5.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.Object obj1 = null;
        boolean boolean2 = textAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 0, 1.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        xYPlot0.setWeight((int) (short) -1);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = null;
        try {
            xYPlot0.setOrientation(plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis9.setLowerMargin(0.0d);
        java.awt.Shape shape12 = dateAxis9.getLeftArrow();
        boolean boolean14 = dateAxis9.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer15 = null;
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis9, polarItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.PiePlotState piePlotState19 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo18);
        piePlotState19.setPieWRadius((double) 10.0f);
        double double22 = piePlotState19.getPieCenterY();
        piePlotState19.setPieWRadius((-4.0d));
        java.awt.Color color25 = java.awt.Color.lightGray;
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        double double28 = piePlot27.getStartAngle();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot27.setBaseSectionOutlineStroke(stroke29);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        java.awt.Paint paint33 = piePlot32.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator34 = piePlot32.getLabelGenerator();
        java.awt.Paint paint35 = piePlot32.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = piePlot32.getLabelPadding();
        org.jfree.chart.util.UnitType unitType37 = rectangleInsets36.getUnitType();
        org.jfree.chart.block.LineBorder lineBorder38 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color25, stroke29, rectangleInsets36);
        org.jfree.chart.block.ColumnArrangement columnArrangement39 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer40 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement39);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D45 = blockContainer40.arrange(graphics2D41, rectangleConstraint44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D49 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D45, 0.025d, 0.05d, rectangleAnchor48);
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D49);
        java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets36.createOutsetRectangle(rectangle2D49, false, false);
        piePlotState19.setLinkArea(rectangle2D49);
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis57.setLowerMargin(0.0d);
        java.awt.Shape shape60 = dateAxis57.getLeftArrow();
        boolean boolean62 = dateAxis57.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = null;
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis57, polarItemRenderer63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        org.jfree.chart.plot.XYPlot xYPlot67 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = xYPlot67.getDomainAxisEdge((int) (short) 10);
        xYPlot67.clearRangeMarkers();
        xYPlot67.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot67.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot();
        xYPlot77.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis80 = xYPlot77.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D81 = xYPlot77.getQuadrantOrigin();
        xYPlot67.zoomDomainAxes((double) (short) 0, plotRenderingInfo76, point2D81, false);
        polarPlot64.zoomDomainAxes((double) (-1), plotRenderingInfo66, point2D81, true);
        org.jfree.chart.plot.PlotState plotState86 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        polarPlot16.draw(graphics2D17, rectangle2D49, point2D81, plotState86, plotRenderingInfo87);
        try {
            xYPlot0.drawBackground(graphics2D6, rectangle2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 90.0d + "'", double28 == 90.0d);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(unitType37);
        org.junit.Assert.assertNotNull(size2D45);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertNull(valueAxis80);
        org.junit.Assert.assertNotNull(point2D81);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Color color0 = java.awt.Color.RED;
        float[] floatArray5 = new float[] { 100, '#', (short) 100, 'a' };
        float[] floatArray6 = color0.getRGBColorComponents(floatArray5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getRangeCrosshairStroke();
        boolean boolean2 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint3 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.configureRangeAxes();
        boolean boolean5 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(2.0d, (double) 100L);
        double double3 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        java.awt.Font font5 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 15);
        java.awt.Paint paint6 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis1.setLabelPaint(paint6);
        categoryAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        java.lang.String str2 = xYPlot0.getPlotType();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = xYPlot0.getDomainMarkers((int) (short) -1, layer4);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYPlot0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle6.getItemLabelPadding();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "XY Plot" + "'", str2.equals("XY Plot"));
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (-1.0f), (double) 205);
        java.lang.String str3 = size2D2.toString();
        double double4 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=-1.0, height=205.0]" + "'", str3.equals("Size2D[width=-1.0, height=205.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 205.0d + "'", double4 == 205.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj2 = new java.lang.Object();
        boolean boolean3 = verticalAlignment1.equals(obj2);
        java.lang.String str4 = verticalAlignment1.toString();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot7);
        java.awt.Font font11 = piePlot7.getLabelFont();
        java.awt.Paint paint13 = piePlot7.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Paint paint16 = piePlot15.getShadowPaint();
        double double17 = piePlot15.getShadowXOffset();
        org.jfree.chart.plot.Plot plot18 = piePlot15.getParent();
        java.awt.Paint paint19 = piePlot15.getBaseSectionOutlinePaint();
        piePlot7.setLabelBackgroundPaint(paint19);
        boolean boolean21 = verticalAlignment1.equals((java.lang.Object) piePlot7);
        java.lang.String str22 = verticalAlignment1.toString();
        boolean boolean23 = multiplePiePlot0.equals((java.lang.Object) verticalAlignment1);
        java.lang.String str24 = multiplePiePlot0.getPlotType();
        java.lang.Comparable comparable25 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot26.getDomainAxisEdge((int) (short) 10);
        boolean boolean29 = multiplePiePlot0.equals((java.lang.Object) rectangleEdge28);
        boolean boolean30 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge28);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "VerticalAlignment.CENTER" + "'", str22.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Multiple Pie Plot" + "'", str24.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + "Other" + "'", comparable25.equals("Other"));
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace2 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = null;
        org.jfree.chart.util.Layer layer4 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker3, layer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        polarPlot9.zoom((double) 10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        polarPlot9.datasetChanged(datasetChangeEvent12);
        boolean boolean14 = polarPlot9.isRadiusGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        polarPlot9.setDataset(xYDataset15);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke1 = xYPlot0.getDomainGridlineStroke();
        xYPlot0.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getDomainAxisEdge((int) (short) 10);
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.util.Size2D size2D5 = textBlock3.calculateDimensions(graphics2D4);
        boolean boolean6 = rectangleEdge2.equals((java.lang.Object) size2D5);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D15 = blockContainer10.arrange(graphics2D11, rectangleConstraint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, 0.025d, 0.05d, rectangleAnchor18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color21 = java.awt.Color.WHITE;
        float[] floatArray27 = new float[] { (-1.0f), (short) 0, 0.0f, (-1L), (-1) };
        float[] floatArray28 = color21.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color20.getRGBComponents(floatArray28);
        boolean boolean30 = rectangleAnchor18.equals((java.lang.Object) color20);
        java.awt.geom.Rectangle2D rectangle2D31 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D5, (double) 1.0f, (double) (byte) -1, rectangleAnchor18);
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        java.awt.Paint paint35 = piePlot34.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator36 = piePlot34.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot34);
        jFreeChart37.clearSubtitles();
        java.lang.Object obj39 = jFreeChart37.getTextAntiAlias();
        boolean boolean40 = rectangleAnchor18.equals((java.lang.Object) jFreeChart37);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(size2D5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator36);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.awt.Paint paint6 = piePlot5.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot5.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot5);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        boolean boolean10 = jFreeChart8.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis1, jFreeChart8);
        float float12 = jFreeChart8.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.5f + "'", float12 == 0.5f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 0, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj6 = jFreeChart5.clone();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart5.createBufferedImage((int) (short) 0, (int) (short) 0, (double) 100.0f, (double) 2, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D6 = blockContainer1.arrange(graphics2D2, rectangleConstraint5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.025d, 0.05d, rectangleAnchor9);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D10);
        java.lang.String str12 = chartEntity11.getShapeCoords();
        java.awt.Shape shape13 = chartEntity11.getArea();
        chartEntity11.setToolTipText("");
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0,-49,1,51" + "'", str12.equals("0,-49,1,51"));
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D((double) (-1.0f), (double) 205);
        size2D6.setWidth((double) 0.0f);
        java.lang.String str9 = size2D6.toString();
        org.jfree.chart.util.Size2D size2D10 = rectangleConstraint2.calculateConstrainedSize(size2D6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Size2D[width=0.0, height=205.0]" + "'", str9.equals("Size2D[width=0.0, height=205.0]"));
        org.junit.Assert.assertNotNull(size2D10);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getDarkerSides();
        java.lang.String str2 = piePlot3D0.getPlotType();
        boolean boolean3 = piePlot3D0.getDarkerSides();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie 3D Plot" + "'", str2.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(100);
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        java.awt.Font font9 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color10 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font9, (java.awt.Paint) color10);
        boolean boolean12 = objectList7.equals((java.lang.Object) color10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot(pieDataset15);
        java.awt.Paint paint17 = ringPlot16.getSeparatorPaint();
        valueMarker14.setLabelPaint(paint17);
        java.lang.Object obj19 = valueMarker14.clone();
        boolean boolean20 = objectList7.equals((java.lang.Object) valueMarker14);
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker14.getLabelAnchor();
        java.awt.Paint paint24 = null;
        try {
            valueMarker14.setLabelPaint(paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        dateAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        double double6 = range4.getUpperBound();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        boolean boolean5 = xYPlot0.isDomainZoomable();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(100);
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList();
        java.awt.Font font9 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color10 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font9, (java.awt.Paint) color10);
        boolean boolean12 = objectList7.equals((java.lang.Object) color10);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.RingPlot ringPlot16 = new org.jfree.chart.plot.RingPlot(pieDataset15);
        java.awt.Paint paint17 = ringPlot16.getSeparatorPaint();
        valueMarker14.setLabelPaint(paint17);
        java.lang.Object obj19 = valueMarker14.clone();
        boolean boolean20 = objectList7.equals((java.lang.Object) valueMarker14);
        org.jfree.chart.util.Layer layer21 = null;
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14, layer21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker14.getLabelAnchor();
        try {
            valueMarker14.setAlpha(2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Paint paint3 = piePlot2.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot2.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle6 = jFreeChart5.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = textTitle6.getMargin();
        textTitle6.setWidth(90.0d);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj11 = new java.lang.Object();
        boolean boolean12 = verticalAlignment10.equals(obj11);
        java.lang.String str13 = verticalAlignment10.toString();
        textTitle6.setVerticalAlignment(verticalAlignment10);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle6.getMargin();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(textTitle6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "VerticalAlignment.CENTER" + "'", str13.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis((int) '4');
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Paint paint6 = valueMarker5.getPaint();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.awt.Paint paint10 = piePlot9.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot9.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot9);
        org.jfree.chart.title.TextTitle textTitle13 = jFreeChart12.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = textTitle13.getMargin();
        textTitle13.setWidth(90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = textTitle13.getPadding();
        valueMarker5.setLabelOffset(rectangleInsets17);
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker5, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertNotNull(textTitle13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        boolean boolean3 = piePlot1.getIgnoreZeroValues();
        java.awt.Stroke stroke4 = piePlot1.getLabelOutlineStroke();
        piePlot1.setCircular(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot3 = categoryAxis2.getPlot();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Paint paint7 = piePlot6.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot6.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart9.getTitle();
        boolean boolean11 = jFreeChart9.getAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis2, jFreeChart9);
        boolean boolean13 = strokeMap0.equals((java.lang.Object) jFreeChart9);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        strokeMap0.put((java.lang.Comparable) 0.5f, stroke15);
        java.lang.Object obj17 = strokeMap0.clone();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(textTitle10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke3);
        double double5 = piePlot1.getMinimumArcAngleToDraw();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        double double9 = piePlot7.getShadowXOffset();
        java.awt.Stroke stroke10 = piePlot7.getBaseSectionOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.Object obj2 = new java.lang.Object();
        boolean boolean3 = verticalAlignment1.equals(obj2);
        java.lang.String str4 = verticalAlignment1.toString();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Paint paint8 = piePlot7.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot7.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot7);
        java.awt.Font font11 = piePlot7.getLabelFont();
        java.awt.Paint paint13 = piePlot7.getSectionOutlinePaint((java.lang.Comparable) (short) 1);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.awt.Paint paint16 = piePlot15.getShadowPaint();
        double double17 = piePlot15.getShadowXOffset();
        org.jfree.chart.plot.Plot plot18 = piePlot15.getParent();
        java.awt.Paint paint19 = piePlot15.getBaseSectionOutlinePaint();
        piePlot7.setLabelBackgroundPaint(paint19);
        boolean boolean21 = verticalAlignment1.equals((java.lang.Object) piePlot7);
        java.lang.String str22 = verticalAlignment1.toString();
        boolean boolean23 = multiplePiePlot0.equals((java.lang.Object) verticalAlignment1);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = multiplePiePlot0.getLegendItems();
        int int25 = legendItemCollection24.getItemCount();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "VerticalAlignment.CENTER" + "'", str22.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextBlockAnchor.TOP_LEFT", graphics2D1, (float) 205, (float) (byte) 10, textAnchor4, (double) ' ', 1.0f, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint4 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        java.awt.Paint paint6 = piePlot3.getBackgroundPaint();
        ringPlot1.setLabelShadowPaint(paint6);
        boolean boolean8 = ringPlot1.getSeparatorsVisible();
        double double9 = ringPlot1.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "", "TextBlockAnchor.TOP_RIGHT");
        java.lang.String str6 = basicProjectInfo5.getLicenceName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.TOP_RIGHT" + "'", str6.equals("TextBlockAnchor.TOP_RIGHT"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = piePlotState1.getEntityCollection();
        double double3 = piePlotState1.getPieCenterY();
        org.junit.Assert.assertNull(entityCollection2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Font font3 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.orange;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] version RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]:None\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0] LICENCE TERMS:\nRectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", font3, (java.awt.Paint) color4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = piePlot7.getLabelOutlinePaint();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font3, paint10);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("Pie Plot", font3);
        java.awt.Paint paint13 = textFragment12.getPaint();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.lang.String str1 = dateAxis0.getLabelURL();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot12.getDomainAxisEdge((int) (short) 10);
        xYPlot12.clearRangeMarkers();
        xYPlot12.setNoDataMessage("TextAnchor.TOP_RIGHT");
        xYPlot12.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        xYPlot22.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot22.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D26 = xYPlot22.getQuadrantOrigin();
        xYPlot12.zoomDomainAxes((double) (short) 0, plotRenderingInfo21, point2D26, false);
        polarPlot9.zoomDomainAxes((double) (-1), plotRenderingInfo11, point2D26, true);
        java.lang.String str31 = polarPlot9.getPlotType();
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = polarPlot9.getOrientation();
        java.lang.String str33 = plotOrientation32.toString();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Polar Plot" + "'", str31.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str33.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot4.getLabelGenerator();
        java.awt.Paint paint7 = piePlot4.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = legendTitle8.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle8.setLegendItemGraphicAnchor(rectangleAnchor10);
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) (byte) -1, rectangleAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.jfree.data.Range range5 = dateAxis1.getRange();
        dateAxis1.setAutoTickUnitSelection(true);
        dateAxis1.setRangeAboutValue((double) 100.0f, (double) 1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        java.awt.Paint paint3 = categoryAxis1.getLabelPaint();
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) 0);
        categoryAxis1.setLabelURL("RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        categoryAxis1.setCategoryLabelPositionOffset(100);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis12.setLowerMargin(0.0d);
        java.awt.Shape shape15 = dateAxis12.getLeftArrow();
        org.jfree.data.Range range16 = dateAxis12.getRange();
        org.jfree.chart.block.ColumnArrangement columnArrangement17 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D23 = blockContainer18.arrange(graphics2D19, rectangleConstraint22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, 0.025d, 0.05d, rectangleAnchor26);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27);
        dateAxis12.setRightArrow((java.awt.Shape) rectangle2D27);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot32 = categoryAxis31.getPlot();
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        double double35 = piePlot34.getShadowXOffset();
        categoryAxis31.setPlot((org.jfree.chart.plot.Plot) piePlot34);
        java.awt.Font font37 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        categoryAxis31.setTickLabelFont(font37);
        dateAxis12.setLabelFont(font37);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-35.57979797979798d), font37);
        double double41 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNull(plot32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis2.setLowerMargin(0.0d);
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        boolean boolean7 = dateAxis2.isHiddenValue((long) '4');
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, polarItemRenderer8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = dateAxis2.getTickLabelInsets();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 'a', (float) 3, 0.0d, (float) 1L, (float) 255);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.awt.Paint paint5 = piePlot4.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot4.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.chart.title.TextTitle textTitle8 = jFreeChart7.getTitle();
        textTitle8.setPadding((double) (short) 0, (double) 100, (-1.0d), 0.4d);
        java.lang.Object obj14 = null;
        blockContainer1.add((org.jfree.chart.block.Block) textTitle8, obj14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        java.awt.Paint paint19 = piePlot18.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = piePlot18.getLabelGenerator();
        java.awt.Paint paint21 = piePlot18.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot18);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = legendTitle22.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle22.setLegendItemGraphicAnchor(rectangleAnchor24);
        legendTitle22.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker29.getLabelAnchor();
        legendTitle22.setLegendItemGraphicAnchor(rectangleAnchor30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge32);
        legendTitle22.setLegendItemGraphicEdge(rectangleEdge32);
        java.awt.geom.Rectangle2D rectangle2D35 = legendTitle22.getBounds();
        try {
            blockContainer1.draw(graphics2D16, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(textTitle8);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis((int) (byte) -1);
        java.awt.geom.Point2D point2D4 = xYPlot0.getQuadrantOrigin();
        boolean boolean5 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke7 = xYPlot6.getRangeCrosshairStroke();
        boolean boolean8 = xYPlot6.isDomainGridlinesVisible();
        java.awt.Paint paint9 = xYPlot6.getRangeGridlinePaint();
        xYPlot0.setRangeGridlinePaint(paint9);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getShadowXOffset();
        double double4 = piePlot1.getStartAngle();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color7 = java.awt.Color.ORANGE;
        categoryAxis6.setTickMarkPaint((java.awt.Paint) color7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.awt.Paint paint12 = piePlot11.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot11.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot11);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = textTitle15.getMargin();
        textTitle15.setWidth(90.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = textTitle15.getPadding();
        boolean boolean20 = color7.equals((java.lang.Object) textTitle15);
        piePlot1.setLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        double double3 = piePlot1.getShadowXOffset();
        double double4 = piePlot1.getStartAngle();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.PiePlotState piePlotState6 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo5);
        piePlotState6.setPieWRadius((double) 10.0f);
        double double9 = piePlotState6.getPieCenterY();
        piePlotState6.setPieWRadius((-4.0d));
        boolean boolean12 = piePlot1.equals((java.lang.Object) (-4.0d));
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator13 = piePlot1.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator13);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis1.setLowerMargin(0.0d);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range4);
        org.jfree.data.Range range6 = dateAxis1.getDefaultAutoRange();
        java.awt.Shape shape7 = dateAxis1.getRightArrow();
        dateAxis1.setRangeWithMargins(0.4d, (double) 'a');
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("TextBlockAnchor.TOP_RIGHT");
        dateAxis12.setLowerMargin(0.0d);
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRange(range15);
        java.awt.Paint paint17 = dateAxis12.getTickMarkPaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) '#', 100.0d);
        org.jfree.chart.util.Size2D size2D24 = blockContainer19.arrange(graphics2D20, rectangleConstraint23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D24, 0.025d, 0.05d, rectangleAnchor27);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D28);
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D28, "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "TextBlockAnchor.TOP_RIGHT");
        dateAxis12.setRightArrow((java.awt.Shape) rectangle2D28);
        dateAxis1.setLeftArrow((java.awt.Shape) rectangle2D28);
        boolean boolean36 = dateAxis1.isHiddenValue((long) 10);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.lang.Object obj1 = null;
        boolean boolean2 = piePlot3D0.equals(obj1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot3D0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Paint paint4 = piePlot3.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3.getLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Font font7 = piePlot3.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("TextAnchor.TOP_RIGHT", font7);
        textTitle8.setText("ClassContext");
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.plot.Plot plot8 = categoryAxis7.getPlot();
        java.awt.Paint paint9 = categoryAxis7.getLabelPaint();
        legendTitle5.setItemPaint(paint9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle5.getMargin();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle5.arrange(graphics2D12);
        java.awt.geom.Rectangle2D rectangle2D14 = legendTitle5.getBounds();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.plot.PiePlotState piePlotState3 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo2);
        piePlotState3.setPassesRequired(0);
        java.lang.Class<?> wildcardClass6 = piePlotState3.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("XY Plot", (java.lang.Class) wildcardClass6);
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Multiple Pie Plot", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
        org.junit.Assert.assertNull(inputStream8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", image3, "", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]", "RectangleConstraint[LengthConstraintType.FIXED: width=35.0, height=100.0]");
        projectInfo7.setInfo("TextAnchor.TOP_RIGHT");
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getStartAngle();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke3);
        double double5 = piePlot1.getMinimumArcAngleToDraw();
        piePlot1.setShadowXOffset((double) 'a');
        piePlot1.setLabelLinkMargin(90.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-5d + "'", double5 == 1.0E-5d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.RingPlot ringPlot6 = new org.jfree.chart.plot.RingPlot(pieDataset5);
        java.awt.Paint paint7 = ringPlot6.getSeparatorPaint();
        valueMarker4.setLabelPaint(paint7);
        java.lang.Object obj9 = valueMarker4.clone();
        valueMarker4.setLabel("ThreadContext");
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = valueMarker13.getLabelAnchor();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = valueMarker13.getLabelOffsetType();
        valueMarker4.setLabelOffsetType(lengthAdjustmentType15);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        boolean boolean9 = textAnchor7.equals((java.lang.Object) false);
        try {
            java.awt.Shape shape10 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Pie 3D Plot", graphics2D1, (float) (byte) 0, (-1.0f), textAnchor4, (double) 'a', textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_RIGHT" + "'", str5.equals("TextAnchor.TOP_RIGHT"));
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (byte) -1, 0.0d, (int) (byte) -1, (java.lang.Comparable) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getShadowPaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot1.getLabelGenerator();
        java.awt.Paint paint4 = piePlot1.getBackgroundPaint();
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle5.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor7);
        legendTitle5.setNotify(false);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = valueMarker12.getLabelAnchor();
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle5.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = legendTitle5.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot20.addChangeListener(plotChangeListener21);
        java.awt.Paint paint23 = piePlot20.getLabelOutlinePaint();
        java.awt.Paint paint24 = piePlot20.getNoDataMessagePaint();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = piePlot20.getLabelGenerator();
        try {
            java.lang.Object obj26 = legendTitle5.draw(graphics2D17, rectangle2D18, (java.lang.Object) pieSectionLabelGenerator25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator25);
    }
}

