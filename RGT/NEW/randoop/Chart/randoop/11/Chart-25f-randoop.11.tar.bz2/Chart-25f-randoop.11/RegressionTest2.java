import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        barRenderer0.setSeriesItemLabelsVisible(100, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = barRenderer0.getSeriesItemLabelGenerator(8);
        java.awt.Paint paint10 = barRenderer0.getSeriesPaint(500);
        java.awt.Color color11 = java.awt.Color.BLACK;
        barRenderer0.setBaseFillPaint((java.awt.Paint) color11, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str8 = categoryAxis6.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot5.setDomainAxis(categoryAxis6);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot5.setDataset(10, categoryDataset11);
        org.jfree.chart.plot.Plot plot13 = categoryPlot5.getParent();
        boolean boolean14 = color0.equals((java.lang.Object) plot13);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setPositiveArrowVisible(true);
        org.jfree.data.Range range8 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        java.awt.Font font9 = numberAxis5.getTickLabelFont();
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker5.getLabelTextAnchor();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker5.setOutlineStroke(stroke7);
        numberAxis1.setTickMarkStroke(stroke7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint12 = barRenderer10.lookupSeriesOutlinePaint(8);
        boolean boolean13 = barRenderer10.isDrawBarOutline();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis16.setRange(1.0d, (double) (byte) 10);
        numberAxis16.setRangeAboutValue(0.0d, (double) 0.5f);
        numberAxis16.setNegativeArrowVisible(true);
        double double25 = numberAxis16.getUpperMargin();
        numberAxis16.setVisible(true);
        numberAxis16.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets((double) 10, (double) ' ', (double) 100, (double) 0.5f);
        numberAxis16.setTickLabelInsets(rectangleInsets34);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        numberAxis16.setTickMarkStroke(stroke37);
        barRenderer10.setSeriesOutlineStroke(4, stroke37, false);
        numberAxis1.setAxisLineStroke(stroke37);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis((int) ' ');
        java.awt.Paint paint19 = categoryPlot4.getOutlinePaint();
        categoryPlot4.clearRangeMarkers(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem25 = barRenderer22.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape26 = barRenderer22.getBaseShape();
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer22.setSeriesOutlineStroke((int) (short) 0, stroke28);
        barRenderer22.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = barRenderer22.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("", font36);
        labelBlock37.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock37.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color48 = java.awt.Color.orange;
        int int49 = color48.getBlue();
        labelBlock37.setPaint((java.awt.Paint) color48);
        barRenderer22.setBasePaint((java.awt.Paint) color48, false);
        java.awt.Color color53 = java.awt.Color.YELLOW;
        float[] floatArray57 = new float[] { 10, '#', (short) -1 };
        float[] floatArray58 = color53.getRGBColorComponents(floatArray57);
        float[] floatArray59 = color48.getColorComponents(floatArray57);
        java.awt.Color color60 = color48.darker();
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color48);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(color60);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        jFreeChart7.addLegend(legendTitle9);
        jFreeChart7.setAntiAlias(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem9 = barRenderer6.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape10 = barRenderer6.getBaseShape();
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer6.setSeriesOutlineStroke((int) (short) 0, stroke12);
        barRenderer6.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.RendererState rendererState18 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo17.getDataArea();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D19, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.clone(shape23);
        barRenderer6.setBaseShape(shape24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem29 = barRenderer26.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape30 = barRenderer26.getBaseShape();
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer26.setSeriesOutlineStroke((int) (short) 0, stroke32);
        barRenderer26.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor37 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor37, textAnchor38, textAnchor39, (double) 0.5f);
        barRenderer26.setSeriesPositiveItemLabelPosition(0, itemLabelPosition41);
        barRenderer6.setBaseNegativeItemLabelPosition(itemLabelPosition41);
        try {
            barRenderer0.setSeriesNegativeItemLabelPosition((-1), itemLabelPosition41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(itemLabelAnchor37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(textAnchor39);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle1.setVerticalAlignment(verticalAlignment3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightOutset(0.0d);
        double double13 = rectangleInsets7.calculateTopInset((double) (-1));
        double double15 = rectangleInsets7.calculateBottomOutset((double) 0L);
        boolean boolean16 = lineBorder6.equals((java.lang.Object) rectangleInsets7);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets7);
        double double19 = rectangleInsets7.extendWidth((double) 500);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 502.0d + "'", double19 == 502.0d);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("RectangleEdge.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleEdge.RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "org.jfree.data.general.DatasetChangeEvent[source= ]");
        boolean boolean7 = legendTitle1.equals((java.lang.Object) shape4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis9.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateLeftOutset((double) (byte) -1);
        double double17 = rectangleInsets13.calculateRightInset((double) 100.0f);
        numberAxis9.setLabelInsets(rectangleInsets13);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer22);
        org.jfree.chart.plot.Plot plot24 = categoryPlot23.getRootPlot();
        numberAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.Color color26 = java.awt.Color.GREEN;
        categoryPlot23.setRangeGridlinePaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot23.getRenderer(0);
        boolean boolean30 = legendTitle1.equals((java.lang.Object) categoryItemRenderer29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = null;
        try {
            legendTitle1.setPadding(rectangleInsets31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(plot24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int15 = color14.getRed();
        barRenderer0.setSeriesPaint(10, (java.awt.Paint) color14);
        java.awt.Color color17 = java.awt.Color.YELLOW;
        float[] floatArray21 = new float[] { 10, '#', (short) -1 };
        float[] floatArray22 = color17.getRGBColorComponents(floatArray21);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 192 + "'", int15 == 192);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str2 = projectInfo1.getInfo();
        java.lang.String str3 = projectInfo1.getVersion();
        java.lang.String str4 = projectInfo1.getCopyright();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.util.List list6 = blockContainer5.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame7 = blockContainer5.getFrame();
        java.util.List list8 = blockContainer5.getBlocks();
        projectInfo1.setContributors(list8);
        projectInfo1.setLicenceText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        boolean boolean12 = lengthAdjustmentType0.equals((java.lang.Object) projectInfo1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(blockFrame7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, true);
        int int8 = color5.getBlue();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (byte) 1, (java.lang.Number) 1);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart7.fireChartChanged();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            java.awt.image.BufferedImage bufferedImage13 = jFreeChart7.createBufferedImage((-16777216), 2, (int) (short) -1, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.Range range11 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        boolean boolean20 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle15.getTextAlignment();
        java.lang.Object obj22 = textTitle15.clone();
        java.lang.Object obj23 = textTitle15.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("");
        labelBlock1.setToolTipText("TextAnchor.TOP_LEFT");
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getPosition();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = null;
        try {
            legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' point.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        java.awt.Stroke stroke12 = categoryPlot4.getOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot4.getDomainAxis();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryAxis13);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle2.setVerticalAlignment(verticalAlignment4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle2.getLegendItemGraphicLocation();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle2, (java.lang.Object) textAnchor7);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        java.util.List list10 = blockContainer9.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame11 = blockContainer9.getFrame();
        boolean boolean12 = legendTitle2.equals((java.lang.Object) blockContainer9);
        java.awt.Paint paint13 = null;
        legendTitle2.setBackgroundPaint(paint13);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(blockFrame11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        boolean boolean4 = axisLocation0.equals((java.lang.Object) plotRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo2.getPlotArea();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(rectangle2D5);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis9.setRange(1.0d, (double) (byte) 10);
        boolean boolean13 = numberAxis9.isVerticalTickLabels();
        boolean boolean14 = numberAxis9.isPositiveArrowVisible();
        org.jfree.data.Range range15 = numberAxis9.getDefaultAutoRange();
        double double16 = range15.getCentralValue();
        numberAxis1.setRangeWithMargins(range15, false, true);
        boolean boolean20 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.data.Range range6 = rectangleConstraint5.getWidthRange();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setPositiveArrowVisible(true);
        org.jfree.data.Range range8 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem12 = barRenderer9.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape13 = barRenderer9.getBaseShape();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer9.setSeriesOutlineStroke((int) (short) 0, stroke15);
        barRenderer9.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer9.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font23);
        labelBlock24.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock24.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color35 = java.awt.Color.orange;
        int int36 = color35.getBlue();
        labelBlock24.setPaint((java.awt.Paint) color35);
        barRenderer9.setBasePaint((java.awt.Paint) color35, false);
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        int int43 = categoryPlot4.getRangeAxisIndex(valueAxis42);
        categoryPlot4.clearDomainAxes();
        java.awt.Paint paint45 = categoryPlot4.getNoDataMessagePaint();
        categoryPlot4.clearDomainAxes();
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType19 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("", font21);
        java.awt.Paint paint23 = labelBlock22.getPaint();
        java.awt.Font font24 = labelBlock22.getFont();
        boolean boolean25 = gradientPaintTransformType19.equals((java.lang.Object) font24);
        boolean boolean26 = textTitle15.equals((java.lang.Object) gradientPaintTransformType19);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(gradientPaintTransformType19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        java.lang.Boolean boolean21 = barRenderer0.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke24);
        java.awt.Paint paint27 = barRenderer0.getSeriesFillPaint(1);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint27);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 3);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker1, jFreeChart5, (int) (byte) 0, (int) (byte) 100);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot15.setDomainAxisLocation(axisLocation16, true);
        boolean boolean19 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) categoryPlot15, true);
        jFreeChart23.clearSubtitles();
        chartProgressEvent8.setChart(jFreeChart23);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer29);
        categoryPlot30.setWeight((int) (short) 0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent33 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot30);
        jFreeChart23.plotChanged(plotChangeEvent33);
        org.jfree.data.KeyedObjects2D keyedObjects2D35 = new org.jfree.data.KeyedObjects2D();
        int int36 = keyedObjects2D35.getRowCount();
        java.util.List list37 = keyedObjects2D35.getRowKeys();
        jFreeChart23.setSubtitles(list37);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot4.setDataset(categoryDataset5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot11.setDomainAxisLocation(axisLocation12, true);
        boolean boolean15 = categoryPlot11.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot11.setDatasetRenderingOrder(datasetRenderingOrder16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot11.getDataset();
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateLeftOutset((double) (byte) -1);
        blockContainer1.setMargin(rectangleInsets2);
        java.util.List list6 = blockContainer1.getBlocks();
        java.lang.Object obj7 = blockContainer1.clone();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range9, range10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis13.setRange(1.0d, (double) (byte) 10);
        boolean boolean17 = numberAxis13.isVerticalTickLabels();
        boolean boolean18 = numberAxis13.isPositiveArrowVisible();
        org.jfree.data.Range range19 = numberAxis13.getDefaultAutoRange();
        java.lang.String str20 = range19.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = rectangleConstraint11.toRangeHeight(range19);
        try {
            org.jfree.chart.util.Size2D size2D22 = centerArrangement0.arrange(blockContainer1, graphics2D8, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Range[0.0,1.0]" + "'", str20.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint21);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        numberAxis1.setUpArrow(shape13);
        double double15 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis19.setUpperBound((double) 8);
        numberAxis19.resizeRange((double) 100);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis1.setDefaultAutoRange(range24);
        java.awt.Stroke stroke26 = numberAxis1.getAxisLineStroke();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(numberTickUnit27);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.awt.Shape shape6 = defaultDrawingSupplier5.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        double double10 = categoryAxis5.getLabelAngle();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor9 = valueMarker8.getLabelTextAnchor();
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker8.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker8.setStroke(stroke12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = valueMarker8.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType14);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D5);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D5);
        java.lang.String str18 = chartEntity17.getShapeCoords();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0,0,1,1" + "'", str18.equals("0,0,1,1"));
    }
}

