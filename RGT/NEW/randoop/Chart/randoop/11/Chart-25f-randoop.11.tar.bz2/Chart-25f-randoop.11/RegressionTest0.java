import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) '4', keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) ' ', (float) (short) -1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) textBlockAnchor0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color9 = java.awt.Color.WHITE;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!", "", "", "", false, shape5, true, (java.awt.Paint) color7, false, (java.awt.Paint) color9, stroke10, false, shape12, stroke13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (java.lang.Comparable) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Stroke stroke6 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("hi!", "", "", "", shape4, (java.awt.Paint) color5, stroke6, (java.awt.Paint) color7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (short) 10, 10.0f, (double) '4', (float) 100, (float) (short) 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Font font1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("", font1, plot2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Shape shape5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Paint paint9 = null;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        java.awt.Stroke stroke15 = null;
        java.awt.Color color16 = java.awt.Color.WHITE;
        try {
            org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", "hi!", "", "", true, shape5, true, (java.awt.Paint) color7, true, paint9, stroke10, false, shape14, stroke15, (java.awt.Paint) color16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (short) 10, range1, lengthConstraintType2, (double) (-1), range4, lengthConstraintType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            textLine5.draw(graphics2D6, 1.0f, (-1.0f), textAnchor9, 0.5f, (float) 100, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = java.awt.Color.WHITE;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = plotRenderingInfo1.getSubplotInfo(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = null;
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1L, (double) 10L, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 15, paint1, stroke2, paint3, stroke4, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0, (double) 0, (double) 100L, 0.0d, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "", "hi!");
        java.lang.String str6 = tickLabelEntity5.toString();
        tickLabelEntity5.setURLText("hi!");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartEntity: tooltip = " + "'", str6.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.awt.Paint paint3 = labelBlock2.getPaint();
        java.awt.Font font4 = labelBlock2.getFont();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, range7);
        try {
            org.jfree.chart.util.Size2D size2D9 = labelBlock2.arrange(graphics2D5, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ChartEntity: tooltip = ", graphics2D1, (float) (short) 100, (float) (short) 0, (double) 100, (float) (short) 0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ChartChangeEventType.DATASET_UPDATED", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = ", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.awt.Paint paint3 = labelBlock2.getPaint();
        java.awt.Font font4 = labelBlock2.getFont();
        org.jfree.chart.block.BlockFrame blockFrame5 = null;
        try {
            labelBlock2.setFrame(blockFrame5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "", "hi!");
        java.lang.String str6 = tickLabelEntity5.toString();
        java.lang.String str7 = tickLabelEntity5.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartEntity: tooltip = " + "'", str6.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Color color1 = java.awt.Color.getColor("ClassContext");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) ' ', (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (32.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.RendererState rendererState5 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo4.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean8 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace10 = numberAxis0.reserveSpace(graphics2D1, plot2, rectangle2D6, rectangleEdge7, axisSpace9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color0 = java.awt.Color.CYAN;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 0.0f, (double) 0.0f, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setInfo("");
        boolean boolean4 = basicProjectInfo0.equals((java.lang.Object) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape1, "org.jfree.data.general.DatasetChangeEvent[source= ]");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, (double) 1.0f, 10.0f, 0.0f);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Color color14 = java.awt.Color.BLACK;
        java.awt.Color color16 = java.awt.Color.white;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor19 = valueMarker18.getLabelTextAnchor();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker18.setOutlineStroke(stroke20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        org.jfree.chart.renderer.RendererState rendererState25 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo24.getDataArea();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D26, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Stroke stroke31 = null;
        java.awt.Paint paint32 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem(attributedString0, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "RectangleEdge.BOTTOM", "ClassContext", false, (java.awt.Shape) rectangle2D8, true, (java.awt.Paint) color14, true, (java.awt.Paint) color16, stroke20, true, shape30, stroke31, paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = centerArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker5.getLabelTextAnchor();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker5.setOutlineStroke(stroke7);
        numberAxis1.setTickMarkStroke(stroke7);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState((double) 0);
        double double13 = axisState12.getCursor();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        org.jfree.chart.renderer.RendererState rendererState16 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo15.getDataArea();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D17, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean23 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge22);
        try {
            java.util.List list24 = numberAxis1.refreshTicks(graphics2D10, axisState12, rectangle2D17, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity8 = new org.jfree.chart.entity.TickLabelEntity(shape5, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        try {
            java.awt.GradientPaint gradientPaint9 = standardGradientPaintTransformer1.transform(gradientPaint2, shape5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.RendererState rendererState5 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo4.getDataArea();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D6, (double) (byte) 100, (-1.0f), (float) '4');
        try {
            legendTitle1.draw(graphics2D2, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = categoryLabelPositions1.getLabelPosition(rectangleEdge2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge4);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = categoryLabelPositions1.getLabelPosition(rectangleEdge4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions7.getLabelPosition(rectangleEdge8);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = categoryLabelPositions7.getLabelPosition(rectangleEdge10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = categoryLabelPositions13.getLabelPosition(rectangleEdge14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge16);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = categoryLabelPositions13.getLabelPosition(rectangleEdge16);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition6, categoryLabelPosition12, categoryLabelPosition18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(categoryLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition12);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNull(categoryLabelPosition15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition18);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getPlotArea();
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) ' ', dataset5);
        java.lang.String str7 = datasetChangeEvent6.toString();
        boolean boolean8 = plotRenderingInfo1.equals((java.lang.Object) datasetChangeEvent6);
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source= ]" + "'", str7.equals("org.jfree.data.general.DatasetChangeEvent[source= ]"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        valueMarker1.setValue((double) (byte) 1);
        java.lang.Class class4 = null;
        try {
            java.util.EventListener[] eventListenerArray5 = valueMarker1.getListeners(class4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Paint paint3 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.RendererState rendererState5 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo4.getDataArea();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D6, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone(shape10);
        try {
            java.awt.GradientPaint gradientPaint12 = standardGradientPaintTransformer1.transform(gradientPaint2, shape10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity(shape7, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) 100L, (float) 2, 100.0f);
        int int16 = color15.getAlpha();
        java.awt.Color color18 = java.awt.Color.orange;
        int int19 = color18.getBlue();
        java.awt.Stroke stroke20 = null;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape23, "org.jfree.data.general.DatasetChangeEvent[source= ]");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis27.setUpperBound((double) 8);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor32 = valueMarker31.getLabelTextAnchor();
        java.awt.Stroke stroke33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker31.setOutlineStroke(stroke33);
        numberAxis27.setTickMarkStroke(stroke33);
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "ChartEntity: tooltip = ", "TextBlockAnchor.TOP_LEFT", true, shape7, true, (java.awt.Paint) color15, true, (java.awt.Paint) color18, stroke20, true, shape23, stroke33, paint36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 10L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "ChartEntity: tooltip = ", "ChartEntity: tooltip = ", "ClassContext");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        try {
            java.lang.Object obj7 = blockContainer0.draw(graphics2D1, rectangle2D5, (java.lang.Object) itemLabelAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        java.awt.Shape shape4 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str7 = projectInfo6.toString();
        boolean boolean8 = textLine5.equals((java.lang.Object) str7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor12, textAnchor13, textAnchor14, (double) 0.5f);
        try {
            textLine5.draw(graphics2D9, (float) (byte) -1, (float) (byte) 1, textAnchor14, 0.0f, (float) 0, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str7.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        try {
            legendTitle1.setLegendItemGraphicEdge(rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        axisSpace0.setTop(0.2d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState((double) 0);
        double double10 = axisState9.getCursor();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D14, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge19);
        try {
            java.util.List list21 = numberAxis1.refreshTicks(graphics2D7, axisState9, rectangle2D14, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1L), (double) 10L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getGPL();
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color9);
        numberAxis1.setTickLabelFont(font7);
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        numberAxis1.removeChangeListener(axisChangeListener12);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.String str1 = categoryLabelWidthType0.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str1.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) 2, 100.0f);
        int int4 = color3.getAlpha();
        java.awt.color.ColorSpace colorSpace5 = null;
        java.awt.Color color6 = java.awt.Color.YELLOW;
        float[] floatArray10 = new float[] { 10, '#', (short) -1 };
        float[] floatArray11 = color6.getRGBColorComponents(floatArray10);
        try {
            float[] floatArray12 = color3.getColorComponents(colorSpace5, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis3.setRange(1.0d, (double) (byte) 10);
        numberAxis3.setRangeAboutValue(0.0d, (double) 0.5f);
        boolean boolean10 = datasetGroup1.equals((java.lang.Object) numberAxis3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35", "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35");
        java.lang.String str3 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35" + "'", str3.equals("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        java.lang.Class class5 = null;
        try {
            java.util.EventListener[] eventListenerArray6 = valueMarker1.getListeners(class5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("hi!", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setRangeAboutValue(0.0d, (double) 0.5f);
        numberAxis1.setVisible(false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB((-1), (int) (byte) 100, (int) (short) -1, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "", "hi!");
        java.lang.String str6 = tickLabelEntity5.getShapeCoords();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35" + "'", str6.equals("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("RectangleEdge.BOTTOM", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'font' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        titleChangeEvent2.setType(chartChangeEventType3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartEntity: tooltip = ", graphics2D1, (double) 'a', (float) 10, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 'a', (double) 1, (double) '#', (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double4 = numberTickUnit3.getSize();
        try {
            org.jfree.chart.axis.TickUnit tickUnit5 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo9.getDataArea();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D11, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection16 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis18.setRange(1.0d, (double) (byte) 10);
        boolean boolean22 = numberAxis18.isVerticalTickLabels();
        boolean boolean23 = numberAxis18.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge24);
        axisCollection16.add((org.jfree.chart.axis.Axis) numberAxis18, rectangleEdge24);
        java.lang.String str27 = rectangleEdge24.toString();
        double double28 = numberAxis1.lengthToJava2D((double) 255, rectangle2D11, rectangleEdge24);
        java.awt.Paint paint29 = numberAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleEdge.RIGHT" + "'", str27.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor8 = valueMarker7.getLabelTextAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ClassContext", graphics2D1, (float) (byte) 0, 0.0f, textAnchor4, (double) 1, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean7 = horizontalAlignment5.equals((java.lang.Object) textBlockAnchor6);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor8, textAnchor9, textAnchor10, (double) 0.5f);
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition12.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType15 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor6, textAnchor13, (double) 15, categoryLabelWidthType15, (float) 15);
        keyedObjects0.addObject((java.lang.Comparable) "org.jfree.data.general.DatasetChangeEvent[source= ]", (java.lang.Object) textAnchor13);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(categoryLabelWidthType15);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock2.setURLText("");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation17 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 1L, (java.lang.Number) 0L);
        try {
            java.lang.Object obj18 = labelBlock2.draw(graphics2D10, rectangle2D14, (java.lang.Object) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        numberAxis1.resizeRange((double) (short) 10, (-1.0d));
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        basicProjectInfo0.setInfo("RectangleEdge.BOTTOM");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis4.setRange(1.0d, (double) (byte) 10);
        boolean boolean8 = numberAxis4.isVerticalTickLabels();
        double double9 = numberAxis4.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D14, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection19 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis21.setRange(1.0d, (double) (byte) 10);
        boolean boolean25 = numberAxis21.isVerticalTickLabels();
        boolean boolean26 = numberAxis21.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
        axisCollection19.add((org.jfree.chart.axis.Axis) numberAxis21, rectangleEdge27);
        java.lang.String str30 = rectangleEdge27.toString();
        double double31 = numberAxis4.lengthToJava2D((double) 255, rectangle2D14, rectangleEdge27);
        try {
            java.awt.geom.Rectangle2D rectangle2D32 = axisSpace0.expand(rectangle2D2, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleEdge.RIGHT" + "'", str30.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        numberAxis1.setLowerMargin((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryAnchor.END", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo4);
        java.awt.geom.Point2D point2D7 = null;
        try {
            int int8 = plotRenderingInfo1.getSubplotIndex(point2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) textBlockAnchor1);
        java.lang.String str3 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HorizontalAlignment.CENTER" + "'", str3.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) ' ', (float) (byte) -1, (float) 255);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(100.0d, (double) (byte) 0, (double) 255, (double) 500, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RectangleEdge.RIGHT", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets5.createInsetRectangle(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 10, (double) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) 255);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 271.0d + "'", double2 == 271.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str7 = projectInfo6.toString();
        boolean boolean8 = textLine5.equals((java.lang.Object) str7);
        org.jfree.chart.text.TextFragment textFragment9 = null;
        textLine5.addFragment(textFragment9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor14 = null;
        try {
            textLine5.draw(graphics2D11, (float) 10L, 1.0f, textAnchor14, (float) (byte) 0, (float) (byte) -1, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str7.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 1.5707963267948966d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", textAnchor3, textAnchor4, 0.0d);
        double double7 = numberTick6.getValue();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textLine5.calculateDimensions(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0, 0.0f, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        valueMarker1.setValue((double) (byte) 1);
        try {
            valueMarker1.setAlpha((float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle1.setVerticalAlignment(verticalAlignment3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str7 = rectangleInsets6.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo9.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker14.getLabelTextAnchor();
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker14.setOutlineStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker14.setStroke(stroke18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = valueMarker14.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets6.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType12, lengthAdjustmentType20);
        try {
            legendTitle1.draw(graphics2D5, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str7.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setWidth(0.0d);
        org.jfree.chart.block.BlockFrame blockFrame5 = labelBlock2.getFrame();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, (double) 100L);
        try {
            org.jfree.chart.util.Size2D size2D10 = labelBlock2.arrange(graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateLeftOutset((double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge3);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = categoryLabelPositions0.getLabelPosition(rectangleEdge3);
        double double6 = categoryLabelPosition5.getAngle();
        double double7 = categoryLabelPosition5.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNull(categoryLabelPosition2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.5707963267948966d + "'", double6 == 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.5707963267948966d + "'", double7 == 1.5707963267948966d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        java.awt.Color color11 = java.awt.Color.cyan;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        java.awt.Color color13 = java.awt.Color.YELLOW;
        float[] floatArray17 = new float[] { 10, '#', (short) -1 };
        float[] floatArray18 = color13.getRGBColorComponents(floatArray17);
        try {
            float[] floatArray19 = color8.getComponents(colorSpace12, floatArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setWidth(0.0d);
        org.jfree.chart.block.BlockFrame blockFrame5 = labelBlock2.getFrame();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str8 = rectangleInsets7.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        org.jfree.chart.renderer.RendererState rendererState11 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo10.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor16 = valueMarker15.getLabelTextAnchor();
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker15.setOutlineStroke(stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker15.setStroke(stroke19);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = valueMarker15.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets7.createAdjustedRectangle(rectangle2D12, lengthAdjustmentType13, lengthAdjustmentType21);
        try {
            labelBlock2.draw(graphics2D6, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(blockFrame5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str8.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.get((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        try {
            blockContainer0.add((org.jfree.chart.block.Block) blockContainer3, (java.lang.Object) color4);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.Color cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.AxisCollection axisCollection5 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection5.add((org.jfree.chart.axis.Axis) numberAxis6, rectangleEdge7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis6.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        numberAxis6.setUpArrow(shape18);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font22);
        labelBlock23.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock23.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color34 = java.awt.Color.orange;
        int int35 = color34.getBlue();
        labelBlock23.setPaint((java.awt.Paint) color34);
        java.awt.Color color38 = java.awt.Color.WHITE;
        java.awt.Stroke stroke39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        org.jfree.chart.renderer.RendererState rendererState43 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo42.getDataArea();
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D44, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.clone(shape48);
        java.awt.Stroke stroke50 = null;
        java.awt.Color color51 = java.awt.Color.yellow;
        try {
            org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("CategoryLabelWidthType.RANGE", "HorizontalAlignment.CENTER", "org.jfree.data.general.DatasetChangeEvent[source= ]", "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35", false, shape18, true, (java.awt.Paint) color34, false, (java.awt.Paint) color38, stroke39, false, shape49, stroke50, (java.awt.Paint) color51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ChartChangeEventType.DATASET_UPDATED", 500, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets1.calculateLeftOutset((double) (byte) -1);
        blockContainer0.setMargin(rectangleInsets1);
        blockContainer0.clear();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        numberAxis1.setRangeAboutValue((double) 1L, (double) (byte) 1);
        numberAxis1.setVerticalTickLabels(true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker5.getLabelTextAnchor();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker5.setOutlineStroke(stroke7);
        numberAxis1.setTickMarkStroke(stroke7);
        boolean boolean10 = numberAxis1.isPositiveArrowVisible();
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setFixedAutoRange(0.0d);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightInset((double) 100.0f);
        double double6 = rectangleInsets0.trimWidth((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        try {
            java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        categoryPlot4.setWeight((int) (short) 0);
        try {
            categoryPlot4.mapDatasetToRangeAxis((int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, range6);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint7.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1, lengthConstraintType2, 0.05d, range4, lengthConstraintType8);
        org.jfree.chart.util.Size2D size2D10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = rectangleConstraint9.calculateConstrainedSize(size2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightInset((double) 100.0f);
        double double5 = rectangleInsets0.getTop();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font3);
        java.awt.Paint paint5 = labelBlock4.getPaint();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        java.util.List list7 = blockContainer6.getBlocks();
        java.lang.Object obj8 = blockContainer6.clone();
        try {
            blockContainer0.add((org.jfree.chart.block.Block) labelBlock4, (java.lang.Object) blockContainer6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.block.BlockContainer cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double3 = numberTickUnit2.getSize();
        try {
            org.jfree.chart.axis.TickUnit tickUnit4 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D5, (double) (byte) 100, (-1.0f), (float) '4');
        try {
            blockBorder0.draw(graphics2D1, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Object obj4 = keyedObjects2D0.getObject(8, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        java.lang.String str2 = basicProjectInfo0.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        basicProjectInfo0.setCopyright("Range[0.0,1.0]");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(libraryArray3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = null;
        org.jfree.chart.util.Layer layer7 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str8 = layer7.toString();
        try {
            categoryPlot4.addDomainMarker(categoryMarker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(layer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Layer.FOREGROUND" + "'", str8.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        axisSpace0.setRight((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets1.calculateLeftOutset((double) (byte) -1);
        blockContainer0.setMargin(rectangleInsets1);
        double double6 = rectangleInsets1.trimHeight((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.0d) + "'", double6 == (-3.0d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setRangeAboutValue(0.0d, (double) 0.5f);
        numberAxis1.setNegativeArrowVisible(true);
        double double10 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.25d) + "'", double10 == (-0.25d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10L, shape3, "", "ChartEntity: tooltip = ");
        java.lang.String str10 = categoryLabelEntity9.getShapeCoords();
        java.lang.String str11 = categoryLabelEntity9.toString();
        java.lang.String str12 = categoryLabelEntity9.toString();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35" + "'", str10.equals("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = " + "'", str11.equals("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = " + "'", str12.equals("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = "));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.TOP_LEFT" + "'", str1.equals("TextAnchor.TOP_LEFT"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str12 = layer11.toString();
        try {
            categoryPlot4.addDomainMarker(3, categoryMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Layer.FOREGROUND" + "'", str12.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 1.5707963267948966d, (double) 100.0f, (int) '4', (java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", textAnchor3, textAnchor4, 0.0d);
        java.lang.String str7 = numberTick6.getText();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str7.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) '4');
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        barRenderer3.setBaseOutlinePaint(paint5);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        try {
            barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.util.List list2 = blockContainer1.getBlocks();
        java.lang.Object obj3 = blockContainer1.clone();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, range6);
        org.jfree.data.Range range8 = rectangleConstraint7.getWidthRange();
        org.jfree.data.Range range9 = rectangleConstraint7.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint7.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D11 = centerArrangement0.arrange(blockContainer1, graphics2D4, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 15, (double) 100L, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor16 = valueMarker15.getLabelTextAnchor();
        java.awt.Stroke stroke17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker15.setOutlineStroke(stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str20 = rectangleInsets19.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        org.jfree.chart.renderer.RendererState rendererState23 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo22.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor28 = valueMarker27.getLabelTextAnchor();
        java.awt.Stroke stroke29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker27.setOutlineStroke(stroke29);
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker27.setStroke(stroke31);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = valueMarker27.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets19.createAdjustedRectangle(rectangle2D24, lengthAdjustmentType25, lengthAdjustmentType33);
        try {
            barRenderer0.drawRangeMarker(graphics2D1, categoryPlot6, valueAxis13, (org.jfree.chart.plot.Marker) valueMarker15, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str20.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(lengthAdjustmentType25);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(lengthAdjustmentType33);
        org.junit.Assert.assertNotNull(rectangle2D34);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setRangeAboutValue(0.0d, (double) 0.5f);
        numberAxis1.setNegativeArrowVisible(true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str13 = rectangleInsets12.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        org.jfree.chart.renderer.RendererState rendererState16 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo15.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType18 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor21 = valueMarker20.getLabelTextAnchor();
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker20.setOutlineStroke(stroke22);
        java.awt.Stroke stroke24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker20.setStroke(stroke24);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = valueMarker20.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets12.createAdjustedRectangle(rectangle2D17, lengthAdjustmentType18, lengthAdjustmentType26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.axis.AxisCollection axisCollection29 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis31.setRange(1.0d, (double) (byte) 10);
        boolean boolean35 = numberAxis31.isVerticalTickLabels();
        boolean boolean36 = numberAxis31.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge37);
        axisCollection29.add((org.jfree.chart.axis.Axis) numberAxis31, rectangleEdge37);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo40);
        org.jfree.chart.renderer.RendererState rendererState42 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo41);
        try {
            org.jfree.chart.axis.AxisState axisState43 = numberAxis1.draw(graphics2D10, (-3.0d), rectangle2D27, rectangle2D28, rectangleEdge37, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str13.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(lengthAdjustmentType18);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        boolean boolean4 = itemLabelAnchor0.equals((java.lang.Object) plotRenderingInfo2);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateLeftOutset((double) (byte) -1);
        double double6 = rectangleInsets2.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        org.jfree.chart.renderer.RendererState rendererState9 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo8.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets2.createOutsetRectangle(rectangle2D10, true, true);
        try {
            blockContainer0.draw(graphics2D1, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = labelBlock2.getMargin();
        labelBlock2.setURLText("CategoryAnchor.END");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.Range range2 = new org.jfree.data.Range((-3.0d), (double) '4');
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        try {
            org.jfree.data.Range range21 = barRenderer0.findRangeBounds(categoryDataset20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, range5);
        org.jfree.data.Range range7 = rectangleConstraint6.getWidthRange();
        org.jfree.data.Range range8 = rectangleConstraint6.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D9 = blockContainer0.arrange(graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str19 = categoryAxis17.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot16.setDomainAxis(categoryAxis17);
        double double21 = categoryAxis17.getCategoryMargin();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets();
        double double26 = rectangleInsets24.calculateLeftOutset((double) (byte) -1);
        double double28 = rectangleInsets24.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        org.jfree.chart.renderer.RendererState rendererState31 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = plotRenderingInfo30.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets24.createOutsetRectangle(rectangle2D32, true, true);
        org.jfree.chart.axis.AxisState axisState36 = new org.jfree.chart.axis.AxisState();
        axisState36.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState41 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean44 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge43);
        axisState41.moveCursor(0.0d, rectangleEdge43);
        axisState36.moveCursor((double) 100L, rectangleEdge43);
        java.util.List list47 = categoryAxis17.refreshTicks(graphics2D22, axisState23, rectangle2D32, rectangleEdge43);
        try {
            labelBlock2.draw(graphics2D11, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(list47);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("ClassContext", (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        java.awt.Paint paint20 = null;
        try {
            categoryPlot4.setRangeGridlinePaint(paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.AxisCollection axisCollection4 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection4.add((org.jfree.chart.axis.Axis) numberAxis5, rectangleEdge6);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = numberAxis5.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        org.jfree.chart.renderer.RendererState rendererState11 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo10.getDataArea();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D12, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.clone(shape16);
        numberAxis5.setUpArrow(shape17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem(attributedString0, "CategoryLabelWidthType.CATEGORY", "TextAnchor.TOP_LEFT", "CategoryLabelWidthType.RANGE", shape17, paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setLowerBound((double) (-1.0f));
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis10.setUpperBound((double) 8);
        numberAxis10.resizeRange((double) 100);
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        double double16 = range15.getUpperBound();
        numberAxis1.setRangeWithMargins(range15, false, false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot16.setDomainAxisLocation(axisLocation17, true);
        boolean boolean20 = categoryPlot16.getDrawSharedDomainAxis();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis23.setRange(1.0d, (double) (byte) 10);
        boolean boolean27 = numberAxis23.isVerticalTickLabels();
        double double28 = numberAxis23.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
        org.jfree.chart.renderer.RendererState rendererState32 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo31.getDataArea();
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D33, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection38 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis40.setRange(1.0d, (double) (byte) 10);
        boolean boolean44 = numberAxis40.isVerticalTickLabels();
        boolean boolean45 = numberAxis40.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge46);
        axisCollection38.add((org.jfree.chart.axis.Axis) numberAxis40, rectangleEdge46);
        java.lang.String str49 = rectangleEdge46.toString();
        double double50 = numberAxis23.lengthToJava2D((double) 255, rectangle2D33, rectangleEdge46);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo52);
        boolean boolean54 = categoryPlot16.render(graphics2D21, rectangle2D33, (int) (byte) 0, plotRenderingInfo53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int56 = color55.getTransparency();
        int int57 = color55.getAlpha();
        java.awt.image.ColorModel colorModel58 = null;
        java.awt.Rectangle rectangle59 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo60);
        org.jfree.chart.renderer.RendererState rendererState62 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo61);
        java.awt.geom.Rectangle2D rectangle2D63 = plotRenderingInfo61.getDataArea();
        java.awt.geom.AffineTransform affineTransform64 = null;
        java.awt.RenderingHints renderingHints65 = null;
        java.awt.PaintContext paintContext66 = color55.createContext(colorModel58, rectangle59, rectangle2D63, affineTransform64, renderingHints65);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo68);
        org.jfree.chart.renderer.RendererState rendererState70 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo69);
        java.awt.geom.Rectangle2D rectangle2D71 = plotRenderingInfo69.getDataArea();
        try {
            org.jfree.chart.axis.AxisState axisState72 = categoryAxis5.draw(graphics2D10, (double) (byte) -1, rectangle2D33, rectangle2D63, rectangleEdge67, plotRenderingInfo69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "RectangleEdge.RIGHT" + "'", str49.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 255 + "'", int57 == 255);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(paintContext66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertNotNull(rectangle2D71);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", textAnchor3, textAnchor4, 0.0d);
        java.lang.Number number7 = numberTick6.getNumber();
        double double8 = numberTick6.getValue();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "", "hi!");
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity15 = new org.jfree.chart.entity.TickLabelEntity(shape12, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        tickLabelEntity9.setArea(shape12);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor20 = valueMarker19.getLabelTextAnchor();
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker19.setOutlineStroke(stroke21);
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker19, jFreeChart23, (int) (byte) 0, (int) (byte) 100);
        java.awt.Stroke stroke27 = valueMarker19.getStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint29 = defaultDrawingSupplier28.getNextPaint();
        try {
            org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem(attributedString0, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "CategoryLabelWidthType.CATEGORY", "ThreadContext", shape12, (java.awt.Paint) color17, stroke27, paint29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis5.setUpperBound((double) 8);
        numberAxis5.resizeRange((double) 100);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, (double) (-1L));
        try {
            org.jfree.chart.util.Size2D size2D13 = blockContainer0.arrange(graphics2D3, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 'a', 0.5f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.String str4 = legendItemEntity3.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str4.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.axis.AxisCollection axisCollection1 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection1.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge3);
        java.util.List list5 = axisCollection1.getAxesAtTop();
        projectInfo0.setContributors(list5);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ChartChangeEventType.DATASET_UPDATED", "RectangleEdge.RIGHT", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.Object obj0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent(obj0, dataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font3);
        boolean boolean5 = axisLocation1.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem7 = barRenderer4.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape8 = barRenderer4.getBaseShape();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer4.setSeriesOutlineStroke((int) (short) 0, stroke10);
        barRenderer4.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        org.jfree.chart.renderer.RendererState rendererState16 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = plotRenderingInfo15.getDataArea();
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D17, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.clone(shape21);
        barRenderer4.setBaseShape(shape22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem28 = barRenderer25.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape29 = barRenderer25.getBaseShape();
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer25.setSeriesOutlineStroke((int) (short) 0, stroke31);
        barRenderer25.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo35);
        org.jfree.chart.renderer.RendererState rendererState37 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo36.getDataArea();
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D38, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape43 = org.jfree.chart.util.ShapeUtilities.clone(shape42);
        barRenderer25.setBaseShape(shape43);
        java.lang.Boolean boolean46 = barRenderer25.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier48 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke49 = defaultDrawingSupplier48.getNextOutlineStroke();
        barRenderer25.setSeriesOutlineStroke((int) ' ', stroke49);
        java.awt.Paint paint51 = null;
        try {
            org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("Range[0.0,1.0]", "ClassContext", "org.jfree.data.general.DatasetChangeEvent[source= ]", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", shape22, (java.awt.Paint) color24, stroke49, paint51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(legendItem28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNull(boolean46);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 100L);
        blockParams0.setTranslateY((double) 15);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = valueMarker1.getLabelOffsetType();
        java.awt.Stroke stroke8 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        boolean boolean7 = barRenderer0.getItemVisible(0, (int) (byte) -1);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke11 = barRenderer0.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis14.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        numberAxis14.removeChangeListener(axisChangeListener18);
        java.awt.Shape shape20 = numberAxis14.getRightArrow();
        barRenderer0.setSeriesShape(8, shape20, true);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity27 = new org.jfree.chart.entity.TickLabelEntity(shape24, "org.jfree.data.general.DatasetChangeEvent[source= ]", "");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D31, (double) (byte) 100, (-1.0f), (float) '4');
        boolean boolean36 = org.jfree.chart.util.ShapeUtilities.equal(shape24, shape35);
        barRenderer0.setBaseShape(shape35);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        numberAxis1.setLowerMargin(0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        java.util.List list3 = blockContainer2.getBlocks();
        java.lang.Object obj4 = blockContainer2.clone();
        java.util.List list5 = blockContainer2.getBlocks();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, range8);
        org.jfree.data.Range range10 = rectangleConstraint9.getWidthRange();
        org.jfree.data.Range range11 = rectangleConstraint9.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D13 = borderArrangement0.arrange(blockContainer2, graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        float float20 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem24 = barRenderer21.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape25 = barRenderer21.getBaseShape();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer21.setSeriesOutlineStroke((int) (short) 0, stroke27);
        barRenderer21.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer21.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("", font35);
        labelBlock36.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock36.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color47 = java.awt.Color.orange;
        int int48 = color47.getBlue();
        labelBlock36.setPaint((java.awt.Paint) color47);
        barRenderer21.setBasePaint((java.awt.Paint) color47, false);
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color47);
        java.awt.Color color53 = color47.darker();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.data.Range range2 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, range7);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = rectangleConstraint8.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range2, lengthConstraintType3, 0.05d, range5, lengthConstraintType9);
        boolean boolean11 = centerArrangement0.equals((java.lang.Object) lengthConstraintType9);
        centerArrangement0.clear();
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("");
        boolean boolean15 = centerArrangement0.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer34);
        boolean boolean36 = categoryPlot35.isRangeZoomable();
        boolean boolean37 = barRenderer0.hasListener((java.util.EventListener) categoryPlot35);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo39);
        org.jfree.chart.renderer.RendererState rendererState41 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo40);
        java.awt.geom.Rectangle2D rectangle2D42 = plotRenderingInfo40.getDataArea();
        try {
            categoryPlot35.drawBackground(graphics2D38, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setStroke(stroke5);
        valueMarker1.setValue((double) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        valueMarker1.notifyListeners(markerChangeEvent9);
        org.jfree.chart.text.TextAnchor textAnchor11 = null;
        try {
            valueMarker1.setLabelTextAnchor(textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 1, (-3.0d), (double) 0, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("RectangleEdge.RIGHT");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("");
        try {
            java.lang.Object obj6 = jFreeChartResources0.getObject("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        try {
            barRenderer0.setSeriesURLGenerator((-1), categoryURLGenerator2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Layer.FOREGROUND", "TextBlockAnchor.TOP_LEFT", "ChartEntity: tooltip = ", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.awt.Paint paint3 = labelBlock2.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.calculateLeftOutset((double) (byte) -1);
        double double8 = rectangleInsets4.calculateRightOutset(0.0d);
        double double10 = rectangleInsets4.calculateTopInset((double) (-1));
        double double12 = rectangleInsets4.calculateBottomOutset((double) 0L);
        labelBlock2.setMargin(rectangleInsets4);
        double double14 = rectangleInsets4.getRight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.setAutoRange(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, range6);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint7.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1, lengthConstraintType2, 0.05d, range4, lengthConstraintType8);
        java.lang.String str10 = rectangleConstraint9.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=-1.0, height=0.05]" + "'", str10.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=-1.0, height=0.05]"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleConstraint[RectangleConstraintType.RANGE: width=-1.0, height=0.05]", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str13 = layer12.toString();
        try {
            barRenderer0.addAnnotation(categoryAnnotation11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Layer.FOREGROUND" + "'", str13.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getInfo();
        java.awt.Image image2 = projectInfo0.getLogo();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(image2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        categoryPlot4.setRangeCrosshairValue(1.0d, true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        numberAxis1.setRangeAboutValue((double) 1L, (double) (byte) 1);
        numberAxis1.setTickMarkOutsideLength((float) ' ');
        numberAxis1.setNegativeArrowVisible(false);
        boolean boolean13 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color9);
        numberAxis1.setTickLabelFont(font7);
        double double12 = numberAxis1.getLowerBound();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.RendererState rendererState18 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo17.getDataArea();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.util.List list21 = numberAxis1.refreshTicks(graphics2D13, axisState15, rectangle2D19, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean3 = horizontalAlignment1.equals((java.lang.Object) textBlockAnchor2);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5, textAnchor6, (double) 0.5f);
        org.jfree.chart.text.TextAnchor textAnchor9 = itemLabelPosition8.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType11 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor2, textAnchor9, (double) 15, categoryLabelWidthType11, (float) 15);
        java.lang.String str14 = textBlockAnchor2.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(categoryLabelWidthType11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.TOP_CENTER" + "'", str14.equals("TextBlockAnchor.TOP_CENTER"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str7 = projectInfo6.toString();
        boolean boolean8 = textLine5.equals((java.lang.Object) str7);
        org.jfree.chart.text.TextFragment textFragment9 = textLine5.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str7.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textFragment9);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock2.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        org.jfree.chart.block.BlockFrame blockFrame13 = null;
        try {
            labelBlock2.setFrame(blockFrame13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        float float20 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot4.getDomainAxisEdge(192);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (byte) 0, 0.0d);
        boolean boolean4 = range2.equals((java.lang.Object) 10.0d);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range2, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle1.setVerticalAlignment(verticalAlignment3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean9 = horizontalAlignment7.equals((java.lang.Object) textBlockAnchor8);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor10, textAnchor11, textAnchor12, (double) 0.5f);
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType17 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor8, textAnchor15, (double) 15, categoryLabelWidthType17, (float) 15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor8);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelWidthType17);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        java.lang.Object obj2 = blockContainer0.clone();
        blockContainer0.clear();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis18.setRange(1.0d, (double) (byte) 10);
        boolean boolean22 = numberAxis18.isVerticalTickLabels();
        boolean boolean23 = numberAxis18.isPositiveArrowVisible();
        org.jfree.data.Range range24 = numberAxis18.getDefaultAutoRange();
        java.awt.Font font26 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("", font28);
        java.awt.Paint paint30 = labelBlock29.getPaint();
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("hi!", font26, paint30, 100.0f);
        java.awt.Paint paint33 = textFragment32.getPaint();
        numberAxis18.setTickMarkPaint(paint33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets();
        double double37 = rectangleInsets35.calculateLeftOutset((double) (byte) -1);
        double double39 = rectangleInsets35.calculateRightInset((double) 100.0f);
        numberAxis18.setTickLabelInsets(rectangleInsets35);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot45.setDomainAxisLocation(axisLocation46, true);
        boolean boolean49 = categoryPlot45.getDrawSharedDomainAxis();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis52.setRange(1.0d, (double) (byte) 10);
        boolean boolean56 = numberAxis52.isVerticalTickLabels();
        double double57 = numberAxis52.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo59);
        org.jfree.chart.renderer.RendererState rendererState61 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo60);
        java.awt.geom.Rectangle2D rectangle2D62 = plotRenderingInfo60.getDataArea();
        java.awt.Shape shape66 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D62, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection67 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis69.setRange(1.0d, (double) (byte) 10);
        boolean boolean73 = numberAxis69.isVerticalTickLabels();
        boolean boolean74 = numberAxis69.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge75);
        axisCollection67.add((org.jfree.chart.axis.Axis) numberAxis69, rectangleEdge75);
        java.lang.String str78 = rectangleEdge75.toString();
        double double79 = numberAxis52.lengthToJava2D((double) 255, rectangle2D62, rectangleEdge75);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo81);
        boolean boolean83 = categoryPlot45.render(graphics2D50, rectangle2D62, (int) (byte) 0, plotRenderingInfo82);
        rectangleInsets35.trim(rectangle2D62);
        java.awt.geom.Point2D point2D85 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo86 = null;
        try {
            jFreeChart14.draw(graphics2D16, rectangle2D62, point2D85, chartRenderingInfo86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "RectangleEdge.RIGHT" + "'", str78.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        numberAxis1.setRange((double) 500, (double) 500);
        boolean boolean12 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setRangeAboutValue(0.0d, (double) 0.5f);
        boolean boolean8 = numberAxis1.isTickLabelsVisible();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int12 = color11.getTransparency();
        int int13 = color11.getAlpha();
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.RendererState rendererState18 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo17.getDataArea();
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color11.createContext(colorModel14, rectangle15, rectangle2D19, affineTransform20, renderingHints21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        double double25 = rectangleInsets23.calculateLeftOutset((double) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace26 = new org.jfree.chart.axis.AxisSpace();
        double double27 = axisSpace26.getLeft();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D31, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection36 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection36.add((org.jfree.chart.axis.Axis) numberAxis37, rectangleEdge38);
        java.awt.geom.Rectangle2D rectangle2D40 = axisSpace26.reserved(rectangle2D31, rectangleEdge38);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets23.createInsetRectangle(rectangle2D31);
        org.jfree.chart.axis.AxisState axisState42 = new org.jfree.chart.axis.AxisState();
        axisState42.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState47 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean50 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge49);
        axisState47.moveCursor(0.0d, rectangleEdge49);
        axisState42.moveCursor((double) 100L, rectangleEdge49);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo53);
        org.jfree.chart.renderer.RendererState rendererState55 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo54);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo57 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo56);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState58 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo57);
        plotRenderingInfo54.addSubplotInfo(plotRenderingInfo57);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo60);
        plotRenderingInfo57.addSubplotInfo(plotRenderingInfo61);
        try {
            org.jfree.chart.axis.AxisState axisState63 = numberAxis1.draw(graphics2D9, (double) 1.0f, (java.awt.geom.Rectangle2D) rectangle15, rectangle2D41, rectangleEdge49, plotRenderingInfo57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        try {
            org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.TickType tickType4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick(tickType4, 0.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", textAnchor7, textAnchor8, 0.0d);
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.text.TextUtilities.drawAlignedString("ThreadContext", graphics2D1, 0.0f, (float) 2, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!", "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightOutset(0.0d);
        double double6 = rectangleInsets0.calculateBottomInset((double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        boolean boolean12 = datasetRenderingOrder9.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker6.getLabelTextAnchor();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setStroke(stroke10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker6.setLabelOffsetType(lengthAdjustmentType13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker6.setLabelTextAnchor(textAnchor15);
        org.jfree.chart.axis.CategoryTick categoryTick18 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100.0f, textBlock1, textBlockAnchor3, textAnchor15, (double) 0.0f);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = categoryTick18.getLabelAnchor();
        java.lang.Comparable comparable20 = categoryTick18.getCategory();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 100.0f + "'", comparable20.equals(100.0f));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets7.createOutsetRectangle(rectangle2D15, true, true);
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D18);
        int int20 = categoryPlot4.getDatasetCount();
        org.jfree.chart.util.SortOrder sortOrder21 = null;
        try {
            categoryPlot4.setRowRenderingOrder(sortOrder21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        double double16 = axisSpace15.getLeft();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D20, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection25 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection25.add((org.jfree.chart.axis.Axis) numberAxis26, rectangleEdge27);
        java.awt.geom.Rectangle2D rectangle2D29 = axisSpace15.reserved(rectangle2D20, rectangleEdge27);
        try {
            categoryPlot4.drawBackground(graphics2D14, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        numberAxis1.setUpArrow(shape13);
        double double15 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension((double) (short) 10);
        boolean boolean18 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font3);
        java.awt.Paint paint5 = labelBlock4.getPaint();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("hi!", font1, paint5, 100.0f);
        java.awt.Paint paint8 = textFragment7.getPaint();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            float float11 = textFragment7.calculateBaselineOffset(graphics2D9, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        boolean boolean2 = shapeList0.equals((java.lang.Object) paint1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot7.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState16 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        plotRenderingInfo15.addSubplotInfo(plotRenderingInfo19);
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot7.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo15, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot7.getOrientation();
        boolean boolean24 = shapeList0.equals((java.lang.Object) plotOrientation23);
        java.awt.Shape shape26 = shapeList0.getShape(500);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(shape26);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        int int31 = barRenderer0.getColumnCount();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 0, true);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(categoryURLGenerator32);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer0.setBaseSeriesVisibleInLegend(false);
        java.awt.Shape shape8 = barRenderer0.getItemShape((int) ' ', (int) (byte) 0);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        barRenderer0.setSeriesPaint((int) (short) 1, paint10, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        boolean boolean15 = jFreeChart14.isBorderVisible();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.plot.Plot plot21 = categoryPlot20.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        org.jfree.chart.renderer.RendererState rendererState26 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo25);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo28);
        plotRenderingInfo25.addSubplotInfo(plotRenderingInfo28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        plotRenderingInfo28.addSubplotInfo(plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot20.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo28, point2D34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = categoryPlot20.getOrientation();
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) plotOrientation36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: PlotOrientation.VERTICAL incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertNotNull(plotOrientation36);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double3 = numberTickUnit2.getSize();
        java.lang.Object obj5 = keyedObjects2D0.getObject((java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        try {
            keyedObjects2D0.removeColumn(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart14.clearSubtitles();
        try {
            org.jfree.chart.title.Title title17 = jFreeChart14.getSubtitle(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("RectangleEdge.RIGHT");
        java.lang.String str3 = projectInfo0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str3.equals("null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType1 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str2 = chartChangeEventType1.toString();
        boolean boolean3 = flowArrangement0.equals((java.lang.Object) chartChangeEventType1);
        org.junit.Assert.assertNotNull(chartChangeEventType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str2.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color6 = java.awt.Color.getColor("ChartEntity: tooltip = ", color5);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, paint1, stroke3, (java.awt.Paint) color6, stroke8, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        try {
            org.jfree.data.Range range6 = barRenderer3.findRangeBounds(categoryDataset5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("Layer.FOREGROUND", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str7 = projectInfo6.toString();
        boolean boolean8 = textLine5.equals((java.lang.Object) str7);
        org.jfree.chart.text.TextFragment textFragment9 = textLine5.getLastTextFragment();
        org.jfree.chart.text.TextFragment textFragment10 = null;
        textLine5.addFragment(textFragment10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str7.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textFragment9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        org.jfree.chart.renderer.RendererState rendererState3 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        boolean boolean4 = axisLocation0.equals((java.lang.Object) plotRenderingInfo2);
        org.jfree.chart.renderer.RendererState rendererState5 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo2);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.util.List list2 = blockContainer1.getBlocks();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, (double) 100L);
        try {
            org.jfree.chart.util.Size2D size2D7 = flowArrangement0.arrange(blockContainer1, graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor9 = valueMarker8.getLabelTextAnchor();
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker8.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker8.setStroke(stroke12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = valueMarker8.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int17 = color16.getTransparency();
        int int18 = color16.getAlpha();
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        org.jfree.chart.renderer.RendererState rendererState23 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo22.getDataArea();
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color16.createContext(colorModel19, rectangle20, rectangle2D24, affineTransform25, renderingHints26);
        try {
            boolean boolean28 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D5, (java.awt.geom.Rectangle2D) rectangle20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(paintContext27);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        boolean boolean3 = chartChangeEventType0.equals((java.lang.Object) chartChangeEventType2);
        java.lang.String str4 = chartChangeEventType2.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str4.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        java.lang.String str2 = basicProjectInfo0.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        basicProjectInfo4.setLicenceName("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo4);
        basicProjectInfo0.setName("HorizontalAlignment.CENTER");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getColumnKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Paint paint14 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = barRenderer0.getURLGenerator((int) (byte) 100, (int) (byte) 10);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(categoryURLGenerator17);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 192, (double) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.awt.Paint paint3 = labelBlock2.getPaint();
        java.awt.Font font4 = labelBlock2.getFont();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) labelBlock2, jFreeChart5, (int) (short) 1, (int) 'a');
        labelBlock2.setToolTipText("RectangleEdge.BOTTOM");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setLowerBound(54.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Color color12 = java.awt.Color.MAGENTA;
        try {
            barRenderer0.setSeriesItemLabelPaint((int) (short) -1, (java.awt.Paint) color12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = new org.jfree.chart.axis.AxisSpace();
        double double4 = axisSpace3.getLeft();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection13 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection13.add((org.jfree.chart.axis.Axis) numberAxis14, rectangleEdge15);
        java.awt.geom.Rectangle2D rectangle2D17 = axisSpace3.reserved(rectangle2D8, rectangleEdge15);
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets0.createInsetRectangle(rectangle2D8);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D8, "TextBlockAnchor.TOP_LEFT", "ThreadContext");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, (double) (-1L));
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range6, (double) 255);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        java.lang.String str2 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RangeType.FULL" + "'", str2.equals("RangeType.FULL"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        java.awt.RenderingHints renderingHints16 = null;
        try {
            jFreeChart14.setRenderingHints(renderingHints16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock2.setURLText("");
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.calculateLeftOutset((double) (byte) -1);
        double double15 = rectangleInsets11.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.RendererState rendererState18 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo17.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets11.createOutsetRectangle(rectangle2D19, true, true);
        try {
            labelBlock2.draw(graphics2D10, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightOutset(0.0d);
        double double5 = rectangleInsets0.getBottom();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = labelBlock2.getMargin();
        java.awt.Paint paint12 = labelBlock2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker1, jFreeChart5, (int) (byte) 0, (int) (byte) 100);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot15.setDomainAxisLocation(axisLocation16, true);
        boolean boolean19 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) categoryPlot15, true);
        jFreeChart23.clearSubtitles();
        chartProgressEvent8.setChart(jFreeChart23);
        org.jfree.chart.event.ChartChangeListener chartChangeListener26 = null;
        try {
            jFreeChart23.removeChangeListener(chartChangeListener26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str8 = categoryAxis6.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot5.setDomainAxis(categoryAxis6);
        boolean boolean10 = paintList0.equals((java.lang.Object) categoryPlot5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        org.jfree.chart.axis.TickUnits tickUnits9 = new org.jfree.chart.axis.TickUnits();
        numberAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits9);
        org.jfree.data.KeyedObjects2D keyedObjects2D11 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double14 = numberTickUnit13.getSize();
        java.lang.Object obj16 = keyedObjects2D11.getObject((java.lang.Comparable) numberTickUnit13, (java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        try {
            org.jfree.chart.axis.TickUnit tickUnit17 = tickUnits9.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = categoryLabelPosition11.getCategoryAnchor();
        org.jfree.chart.text.TextAnchor textAnchor13 = categoryLabelPosition11.getRotationAnchor();
        try {
            textLine5.draw(graphics2D6, (float) 0, (float) 8, textAnchor13, 1.0f, (float) 192, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) textBlockAnchor1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        boolean boolean8 = categoryPlot7.isRangeZoomable();
        boolean boolean9 = horizontalAlignment0.equals((java.lang.Object) boolean8);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = null;
        boolean boolean2 = legendItemCollection0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis4.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("", font10);
        java.awt.Color color12 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font10, (java.awt.Paint) color12);
        numberAxis4.setTickLabelFont(font10);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("org.jfree.data.general.DatasetChangeEvent[source= ]", font10, (java.awt.Paint) color15, (float) 0);
        textLine1.addFragment(textFragment17);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity24 = new org.jfree.chart.entity.TickLabelEntity(shape21, "", "hi!");
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity30 = new org.jfree.chart.entity.TickLabelEntity(shape27, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        tickLabelEntity24.setArea(shape27);
        boolean boolean32 = textFragment17.equals((java.lang.Object) tickLabelEntity24);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator33 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator34 = null;
        try {
            java.lang.String str35 = tickLabelEntity24.getImageMapAreaTag(toolTipTagFragmentGenerator33, uRLTagFragmentGenerator34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        int int1 = shapeList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(itemLabelPosition8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = new org.jfree.chart.util.RectangleInsets();
        double double4 = rectangleInsets2.calculateLeftOutset((double) (byte) -1);
        double double5 = rectangleInsets2.getRight();
        valueMarker1.setLabelOffset(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.String str2 = datasetGroup1.getID();
        java.lang.String str3 = datasetGroup1.getID();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis5.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font11);
        java.awt.Color color13 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("hi!", font11, (java.awt.Paint) color13);
        numberAxis5.setTickLabelFont(font11);
        numberAxis5.setVerticalTickLabels(false);
        boolean boolean18 = datasetGroup1.equals((java.lang.Object) false);
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        double double20 = axisSpace19.getRight();
        java.lang.String str21 = axisSpace19.toString();
        axisSpace19.setBottom(100.0d);
        boolean boolean24 = datasetGroup1.equals((java.lang.Object) axisSpace19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets1.calculateLeftOutset((double) (byte) -1);
        blockContainer0.setMargin(rectangleInsets1);
        org.jfree.chart.block.Arrangement arrangement5 = blockContainer0.getArrangement();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(arrangement5);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        numberAxis1.setUpArrow(shape13);
        numberAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator11);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(35.0d, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (0.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font9);
        labelBlock10.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color16 = java.awt.Color.YELLOW;
        int int17 = color16.getAlpha();
        labelBlock10.setPaint((java.awt.Paint) color16);
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setUpperBound((double) 8);
        numberAxis2.resizeRange((double) 100);
        boolean boolean7 = booleanList0.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker6.getLabelTextAnchor();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setStroke(stroke10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker6.setLabelOffsetType(lengthAdjustmentType13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker6.setLabelTextAnchor(textAnchor15);
        org.jfree.chart.axis.CategoryTick categoryTick18 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100.0f, textBlock1, textBlockAnchor3, textAnchor15, (double) 0.0f);
        org.jfree.chart.text.TextBlock textBlock19 = categoryTick18.getLabel();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNull(textBlock19);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        java.lang.Boolean boolean21 = barRenderer0.getSeriesVisible(8);
        boolean boolean22 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        try {
            categoryPlot4.setBackgroundImageAlpha((float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10L, shape3, "", "ChartEntity: tooltip = ");
        java.lang.Comparable comparable10 = categoryLabelEntity9.getKey();
        java.lang.String str11 = categoryLabelEntity9.getShapeCoords();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10L + "'", comparable10.equals(10L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35" + "'", str11.equals("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = categoryLabelPosition7.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) (byte) 0, 0.0d, rectangleAnchor8);
        size2D2.width = 0.2d;
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        categoryPlot4.setAnchorValue((double) '#', false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot4.getDomainAxisLocation((int) 'a');
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setStroke(stroke5);
        valueMarker1.setValue((double) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        valueMarker1.notifyListeners(markerChangeEvent9);
        java.lang.Class class11 = null;
        try {
            java.util.EventListener[] eventListenerArray12 = valueMarker1.getListeners(class11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem4 = barRenderer1.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape5 = barRenderer1.getBaseShape();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) (short) 0, stroke7);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer1.getNegativeItemLabelPositionFallback();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = barRenderer1.getLegendItems();
        java.util.Iterator iterator13 = legendItemCollection12.iterator();
        boolean boolean14 = itemLabelAnchor0.equals((java.lang.Object) iterator13);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(iterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        categoryPlot4.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        int int31 = barRenderer0.getColumnCount();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis35.setUpperBound((double) 8);
        numberAxis35.resizeRange((double) 100);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int41 = color40.getTransparency();
        int int42 = color40.getAlpha();
        java.awt.image.ColorModel colorModel43 = null;
        java.awt.Rectangle rectangle44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo45);
        org.jfree.chart.renderer.RendererState rendererState47 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo46);
        java.awt.geom.Rectangle2D rectangle2D48 = plotRenderingInfo46.getDataArea();
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color40.createContext(colorModel43, rectangle44, rectangle2D48, affineTransform49, renderingHints50);
        numberAxis35.setUpArrow((java.awt.Shape) rectangle2D48);
        barRenderer0.setSeriesShape(3, (java.awt.Shape) rectangle2D48);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(categoryURLGenerator32);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 255 + "'", int42 == 255);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(paintContext51);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleEdge.RIGHT", graphics2D1, (float) (short) 0, (float) (short) 1, 132.5d, (float) (short) 0, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font8);
        java.awt.Color color10 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font8, (java.awt.Paint) color10);
        numberAxis2.setTickLabelFont(font8);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("org.jfree.data.general.DatasetChangeEvent[source= ]", font8, (java.awt.Paint) color13, (float) 0);
        int int16 = color13.getBlue();
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0, 132.5d, (double) 1.0f, (double) 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.awt.Paint paint3 = labelBlock2.getPaint();
        java.awt.Font font4 = labelBlock2.getFont();
        double double5 = labelBlock2.getContentXOffset();
        labelBlock2.setMargin((double) (-1.0f), (double) 2, (double) 0.5f, 0.0d);
        java.lang.String str11 = labelBlock2.getToolTipText();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range13, range14);
        org.jfree.data.Range range16 = rectangleConstraint15.getWidthRange();
        org.jfree.data.Range range17 = rectangleConstraint15.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint15.toFixedHeight((double) '#');
        double double20 = rectangleConstraint19.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D21 = labelBlock2.arrange(graphics2D12, rectangleConstraint19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 35.0d + "'", double20 == 35.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        axisSpace0.setBottom((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        try {
            keyedObjects0.removeValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        org.jfree.chart.axis.TickUnits tickUnits9 = new org.jfree.chart.axis.TickUnits();
        numberAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits9);
        int int11 = tickUnits9.size();
        int int12 = tickUnits9.size();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        java.awt.Paint paint6 = null;
        legendTitle1.setBackgroundPaint(paint6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = legendTitle1.getVerticalAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range10, range11);
        org.jfree.data.Range range13 = rectangleConstraint12.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D14 = legendTitle1.arrange(graphics2D9, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        boolean boolean2 = shapeList0.equals((java.lang.Object) paint1);
        int int3 = shapeList0.size();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35");
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker5.getLabelTextAnchor();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker5.setOutlineStroke(stroke7);
        numberAxis1.setTickMarkStroke(stroke7);
        numberAxis1.setRange((double) 1, (double) 2.0f);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.Color color1 = java.awt.Color.YELLOW;
        float[] floatArray5 = new float[] { 10, '#', (short) -1 };
        float[] floatArray6 = color1.getRGBColorComponents(floatArray5);
        try {
            float[] floatArray7 = color0.getRGBComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot15.getRenderer(0);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot15.setDataset(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot15.getFixedLegendItems();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = null;
        try {
            categoryPlot15.addDomainMarker(categoryMarker25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categoryItemRenderer21);
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.junit.Assert.assertNotNull(rectangleConstraint0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        boolean boolean15 = jFreeChart14.isBorderVisible();
        org.jfree.chart.block.CenterArrangement centerArrangement16 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle18.setVerticalAlignment(verticalAlignment20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendTitle18.getLegendItemGraphicLocation();
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        centerArrangement16.add((org.jfree.chart.block.Block) legendTitle18, (java.lang.Object) textAnchor23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle18.setHorizontalAlignment(horizontalAlignment25);
        jFreeChart14.addLegend(legendTitle18);
        jFreeChart14.removeLegend();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "", "hi!");
        java.lang.String str6 = tickLabelEntity5.toString();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        org.jfree.chart.plot.Plot plot12 = categoryPlot11.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.RendererState rendererState17 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState20 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo19);
        plotRenderingInfo16.addSubplotInfo(plotRenderingInfo19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        plotRenderingInfo19.addSubplotInfo(plotRenderingInfo23);
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot11.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo19, point2D25);
        boolean boolean27 = tickLabelEntity5.equals((java.lang.Object) point2D25);
        java.lang.String str28 = tickLabelEntity5.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartEntity: tooltip = " + "'", str6.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ChartEntity: tooltip = " + "'", str28.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint(range3, range4);
        org.jfree.data.Range range6 = rectangleConstraint5.getWidthRange();
        org.jfree.data.Range range7 = rectangleConstraint5.getWidthRange();
        java.lang.String str8 = rectangleConstraint5.toString();
        try {
            org.jfree.chart.util.Size2D size2D9 = columnArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str8.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        float float9 = numberAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        numberAxis1.setTickUnit(numberTickUnit11, false, true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit15, true, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(numberTickUnit15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        boolean boolean20 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle15.getTextAlignment();
        textTitle15.setURLText("");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        java.lang.Boolean boolean21 = barRenderer0.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke24);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator26);
        barRenderer0.setBaseCreateEntities(false, true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        barRenderer0.notifyListeners(rendererChangeEvent31);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.plot.Plot plot21 = categoryPlot20.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        org.jfree.chart.renderer.RendererState rendererState26 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo25);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo28);
        plotRenderingInfo25.addSubplotInfo(plotRenderingInfo28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        plotRenderingInfo28.addSubplotInfo(plotRenderingInfo32);
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot20.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo28, point2D34);
        double double36 = categoryPlot20.getAnchorValue();
        try {
            jFreeChart14.setTextAntiAlias((java.lang.Object) double36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0.0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        java.lang.Object obj2 = blockContainer0.clone();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent5 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle4);
        java.lang.Object obj6 = legendTitle4.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor7);
        java.awt.Paint paint9 = null;
        legendTitle4.setBackgroundPaint(paint9);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            blockContainer0.add((org.jfree.chart.block.Block) legendTitle4, (java.lang.Object) textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.text.TextAnchor cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        barRenderer0.setMaximumBarWidth((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator((int) 'a', 192);
        barRenderer0.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 100L);
        double double3 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getPlotArea();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        double double5 = categoryItemRendererState4.getSeriesRunningTotal();
        double double6 = categoryItemRendererState4.getBarWidth();
        double double7 = categoryItemRendererState4.getSeriesRunningTotal();
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        double double2 = axisSpace0.getTop();
        axisSpace0.setBottom((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setStroke(stroke5);
        valueMarker1.setValue((double) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        valueMarker1.notifyListeners(markerChangeEvent9);
        java.awt.Font font11 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        boolean boolean12 = valueMarker1.equals((java.lang.Object) font11);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets7.createOutsetRectangle(rectangle2D15, true, true);
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D18);
        categoryPlot4.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        double double9 = range7.constrain((double) 8);
        double double10 = range7.getUpperBound();
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range7, (-0.25d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        int int9 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem14 = barRenderer11.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape15 = barRenderer11.getBaseShape();
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer11.setSeriesOutlineStroke((int) (short) 0, stroke17);
        barRenderer11.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer11.getNegativeItemLabelPositionFallback();
        categoryPlot4.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11, false);
        try {
            categoryPlot4.setBackgroundImageAlpha((float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(itemLabelPosition21);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        barRenderer0.setMaximumBarWidth((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator((int) 'a', 192);
        java.lang.Boolean boolean11 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) 0);
        int int12 = barRenderer0.getPassCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getSeriesPositiveItemLabelPosition(2);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        java.awt.Paint paint6 = null;
        legendTitle1.setBackgroundPaint(paint6);
        java.awt.Paint paint8 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot9.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.chart.renderer.RendererState rendererState15 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo17);
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        plotRenderingInfo17.addSubplotInfo(plotRenderingInfo21);
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot9.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo17, point2D23);
        float float25 = categoryPlot9.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem29 = barRenderer26.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape30 = barRenderer26.getBaseShape();
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer26.setSeriesOutlineStroke((int) (short) 0, stroke32);
        barRenderer26.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer26.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("", font40);
        labelBlock41.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock41.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color52 = java.awt.Color.orange;
        int int53 = color52.getBlue();
        labelBlock41.setPaint((java.awt.Paint) color52);
        barRenderer26.setBasePaint((java.awt.Paint) color52, false);
        categoryPlot9.setDomainGridlinePaint((java.awt.Paint) color52);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem62 = barRenderer59.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer59.setBaseSeriesVisibleInLegend(false);
        java.awt.Shape shape67 = barRenderer59.getItemShape((int) ' ', (int) (byte) 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator68 = null;
        barRenderer59.setBaseURLGenerator(categoryURLGenerator68, false);
        java.awt.Stroke stroke71 = barRenderer59.getBaseStroke();
        barRenderer0.setBaseStroke(stroke71, true);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNull(legendItem62);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        java.awt.Paint paint10 = barRenderer0.getItemFillPaint(0, (int) '#');
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setPositiveArrowVisible(true);
        org.jfree.data.Range range19 = categoryPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem23 = barRenderer20.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape24 = barRenderer20.getBaseShape();
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer20.setSeriesOutlineStroke((int) (short) 0, stroke26);
        barRenderer20.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer20.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("", font34);
        labelBlock35.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock35.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color46 = java.awt.Color.orange;
        int int47 = color46.getBlue();
        labelBlock35.setPaint((java.awt.Paint) color46);
        barRenderer20.setBasePaint((java.awt.Paint) color46, false);
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color46);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot15.getRangeAxisEdge();
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        java.awt.Color color55 = java.awt.Color.BLACK;
        barRenderer0.setSeriesFillPaint((int) 'a', (java.awt.Paint) color55, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(legendItem23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(color55);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        jFreeChart14.clearSubtitles();
        org.jfree.chart.event.ChartProgressListener chartProgressListener16 = null;
        jFreeChart14.removeProgressListener(chartProgressListener16);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font11);
        java.awt.Paint paint13 = labelBlock12.getPaint();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font9, paint13, 100.0f);
        java.awt.Paint paint16 = textFragment15.getPaint();
        numberAxis1.setTickMarkPaint(paint16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets18.calculateLeftOutset((double) (byte) -1);
        double double22 = rectangleInsets18.calculateRightInset((double) 100.0f);
        numberAxis1.setTickLabelInsets(rectangleInsets18);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot28.setDomainAxisLocation(axisLocation29, true);
        boolean boolean32 = categoryPlot28.getDrawSharedDomainAxis();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis35.setRange(1.0d, (double) (byte) 10);
        boolean boolean39 = numberAxis35.isVerticalTickLabels();
        double double40 = numberAxis35.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        org.jfree.chart.renderer.RendererState rendererState44 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo43);
        java.awt.geom.Rectangle2D rectangle2D45 = plotRenderingInfo43.getDataArea();
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D45, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection50 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis52.setRange(1.0d, (double) (byte) 10);
        boolean boolean56 = numberAxis52.isVerticalTickLabels();
        boolean boolean57 = numberAxis52.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge58);
        axisCollection50.add((org.jfree.chart.axis.Axis) numberAxis52, rectangleEdge58);
        java.lang.String str61 = rectangleEdge58.toString();
        double double62 = numberAxis35.lengthToJava2D((double) 255, rectangle2D45, rectangleEdge58);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo64);
        boolean boolean66 = categoryPlot28.render(graphics2D33, rectangle2D45, (int) (byte) 0, plotRenderingInfo65);
        rectangleInsets18.trim(rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D69 = rectangleInsets18.createInsetRectangle(rectangle2D68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleEdge.RIGHT" + "'", str61.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightOutset(0.0d);
        double double6 = rectangleInsets0.calculateTopInset((double) (-1));
        double double8 = rectangleInsets0.calculateLeftInset((double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("RectangleEdge.RIGHT");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("");
        java.lang.Object[][] objArray5 = jFreeChartResources0.getContents();
        java.util.Set<java.lang.String> strSet6 = jFreeChartResources0.keySet();
        try {
            java.lang.Object obj8 = jFreeChartResources0.getObject("AxisLocation.TOP_OR_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key AxisLocation.TOP_OR_RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setRange(1.0d, (double) (byte) 10);
        boolean boolean6 = numberAxis2.isVerticalTickLabels();
        boolean boolean7 = numberAxis2.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = null;
        valueMarker1.setOutlineStroke(stroke3);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color9);
        numberAxis1.setTickLabelFont(font7);
        numberAxis1.setLabelURL("org.jfree.data.general.DatasetChangeEvent[source= ]");
        numberAxis1.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightOutset(0.0d);
        double double6 = rectangleInsets0.calculateTopInset((double) (-1));
        double double8 = rectangleInsets0.calculateTopInset((double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.clearCategoryLabelToolTips();
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range(8.0d, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (8.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setRangeAboutValue(0.0d, (double) 0.5f);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis9.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.axis.AxisCollection axisCollection13 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection13.add((org.jfree.chart.axis.Axis) numberAxis14, rectangleEdge15);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = numberAxis14.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.RendererState rendererState20 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D21, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.clone(shape25);
        numberAxis14.setUpArrow(shape26);
        double double28 = numberAxis14.getLabelAngle();
        numberAxis14.setFixedDimension((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis32.setUpperBound((double) 8);
        numberAxis32.resizeRange((double) 100);
        org.jfree.data.Range range37 = numberAxis32.getDefaultAutoRange();
        numberAxis14.setDefaultAutoRange(range37);
        double double39 = range37.getLength();
        numberAxis9.setRangeWithMargins(range37, false, false);
        numberAxis1.setRange(range37, true, true);
        double double47 = range37.constrain((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        numberAxis1.setUpArrow(shape13);
        double double15 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis19.setUpperBound((double) 8);
        numberAxis19.resizeRange((double) 100);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis1.setDefaultAutoRange(range24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = new org.jfree.chart.axis.AxisSpace();
        double double27 = axisSpace26.getRight();
        axisSpace26.setLeft((double) 10.0f);
        boolean boolean30 = range24.equals((java.lang.Object) axisSpace26);
        axisSpace26.setTop((double) 192);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        numberAxis1.setUpArrow(shape13);
        double double15 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis19.setUpperBound((double) 8);
        numberAxis19.resizeRange((double) 100);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis1.setDefaultAutoRange(range24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = new org.jfree.chart.axis.AxisSpace();
        double double27 = axisSpace26.getRight();
        axisSpace26.setLeft((double) 10.0f);
        boolean boolean30 = range24.equals((java.lang.Object) axisSpace26);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge32);
        axisSpace26.add((double) (short) 0, rectangleEdge32);
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.DatasetChangeEvent[source= ]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.blue;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("LegendItemEntity: seriesKey=null, dataset=null", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets1.calculateLeftOutset((double) (byte) -1);
        blockContainer0.setMargin(rectangleInsets1);
        java.util.List list5 = blockContainer0.getBlocks();
        blockContainer0.setID("org.jfree.data.general.DatasetChangeEvent[source= ]");
        boolean boolean8 = blockContainer0.isEmpty();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8388608) + "'", int1 == (-8388608));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom(100.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            axisSpace0.add(3.0d, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, true);
        java.awt.Stroke stroke9 = barRenderer0.getSeriesOutlineStroke(255);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) 'a');
        java.awt.Color color12 = java.awt.Color.BLACK;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color12, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(drawingSupplier15);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = categoryLabelPosition7.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) (byte) 0, 0.0d, rectangleAnchor8);
        double double10 = size2D2.getHeight();
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem21 = barRenderer18.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape22 = barRenderer18.getBaseShape();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer18.setSeriesOutlineStroke((int) (short) 0, stroke24);
        barRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D31, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.clone(shape35);
        barRenderer18.setBaseShape(shape36);
        java.lang.Boolean boolean39 = barRenderer18.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke42 = defaultDrawingSupplier41.getNextOutlineStroke();
        barRenderer18.setSeriesOutlineStroke((int) ' ', stroke42);
        categoryPlot15.setRangeGridlineStroke(stroke42);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker46.getLabelTextAnchor();
        categoryPlot15.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker46);
        double double49 = valueMarker46.getValue();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, range6);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint7.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D9 = legendTitle1.arrange(graphics2D4, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem21 = barRenderer18.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape22 = barRenderer18.getBaseShape();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer18.setSeriesOutlineStroke((int) (short) 0, stroke24);
        barRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D31, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.clone(shape35);
        barRenderer18.setBaseShape(shape36);
        java.lang.Boolean boolean39 = barRenderer18.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke42 = defaultDrawingSupplier41.getNextOutlineStroke();
        barRenderer18.setSeriesOutlineStroke((int) ' ', stroke42);
        categoryPlot15.setRangeGridlineStroke(stroke42);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent45 = null;
        categoryPlot15.rendererChanged(rendererChangeEvent45);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = null;
        try {
            categoryPlot15.addDomainMarker(categoryMarker47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = null;
        boolean boolean2 = keyedObjects2D0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightInset((double) 100.0f);
        double double6 = rectangleInsets0.extendWidth((double) '4');
        double double7 = rectangleInsets0.getRight();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 54.0d + "'", double6 == 54.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        textTitle15.setVerticalAlignment(verticalAlignment17);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke11 = barRenderer0.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis14.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        numberAxis14.removeChangeListener(axisChangeListener18);
        java.awt.Shape shape20 = numberAxis14.getRightArrow();
        barRenderer0.setSeriesShape(8, shape20, true);
        java.awt.Paint paint25 = barRenderer0.getItemLabelPaint((int) ' ', 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem30 = barRenderer27.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape31 = barRenderer27.getBaseShape();
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer27.setSeriesOutlineStroke((int) (short) 0, stroke33);
        barRenderer27.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = barRenderer27.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock42 = new org.jfree.chart.block.LabelBlock("", font41);
        labelBlock42.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock42.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color53 = java.awt.Color.orange;
        int int54 = color53.getBlue();
        labelBlock42.setPaint((java.awt.Paint) color53);
        barRenderer27.setBasePaint((java.awt.Paint) color53, false);
        barRenderer0.setSeriesFillPaint(500, (java.awt.Paint) color53);
        java.awt.Paint paint60 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        try {
            barRenderer0.setSeriesPaint((int) (short) -1, paint60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(legendItem30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets7.createOutsetRectangle(rectangle2D15, true, true);
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D18);
        int int20 = categoryPlot4.getDatasetCount();
        boolean boolean21 = categoryPlot4.isOutlineVisible();
        categoryPlot4.setBackgroundImageAlignment(0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str1.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = categoryLabelPosition7.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) (byte) 0, 0.0d, rectangleAnchor8);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        java.lang.Comparable comparable13 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity15 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D9, "ChartChangeEventType.NEW_DATASET", "ChartChangeEventType.DATASET_UPDATED", categoryDataset12, comparable13, (java.lang.Comparable) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toFixedHeight((double) '#');
        double double7 = rectangleConstraint6.getHeight();
        org.jfree.data.Range range8 = rectangleConstraint6.getHeightRange();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setLowerMargin((double) (short) 1);
        double double7 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        boolean boolean20 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle15.getTextAlignment();
        java.lang.Object obj22 = textTitle15.clone();
        java.awt.Font font23 = textTitle15.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 0L);
        double double4 = rectangleInsets0.calculateRightOutset((double) 0.0f);
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = categoryLabelPosition13.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (byte) 0, 0.0d, rectangleAnchor14);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) true, (java.awt.Shape) rectangle2D15, "LegendItemEntity: seriesKey=null, dataset=null", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets0.createInsetRectangle(rectangle2D15, false, true);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateLeftOutset((double) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        double double19 = axisSpace18.getLeft();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.RendererState rendererState22 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D23, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection28 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection28.add((org.jfree.chart.axis.Axis) numberAxis29, rectangleEdge30);
        java.awt.geom.Rectangle2D rectangle2D32 = axisSpace18.reserved(rectangle2D23, rectangleEdge30);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets15.createInsetRectangle(rectangle2D23);
        try {
            categoryPlot4.drawBackground(graphics2D14, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_RIGHT" + "'", str1.equals("TextBlockAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        boolean boolean15 = jFreeChart14.isBorderVisible();
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart14.createBufferedImage((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (97) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        java.lang.String str2 = projectInfo0.toString();
        projectInfo0.setLicenceName("CategoryAnchor.END");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str2.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis6.setUpperBound((double) 8);
        numberAxis6.resizeRange((double) 100);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int12 = color11.getTransparency();
        int int13 = color11.getAlpha();
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.RendererState rendererState18 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo17.getDataArea();
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color11.createContext(colorModel14, rectangle15, rectangle2D19, affineTransform20, renderingHints21);
        numberAxis6.setUpArrow((java.awt.Shape) rectangle2D19);
        try {
            legendTitle1.draw(graphics2D4, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(paintContext22);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB((int) '#', (int) (byte) 100, (int) (short) 100, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str8 = categoryAxis6.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot5.setDomainAxis(categoryAxis6);
        double double10 = categoryAxis6.getCategoryMargin();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateLeftOutset((double) (byte) -1);
        double double17 = rectangleInsets13.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.RendererState rendererState20 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets13.createOutsetRectangle(rectangle2D21, true, true);
        org.jfree.chart.axis.AxisState axisState25 = new org.jfree.chart.axis.AxisState();
        axisState25.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState30 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean33 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge32);
        axisState30.moveCursor(0.0d, rectangleEdge32);
        axisState25.moveCursor((double) 100L, rectangleEdge32);
        java.util.List list36 = categoryAxis6.refreshTicks(graphics2D11, axisState12, rectangle2D21, rectangleEdge32);
        categoryAxis6.setCategoryLabelPositionOffset(100);
        boolean boolean39 = gradientPaintTransformType0.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 15, 2.0f, (float) (byte) 0);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem21 = barRenderer18.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape22 = barRenderer18.getBaseShape();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer18.setSeriesOutlineStroke((int) (short) 0, stroke24);
        barRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D31, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.clone(shape35);
        barRenderer18.setBaseShape(shape36);
        java.lang.Boolean boolean39 = barRenderer18.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke42 = defaultDrawingSupplier41.getNextOutlineStroke();
        barRenderer18.setSeriesOutlineStroke((int) ' ', stroke42);
        categoryPlot15.setRangeGridlineStroke(stroke42);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker46.getLabelTextAnchor();
        categoryPlot15.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker46);
        int int49 = categoryPlot15.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }
}

