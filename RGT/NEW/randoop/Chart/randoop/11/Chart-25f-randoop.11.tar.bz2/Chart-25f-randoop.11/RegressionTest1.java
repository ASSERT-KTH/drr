import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        boolean boolean20 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle15.getTextAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = null;
        try {
            textTitle15.setVerticalAlignment(verticalAlignment22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str1 = layer0.toString();
        java.awt.Color color2 = java.awt.Color.lightGray;
        int int3 = color2.getRed();
        boolean boolean4 = layer0.equals((java.lang.Object) int3);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.FOREGROUND" + "'", str1.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 192 + "'", int3 == 192);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str10 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot7.setDomainAxis(categoryAxis8);
        double double12 = categoryAxis8.getCategoryMargin();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateLeftOutset((double) (byte) -1);
        double double19 = rectangleInsets15.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.RendererState rendererState22 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets15.createOutsetRectangle(rectangle2D23, true, true);
        org.jfree.chart.axis.AxisState axisState27 = new org.jfree.chart.axis.AxisState();
        axisState27.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState32 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge34);
        axisState32.moveCursor(0.0d, rectangleEdge34);
        axisState27.moveCursor((double) 100L, rectangleEdge34);
        java.util.List list38 = categoryAxis8.refreshTicks(graphics2D13, axisState14, rectangle2D23, rectangleEdge34);
        org.jfree.chart.axis.AxisState axisState40 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean43 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge42);
        axisState40.moveCursor(0.0d, rectangleEdge42);
        java.util.List list45 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D23, rectangleEdge42);
        java.util.Collection collection46 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list45);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(collection46);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        barRenderer0.setSeriesItemLabelsVisible(100, (java.lang.Boolean) true, false);
        java.awt.Font font7 = barRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 132.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis17.setRange(1.0d, (double) (byte) 10);
        numberAxis17.setRangeAboutValue(0.0d, (double) 0.5f);
        boolean boolean24 = numberAxis17.isTickLabelsVisible();
        org.jfree.data.Range range25 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(range25);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo4);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = plotRenderingInfo4.getSubplotInfo((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean1 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (-8388608));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis4.setRange(1.0d, (double) (byte) 10);
        boolean boolean8 = numberAxis4.isVerticalTickLabels();
        boolean boolean9 = numberAxis4.isPositiveArrowVisible();
        org.jfree.data.Range range10 = numberAxis4.getDefaultAutoRange();
        java.lang.String str11 = range10.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeHeight(range10);
        java.lang.String str13 = rectangleConstraint12.toString();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Range[0.0,1.0]" + "'", str11.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]" + "'", str13.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        barRenderer0.setBaseItemLabelsVisible(true, true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "org.jfree.data.general.DatasetChangeEvent[source= ]");
        boolean boolean7 = legendTitle1.equals((java.lang.Object) shape4);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity(shape4, "CategoryLabelWidthType.CATEGORY", "poly");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot4.getRangeAxis();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity8 = new org.jfree.chart.entity.TickLabelEntity(shape5, "org.jfree.data.general.DatasetChangeEvent[source= ]", "");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        org.jfree.chart.renderer.RendererState rendererState11 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo10.getDataArea();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D12, (double) (byte) 100, (-1.0f), (float) '4');
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape5, shape16);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, (double) (short) 100, (-3.0d));
        boolean boolean24 = org.jfree.chart.util.ShapeUtilities.equal(shape16, shape23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        try {
            org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem(attributedString0, "ChartChangeEventType.NEW_DATASET", "", "HorizontalAlignment.CENTER", shape23, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        numberAxis1.setUpArrow(shape13);
        double double15 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        java.awt.Color color15 = java.awt.Color.orange;
        int int16 = color15.getBlue();
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.event.ChartChangeListener chartChangeListener18 = null;
        try {
            jFreeChart14.addChangeListener(chartChangeListener18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.lang.Boolean boolean12 = barRenderer0.getSeriesVisibleInLegend(192);
        boolean boolean13 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(boolean12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font11);
        java.awt.Paint paint13 = labelBlock12.getPaint();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font9, paint13, 100.0f);
        java.awt.Paint paint16 = textFragment15.getPaint();
        numberAxis1.setTickMarkPaint(paint16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets18.calculateLeftOutset((double) (byte) -1);
        double double22 = rectangleInsets18.calculateRightInset((double) 100.0f);
        numberAxis1.setTickLabelInsets(rectangleInsets18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        org.jfree.chart.renderer.RendererState rendererState26 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo25.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets18.createOutsetRectangle(rectangle2D27, false, false);
        double double32 = rectangleInsets18.calculateTopInset(3.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.lang.Object obj3 = valueMarker1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        boolean boolean9 = categoryPlot8.isRangeZoomable();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        java.awt.Stroke stroke11 = null;
        valueMarker1.setOutlineStroke(stroke11);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toFixedHeight((double) '#');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint6.toUnconstrainedWidth();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("RectangleEdge.RIGHT");
        java.awt.Image image3 = projectInfo0.getLogo();
        java.awt.Image image4 = null;
        projectInfo0.setLogo(image4);
        java.lang.String str6 = projectInfo0.getLicenceText();
        projectInfo0.addOptionalLibrary("");
        java.util.List list9 = projectInfo0.getContributors();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 192);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis4.setRange(1.0d, (double) (byte) 10);
        boolean boolean8 = numberAxis4.isVerticalTickLabels();
        boolean boolean9 = numberAxis4.isPositiveArrowVisible();
        org.jfree.data.Range range10 = numberAxis4.getDefaultAutoRange();
        java.lang.String str11 = range10.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint2.toRangeHeight(range10);
        double double13 = range10.getLength();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Range[0.0,1.0]" + "'", str11.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition();
        barRenderer0.setSeriesPositiveItemLabelPosition(100, itemLabelPosition6, false);
        barRenderer0.setAutoPopulateSeriesStroke(true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.setAutoRange(true);
        numberAxis1.setFixedDimension((double) 100);
        java.awt.Shape shape8 = numberAxis1.getUpArrow();
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setGenerateEntities(false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("CategoryLabelWidthType.RANGE", graphics2D1, (double) 10, (float) (-1L), 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RectangleEdge.RIGHT", (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(0);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Number number1 = null;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 100.0d, number1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        barRenderer0.setSeriesItemLabelsVisible(100, (java.lang.Boolean) true, false);
        int int7 = barRenderer0.getRowCount();
        java.awt.Paint paint9 = barRenderer0.getSeriesFillPaint(192);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (byte) 10, (double) ' ');
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        barRenderer0.setSeriesCreateEntities(192, (java.lang.Boolean) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = barRenderer0.getPlot();
        java.awt.Stroke stroke8 = barRenderer0.lookupSeriesStroke(1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = barRenderer0.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(gradientPaintTransformer9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis3.setUpperBound((double) 8);
        numberAxis3.resizeRange((double) 100);
        org.jfree.data.Range range8 = numberAxis3.getDefaultAutoRange();
        java.awt.Font font9 = numberAxis3.getLabelFont();
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ", font9);
        java.awt.Color color11 = java.awt.Color.YELLOW;
        org.jfree.chart.axis.AxisCollection axisCollection12 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis14.setRange(1.0d, (double) (byte) 10);
        boolean boolean18 = numberAxis14.isVerticalTickLabels();
        boolean boolean19 = numberAxis14.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        axisCollection12.add((org.jfree.chart.axis.Axis) numberAxis14, rectangleEdge20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        double double28 = rectangleInsets26.calculateLeftOutset((double) (byte) -1);
        double double30 = rectangleInsets26.calculateLeftInset(0.0d);
        try {
            org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle("ClassContext", font9, (java.awt.Paint) color11, rectangleEdge20, horizontalAlignment24, verticalAlignment25, rectangleInsets26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("RectangleEdge.RIGHT");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("");
        java.lang.Object[][] objArray5 = jFreeChartResources0.getContents();
        java.lang.Object obj7 = jFreeChartResources0.handleGetObject("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart8);
        org.jfree.chart.JFreeChart jFreeChart10 = chartChangeEvent9.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str12 = chartChangeEventType11.toString();
        chartChangeEvent9.setType(chartChangeEventType11);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(jFreeChart10);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str12.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Shape shape13 = barRenderer0.getItemShape(10, (int) '4');
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        boolean boolean17 = categoryPlot4.isSubplot();
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        double double19 = axisSpace18.getRight();
        double double20 = axisSpace18.getTop();
        java.lang.String str21 = axisSpace18.toString();
        categoryPlot4.setFixedDomainAxisSpace(axisSpace18);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray23 = null;
        try {
            categoryPlot4.setDomainAxes(categoryAxisArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets7.createOutsetRectangle(rectangle2D15, true, true);
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D18);
        int int20 = categoryPlot4.getDatasetCount();
        java.lang.Object obj21 = categoryPlot4.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        boolean boolean15 = jFreeChart14.isBorderVisible();
        org.jfree.chart.block.CenterArrangement centerArrangement16 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle18.setVerticalAlignment(verticalAlignment20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendTitle18.getLegendItemGraphicLocation();
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        centerArrangement16.add((org.jfree.chart.block.Block) legendTitle18, (java.lang.Object) textAnchor23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle18.setHorizontalAlignment(horizontalAlignment25);
        jFreeChart14.addLegend(legendTitle18);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray28 = legendTitle18.getSources();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(legendItemSourceArray28);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) ' ', (java.lang.Boolean) false);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        boolean boolean6 = booleanList0.equals((java.lang.Object) 15);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        boolean boolean15 = jFreeChart14.isBorderVisible();
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart14.addChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = legendTitle1.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart7.fireChartChanged();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str11 = rectangleInsets10.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor19 = valueMarker18.getLabelTextAnchor();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker18.setOutlineStroke(stroke20);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker18.setStroke(stroke22);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = valueMarker18.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets10.createAdjustedRectangle(rectangle2D15, lengthAdjustmentType16, lengthAdjustmentType24);
        try {
            jFreeChart7.draw(graphics2D9, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str11.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets1.calculateLeftOutset((double) (byte) -1);
        blockContainer0.setMargin(rectangleInsets1);
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement6 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape11, "", "hi!");
        centerArrangement6.add((org.jfree.chart.block.Block) labelBlock8, (java.lang.Object) "");
        java.lang.Object obj16 = null;
        flowArrangement5.add((org.jfree.chart.block.Block) labelBlock8, obj16);
        blockContainer0.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int7 = color6.getTransparency();
        int int8 = color6.getAlpha();
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color6.createContext(colorModel9, rectangle10, rectangle2D14, affineTransform15, renderingHints16);
        numberAxis1.setUpArrow((java.awt.Shape) rectangle2D14);
        org.jfree.chart.event.AxisChangeListener axisChangeListener19 = null;
        numberAxis1.removeChangeListener(axisChangeListener19);
        org.jfree.data.Range range23 = new org.jfree.data.Range((double) (byte) 0, 0.0d);
        boolean boolean25 = range23.equals((java.lang.Object) 10.0d);
        numberAxis1.setRangeWithMargins(range23);
        boolean boolean29 = range23.intersects((double) 8, (double) 'a');
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        barRenderer0.setMaximumBarWidth((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator((int) 'a', 192);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem13 = barRenderer10.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape14 = barRenderer10.getBaseShape();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer10.setSeriesOutlineStroke((int) (short) 0, stroke16);
        barRenderer10.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke21 = barRenderer10.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis24.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener28 = null;
        numberAxis24.removeChangeListener(axisChangeListener28);
        java.awt.Shape shape30 = numberAxis24.getRightArrow();
        barRenderer10.setSeriesShape(8, shape30, true);
        barRenderer0.setBaseShape(shape30, true);
        barRenderer0.setBaseCreateEntities(false, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        boolean boolean12 = categoryPlot4.isRangeZoomable();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle1.setVerticalAlignment(verticalAlignment3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        java.util.List list7 = blockContainer6.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame8 = blockContainer6.getFrame();
        legendTitle1.setFrame(blockFrame8);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(blockFrame8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean3 = rectangleEdge0.equals((java.lang.Object) color2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = categoryLabelPositions4.getLabelPosition(rectangleEdge5);
        boolean boolean7 = rectangleEdge0.equals((java.lang.Object) rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNull(categoryLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        java.awt.Font font10 = barRenderer0.getItemLabelFont((int) ' ', 255);
        barRenderer0.setItemLabelAnchorOffset((double) (-1));
        barRenderer0.setBaseCreateEntities(true, true);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        boolean boolean5 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Font font20 = categoryPlot15.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = valueMarker1.getLabelAnchor();
        java.awt.Paint paint4 = valueMarker1.getPaint();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.String str2 = datasetGroup1.getID();
        java.lang.Object obj3 = datasetGroup1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(obj3);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        java.lang.Class class1 = null;
//        try {
//            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("1", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 0.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        double double2 = axisSpace0.getTop();
        java.lang.Object obj3 = axisSpace0.clone();
        axisSpace0.setTop((double) 4);
        double double6 = axisSpace0.getBottom();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        java.awt.color.ColorSpace colorSpace6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem10 = barRenderer7.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape11 = barRenderer7.getBaseShape();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer7.setSeriesOutlineStroke((int) (short) 0, stroke13);
        barRenderer7.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer7.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("", font21);
        labelBlock22.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock22.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color33 = java.awt.Color.orange;
        int int34 = color33.getBlue();
        labelBlock22.setPaint((java.awt.Paint) color33);
        barRenderer7.setBasePaint((java.awt.Paint) color33, false);
        java.awt.Color color38 = java.awt.Color.YELLOW;
        float[] floatArray42 = new float[] { 10, '#', (short) -1 };
        float[] floatArray43 = color38.getRGBColorComponents(floatArray42);
        float[] floatArray44 = color33.getColorComponents(floatArray42);
        try {
            float[] floatArray45 = color4.getColorComponents(colorSpace6, floatArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(legendItem10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("RectangleEdge.RIGHT");
        java.lang.String str3 = projectInfo0.getVersion();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        java.lang.String str2 = axisSpace0.toString();
        java.lang.String str3 = axisSpace0.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        double double6 = numberAxis1.getFixedAutoRange();
        double double7 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-396.0d) + "'", double7 == (-396.0d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(255);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        basicProjectInfo0.setCopyright("CategoryLabelWidthType.RANGE");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        categoryPlot4.setAnchorValue((double) '#', false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis17.setRange(1.0d, (double) (byte) 10);
        boolean boolean21 = numberAxis17.isVerticalTickLabels();
        double double22 = numberAxis17.getLowerBound();
        boolean boolean23 = legendItemCollection15.equals((java.lang.Object) numberAxis17);
        java.util.Iterator iterator24 = legendItemCollection15.iterator();
        categoryPlot4.setFixedLegendItems(legendItemCollection15);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace26);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(iterator24);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        size2D2.setHeight((double) (byte) 10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem16 = barRenderer13.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape17 = barRenderer13.getBaseShape();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer13.setSeriesOutlineStroke((int) (short) 0, stroke19);
        barRenderer13.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor24, textAnchor25, textAnchor26, (double) 0.5f);
        barRenderer13.setSeriesPositiveItemLabelPosition(0, itemLabelPosition28);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition28, true);
        barRenderer0.setBase((double) 1L);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(legendItem16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        double double3 = size2D2.height;
        size2D2.width = (-3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        labelBlock2.setURLText("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str20 = categoryAxis18.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot17.setDomainAxis(categoryAxis18);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis25.setRange(1.0d, (double) (byte) 10);
        boolean boolean29 = numberAxis25.isVerticalTickLabels();
        double double30 = numberAxis25.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.RendererState rendererState34 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D35, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection40 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis42.setRange(1.0d, (double) (byte) 10);
        boolean boolean46 = numberAxis42.isVerticalTickLabels();
        boolean boolean47 = numberAxis42.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge48);
        axisCollection40.add((org.jfree.chart.axis.Axis) numberAxis42, rectangleEdge48);
        java.lang.String str51 = rectangleEdge48.toString();
        double double52 = numberAxis25.lengthToJava2D((double) 255, rectangle2D35, rectangleEdge48);
        org.jfree.chart.LegendItemSource legendItemSource53 = null;
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle(legendItemSource53);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent55 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle54);
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle54.setVerticalAlignment(verticalAlignment56);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = legendTitle54.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = legendTitle54.getLegendItemGraphicEdge();
        double double60 = categoryAxis18.getCategoryEnd((int) '#', 4, rectangle2D35, rectangleEdge59);
        labelBlock2.setBounds(rectangle2D35);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "RectangleEdge.RIGHT" + "'", str51.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str1 = layer0.toString();
        java.lang.String str2 = layer0.toString();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Layer.FOREGROUND" + "'", str1.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Layer.FOREGROUND" + "'", str2.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10L, shape3, "", "ChartEntity: tooltip = ");
        java.lang.String str10 = categoryLabelEntity9.getShapeCoords();
        java.lang.String str11 = categoryLabelEntity9.toString();
        java.lang.String str12 = categoryLabelEntity9.toString();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot17.setDomainAxisLocation(axisLocation18, true);
        boolean boolean21 = categoryPlot17.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot17.setDatasetRenderingOrder(datasetRenderingOrder22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot17.getDataset();
        categoryPlot17.setAnchorValue((double) '#', false);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis30.setRange(1.0d, (double) (byte) 10);
        boolean boolean34 = numberAxis30.isVerticalTickLabels();
        double double35 = numberAxis30.getLowerBound();
        boolean boolean36 = legendItemCollection28.equals((java.lang.Object) numberAxis30);
        java.util.Iterator iterator37 = legendItemCollection28.iterator();
        categoryPlot17.setFixedLegendItems(legendItemCollection28);
        boolean boolean39 = categoryLabelEntity9.equals((java.lang.Object) categoryPlot17);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35" + "'", str10.equals("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = " + "'", str11.equals("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = " + "'", str12.equals("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = "));
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(iterator37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem4 = barRenderer1.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape5 = barRenderer1.getBaseShape();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) (short) 0, stroke7);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer1.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("", font15);
        labelBlock16.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock16.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color27 = java.awt.Color.orange;
        int int28 = color27.getBlue();
        labelBlock16.setPaint((java.awt.Paint) color27);
        barRenderer1.setBasePaint((java.awt.Paint) color27, false);
        java.awt.Color color32 = java.awt.Color.YELLOW;
        float[] floatArray36 = new float[] { 10, '#', (short) -1 };
        float[] floatArray37 = color32.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color27.getColorComponents(floatArray36);
        try {
            float[] floatArray39 = color0.getComponents(floatArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis12.setRange(1.0d, (double) (byte) 10);
        boolean boolean16 = numberAxis12.isVerticalTickLabels();
        double double17 = numberAxis12.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.RendererState rendererState21 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D22, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection27 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis29.setRange(1.0d, (double) (byte) 10);
        boolean boolean33 = numberAxis29.isVerticalTickLabels();
        boolean boolean34 = numberAxis29.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge35);
        axisCollection27.add((org.jfree.chart.axis.Axis) numberAxis29, rectangleEdge35);
        java.lang.String str38 = rectangleEdge35.toString();
        double double39 = numberAxis12.lengthToJava2D((double) 255, rectangle2D22, rectangleEdge35);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent42 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle41.setVerticalAlignment(verticalAlignment43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendTitle41.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = legendTitle41.getLegendItemGraphicEdge();
        double double47 = categoryAxis5.getCategoryEnd((int) '#', 4, rectangle2D22, rectangleEdge46);
        java.lang.String str48 = rectangleEdge46.toString();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleEdge.RIGHT" + "'", str38.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "RectangleEdge.LEFT" + "'", str48.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        int int31 = barRenderer0.getColumnCount();
        boolean boolean33 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 10);
        boolean boolean35 = barRenderer0.isSeriesVisible((int) (byte) 100);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer0.setBaseSeriesVisibleInLegend(false);
        java.awt.Shape shape8 = barRenderer0.getItemShape((int) ' ', (int) (byte) 0);
        java.awt.Paint paint10 = barRenderer0.lookupSeriesPaint((int) '4');
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = barRenderer0.getPlot();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setPositiveArrowVisible(true);
        org.jfree.data.Range range16 = categoryPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.axis.AxisCollection axisCollection17 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection17.add((org.jfree.chart.axis.Axis) numberAxis18, rectangleEdge19);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = numberAxis18.getStandardTickUnits();
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str30 = categoryAxis28.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot27.setDomainAxis(categoryAxis28);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis35.setRange(1.0d, (double) (byte) 10);
        boolean boolean39 = numberAxis35.isVerticalTickLabels();
        double double40 = numberAxis35.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        org.jfree.chart.renderer.RendererState rendererState44 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo43);
        java.awt.geom.Rectangle2D rectangle2D45 = plotRenderingInfo43.getDataArea();
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D45, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection50 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis52.setRange(1.0d, (double) (byte) 10);
        boolean boolean56 = numberAxis52.isVerticalTickLabels();
        boolean boolean57 = numberAxis52.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge58);
        axisCollection50.add((org.jfree.chart.axis.Axis) numberAxis52, rectangleEdge58);
        java.lang.String str61 = rectangleEdge58.toString();
        double double62 = numberAxis35.lengthToJava2D((double) 255, rectangle2D45, rectangleEdge58);
        org.jfree.chart.LegendItemSource legendItemSource63 = null;
        org.jfree.chart.title.LegendTitle legendTitle64 = new org.jfree.chart.title.LegendTitle(legendItemSource63);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent65 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle64);
        org.jfree.chart.util.VerticalAlignment verticalAlignment66 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle64.setVerticalAlignment(verticalAlignment66);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = legendTitle64.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = legendTitle64.getLegendItemGraphicEdge();
        double double70 = categoryAxis28.getCategoryEnd((int) '#', 4, rectangle2D45, rectangleEdge69);
        barRenderer0.drawRangeMarker(graphics2D7, categoryPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker22, rectangle2D45);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator74 = barRenderer0.getToolTipGenerator((int) '#', (int) (short) 0);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleEdge.RIGHT" + "'", str61.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment66);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNull(categoryToolTipGenerator74);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = categoryLabelPosition7.getCategoryAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = categoryLabelPosition7.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition7);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        projectInfo0.setName("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker6.getLabelTextAnchor();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setStroke(stroke10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker6.setLabelOffsetType(lengthAdjustmentType13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker6.setLabelTextAnchor(textAnchor15);
        org.jfree.chart.axis.CategoryTick categoryTick18 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100.0f, textBlock1, textBlockAnchor3, textAnchor15, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor19 = categoryTick18.getTextAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 0);
        double double2 = axisState1.getCursor();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.calculateLeftOutset((double) (byte) -1);
        blockContainer3.setMargin(rectangleInsets4);
        java.util.List list8 = blockContainer3.getBlocks();
        axisState1.setTicks(list8);
        double double10 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 3);
        double double3 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.block.BlockContainer blockContainer4 = null;
        legendTitle1.setWrapper(blockContainer4);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        boolean boolean20 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle15.getTextAlignment();
        java.lang.String str22 = textTitle15.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot15.getRenderer(0);
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 1.0f };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray26, numberArray28, numberArray30 };
        org.jfree.data.category.CategoryDataset categoryDataset32 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ClassContext", "null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", numberArray31);
        try {
            categoryPlot15.setDataset((-8388608), categoryDataset32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(categoryDataset32);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "org.jfree.data.general.DatasetChangeEvent[source= ]");
        boolean boolean7 = legendTitle1.equals((java.lang.Object) shape4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer8.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean14 = barRenderer8.getSeriesCreateEntities(15);
        boolean boolean15 = legendTitle1.equals((java.lang.Object) barRenderer8);
        barRenderer8.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 'a', 0.5f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.Object obj4 = legendItemEntity3.clone();
        java.lang.String str5 = legendItemEntity3.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str5.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("", font2);
        java.awt.Color color4 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font2, (java.awt.Paint) color4);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str7 = projectInfo6.toString();
        boolean boolean8 = textLine5.equals((java.lang.Object) str7);
        java.awt.Graphics2D graphics2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textLine5.calculateDimensions(graphics2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str7.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font5);
        java.awt.Paint paint7 = labelBlock6.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) '#', 0.0d, 0.0d, 0.0d, paint7);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        categoryPlot4.setAnchorValue((double) '#', false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent15);
        try {
            categoryPlot4.zoom(132.5d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        java.lang.String str2 = axisSpace0.toString();
        axisSpace0.setBottom(100.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean6 = axisSpace0.equals((java.lang.Object) rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        try {
            org.jfree.chart.plot.XYPlot xYPlot15 = jFreeChart14.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        java.awt.Paint paint20 = textTitle15.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesOutlinePaint(8);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.plot.Plot plot14 = categoryPlot13.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo21);
        plotRenderingInfo18.addSubplotInfo(plotRenderingInfo21);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        plotRenderingInfo21.addSubplotInfo(plotRenderingInfo25);
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot13.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo21, point2D27);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis30.setRange(1.0d, (double) (byte) 10);
        boolean boolean34 = numberAxis30.isVerticalTickLabels();
        boolean boolean35 = numberAxis30.isPositiveArrowVisible();
        java.lang.Object obj36 = numberAxis30.clone();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        barRenderer5.drawRangeGridline(graphics2D8, categoryPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis30, rectangle2D37, (double) (-1L));
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity45 = new org.jfree.chart.entity.TickLabelEntity(shape42, "", "hi!");
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity51 = new org.jfree.chart.entity.TickLabelEntity(shape48, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        tickLabelEntity45.setArea(shape48);
        barRenderer5.setBaseShape(shape48);
        java.awt.Paint paint55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        java.awt.Color color57 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int58 = color57.getTransparency();
        java.awt.Stroke stroke59 = null;
        java.awt.Shape shape61 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer62 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem65 = barRenderer62.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape66 = barRenderer62.getBaseShape();
        java.awt.Stroke stroke68 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer62.setSeriesOutlineStroke((int) (short) 0, stroke68);
        barRenderer62.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke73 = barRenderer62.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis76.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener80 = null;
        numberAxis76.removeChangeListener(axisChangeListener80);
        java.awt.Shape shape82 = numberAxis76.getRightArrow();
        barRenderer62.setSeriesShape(8, shape82, true);
        java.awt.Stroke stroke86 = barRenderer62.lookupSeriesStroke(0);
        java.awt.Paint paint87 = null;
        try {
            org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem(attributedString0, "ChartChangeEventType.NEW_DATASET", "", "CategoryLabelWidthType.RANGE", false, shape48, false, paint55, true, (java.awt.Paint) color57, stroke59, true, shape61, stroke86, paint87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNull(legendItem65);
        org.junit.Assert.assertNotNull(shape66);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(stroke73);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(stroke86);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        java.lang.String str2 = projectInfo0.toString();
        java.lang.String str3 = projectInfo0.toString();
        java.util.List list4 = projectInfo0.getContributors();
        projectInfo0.setCopyright("RectangleEdge.BOTTOM");
        org.jfree.chart.ui.Library library11 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "hi!");
        projectInfo0.addLibrary(library11);
        projectInfo0.setInfo("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str2.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str3.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.data.general.DatasetGroup datasetGroup2 = new org.jfree.data.general.DatasetGroup("");
        java.lang.String str3 = datasetGroup2.getID();
        java.lang.String str4 = datasetGroup2.getID();
        int int5 = numberTickUnit0.compareTo((java.lang.Object) str4);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj2 = keyedObjects0.getObject(0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        org.jfree.chart.renderer.RendererState rendererState6 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getPlotArea();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        double double9 = categoryItemRendererState8.getSeriesRunningTotal();
        double double10 = categoryItemRendererState8.getSeriesRunningTotal();
        keyedObjects0.addObject((java.lang.Comparable) (byte) 0, (java.lang.Object) categoryItemRendererState8);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        boolean boolean16 = textTitle15.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int int3 = java.awt.Color.HSBtoRGB((float) 10L, (float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        barRenderer0.setSeriesCreateEntities(192, (java.lang.Boolean) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = barRenderer0.getPlot();
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot14.setDomainAxisLocation(axisLocation15, true);
        boolean boolean18 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot14.setDatasetRenderingOrder(datasetRenderingOrder19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot14.getDataset();
        categoryPlot14.setAnchorValue((double) '#', false);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis27.setRange(1.0d, (double) (byte) 10);
        boolean boolean31 = numberAxis27.isVerticalTickLabels();
        double double32 = numberAxis27.getLowerBound();
        boolean boolean33 = legendItemCollection25.equals((java.lang.Object) numberAxis27);
        java.util.Iterator iterator34 = legendItemCollection25.iterator();
        categoryPlot14.setFixedLegendItems(legendItemCollection25);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor39 = valueMarker38.getLabelTextAnchor();
        java.awt.Stroke stroke40 = valueMarker38.getStroke();
        java.awt.Stroke stroke41 = valueMarker38.getOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis43.setRange(1.0d, (double) (byte) 10);
        boolean boolean47 = numberAxis43.isVerticalTickLabels();
        boolean boolean48 = numberAxis43.isPositiveArrowVisible();
        org.jfree.data.Range range49 = numberAxis43.getDefaultAutoRange();
        java.awt.Font font51 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font53 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock54 = new org.jfree.chart.block.LabelBlock("", font53);
        java.awt.Paint paint55 = labelBlock54.getPaint();
        org.jfree.chart.text.TextFragment textFragment57 = new org.jfree.chart.text.TextFragment("hi!", font51, paint55, 100.0f);
        java.awt.Paint paint58 = textFragment57.getPaint();
        numberAxis43.setTickMarkPaint(paint58);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets();
        double double62 = rectangleInsets60.calculateLeftOutset((double) (byte) -1);
        double double64 = rectangleInsets60.calculateRightInset((double) 100.0f);
        numberAxis43.setTickLabelInsets(rectangleInsets60);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo66);
        org.jfree.chart.renderer.RendererState rendererState68 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo67);
        java.awt.geom.Rectangle2D rectangle2D69 = plotRenderingInfo67.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets60.createOutsetRectangle(rectangle2D69, false, false);
        try {
            barRenderer0.drawRangeMarker(graphics2D9, categoryPlot14, valueAxis36, (org.jfree.chart.plot.Marker) valueMarker38, rectangle2D69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(iterator34);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D72);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) ' ');
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, true);
        java.awt.Stroke stroke9 = barRenderer0.getSeriesOutlineStroke(255);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) 'a');
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType12 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer13 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType12);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer13);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem19 = barRenderer16.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape20 = barRenderer16.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer16.setSeriesOutlineStroke((int) (short) 0, stroke22);
        barRenderer16.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke27 = barRenderer16.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis30.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener34 = null;
        numberAxis30.removeChangeListener(axisChangeListener34);
        java.awt.Shape shape36 = numberAxis30.getRightArrow();
        barRenderer16.setSeriesShape(8, shape36, true);
        java.awt.Paint paint41 = barRenderer16.getItemLabelPaint((int) ' ', 0);
        barRenderer0.setSeriesItemLabelPaint((int) ' ', paint41);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = null;
        try {
            barRenderer0.setSeriesURLGenerator((int) (byte) -1, categoryURLGenerator44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformType12);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(stroke27);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) (byte) -1);
        double double16 = rectangleInsets12.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets12.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        axisState24.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        axisState29.moveCursor(0.0d, rectangleEdge31);
        axisState24.moveCursor((double) 100L, rectangleEdge31);
        java.util.List list35 = categoryAxis5.refreshTicks(graphics2D10, axisState11, rectangle2D20, rectangleEdge31);
        float float36 = categoryAxis5.getTickMarkInsideLength();
        org.jfree.data.KeyedObjects2D keyedObjects2D37 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double40 = numberTickUnit39.getSize();
        java.lang.Object obj42 = keyedObjects2D37.getObject((java.lang.Comparable) numberTickUnit39, (java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis5.setTickLabelFont((java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ", font43);
        categoryAxis5.configure();
        categoryAxis5.setMaximumCategoryLabelLines(192);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        jFreeChart7.addLegend(legendTitle9);
        legendTitle9.setMargin((double) (-8388608), 10.0d, (double) 3, (double) 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        boolean boolean6 = barRenderer0.isSeriesVisibleInLegend((int) (byte) 100);
        java.awt.Shape shape8 = barRenderer0.getSeriesShape((int) '4');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(shape8);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        java.lang.Class class0 = null;
//        try {
//            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("RectangleEdge.LEFT", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setUpperBound((double) 8);
        numberAxis2.resizeRange((double) 100);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        java.awt.Font font8 = numberAxis2.getLabelFont();
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ", font8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getFirstTextFragment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            textFragment10.draw(graphics2D11, (float) (byte) 1, (float) 3, textAnchor14, (float) (short) 10, 0.5f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = categoryLabelPosition2.getCategoryAnchor();
        java.lang.String str4 = rectangleAnchor3.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str4.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getLicenceName();
        basicProjectInfo0.setInfo("Layer.FOREGROUND");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) '4');
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke11 = barRenderer0.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis14.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        numberAxis14.removeChangeListener(axisChangeListener18);
        java.awt.Shape shape20 = numberAxis14.getRightArrow();
        barRenderer0.setSeriesShape(8, shape20, true);
        boolean boolean25 = barRenderer0.getItemCreateEntity((int) (byte) 100, (int) (byte) 0);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        barRenderer0.setMaximumBarWidth((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator((int) 'a', 192);
        barRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem15 = barRenderer12.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape16 = barRenderer12.getBaseShape();
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer12.setSeriesOutlineStroke((int) (short) 0, stroke18);
        barRenderer12.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke23 = barRenderer12.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis26.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener30 = null;
        numberAxis26.removeChangeListener(axisChangeListener30);
        java.awt.Shape shape32 = numberAxis26.getRightArrow();
        barRenderer12.setSeriesShape(8, shape32, true);
        java.awt.Paint paint37 = barRenderer12.getItemLabelPaint((int) ' ', 0);
        barRenderer0.setBaseOutlinePaint(paint37);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(legendItem15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle2.setVerticalAlignment(verticalAlignment4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle2.getLegendItemGraphicLocation();
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle2, (java.lang.Object) textAnchor7);
        legendTitle2.setHeight((double) (byte) -1);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("RectangleEdge.RIGHT");
        java.awt.Image image3 = projectInfo0.getLogo();
        java.awt.Image image4 = null;
        projectInfo0.setLogo(image4);
        java.lang.String str6 = projectInfo0.getName();
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        barRenderer0.setSeriesCreateEntities(192, (java.lang.Boolean) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = barRenderer0.getPlot();
        barRenderer0.setMaximumBarWidth((double) (byte) 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryPlot6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        boolean boolean18 = categoryPlot15.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        java.lang.String str2 = projectInfo0.toString();
        java.lang.String str3 = projectInfo0.toString();
        java.util.List list4 = projectInfo0.getContributors();
        projectInfo0.setCopyright("RectangleEdge.BOTTOM");
        org.jfree.chart.ui.Library library11 = new org.jfree.chart.ui.Library("hi!", "", "hi!", "hi!");
        projectInfo0.addLibrary(library11);
        java.lang.String str13 = library11.getVersion();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str2.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str3.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("CategoryLabelWidthType.CATEGORY", graphics2D1, (float) '4', (float) 4, (double) 0, (float) (-16777216), (float) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        float float20 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot4.getInsets();
        java.lang.String str23 = rectangleInsets22.toString();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str23.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        java.awt.Graphics2D graphics2D16 = null;
        try {
            org.jfree.chart.util.Size2D size2D17 = textTitle15.arrange(graphics2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font4);
        java.awt.Paint paint6 = labelBlock5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, paint6, 100.0f);
        java.awt.Color color9 = java.awt.Color.cyan;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color9, (float) 500);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.TickType tickType13 = null;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick(tickType13, 0.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", textAnchor16, textAnchor17, 0.0d);
        java.lang.Number number20 = numberTick19.getNumber();
        org.jfree.chart.text.TextAnchor textAnchor21 = numberTick19.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor22 = numberTick19.getRotationAnchor();
        try {
            float float23 = textFragment11.calculateBaselineOffset(graphics2D12, textAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        java.awt.Stroke stroke17 = categoryPlot4.getRangeGridlineStroke();
        boolean boolean18 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setCopyright("RectangleEdge.RIGHT");
        java.awt.Image image3 = projectInfo0.getLogo();
        java.awt.Image image4 = null;
        projectInfo0.setLogo(image4);
        projectInfo0.setInfo("");
        org.junit.Assert.assertNull(image3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        java.lang.Object obj7 = numberAxis1.clone();
        java.lang.Object obj8 = numberAxis1.clone();
        boolean boolean9 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, true);
        java.awt.Stroke stroke9 = barRenderer0.getSeriesOutlineStroke(255);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) 'a');
        double double12 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        jFreeChart7.addLegend(legendTitle9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            jFreeChart7.handleClick((int) (short) 0, (-16777216), chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        boolean boolean4 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", textAnchor3, textAnchor4, 0.0d);
        java.lang.Number number7 = numberTick6.getNumber();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick6.getTextAnchor();
        java.lang.Number number9 = numberTick6.getNumber();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.0d + "'", number9.equals(0.0d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker6.getLabelTextAnchor();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setStroke(stroke10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker6.setLabelOffsetType(lengthAdjustmentType13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker6.setLabelTextAnchor(textAnchor15);
        org.jfree.chart.axis.CategoryTick categoryTick18 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100.0f, textBlock1, textBlockAnchor3, textAnchor15, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor19 = categoryTick18.getRotationAnchor();
        java.lang.String str20 = categoryTick18.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle1.setVerticalAlignment(verticalAlignment3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicLocation();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot12.setDomainAxisLocation(axisLocation13, true);
        boolean boolean16 = categoryPlot12.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot12.setDatasetRenderingOrder(datasetRenderingOrder17);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("ThreadContext", font7, (org.jfree.chart.plot.Plot) categoryPlot12, true);
        java.awt.Color color21 = java.awt.Color.orange;
        int int22 = color21.getBlue();
        jFreeChart20.setBackgroundPaint((java.awt.Paint) color21);
        legendTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart20);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart7.setBorderVisible(false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            jFreeChart7.handleClick((int) (short) 0, 0, chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        labelBlock2.setToolTipText("Layer.FOREGROUND");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot9.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.chart.renderer.RendererState rendererState15 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo17);
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        plotRenderingInfo17.addSubplotInfo(plotRenderingInfo21);
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot9.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo17, point2D23);
        float float25 = categoryPlot9.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem29 = barRenderer26.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape30 = barRenderer26.getBaseShape();
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer26.setSeriesOutlineStroke((int) (short) 0, stroke32);
        barRenderer26.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer26.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("", font40);
        labelBlock41.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock41.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color52 = java.awt.Color.orange;
        int int53 = color52.getBlue();
        labelBlock41.setPaint((java.awt.Paint) color52);
        barRenderer26.setBasePaint((java.awt.Paint) color52, false);
        categoryPlot9.setDomainGridlinePaint((java.awt.Paint) color52);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        java.awt.Font font60 = barRenderer0.getSeriesItemLabelFont((int) (short) -1);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNull(font60);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        boolean boolean20 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle15.getTextAlignment();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.Range range23 = null;
        org.jfree.data.Range range24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(range23, range24);
        org.jfree.data.Range range26 = rectangleConstraint25.getWidthRange();
        org.jfree.data.Range range27 = rectangleConstraint25.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint25.toFixedHeight((double) '#');
        try {
            org.jfree.chart.util.Size2D size2D30 = textTitle15.arrange(graphics2D22, rectangleConstraint25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        java.lang.String str2 = basicProjectInfo0.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        basicProjectInfo4.setLicenceName("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo4);
        org.jfree.chart.ui.Library[] libraryArray9 = basicProjectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis19.setRange(1.0d, (double) (byte) 10);
        boolean boolean23 = numberAxis19.isVerticalTickLabels();
        boolean boolean24 = numberAxis19.isPositiveArrowVisible();
        org.jfree.data.Range range25 = numberAxis19.getDefaultAutoRange();
        numberAxis1.setDefaultAutoRange(range25);
        numberAxis1.setInverted(false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        java.util.List list4 = axisCollection0.getAxesAtTop();
        java.util.List list5 = axisCollection0.getAxesAtBottom();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis7.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        numberAxis7.removeChangeListener(axisChangeListener11);
        org.jfree.chart.LegendItemSource legendItemSource13 = null;
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle(legendItemSource13);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle14);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape17, "org.jfree.data.general.DatasetChangeEvent[source= ]");
        boolean boolean20 = legendTitle14.equals((java.lang.Object) shape17);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle14.getLegendItemGraphicEdge();
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis7, rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot15.getRenderer(0);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot15.setDataset(categoryDataset22);
        boolean boolean24 = categoryPlot15.isRangeCrosshairLockedOnData();
        java.awt.Font font27 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("", font29);
        java.awt.Paint paint31 = labelBlock30.getPaint();
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("hi!", font27, paint31, 100.0f);
        java.awt.Paint paint34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock35 = org.jfree.chart.text.TextUtilities.createTextBlock("", font27, paint34);
        categoryPlot15.setNoDataMessageFont(font27);
        boolean boolean37 = categoryPlot15.isSubplot();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(textBlock35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        java.awt.Stroke stroke12 = categoryPlot4.getOutlineStroke();
        java.util.List list13 = categoryPlot4.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot4.getDomainAxisEdge((int) (byte) 100);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color5 = java.awt.Color.YELLOW;
        float[] floatArray9 = new float[] { 10, '#', (short) -1 };
        float[] floatArray10 = color5.getRGBColorComponents(floatArray9);
        float[] floatArray11 = java.awt.Color.RGBtoHSB((int) '#', 10, 0, floatArray9);
        try {
            float[] floatArray12 = color0.getComponents(colorSpace1, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        java.awt.Stroke stroke17 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot4.getRangeAxisLocation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        numberAxis1.removeChangeListener(axisChangeListener5);
        java.awt.Shape shape7 = numberAxis1.getRightArrow();
        boolean boolean8 = numberAxis1.isPositiveArrowVisible();
        try {
            numberAxis1.zoomRange(2.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (19.0) <= upper (-8.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis21.setUpperBound((double) 8);
        numberAxis21.resizeRange((double) 100);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        java.awt.Font font27 = numberAxis21.getLabelFont();
        java.awt.Paint paint28 = numberAxis21.getTickMarkPaint();
        org.jfree.data.Range range29 = categoryPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot15.getDomainAxisForDataset((-16777216));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNull(categoryAxis31);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        java.lang.Object obj4 = legendTitle2.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor5);
        java.awt.Paint paint7 = null;
        legendTitle2.setBackgroundPaint(paint7);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = legendTitle2.getVerticalAlignment();
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment9, 100.0d, (double) (-1.0f));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setRange(1.0d, (double) (byte) 10);
        boolean boolean6 = numberAxis2.isVerticalTickLabels();
        boolean boolean7 = numberAxis2.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge8);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge8);
        org.jfree.chart.plot.Plot plot11 = null;
        numberAxis2.setPlot(plot11);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets7.createOutsetRectangle(rectangle2D15, true, true);
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        org.jfree.chart.renderer.RendererState rendererState24 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo23);
        boolean boolean25 = axisLocation21.equals((java.lang.Object) plotRenderingInfo23);
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot4.zoomRangeAxes((double) (byte) -1, plotRenderingInfo23, point2D26);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str10 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot7.setDomainAxis(categoryAxis8);
        double double12 = categoryAxis8.getCategoryMargin();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateLeftOutset((double) (byte) -1);
        double double19 = rectangleInsets15.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.RendererState rendererState22 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets15.createOutsetRectangle(rectangle2D23, true, true);
        org.jfree.chart.axis.AxisState axisState27 = new org.jfree.chart.axis.AxisState();
        axisState27.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState32 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge34);
        axisState32.moveCursor(0.0d, rectangleEdge34);
        axisState27.moveCursor((double) 100L, rectangleEdge34);
        java.util.List list38 = categoryAxis8.refreshTicks(graphics2D13, axisState14, rectangle2D23, rectangleEdge34);
        org.jfree.chart.axis.AxisState axisState40 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean43 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge42);
        axisState40.moveCursor(0.0d, rectangleEdge42);
        java.util.List list45 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D23, rectangleEdge42);
        categoryAxis0.setLowerMargin((double) 0.0f);
        java.awt.Font font49 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 0.2d);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT", "LegendItemEntity: seriesKey=null, dataset=null");
        double double53 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle1.getItemContainer();
        java.lang.String str5 = legendTitle1.getID();
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.setMax(35.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot6.getDataset();
        categoryPlot6.setAnchorValue((double) '#', false);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis19.setRange(1.0d, (double) (byte) 10);
        boolean boolean23 = numberAxis19.isVerticalTickLabels();
        double double24 = numberAxis19.getLowerBound();
        boolean boolean25 = legendItemCollection17.equals((java.lang.Object) numberAxis19);
        java.util.Iterator iterator26 = legendItemCollection17.iterator();
        categoryPlot6.setFixedLegendItems(legendItemCollection17);
        java.lang.Object obj28 = categoryPlot6.clone();
        boolean boolean29 = borderArrangement0.equals((java.lang.Object) categoryPlot6);
        org.jfree.chart.block.BlockContainer blockContainer30 = null;
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.data.Range range32 = null;
        org.jfree.data.Range range33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = new org.jfree.chart.block.RectangleConstraint(range32, range33);
        org.jfree.data.Range range35 = rectangleConstraint34.getWidthRange();
        org.jfree.data.Range range36 = rectangleConstraint34.getWidthRange();
        java.lang.String str37 = rectangleConstraint34.toString();
        try {
            org.jfree.chart.util.Size2D size2D38 = borderArrangement0.arrange(blockContainer30, graphics2D31, rectangleConstraint34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(iterator26);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str37.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.plot.Plot plot6 = categoryPlot5.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        org.jfree.chart.renderer.RendererState rendererState11 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo13);
        plotRenderingInfo10.addSubplotInfo(plotRenderingInfo13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot5.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo13, point2D19);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot5.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        double double24 = axisSpace23.getLeft();
        double double25 = axisSpace23.getTop();
        java.lang.Object obj26 = axisSpace23.clone();
        boolean boolean27 = plotOrientation21.equals((java.lang.Object) axisSpace23);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("RectangleEdge.RIGHT");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("");
        java.lang.Object obj6 = jFreeChartResources0.handleGetObject("ThreadContext");
        java.util.Locale locale7 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(locale7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("TextBlockAnchor.TOP_LEFT", "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ", "RectangleEdge.RIGHT", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        java.lang.String str5 = library4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.RIGHT" + "'", str5.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.util.List list2 = keyedObjects2D0.getRowKeys();
        try {
            keyedObjects2D0.removeRow((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = categoryLabelPositions1.getLabelPosition(rectangleEdge2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge4);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = categoryLabelPositions1.getLabelPosition(rectangleEdge4);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = categoryLabelPosition6.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str9 = categoryLabelWidthType8.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor7, categoryLabelWidthType8, (float) 3);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement13 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape18, "", "hi!");
        centerArrangement13.add((org.jfree.chart.block.Block) labelBlock15, (java.lang.Object) "");
        java.lang.Object obj23 = null;
        flowArrangement12.add((org.jfree.chart.block.Block) labelBlock15, obj23);
        flowArrangement12.clear();
        org.jfree.chart.block.BlockContainer blockContainer26 = new org.jfree.chart.block.BlockContainer();
        java.util.List list27 = blockContainer26.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame28 = blockContainer26.getFrame();
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("CategoryLabelWidthType.CATEGORY");
        flowArrangement12.add((org.jfree.chart.block.Block) blockContainer26, (java.lang.Object) textFragment30);
        boolean boolean32 = categoryLabelWidthType8.equals((java.lang.Object) blockContainer26);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(categoryLabelPosition3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str9.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(blockFrame28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.plot.Plot plot6 = categoryPlot5.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        org.jfree.chart.renderer.RendererState rendererState11 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo13);
        plotRenderingInfo10.addSubplotInfo(plotRenderingInfo13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot5.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo13, point2D19);
        float float21 = categoryPlot5.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem25 = barRenderer22.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape26 = barRenderer22.getBaseShape();
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer22.setSeriesOutlineStroke((int) (short) 0, stroke28);
        barRenderer22.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = barRenderer22.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("", font36);
        labelBlock37.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock37.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color48 = java.awt.Color.orange;
        int int49 = color48.getBlue();
        labelBlock37.setPaint((java.awt.Paint) color48);
        barRenderer22.setBasePaint((java.awt.Paint) color48, false);
        categoryPlot5.setDomainGridlinePaint((java.awt.Paint) color48);
        org.jfree.chart.plot.PlotOrientation plotOrientation54 = categoryPlot5.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNull(legendItem25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(plotOrientation54);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font8);
        java.awt.Color color10 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font8, (java.awt.Paint) color10);
        numberAxis2.setTickLabelFont(font8);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str20 = categoryAxis18.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot17.setDomainAxis(categoryAxis18);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot17.setDataset(10, categoryDataset23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ", font8, (org.jfree.chart.plot.Plot) categoryPlot17, true);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisSpace axisSpace30 = new org.jfree.chart.axis.AxisSpace();
        double double31 = axisSpace30.getLeft();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.RendererState rendererState34 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D35, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection40 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection40.add((org.jfree.chart.axis.Axis) numberAxis41, rectangleEdge42);
        java.awt.geom.Rectangle2D rectangle2D44 = axisSpace30.reserved(rectangle2D35, rectangleEdge42);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        try {
            jFreeChart28.draw(graphics2D29, rectangle2D44, chartRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(rectangle2D44);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot8.setDomainAxisLocation(axisLocation9, true);
        boolean boolean12 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot8.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) categoryPlot8, true);
        java.awt.Color color17 = java.awt.Color.orange;
        int int18 = color17.getBlue();
        jFreeChart16.setBackgroundPaint((java.awt.Paint) color17);
        legendTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ChartChangeEventType.NEW_DATASET", graphics2D1, 100.0f, 1.0f, (double) 2, (float) (short) 10, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 2.0f);
        valueMarker1.setLabel("RangeType.FULL");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        labelBlock7.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color13 = java.awt.Color.YELLOW;
        int int14 = color13.getAlpha();
        labelBlock7.setPaint((java.awt.Paint) color13);
        labelBlock7.setURLText("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets18.calculateLeftOutset((double) (byte) -1);
        double double22 = rectangleInsets18.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        org.jfree.chart.renderer.RendererState rendererState25 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo24.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D29 = rectangleInsets18.createOutsetRectangle(rectangle2D26, true, true);
        labelBlock7.setPadding(rectangleInsets18);
        valueMarker1.setLabelOffset(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor9 = valueMarker8.getLabelTextAnchor();
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker8.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker8.setStroke(stroke12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = valueMarker8.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType14);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D5);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D5, "LegendItemEntity: seriesKey=null, dataset=null", "CategoryLabelWidthType.RANGE");
        chartEntity19.setToolTipText("TextBlockAnchor.TOP_CENTER");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker6.getLabelTextAnchor();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setStroke(stroke10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker6.setLabelOffsetType(lengthAdjustmentType13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker6.setLabelTextAnchor(textAnchor15);
        org.jfree.chart.axis.CategoryTick categoryTick18 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100.0f, textBlock1, textBlockAnchor3, textAnchor15, (double) 0.0f);
        java.lang.Comparable comparable19 = categoryTick18.getCategory();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + 100.0f + "'", comparable19.equals(100.0f));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot8.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        plotRenderingInfo16.addSubplotInfo(plotRenderingInfo20);
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot8.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo16, point2D22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis25.setRange(1.0d, (double) (byte) 10);
        boolean boolean29 = numberAxis25.isVerticalTickLabels();
        boolean boolean30 = numberAxis25.isPositiveArrowVisible();
        java.lang.Object obj31 = numberAxis25.clone();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        barRenderer0.drawRangeGridline(graphics2D3, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis25, rectangle2D32, (double) (-1L));
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = null;
        org.jfree.chart.util.Size2D size2D39 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition44 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor42, textBlockAnchor43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = categoryLabelPosition44.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D46 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D39, (double) (byte) 0, 0.0d, rectangleAnchor45);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis48.setUpperBound((double) 8);
        numberAxis48.resizeRange((double) 100);
        org.jfree.data.Range range53 = numberAxis48.getDefaultAutoRange();
        numberAxis48.setLowerBound((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = new org.jfree.chart.util.RectangleInsets();
        double double58 = rectangleInsets56.calculateLeftOutset((double) (byte) -1);
        double double60 = rectangleInsets56.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo61);
        org.jfree.chart.renderer.RendererState rendererState63 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo62);
        java.awt.geom.Rectangle2D rectangle2D64 = plotRenderingInfo62.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets56.createOutsetRectangle(rectangle2D64, true, true);
        numberAxis48.setRightArrow((java.awt.Shape) rectangle2D67);
        boolean boolean69 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D46, rectangle2D67);
        try {
            barRenderer0.drawOutline(graphics2D35, categoryPlot36, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        boolean boolean20 = textTitle15.getExpandToFitSpace();
        java.lang.Object obj21 = textTitle15.clone();
        java.lang.Object obj22 = textTitle15.clone();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.data.Range range24 = null;
        org.jfree.data.Range range25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range24, range25);
        double double27 = rectangleConstraint26.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D28 = textTitle15.arrange(graphics2D23, rectangleConstraint26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo4);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot11.setDomainAxisLocation(axisLocation12, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getPlotArea();
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot11.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo18, point2D21);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = plotRenderingInfo18.getOwner();
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(rectangle2D20);
        org.junit.Assert.assertNull(chartRenderingInfo24);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        numberAxis1.setRangeAboutValue((double) 1L, (double) (byte) 1);
        numberAxis1.setTickMarkOutsideLength((float) ' ');
        numberAxis1.setNegativeArrowVisible(false);
        float float13 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.shrink(rectangle2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        float float20 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot4.getFixedLegendItems();
        java.awt.Paint paint22 = categoryPlot4.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        java.lang.Comparable comparable2 = null;
        keyedObjects2D0.removeColumn(comparable2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int5 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) numberTickUnit4);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        categoryPlot4.configureDomainAxes();
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.entity.EntityCollection entityCollection3 = rendererState2.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection4 = rendererState2.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection5 = rendererState2.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection3);
        org.junit.Assert.assertNull(entityCollection4);
        org.junit.Assert.assertNull(entityCollection5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis4.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("", font10);
        java.awt.Color color12 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font10, (java.awt.Paint) color12);
        numberAxis4.setTickLabelFont(font10);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("org.jfree.data.general.DatasetChangeEvent[source= ]", font10, (java.awt.Paint) color15, (float) 0);
        textLine1.addFragment(textFragment17);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            textFragment17.draw(graphics2D19, (float) (short) 100, (float) (byte) -1, textAnchor22, (float) (-8388608), (float) (-8388608), (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem19 = barRenderer16.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer16.setBaseSeriesVisibleInLegend(false);
        java.awt.Stroke stroke23 = barRenderer16.lookupSeriesOutlineStroke(0);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = barRenderer16.getSeriesURLGenerator((int) (short) 10);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(categoryURLGenerator26);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot4.setDataset(10, categoryDataset10);
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection13 = categoryPlot4.getDomainMarkers(layer12);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = java.awt.Color.getColor("ChartEntity: tooltip = ", color1);
        java.awt.image.ColorModel colorModel3 = null;
        java.awt.Rectangle rectangle4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis6.setUpperBound((double) 8);
        numberAxis6.resizeRange((double) 100);
        org.jfree.data.Range range11 = numberAxis6.getDefaultAutoRange();
        numberAxis6.setLowerBound((double) (-1.0f));
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets();
        double double16 = rectangleInsets14.calculateLeftOutset((double) (byte) -1);
        double double18 = rectangleInsets14.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.RendererState rendererState21 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets14.createOutsetRectangle(rectangle2D22, true, true);
        numberAxis6.setRightArrow((java.awt.Shape) rectangle2D25);
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color1.createContext(colorModel3, rectangle4, rectangle2D25, affineTransform27, renderingHints28);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(paintContext29);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, (-0.25d), 54.0d, (-0.25d));
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis6.setRange(1.0d, (double) (byte) 10);
        boolean boolean10 = numberAxis6.isVerticalTickLabels();
        numberAxis6.setLabel("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        boolean boolean13 = blockBorder4.equals((java.lang.Object) numberAxis6);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str15 = axisLocation14.toString();
        boolean boolean16 = numberAxis6.equals((java.lang.Object) axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str15.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem4 = barRenderer1.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape5 = barRenderer1.getBaseShape();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer1.setSeriesOutlineStroke((int) (short) 0, stroke7);
        barRenderer1.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer1.getNegativeItemLabelPositionFallback();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = barRenderer1.getLegendItems();
        int int13 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer1);
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        numberAxis1.setAxisLineVisible(false);
        org.jfree.data.KeyedObjects2D keyedObjects2D7 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double10 = numberTickUnit9.getSize();
        java.lang.Object obj12 = keyedObjects2D7.getObject((java.lang.Comparable) numberTickUnit9, (java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        numberAxis1.setTickUnit(numberTickUnit9);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        org.jfree.chart.plot.Plot plot6 = categoryPlot5.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        org.jfree.chart.renderer.RendererState rendererState11 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState14 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo13);
        plotRenderingInfo10.addSubplotInfo(plotRenderingInfo13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot5.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo13, point2D19);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = categoryPlot5.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation21);
        java.lang.String str23 = rectangleEdge22.toString();
        boolean boolean24 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge22);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleEdge.RIGHT" + "'", str23.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 'a', 0.5f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator4 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator5 = null;
        java.lang.String str6 = legendItemEntity3.getImageMapAreaTag(toolTipTagFragmentGenerator4, uRLTagFragmentGenerator5);
        java.lang.String str7 = legendItemEntity3.getShapeType();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem11 = barRenderer8.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer8.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color13, true);
        java.awt.Color color16 = java.awt.Color.cyan;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        float[] floatArray18 = null;
        float[] floatArray19 = color13.getComponents(colorSpace17, floatArray18);
        boolean boolean20 = legendItemEntity3.equals((java.lang.Object) floatArray19);
        org.jfree.data.general.Dataset dataset21 = legendItemEntity3.getDataset();
        java.lang.String str22 = legendItemEntity3.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "poly" + "'", str7.equals("poly"));
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(dataset21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str22.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getRed();
        int int2 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        java.util.List list3 = blockContainer2.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame4 = blockContainer2.getFrame();
        java.util.List list5 = blockContainer2.getBlocks();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = borderArrangement0.arrange(blockContainer2, graphics2D6, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        numberAxis1.removeChangeListener(axisChangeListener5);
        java.awt.Shape shape7 = numberAxis1.getRightArrow();
        boolean boolean8 = numberAxis1.isAutoTickUnitSelection();
        numberAxis1.resizeRange(271.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        boolean boolean15 = jFreeChart14.isBorderVisible();
        org.jfree.chart.block.CenterArrangement centerArrangement16 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent19 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle18);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle18.setVerticalAlignment(verticalAlignment20);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = legendTitle18.getLegendItemGraphicLocation();
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        centerArrangement16.add((org.jfree.chart.block.Block) legendTitle18, (java.lang.Object) textAnchor23);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        legendTitle18.setHorizontalAlignment(horizontalAlignment25);
        jFreeChart14.addLegend(legendTitle18);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = legendTitle18.getPosition();
        double double29 = legendTitle18.getContentXOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker1, jFreeChart5, (int) (byte) 0, (int) (byte) 100);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot15.setDomainAxisLocation(axisLocation16, true);
        boolean boolean19 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) categoryPlot15, true);
        jFreeChart23.clearSubtitles();
        chartProgressEvent8.setChart(jFreeChart23);
        jFreeChart23.setTitle("HorizontalAlignment.CENTER");
        org.jfree.chart.title.LegendTitle legendTitle28 = null;
        try {
            jFreeChart23.addLegend(legendTitle28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, true);
        java.awt.Stroke stroke9 = barRenderer0.getSeriesOutlineStroke(255);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) 'a');
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType12 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer13 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType12);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer13);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem19 = barRenderer16.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape20 = barRenderer16.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer16.setSeriesOutlineStroke((int) (short) 0, stroke22);
        barRenderer16.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke27 = barRenderer16.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis30.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener34 = null;
        numberAxis30.removeChangeListener(axisChangeListener34);
        java.awt.Shape shape36 = numberAxis30.getRightArrow();
        barRenderer16.setSeriesShape(8, shape36, true);
        java.awt.Paint paint41 = barRenderer16.getItemLabelPaint((int) ' ', 0);
        barRenderer0.setSeriesItemLabelPaint((int) ' ', paint41);
        boolean boolean44 = barRenderer0.isSeriesVisibleInLegend(0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformType12);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(stroke27);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(drawingSupplier45);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean6 = barRenderer0.getSeriesCreateEntities(15);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setSeriesURLGenerator(3, categoryURLGenerator8);
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        numberAxis1.setTickMarkInsideLength((float) (short) 0);
        java.awt.Color color12 = java.awt.Color.MAGENTA;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str16 = rectangleInsets15.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType21 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor24 = valueMarker23.getLabelTextAnchor();
        java.awt.Stroke stroke25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker23.setOutlineStroke(stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker23.setStroke(stroke27);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = valueMarker23.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets15.createAdjustedRectangle(rectangle2D20, lengthAdjustmentType21, lengthAdjustmentType29);
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color12.createContext(colorModel13, rectangle14, rectangle2D30, affineTransform31, renderingHints32);
        org.jfree.chart.axis.AxisCollection axisCollection34 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis36.setRange(1.0d, (double) (byte) 10);
        boolean boolean40 = numberAxis36.isVerticalTickLabels();
        boolean boolean41 = numberAxis36.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge42);
        axisCollection34.add((org.jfree.chart.axis.Axis) numberAxis36, rectangleEdge42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge42);
        try {
            double double46 = numberAxis1.lengthToJava2D(0.05d, (java.awt.geom.Rectangle2D) rectangle14, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str16.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType21);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint(10);
        barRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font4);
        java.awt.Paint paint6 = labelBlock5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, paint6, 100.0f);
        java.awt.Color color9 = java.awt.Color.cyan;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color9, (float) 500);
        java.lang.String str12 = textFragment11.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font4);
        java.awt.Paint paint6 = labelBlock5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, paint6, 100.0f);
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock10.calculateDimensions(graphics2D11);
        size2D12.setHeight((double) 3);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        boolean boolean2 = horizontalAlignment0.equals((java.lang.Object) textBlockAnchor1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment3, (double) 192, 100.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot15.getRenderer(0);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot15.setDataset(categoryDataset22);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot15.getFixedLegendItems();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str26 = layer25.toString();
        java.util.Collection collection27 = categoryPlot15.getDomainMarkers(layer25);
        org.jfree.chart.axis.AxisSpace axisSpace28 = categoryPlot15.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categoryItemRenderer21);
        org.junit.Assert.assertNull(legendItemCollection24);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Layer.FOREGROUND" + "'", str26.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(axisSpace28);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getPlotArea();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        double double5 = categoryItemRendererState4.getSeriesRunningTotal();
        double double6 = categoryItemRendererState4.getSeriesRunningTotal();
        categoryItemRendererState4.setBarWidth((double) 0.0f);
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        boolean boolean11 = numberAxis1.isAutoRange();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart7.setAntiAlias(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean11 = jFreeChart7.equals((java.lang.Object) itemLabelAnchor10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.axis.AxisCollection axisCollection5 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection5.add((org.jfree.chart.axis.Axis) numberAxis6, rectangleEdge7);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis6.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        numberAxis6.setUpArrow(shape18);
        double double20 = numberAxis6.getLabelAngle();
        numberAxis6.setFixedDimension((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis24.setUpperBound((double) 8);
        numberAxis24.resizeRange((double) 100);
        org.jfree.data.Range range29 = numberAxis24.getDefaultAutoRange();
        numberAxis6.setDefaultAutoRange(range29);
        double double31 = range29.getLength();
        numberAxis1.setRangeWithMargins(range29, false, false);
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot5.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(categoryAnchor8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot4.setDataset(10, categoryDataset10);
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryPlot4.equals(obj12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot4.getRangeAxisLocation(3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font11);
        java.awt.Paint paint13 = labelBlock12.getPaint();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font9, paint13, 100.0f);
        java.awt.Paint paint16 = textFragment15.getPaint();
        numberAxis1.setTickMarkPaint(paint16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets18.calculateLeftOutset((double) (byte) -1);
        double double22 = rectangleInsets18.calculateRightInset((double) 100.0f);
        numberAxis1.setTickLabelInsets(rectangleInsets18);
        boolean boolean24 = numberAxis1.isVisible();
        java.text.NumberFormat numberFormat25 = null;
        numberAxis1.setNumberFormatOverride(numberFormat25);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        java.awt.Stroke stroke17 = categoryPlot4.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot4.getDomainAxis();
        double double19 = categoryPlot4.getAnchorValue();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.awt.Color color3 = java.awt.Color.getHSBColor((-1.0f), 0.0f, (float) (byte) 0);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 10L, shape3, "", "ChartEntity: tooltip = ");
        java.lang.String str10 = categoryLabelEntity9.getShapeCoords();
        java.lang.String str11 = categoryLabelEntity9.toString();
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryLabelEntity9.equals(obj12);
        java.lang.String str14 = categoryLabelEntity9.getToolTipText();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35" + "'", str10.equals("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = " + "'", str11.equals("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (-3.0d), 0.0d, (double) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets5.createOutsetRectangle(rectangle2D13, true, true);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor19 = valueMarker18.getLabelTextAnchor();
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker18.setOutlineStroke(stroke20);
        java.awt.Stroke stroke22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker18.setStroke(stroke22);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = valueMarker18.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets4.createAdjustedRectangle(rectangle2D16, lengthAdjustmentType24, lengthAdjustmentType25);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint(10);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color16 = java.awt.Color.getColor("ChartEntity: tooltip = ", color15);
        barRenderer0.setSeriesPaint((int) ' ', (java.awt.Paint) color16);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.data.Range range6 = null;
        try {
            numberAxis1.setRange(range6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightOutset(0.0d);
        double double5 = rectangleInsets0.getTop();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str7 = rectangleInsets6.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo9.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor15 = valueMarker14.getLabelTextAnchor();
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker14.setOutlineStroke(stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker14.setStroke(stroke18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = valueMarker14.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets6.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType12, lengthAdjustmentType20);
        java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets0.createOutsetRectangle(rectangle2D11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str7.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray5 = null;
        java.awt.Stroke[] strokeArray6 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray4, strokeArray5, strokeArray6, shapeArray7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str10 = rectangleInsets9.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor18 = valueMarker17.getLabelTextAnchor();
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker17.setOutlineStroke(stroke19);
        java.awt.Stroke stroke21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker17.setStroke(stroke21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = valueMarker17.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets9.createAdjustedRectangle(rectangle2D14, lengthAdjustmentType15, lengthAdjustmentType23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot29.setDomainAxisLocation(axisLocation30, true);
        boolean boolean33 = categoryPlot29.getDrawSharedDomainAxis();
        int int34 = categoryPlot29.getBackgroundImageAlignment();
        java.awt.Stroke stroke35 = categoryPlot29.getRangeGridlineStroke();
        boolean boolean36 = lengthAdjustmentType23.equals((java.lang.Object) stroke35);
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem40 = barRenderer37.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer37.setBaseSeriesVisibleInLegend(false);
        java.awt.Shape shape45 = barRenderer37.getItemShape((int) ' ', (int) (byte) 0);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator46 = null;
        barRenderer37.setBaseURLGenerator(categoryURLGenerator46, false);
        java.awt.Stroke stroke49 = barRenderer37.getBaseStroke();
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor52 = valueMarker51.getLabelTextAnchor();
        java.awt.Stroke stroke53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker51.setOutlineStroke(stroke53);
        org.jfree.chart.JFreeChart jFreeChart55 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent58 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker51, jFreeChart55, (int) (byte) 0, (int) (byte) 100);
        java.awt.Stroke stroke59 = valueMarker51.getStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint61 = defaultDrawingSupplier60.getNextOutlinePaint();
        java.awt.Stroke stroke62 = defaultDrawingSupplier60.getNextOutlineStroke();
        java.awt.Stroke[] strokeArray63 = new java.awt.Stroke[] { stroke35, stroke49, stroke59, stroke62 };
        java.awt.Shape[] shapeArray64 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier65 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray5, strokeArray63, shapeArray64);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(strokeArray6);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str10.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 15 + "'", int34 == 15);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(legendItem40);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(textAnchor52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(strokeArray63);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) (-1.0f));
        columnArrangement4.clear();
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        numberAxis1.setRangeAboutValue((double) 1L, (double) (byte) 1);
        numberAxis1.setTickMarkOutsideLength((float) ' ');
        numberAxis1.setAutoRange(false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        float float20 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem24 = barRenderer21.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape25 = barRenderer21.getBaseShape();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer21.setSeriesOutlineStroke((int) (short) 0, stroke27);
        barRenderer21.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer21.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("", font35);
        labelBlock36.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock36.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color47 = java.awt.Color.orange;
        int int48 = color47.getBlue();
        labelBlock36.setPaint((java.awt.Paint) color47);
        barRenderer21.setBasePaint((java.awt.Paint) color47, false);
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color47);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor54 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str55 = categoryAnchor54.toString();
        categoryPlot4.setDomainGridlinePosition(categoryAnchor54);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent59 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle58);
        java.lang.Object obj60 = legendTitle58.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle58.setLegendItemGraphicLocation(rectangleAnchor61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment63 = legendTitle58.getHorizontalAlignment();
        boolean boolean64 = categoryAnchor54.equals((java.lang.Object) legendTitle58);
        java.awt.Font font71 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock72 = new org.jfree.chart.block.LabelBlock("", font71);
        java.awt.Color color73 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine74 = new org.jfree.chart.text.TextLine("hi!", font71, (java.awt.Paint) color73);
        org.jfree.chart.block.BlockBorder blockBorder75 = new org.jfree.chart.block.BlockBorder(1.0d, (double) (-1.0f), (double) 0, 100.0d, (java.awt.Paint) color73);
        legendTitle58.setFrame((org.jfree.chart.block.BlockFrame) blockBorder75);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = blockBorder75.getInsets();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(categoryAnchor54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "CategoryAnchor.END" + "'", str55.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(horizontalAlignment63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(rectangleInsets77);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker1, jFreeChart5, (int) (byte) 0, (int) (byte) 100);
        org.jfree.chart.JFreeChart jFreeChart9 = chartProgressEvent8.getChart();
        chartProgressEvent8.setPercent(0);
        int int12 = chartProgressEvent8.getPercent();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(jFreeChart9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(500, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        boolean boolean2 = shapeList0.equals((java.lang.Object) paint1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.plot.Plot plot8 = categoryPlot7.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo14);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState16 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        plotRenderingInfo15.addSubplotInfo(plotRenderingInfo19);
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot7.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo15, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot7.getOrientation();
        boolean boolean24 = shapeList0.equals((java.lang.Object) plotOrientation23);
        java.lang.Object obj25 = shapeList0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plot8);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke11 = barRenderer0.getSeriesStroke(100);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setBasePaint((java.awt.Paint) color12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator16, true);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo7);
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot4.zoomDomainAxes((double) 0L, plotRenderingInfo7, point2D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            categoryPlot4.setRangeAxisLocation((int) (byte) -1, axisLocation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot8.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        plotRenderingInfo16.addSubplotInfo(plotRenderingInfo20);
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot8.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo16, point2D22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis25.setRange(1.0d, (double) (byte) 10);
        boolean boolean29 = numberAxis25.isVerticalTickLabels();
        boolean boolean30 = numberAxis25.isPositiveArrowVisible();
        java.lang.Object obj31 = numberAxis25.clone();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        barRenderer0.drawRangeGridline(graphics2D3, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis25, rectangle2D32, (double) (-1L));
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo37);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState39 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo38);
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot8.zoomRangeAxes((double) 10.0f, (double) (-8388608), plotRenderingInfo38, point2D40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = null;
        try {
            categoryPlot8.setDomainAxisLocation(axisLocation42, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        java.awt.Font font10 = barRenderer0.getItemLabelFont((int) ' ', 255);
        barRenderer0.setItemLabelAnchorOffset((double) (-1));
        boolean boolean13 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        double double2 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 1, 0.0f, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        java.awt.Paint paint6 = numberAxis1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot4.zoomRangeAxes((double) '#', (double) 1.0f, plotRenderingInfo11, point2D14);
        java.awt.Stroke stroke16 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis((int) ' ');
        java.awt.Paint paint19 = categoryPlot4.getOutlinePaint();
        categoryPlot4.clearRangeMarkers(0);
        boolean boolean22 = categoryPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint12 = barRenderer0.getSeriesItemLabelPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem16 = barRenderer13.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape17 = barRenderer13.getBaseShape();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer13.setSeriesOutlineStroke((int) (short) 0, stroke19);
        barRenderer13.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor24, textAnchor25, textAnchor26, (double) 0.5f);
        barRenderer13.setSeriesPositiveItemLabelPosition(0, itemLabelPosition28);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition28, true);
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor36 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor36, textAnchor37, textAnchor38, (double) 0.5f);
        org.jfree.chart.text.TextAnchor textAnchor41 = itemLabelPosition40.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor42 = itemLabelPosition40.getItemLabelAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition40, true);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(legendItem16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(itemLabelAnchor36);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(itemLabelAnchor42);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("AxisLocation.BOTTOM_OR_RIGHT", graphics2D1, 1.0d, (float) 100L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        categoryPlot4.clearDomainMarkers();
        java.awt.Color color21 = java.awt.Color.WHITE;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot4.getOrientation();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(plotOrientation23);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        java.lang.String str2 = basicProjectInfo0.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        basicProjectInfo4.setLicenceName("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo4);
        basicProjectInfo0.addOptionalLibrary("AxisLocation.BOTTOM_OR_RIGHT");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis3.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font9);
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font9, (java.awt.Paint) color11);
        numberAxis3.setTickLabelFont(font9);
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", font9);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("CategoryAnchor.END", font9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem19 = barRenderer16.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape20 = barRenderer16.getBaseShape();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer16.setSeriesOutlineStroke((int) (short) 0, stroke22);
        barRenderer16.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = barRenderer16.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("", font30);
        labelBlock31.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock31.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color42 = java.awt.Color.orange;
        int int43 = color42.getBlue();
        labelBlock31.setPaint((java.awt.Paint) color42);
        barRenderer16.setBasePaint((java.awt.Paint) color42, false);
        boolean boolean47 = textTitle15.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true, false);
        boolean boolean6 = barRenderer0.isSeriesVisibleInLegend((int) (byte) 100);
        boolean boolean7 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer0.setSeriesURLGenerator((int) 'a', categoryURLGenerator9, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        numberAxis1.setUpArrow(shape13);
        double double15 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis19.setUpperBound((double) 8);
        numberAxis19.resizeRange((double) 100);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis1.setDefaultAutoRange(range24);
        double double26 = range24.getCentralValue();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.5d + "'", double26 == 0.5d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.plot.Plot plot9 = categoryPlot8.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo16);
        plotRenderingInfo13.addSubplotInfo(plotRenderingInfo16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        plotRenderingInfo16.addSubplotInfo(plotRenderingInfo20);
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot8.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo16, point2D22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis25.setRange(1.0d, (double) (byte) 10);
        boolean boolean29 = numberAxis25.isVerticalTickLabels();
        boolean boolean30 = numberAxis25.isPositiveArrowVisible();
        java.lang.Object obj31 = numberAxis25.clone();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        barRenderer0.drawRangeGridline(graphics2D3, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis25, rectangle2D32, (double) (-1L));
        org.jfree.chart.axis.AxisCollection axisCollection36 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection36.add((org.jfree.chart.axis.Axis) numberAxis37, rectangleEdge38);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = numberAxis37.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        org.jfree.chart.renderer.RendererState rendererState43 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo42);
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo42.getDataArea();
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D44, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.clone(shape48);
        numberAxis37.setUpArrow(shape49);
        double double51 = numberAxis37.getLabelAngle();
        java.lang.String str52 = numberAxis37.getLabelToolTip();
        org.jfree.chart.renderer.category.BarRenderer barRenderer53 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem56 = barRenderer53.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape57 = barRenderer53.getBaseShape();
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer53.setSeriesOutlineStroke((int) (short) 0, stroke59);
        numberAxis37.setAxisLineStroke(stroke59);
        try {
            barRenderer0.setSeriesOutlineStroke((int) (byte) -1, stroke59, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNull(legendItem56);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ClassContext", "null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", numberArray8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str17 = categoryAxis15.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot14.setDomainAxis(categoryAxis15);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 0, (float) 100L);
        boolean boolean22 = categoryAxis15.equals((java.lang.Object) shape21);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis24.setRange(1.0d, (double) (byte) 10);
        boolean boolean28 = numberAxis24.isVerticalTickLabels();
        boolean boolean29 = numberAxis24.isPositiveArrowVisible();
        org.jfree.data.Range range30 = numberAxis24.getDefaultAutoRange();
        java.awt.Font font32 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("", font34);
        java.awt.Paint paint36 = labelBlock35.getPaint();
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("hi!", font32, paint36, 100.0f);
        java.awt.Paint paint39 = textFragment38.getPaint();
        numberAxis24.setTickMarkPaint(paint39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets();
        double double43 = rectangleInsets41.calculateLeftOutset((double) (byte) -1);
        double double45 = rectangleInsets41.calculateRightInset((double) 100.0f);
        numberAxis24.setTickLabelInsets(rectangleInsets41);
        boolean boolean47 = numberAxis24.isVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem51 = barRenderer48.getLegendItem((int) 'a', (int) (byte) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer48);
        org.jfree.data.KeyToGroupMap keyToGroupMap53 = null;
        try {
            org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset9, keyToGroupMap53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(legendItem51);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = categoryPlot15.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        categoryPlot4.setAnchorValue((double) (short) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot4.getDomainAxis();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNull(categoryAxis22);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) rectangleAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str2 = basicProjectInfo1.getLicenceName();
        boolean boolean3 = categoryAnchor0.equals((java.lang.Object) basicProjectInfo1);
        java.lang.String str4 = categoryAnchor0.toString();
        java.lang.String str5 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CategoryAnchor.END" + "'", str4.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CategoryAnchor.END" + "'", str5.equals("CategoryAnchor.END"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        projectInfo0.setLicenceText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        projectInfo0.setLicenceName("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        org.jfree.chart.ui.Library[] libraryArray6 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot4.setDataset(categoryDataset5);
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryPlot4.setBackgroundPaint(paint7);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        java.awt.Paint paint6 = null;
        legendTitle1.setBackgroundPaint(paint6);
        java.awt.Paint paint8 = legendTitle1.getBackgroundPaint();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int11 = color10.getTransparency();
        int int12 = color10.getAlpha();
        java.awt.Color color13 = java.awt.Color.getColor("CategoryAnchor.END", color10);
        legendTitle1.setBackgroundPaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 255 + "'", int12 == 255);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        boolean boolean4 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke6 = barRenderer0.getSeriesStroke((-16777216));
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        categoryPlot4.setAnchorValue((double) '#', false);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis17.setRange(1.0d, (double) (byte) 10);
        boolean boolean21 = numberAxis17.isVerticalTickLabels();
        double double22 = numberAxis17.getLowerBound();
        boolean boolean23 = legendItemCollection15.equals((java.lang.Object) numberAxis17);
        java.util.Iterator iterator24 = legendItemCollection15.iterator();
        categoryPlot4.setFixedLegendItems(legendItemCollection15);
        org.jfree.chart.LegendItem legendItem26 = null;
        legendItemCollection15.add(legendItem26);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(iterator24);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        axisState2.cursorRight((double) (short) 100);
        axisState2.cursorDown((double) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str14 = categoryAxis12.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot11.setDomainAxis(categoryAxis12);
        double double16 = categoryAxis12.getCategoryMargin();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets();
        double double21 = rectangleInsets19.calculateLeftOutset((double) (byte) -1);
        double double23 = rectangleInsets19.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        org.jfree.chart.renderer.RendererState rendererState26 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo25.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets19.createOutsetRectangle(rectangle2D27, true, true);
        org.jfree.chart.axis.AxisState axisState31 = new org.jfree.chart.axis.AxisState();
        axisState31.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState36 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean39 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge38);
        axisState36.moveCursor(0.0d, rectangleEdge38);
        axisState31.moveCursor((double) 100L, rectangleEdge38);
        java.util.List list42 = categoryAxis12.refreshTicks(graphics2D17, axisState18, rectangle2D27, rectangleEdge38);
        axisState2.setTicks(list42);
        axisState1.setTicks(list42);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2d + "'", double16 == 0.2d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(list42);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        boolean boolean20 = textTitle15.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textTitle15.getTextAlignment();
        java.lang.Object obj22 = textTitle15.clone();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        textTitle15.draw(graphics2D23, rectangle2D24);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = categoryPlot4.getOrientation();
        categoryPlot4.setAnchorValue(271.0d, false);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(plotOrientation20);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        textTitle15.setPadding((double) 0, 132.5d, (double) 1.0f, (double) (-1.0f));
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot8.setDomainAxisLocation(axisLocation9, true);
        boolean boolean12 = categoryPlot8.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot8.setDatasetRenderingOrder(datasetRenderingOrder13);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("ThreadContext", font3, (org.jfree.chart.plot.Plot) categoryPlot8, true);
        org.jfree.chart.title.TextTitle textTitle17 = jFreeChart16.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = textTitle17.getTextAlignment();
        textTitle17.setExpandToFitSpace(false);
        java.awt.Paint paint21 = textTitle17.getPaint();
        boolean boolean22 = textTitle17.getExpandToFitSpace();
        java.lang.Object obj23 = textTitle17.clone();
        boolean boolean24 = strokeList0.equals((java.lang.Object) textTitle17);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(textTitle17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem19 = barRenderer16.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer16.setBaseSeriesVisibleInLegend(false);
        java.awt.Stroke stroke23 = barRenderer16.lookupSeriesOutlineStroke(0);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        barRenderer16.setBaseSeriesVisible(false, true);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint2.toFixedHeight((double) '#');
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        double double10 = size2D9.height;
        size2D9.width = 10;
        try {
            org.jfree.chart.util.Size2D size2D13 = rectangleConstraint6.calculateConstrainedSize(size2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setRange(1.0d, (double) (byte) 10);
        boolean boolean6 = numberAxis2.isVerticalTickLabels();
        boolean boolean7 = numberAxis2.isPositiveArrowVisible();
        java.lang.Object obj8 = numberAxis2.clone();
        java.lang.Object obj9 = numberAxis2.clone();
        boolean boolean10 = rangeType0.equals(obj9);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) "ChartChangeEventType.NEW_DATASET");
        int int4 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (short) 10);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Number number8 = meanAndStandardDeviation7.getStandardDeviation();
        boolean boolean9 = keyedObjects2D0.equals((java.lang.Object) number8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", textAnchor3, textAnchor4, 0.0d);
        java.lang.Number number7 = numberTick6.getNumber();
        double double8 = numberTick6.getAngle();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        java.lang.Boolean boolean21 = barRenderer0.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextOutlineStroke();
        barRenderer0.setSeriesOutlineStroke((int) ' ', stroke24);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator26);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator28 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator28);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.lang.String str6 = textBlockAnchor5.toString();
        java.awt.Shape shape10 = textBlock0.calculateBounds(graphics2D2, 0.5f, (float) (byte) 100, textBlockAnchor5, 0.5f, (float) '#', (double) (byte) 100);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str6.equals("TextBlockAnchor.TOP_LEFT"));
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Comparable comparable3 = keyedObjects2D0.getRowKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.block.BlockFrame blockFrame3 = legendTitle1.getFrame();
        org.jfree.chart.block.BlockContainer blockContainer4 = legendTitle1.getItemContainer();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("", font6);
        java.awt.Paint paint8 = labelBlock7.getPaint();
        java.awt.Font font9 = labelBlock7.getFont();
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) labelBlock7, jFreeChart10, (int) (short) 1, (int) 'a');
        blockContainer4.add((org.jfree.chart.block.Block) labelBlock7);
        org.junit.Assert.assertNotNull(blockFrame3);
        org.junit.Assert.assertNotNull(blockContainer4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) (byte) 1, (int) (short) 10);
        jFreeChart14.removeLegend();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(bufferedImage17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        java.awt.Color color8 = java.awt.Color.DARK_GRAY;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer13);
        boolean boolean15 = categoryPlot14.isRangeZoomable();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double19 = rectangleInsets17.calculateLeftOutset((double) (byte) -1);
        double double21 = rectangleInsets17.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        org.jfree.chart.renderer.RendererState rendererState24 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = plotRenderingInfo23.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets17.createOutsetRectangle(rectangle2D25, true, true);
        categoryPlot14.drawBackgroundImage(graphics2D16, rectangle2D28);
        int int30 = categoryPlot14.getDatasetCount();
        boolean boolean31 = categoryPlot14.isOutlineVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot14);
        categoryPlot5.notifyListeners(plotChangeEvent32);
        java.awt.Color color34 = java.awt.Color.YELLOW;
        categoryPlot5.setRangeCrosshairPaint((java.awt.Paint) color34);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.lang.String str4 = textBlockAnchor3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition5);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str4.equals("TextBlockAnchor.TOP_LEFT"));
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = new org.jfree.chart.util.RectangleInsets();
        double double3 = rectangleInsets1.calculateLeftOutset((double) (byte) -1);
        blockContainer0.setMargin(rectangleInsets1);
        double double5 = rectangleInsets1.getBottom();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12, textAnchor13, (double) 0.5f);
        barRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition15);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        double double20 = categoryPlot4.getAnchorValue();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot4.setRenderer(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        double double8 = range7.getCentralValue();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis10.setUpperBound((double) 8);
        numberAxis10.resizeRange((double) 100);
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        double double16 = range15.getUpperBound();
        org.jfree.data.Range range17 = org.jfree.data.Range.combine(range7, range15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState20 = new org.jfree.chart.axis.AxisState();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str28 = categoryAxis26.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot25.setDomainAxis(categoryAxis26);
        double double30 = categoryAxis26.getCategoryMargin();
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.AxisState axisState32 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets();
        double double35 = rectangleInsets33.calculateLeftOutset((double) (byte) -1);
        double double37 = rectangleInsets33.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        org.jfree.chart.renderer.RendererState rendererState40 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo39);
        java.awt.geom.Rectangle2D rectangle2D41 = plotRenderingInfo39.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets33.createOutsetRectangle(rectangle2D41, true, true);
        org.jfree.chart.axis.AxisState axisState45 = new org.jfree.chart.axis.AxisState();
        axisState45.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState50 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean53 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge52);
        axisState50.moveCursor(0.0d, rectangleEdge52);
        axisState45.moveCursor((double) 100L, rectangleEdge52);
        java.util.List list56 = categoryAxis26.refreshTicks(graphics2D31, axisState32, rectangle2D41, rectangleEdge52);
        org.jfree.chart.axis.AxisState axisState58 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean61 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge60);
        axisState58.moveCursor(0.0d, rectangleEdge60);
        java.util.List list63 = categoryAxis18.refreshTicks(graphics2D19, axisState20, rectangle2D41, rectangleEdge60);
        boolean boolean64 = range7.equals((java.lang.Object) axisState20);
        axisState20.cursorRight((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.2d + "'", double30 == 0.2d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, true);
        java.awt.Stroke stroke9 = barRenderer0.getSeriesOutlineStroke(255);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) 'a');
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType12 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer13 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType12);
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis16.setRange(1.0d, (double) (byte) 10);
        boolean boolean20 = numberAxis16.isVerticalTickLabels();
        boolean boolean21 = numberAxis16.isPositiveArrowVisible();
        org.jfree.data.Range range22 = numberAxis16.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis24.setRange(1.0d, (double) (byte) 10);
        boolean boolean28 = numberAxis24.isVerticalTickLabels();
        boolean boolean29 = numberAxis24.isPositiveArrowVisible();
        org.jfree.data.Range range30 = numberAxis24.getDefaultAutoRange();
        double double31 = range30.getCentralValue();
        numberAxis16.setRangeWithMargins(range30, false, true);
        boolean boolean35 = standardGradientPaintTransformer13.equals((java.lang.Object) false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformType12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.5d + "'", double31 == 0.5d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) ' ', dataset1);
        java.lang.String str3 = datasetChangeEvent2.toString();
        org.jfree.data.general.Dataset dataset4 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source= ]" + "'", str3.equals("org.jfree.data.general.DatasetChangeEvent[source= ]"));
        org.junit.Assert.assertNull(dataset4);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke11 = barRenderer0.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis14.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        numberAxis14.removeChangeListener(axisChangeListener18);
        java.awt.Shape shape20 = numberAxis14.getRightArrow();
        barRenderer0.setSeriesShape(8, shape20, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean2 = verticalAlignment0.equals((java.lang.Object) "AxisLocation.TOP_OR_RIGHT");
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor5 = valueMarker4.getLabelTextAnchor();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker4.setOutlineStroke(stroke6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent11 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker4, jFreeChart8, (int) (byte) 0, (int) (byte) 100);
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot18.setDomainAxisLocation(axisLocation19, true);
        boolean boolean22 = categoryPlot18.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot18.setDatasetRenderingOrder(datasetRenderingOrder23);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("ThreadContext", font13, (org.jfree.chart.plot.Plot) categoryPlot18, true);
        jFreeChart26.clearSubtitles();
        chartProgressEvent11.setChart(jFreeChart26);
        jFreeChart26.setTitle("HorizontalAlignment.CENTER");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "AxisLocation.TOP_OR_RIGHT", jFreeChart26, chartChangeEventType31);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(chartChangeEventType31);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        barRenderer0.setMaximumBarWidth((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator((int) 'a', 192);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem13 = barRenderer10.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape14 = barRenderer10.getBaseShape();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer10.setSeriesOutlineStroke((int) (short) 0, stroke16);
        barRenderer10.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke21 = barRenderer10.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis24.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener28 = null;
        numberAxis24.removeChangeListener(axisChangeListener28);
        java.awt.Shape shape30 = numberAxis24.getRightArrow();
        barRenderer10.setSeriesShape(8, shape30, true);
        barRenderer0.setBaseShape(shape30, true);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.clone(shape30);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(shape35);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "", "hi!");
        centerArrangement1.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) "");
        java.lang.Object obj11 = null;
        flowArrangement0.add((org.jfree.chart.block.Block) labelBlock3, obj11);
        flowArrangement0.clear();
        flowArrangement0.clear();
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesOutlinePaint(8);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot9.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.chart.renderer.RendererState rendererState15 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo17);
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        plotRenderingInfo17.addSubplotInfo(plotRenderingInfo21);
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot9.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo17, point2D23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis26.setRange(1.0d, (double) (byte) 10);
        boolean boolean30 = numberAxis26.isVerticalTickLabels();
        boolean boolean31 = numberAxis26.isPositiveArrowVisible();
        java.lang.Object obj32 = numberAxis26.clone();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        barRenderer1.drawRangeGridline(graphics2D4, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis26, rectangle2D33, (double) (-1L));
        boolean boolean37 = barRenderer1.isSeriesItemLabelsVisible((-8388608));
        boolean boolean39 = barRenderer1.isSeriesItemLabelsVisible(0);
        int int40 = objectList0.indexOf((java.lang.Object) boolean39);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        int int2 = numberTickUnit0.getMinorTickCount();
        java.lang.String str4 = numberTickUnit0.valueToString((double) (short) 100);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        java.awt.Paint paint6 = null;
        legendTitle1.setBackgroundPaint(paint6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis10.setRange(1.0d, (double) (byte) 10);
        boolean boolean14 = numberAxis10.isVerticalTickLabels();
        boolean boolean15 = numberAxis10.isPositiveArrowVisible();
        org.jfree.data.Range range16 = numberAxis10.getDefaultAutoRange();
        java.awt.Font font18 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("", font20);
        java.awt.Paint paint22 = labelBlock21.getPaint();
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("hi!", font18, paint22, 100.0f);
        java.awt.Paint paint25 = textFragment24.getPaint();
        numberAxis10.setTickMarkPaint(paint25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets();
        double double29 = rectangleInsets27.calculateLeftOutset((double) (byte) -1);
        double double31 = rectangleInsets27.calculateRightInset((double) 100.0f);
        numberAxis10.setTickLabelInsets(rectangleInsets27);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot37.setDomainAxisLocation(axisLocation38, true);
        boolean boolean41 = categoryPlot37.getDrawSharedDomainAxis();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis44.setRange(1.0d, (double) (byte) 10);
        boolean boolean48 = numberAxis44.isVerticalTickLabels();
        double double49 = numberAxis44.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo51);
        org.jfree.chart.renderer.RendererState rendererState53 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo52);
        java.awt.geom.Rectangle2D rectangle2D54 = plotRenderingInfo52.getDataArea();
        java.awt.Shape shape58 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D54, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection59 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis61.setRange(1.0d, (double) (byte) 10);
        boolean boolean65 = numberAxis61.isVerticalTickLabels();
        boolean boolean66 = numberAxis61.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge67);
        axisCollection59.add((org.jfree.chart.axis.Axis) numberAxis61, rectangleEdge67);
        java.lang.String str70 = rectangleEdge67.toString();
        double double71 = numberAxis44.lengthToJava2D((double) 255, rectangle2D54, rectangleEdge67);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo73);
        boolean boolean75 = categoryPlot37.render(graphics2D42, rectangle2D54, (int) (byte) 0, plotRenderingInfo74);
        rectangleInsets27.trim(rectangle2D54);
        legendTitle1.setPadding(rectangleInsets27);
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = new org.jfree.chart.util.RectangleInsets((double) 10, (double) ' ', (double) 100, (double) 0.5f);
        double double84 = rectangleInsets82.extendWidth(100.0d);
        legendTitle1.setItemLabelPadding(rectangleInsets82);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "RectangleEdge.RIGHT" + "'", str70.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 132.5d + "'", double84 == 132.5d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        booleanList0.setBoolean((int) (byte) 100, (java.lang.Boolean) false);
        int int4 = booleanList0.size();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 101 + "'", int4 == 101);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot15.getRenderer(0);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot15.setDataset(categoryDataset22);
        boolean boolean24 = categoryPlot15.isRangeCrosshairLockedOnData();
        java.awt.Paint paint25 = categoryPlot15.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.CenterArrangement centerArrangement4 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle6.setVerticalAlignment(verticalAlignment8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle6.getLegendItemGraphicLocation();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        centerArrangement4.add((org.jfree.chart.block.Block) legendTitle6, (java.lang.Object) textAnchor11);
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", graphics2D1, (float) (short) -1, (float) (-1L), textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        basicProjectInfo0.setLicenceName("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        basicProjectInfo0.setInfo("TextBlockAnchor.BOTTOM_RIGHT");
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) (byte) -1);
        double double16 = rectangleInsets12.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets12.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        axisState24.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        axisState29.moveCursor(0.0d, rectangleEdge31);
        axisState24.moveCursor((double) 100L, rectangleEdge31);
        java.util.List list35 = categoryAxis5.refreshTicks(graphics2D10, axisState11, rectangle2D20, rectangleEdge31);
        float float36 = categoryAxis5.getTickMarkInsideLength();
        org.jfree.data.KeyedObjects2D keyedObjects2D37 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double40 = numberTickUnit39.getSize();
        java.lang.Object obj42 = keyedObjects2D37.getObject((java.lang.Comparable) numberTickUnit39, (java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis5.setTickLabelFont((java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ", font43);
        categoryAxis5.configure();
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("", font47);
        java.awt.Paint paint49 = labelBlock48.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        double double52 = rectangleInsets50.calculateLeftOutset((double) (byte) -1);
        double double54 = rectangleInsets50.calculateRightOutset(0.0d);
        double double56 = rectangleInsets50.calculateTopInset((double) (-1));
        double double58 = rectangleInsets50.calculateBottomOutset((double) 0L);
        labelBlock48.setMargin(rectangleInsets50);
        categoryAxis5.setLabelInsets(rectangleInsets50);
        double double61 = rectangleInsets50.getRight();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        java.awt.Paint paint16 = textTitle15.getBackgroundPaint();
        java.lang.Object obj17 = null;
        boolean boolean18 = textTitle15.equals(obj17);
        java.awt.Paint paint19 = textTitle15.getBackgroundPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4194112) + "'", int1 == (-4194112));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem19 = barRenderer16.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer16.setBaseSeriesVisibleInLegend(false);
        java.awt.Stroke stroke23 = barRenderer16.lookupSeriesOutlineStroke(0);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.lang.Boolean boolean26 = barRenderer16.getSeriesCreateEntities(0);
        barRenderer16.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = barRenderer16.getSeriesPositiveItemLabelPosition(10);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint2.getHeightConstraintType();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        barRenderer0.setSeriesItemLabelPaint((int) ' ', (java.awt.Paint) color5, true);
        java.awt.Stroke stroke9 = barRenderer0.getSeriesOutlineStroke(255);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) 'a');
        java.awt.Color color12 = java.awt.Color.BLACK;
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color12, false);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor4 = valueMarker3.getLabelTextAnchor();
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker3.setOutlineStroke(stroke5);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker3.setStroke(stroke7);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker3.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker3.setLabelOffsetType(lengthAdjustmentType10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker3.setLabelTextAnchor(textAnchor12);
        org.jfree.chart.text.TextAnchor textAnchor14 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 192, "ThreadContext", textAnchor12, textAnchor14, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker5.getLabelTextAnchor();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker5.setOutlineStroke(stroke7);
        numberAxis1.setTickMarkStroke(stroke7);
        boolean boolean10 = numberAxis1.isPositiveArrowVisible();
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        float float20 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem24 = barRenderer21.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape25 = barRenderer21.getBaseShape();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer21.setSeriesOutlineStroke((int) (short) 0, stroke27);
        barRenderer21.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer21.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("", font35);
        labelBlock36.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock36.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color47 = java.awt.Color.orange;
        int int48 = color47.getBlue();
        labelBlock36.setPaint((java.awt.Paint) color47);
        barRenderer21.setBasePaint((java.awt.Paint) color47, false);
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color47);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor54 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str55 = categoryAnchor54.toString();
        categoryPlot4.setDomainGridlinePosition(categoryAnchor54);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent59 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle58);
        java.lang.Object obj60 = legendTitle58.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle58.setLegendItemGraphicLocation(rectangleAnchor61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment63 = legendTitle58.getHorizontalAlignment();
        boolean boolean64 = categoryAnchor54.equals((java.lang.Object) legendTitle58);
        java.awt.Font font71 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock72 = new org.jfree.chart.block.LabelBlock("", font71);
        java.awt.Color color73 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine74 = new org.jfree.chart.text.TextLine("hi!", font71, (java.awt.Paint) color73);
        org.jfree.chart.block.BlockBorder blockBorder75 = new org.jfree.chart.block.BlockBorder(1.0d, (double) (-1.0f), (double) 0, 100.0d, (java.awt.Paint) color73);
        legendTitle58.setFrame((org.jfree.chart.block.BlockFrame) blockBorder75);
        org.jfree.chart.block.BlockContainer blockContainer77 = legendTitle58.getItemContainer();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(categoryAnchor54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "CategoryAnchor.END" + "'", str55.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(horizontalAlignment63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(blockContainer77);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.util.List list2 = keyedObjects0.getKeys();
        java.lang.Object obj4 = keyedObjects0.getObject(3);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis7.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        double double13 = rectangleInsets11.calculateLeftOutset((double) (byte) -1);
        double double15 = rectangleInsets11.calculateRightInset((double) 100.0f);
        numberAxis7.setLabelInsets(rectangleInsets11);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        org.jfree.chart.plot.Plot plot22 = categoryPlot21.getRootPlot();
        numberAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot21);
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem27 = barRenderer24.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape28 = barRenderer24.getBaseShape();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer24.setSeriesOutlineStroke((int) (short) 0, stroke30);
        barRenderer24.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        org.jfree.chart.renderer.RendererState rendererState36 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo35);
        java.awt.geom.Rectangle2D rectangle2D37 = plotRenderingInfo35.getDataArea();
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D37, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.clone(shape41);
        barRenderer24.setBaseShape(shape42);
        java.lang.Boolean boolean45 = barRenderer24.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier47 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke48 = defaultDrawingSupplier47.getNextOutlineStroke();
        barRenderer24.setSeriesOutlineStroke((int) ' ', stroke48);
        categoryPlot21.setRangeGridlineStroke(stroke48);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor53 = valueMarker52.getLabelTextAnchor();
        categoryPlot21.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker52);
        keyedObjects0.setObject((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.lang.Object) categoryPlot21);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(textAnchor53);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        float float14 = categoryPlot4.getBackgroundAlpha();
        categoryPlot4.configureDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) 10L);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            lineBorder0.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        java.lang.Boolean boolean21 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) -1);
        barRenderer0.setBase((double) (byte) 0);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(boolean21);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "", "hi!");
        centerArrangement1.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) "");
        java.lang.Object obj11 = null;
        flowArrangement0.add((org.jfree.chart.block.Block) labelBlock3, obj11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = labelBlock3.getPadding();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = labelBlock3.arrange(graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis12.setRange(1.0d, (double) (byte) 10);
        boolean boolean16 = numberAxis12.isVerticalTickLabels();
        double double17 = numberAxis12.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.RendererState rendererState21 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D22, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection27 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis29.setRange(1.0d, (double) (byte) 10);
        boolean boolean33 = numberAxis29.isVerticalTickLabels();
        boolean boolean34 = numberAxis29.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge35);
        axisCollection27.add((org.jfree.chart.axis.Axis) numberAxis29, rectangleEdge35);
        java.lang.String str38 = rectangleEdge35.toString();
        double double39 = numberAxis12.lengthToJava2D((double) 255, rectangle2D22, rectangleEdge35);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent42 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle41.setVerticalAlignment(verticalAlignment43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendTitle41.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = legendTitle41.getLegendItemGraphicEdge();
        double double47 = categoryAxis5.getCategoryEnd((int) '#', 4, rectangle2D22, rectangleEdge46);
        float float48 = categoryAxis5.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleEdge.RIGHT" + "'", str38.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.0f + "'", float48 == 0.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) (byte) -1);
        double double16 = rectangleInsets12.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets12.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        axisState24.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        axisState29.moveCursor(0.0d, rectangleEdge31);
        axisState24.moveCursor((double) 100L, rectangleEdge31);
        java.util.List list35 = categoryAxis5.refreshTicks(graphics2D10, axisState11, rectangle2D20, rectangleEdge31);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions37 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition39 = categoryLabelPositions37.getLabelPosition(rectangleEdge38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean41 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge40);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition42 = categoryLabelPositions37.getLabelPosition(rectangleEdge40);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = categoryLabelPosition42.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType44 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str45 = categoryLabelWidthType44.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition47 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor36, textBlockAnchor43, categoryLabelWidthType44, (float) 3);
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor36);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(categoryLabelPositions37);
        org.junit.Assert.assertNull(categoryLabelPosition39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition42);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertNotNull(categoryLabelWidthType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str45.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(point2D48);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = barRenderer0.getPlot();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setPositiveArrowVisible(true);
        org.jfree.data.Range range16 = categoryPlot12.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.axis.AxisCollection axisCollection17 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection17.add((org.jfree.chart.axis.Axis) numberAxis18, rectangleEdge19);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = numberAxis18.getStandardTickUnits();
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str30 = categoryAxis28.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot27.setDomainAxis(categoryAxis28);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis35.setRange(1.0d, (double) (byte) 10);
        boolean boolean39 = numberAxis35.isVerticalTickLabels();
        double double40 = numberAxis35.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo42);
        org.jfree.chart.renderer.RendererState rendererState44 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo43);
        java.awt.geom.Rectangle2D rectangle2D45 = plotRenderingInfo43.getDataArea();
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D45, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection50 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis52.setRange(1.0d, (double) (byte) 10);
        boolean boolean56 = numberAxis52.isVerticalTickLabels();
        boolean boolean57 = numberAxis52.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge58);
        axisCollection50.add((org.jfree.chart.axis.Axis) numberAxis52, rectangleEdge58);
        java.lang.String str61 = rectangleEdge58.toString();
        double double62 = numberAxis35.lengthToJava2D((double) 255, rectangle2D45, rectangleEdge58);
        org.jfree.chart.LegendItemSource legendItemSource63 = null;
        org.jfree.chart.title.LegendTitle legendTitle64 = new org.jfree.chart.title.LegendTitle(legendItemSource63);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent65 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle64);
        org.jfree.chart.util.VerticalAlignment verticalAlignment66 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle64.setVerticalAlignment(verticalAlignment66);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = legendTitle64.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = legendTitle64.getLegendItemGraphicEdge();
        double double70 = categoryAxis28.getCategoryEnd((int) '#', 4, rectangle2D45, rectangleEdge69);
        barRenderer0.drawRangeMarker(graphics2D7, categoryPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis18, marker22, rectangle2D45);
        org.jfree.chart.axis.AxisSpace axisSpace72 = new org.jfree.chart.axis.AxisSpace();
        double double73 = axisSpace72.getLeft();
        double double74 = axisSpace72.getTop();
        categoryPlot12.setFixedDomainAxisSpace(axisSpace72);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "RectangleEdge.RIGHT" + "'", str61.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment66);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer34);
        boolean boolean36 = categoryPlot35.isRangeZoomable();
        boolean boolean37 = barRenderer0.hasListener((java.util.EventListener) categoryPlot35);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("", font40);
        java.awt.Color color42 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine43 = new org.jfree.chart.text.TextLine("hi!", font40, (java.awt.Paint) color42);
        org.jfree.chart.ui.ProjectInfo projectInfo44 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str45 = projectInfo44.toString();
        boolean boolean46 = textLine43.equals((java.lang.Object) str45);
        org.jfree.chart.text.TextFragment textFragment47 = textLine43.getLastTextFragment();
        java.awt.Paint paint48 = textFragment47.getPaint();
        barRenderer0.setBaseItemLabelPaint(paint48, false);
        java.awt.Shape shape53 = barRenderer0.getItemShape(15, 101);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str45.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(textFragment47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(shape53);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font4);
        java.awt.Paint paint6 = labelBlock5.getPaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("hi!", font2, paint6, 100.0f);
        java.awt.Paint paint9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint9);
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        boolean boolean12 = textBlock10.equals((java.lang.Object) textAnchor11);
        org.jfree.chart.text.TextLine textLine13 = textBlock10.getLastLine();
        org.jfree.chart.text.TextLine textLine14 = textBlock10.getLastLine();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(textLine13);
        org.junit.Assert.assertNull(textLine14);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis12.setRange(1.0d, (double) (byte) 10);
        boolean boolean16 = numberAxis12.isVerticalTickLabels();
        double double17 = numberAxis12.getLowerBound();
        numberAxis12.setVisible(true);
        org.jfree.chart.axis.TickUnits tickUnits20 = new org.jfree.chart.axis.TickUnits();
        numberAxis12.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits20);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo22 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str23 = basicProjectInfo22.getCopyright();
        java.lang.String str24 = basicProjectInfo22.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray25 = basicProjectInfo22.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo26 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray27 = basicProjectInfo26.getOptionalLibraries();
        basicProjectInfo26.setLicenceName("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        basicProjectInfo22.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo26);
        boolean boolean31 = tickUnits20.equals((java.lang.Object) basicProjectInfo22);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis33.setRange(1.0d, (double) (byte) 10);
        boolean boolean37 = numberAxis33.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis39.setRange(1.0d, (double) (byte) 10);
        boolean boolean43 = numberAxis39.isVerticalTickLabels();
        double double44 = numberAxis39.getLowerBound();
        numberAxis39.setVisible(true);
        float float47 = numberAxis39.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit49 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        numberAxis39.setTickUnit(numberTickUnit49, false, true);
        numberAxis33.setTickUnit(numberTickUnit49);
        tickUnits20.add((org.jfree.chart.axis.TickUnit) numberTickUnit49);
        numberAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits20);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(libraryArray25);
        org.junit.Assert.assertNotNull(libraryArray27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo5);
        org.jfree.chart.renderer.RendererState rendererState7 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo6.getDataArea();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D8, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.clone(shape12);
        numberAxis1.setUpArrow(shape13);
        double double15 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis19.setUpperBound((double) 8);
        numberAxis19.resizeRange((double) 100);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis1.setDefaultAutoRange(range24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = new org.jfree.chart.axis.AxisSpace();
        double double27 = axisSpace26.getRight();
        axisSpace26.setLeft((double) 10.0f);
        boolean boolean30 = range24.equals((java.lang.Object) axisSpace26);
        java.lang.String str31 = axisSpace26.toString();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom(100.0d);
        double double3 = axisSpace0.getRight();
        double double4 = axisSpace0.getTop();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setRangeAboutValue(0.0d, (double) 0.5f);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis11.setUpperBound((double) 8);
        numberAxis11.resizeRange((double) 100);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        java.awt.Font font17 = numberAxis11.getLabelFont();
        numberAxis1.setLabelFont(font17);
        float float19 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "org.jfree.data.general.DatasetChangeEvent[source= ]");
        boolean boolean7 = legendTitle1.equals((java.lang.Object) shape4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis9.setRange(1.0d, (double) (byte) 10);
        boolean boolean13 = numberAxis9.isVerticalTickLabels();
        boolean boolean14 = numberAxis9.isPositiveArrowVisible();
        org.jfree.data.Range range15 = numberAxis9.getDefaultAutoRange();
        java.awt.Font font17 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("", font19);
        java.awt.Paint paint21 = labelBlock20.getPaint();
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("hi!", font17, paint21, 100.0f);
        java.awt.Paint paint24 = textFragment23.getPaint();
        numberAxis9.setTickMarkPaint(paint24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets();
        double double28 = rectangleInsets26.calculateLeftOutset((double) (byte) -1);
        double double30 = rectangleInsets26.calculateRightInset((double) 100.0f);
        numberAxis9.setTickLabelInsets(rectangleInsets26);
        legendTitle1.setPadding(rectangleInsets26);
        double double34 = rectangleInsets26.calculateBottomOutset((double) 2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
        org.jfree.chart.axis.AxisCollection axisCollection2 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection2.add((org.jfree.chart.axis.Axis) numberAxis3, rectangleEdge4);
        java.util.List list6 = axisCollection2.getAxesAtTop();
        java.util.List list7 = axisCollection2.getAxesAtBottom();
        axisState1.setTicks(list7);
        axisState1.setCursor(0.0d);
        java.util.List list11 = axisState1.getTicks();
        axisState1.setMax(0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color9);
        numberAxis1.setTickLabelFont(font7);
        numberAxis1.setVerticalTickLabels(false);
        double double14 = numberAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart7.removeLegend();
        jFreeChart7.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color9);
        numberAxis1.setTickLabelFont(font7);
        double double12 = numberAxis1.getLowerBound();
        boolean boolean13 = numberAxis1.isTickLabelsVisible();
        double double14 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) (byte) -1);
        double double16 = rectangleInsets12.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets12.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        axisState24.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        axisState29.moveCursor(0.0d, rectangleEdge31);
        axisState24.moveCursor((double) 100L, rectangleEdge31);
        java.util.List list35 = categoryAxis5.refreshTicks(graphics2D10, axisState11, rectangle2D20, rectangleEdge31);
        float float36 = categoryAxis5.getTickMarkInsideLength();
        org.jfree.data.KeyedObjects2D keyedObjects2D37 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double40 = numberTickUnit39.getSize();
        java.lang.Object obj42 = keyedObjects2D37.getObject((java.lang.Comparable) numberTickUnit39, (java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis5.setTickLabelFont((java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ", font43);
        categoryAxis5.configure();
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("", font47);
        java.awt.Paint paint49 = labelBlock48.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets();
        double double52 = rectangleInsets50.calculateLeftOutset((double) (byte) -1);
        double double54 = rectangleInsets50.calculateRightOutset(0.0d);
        double double56 = rectangleInsets50.calculateTopInset((double) (-1));
        double double58 = rectangleInsets50.calculateBottomOutset((double) 0L);
        labelBlock48.setMargin(rectangleInsets50);
        categoryAxis5.setLabelInsets(rectangleInsets50);
        categoryAxis5.setMaximumCategoryLabelLines((int) (byte) -1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (-8388608));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis21.setUpperBound((double) 8);
        numberAxis21.resizeRange((double) 100);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        java.awt.Font font27 = numberAxis21.getLabelFont();
        java.awt.Paint paint28 = numberAxis21.getTickMarkPaint();
        org.jfree.data.Range range29 = categoryPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis31.setRange(1.0d, (double) (byte) 10);
        numberAxis31.setRangeAboutValue(0.0d, (double) 0.5f);
        numberAxis31.setNegativeArrowVisible(true);
        double double40 = numberAxis31.getUpperMargin();
        numberAxis31.setVisible(true);
        numberAxis31.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = new org.jfree.chart.util.RectangleInsets((double) 10, (double) ' ', (double) 100, (double) 0.5f);
        numberAxis31.setTickLabelInsets(rectangleInsets49);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke52 = defaultDrawingSupplier51.getNextOutlineStroke();
        numberAxis31.setTickMarkStroke(stroke52);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] { numberAxis31 };
        categoryPlot15.setRangeAxes(valueAxisArray54);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(valueAxisArray54);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets7.createOutsetRectangle(rectangle2D15, true, true);
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D18);
        int int20 = categoryPlot4.getDatasetCount();
        boolean boolean21 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation24, plotOrientation25);
        categoryPlot4.setDomainAxisLocation(1, axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart7.setBorderVisible(false);
        java.lang.Object obj10 = jFreeChart7.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart7.setAntiAlias(true);
        org.jfree.chart.event.ChartProgressListener chartProgressListener10 = null;
        jFreeChart7.removeProgressListener(chartProgressListener10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        java.lang.Boolean boolean21 = barRenderer0.getSeriesVisible(8);
        double double22 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Font font24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot29.setDomainAxisLocation(axisLocation30, true);
        boolean boolean33 = categoryPlot29.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder34 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot29.setDatasetRenderingOrder(datasetRenderingOrder34);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("ThreadContext", font24, (org.jfree.chart.plot.Plot) categoryPlot29, true);
        java.awt.image.BufferedImage bufferedImage40 = jFreeChart37.createBufferedImage((int) (byte) 1, (int) (short) 10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor41 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor43 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor41, textAnchor42, textAnchor43, (double) 0.5f);
        org.jfree.chart.text.TextAnchor textAnchor46 = itemLabelPosition45.getRotationAnchor();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean48 = itemLabelPosition45.equals((java.lang.Object) categoryAnchor47);
        java.awt.Paint paint49 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        boolean boolean50 = categoryAnchor47.equals((java.lang.Object) paint49);
        jFreeChart37.setBorderPaint(paint49);
        barRenderer0.setBasePaint(paint49);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder34);
        org.junit.Assert.assertNotNull(bufferedImage40);
        org.junit.Assert.assertNotNull(itemLabelAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertNotNull(categoryAnchor47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = valueMarker1.getLabelOffsetType();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color9 = color8.darker();
        valueMarker1.setPaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        numberAxis1.setRangeAboutValue(0.0d, (double) 0.5f);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState((double) 0);
        double double11 = axisState10.getCursor();
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateLeftOutset((double) (byte) -1);
        blockContainer12.setMargin(rectangleInsets13);
        java.util.List list17 = blockContainer12.getBlocks();
        axisState10.setTicks(list17);
        org.jfree.chart.util.Size2D size2D21 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor24, textBlockAnchor25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = categoryLabelPosition26.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D28 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D21, (double) (byte) 0, 0.0d, rectangleAnchor27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = new org.jfree.chart.axis.AxisState();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str39 = categoryAxis37.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot36.setDomainAxis(categoryAxis37);
        double double41 = categoryAxis37.getCategoryMargin();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.AxisState axisState43 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets();
        double double46 = rectangleInsets44.calculateLeftOutset((double) (byte) -1);
        double double48 = rectangleInsets44.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo49);
        org.jfree.chart.renderer.RendererState rendererState51 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo50);
        java.awt.geom.Rectangle2D rectangle2D52 = plotRenderingInfo50.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets44.createOutsetRectangle(rectangle2D52, true, true);
        org.jfree.chart.axis.AxisState axisState56 = new org.jfree.chart.axis.AxisState();
        axisState56.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState61 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean64 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge63);
        axisState61.moveCursor(0.0d, rectangleEdge63);
        axisState56.moveCursor((double) 100L, rectangleEdge63);
        java.util.List list67 = categoryAxis37.refreshTicks(graphics2D42, axisState43, rectangle2D52, rectangleEdge63);
        org.jfree.chart.axis.AxisState axisState69 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean72 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge71);
        axisState69.moveCursor(0.0d, rectangleEdge71);
        java.util.List list74 = categoryAxis29.refreshTicks(graphics2D30, axisState31, rectangle2D52, rectangleEdge71);
        try {
            java.util.List list75 = numberAxis1.refreshTicks(graphics2D8, axisState10, rectangle2D28, rectangleEdge71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.2d + "'", double41 == 0.2d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(list74);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        java.lang.String str2 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.lang.String str2 = textBlockAnchor1.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        double double4 = categoryLabelPosition3.getAngle();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = categoryLabelPosition3.getWidthType();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = categoryLabelPosition3.getLabelAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str2.equals("TextBlockAnchor.TOP_LEFT"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor9 = valueMarker8.getLabelTextAnchor();
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker8.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker8.setStroke(stroke12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = valueMarker8.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType14);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) rectangle2D5);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D5);
        java.lang.String str18 = chartEntity17.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ChartEntity: tooltip = null" + "'", str18.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = categoryLabelPositions8.getLabelPosition(rectangleEdge9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean12 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge11);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = categoryLabelPositions8.getLabelPosition(rectangleEdge11);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = categoryLabelPosition13.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType15 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str16 = categoryLabelWidthType15.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor14, categoryLabelWidthType15, (float) 3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition18);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNull(categoryLabelPosition10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(categoryLabelWidthType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str16.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str5 = numberTickUnit4.toString();
        int int6 = numberTickUnit4.getMinorTickCount();
        java.lang.String str8 = numberTickUnit4.valueToString((double) 1L);
        try {
            org.jfree.data.xy.XYDataset xYDataset9 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 1, (-0.25d), 10, (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[size=1]" + "'", str5.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.awt.Paint paint3 = labelBlock2.getPaint();
        java.awt.Font font4 = labelBlock2.getFont();
        org.jfree.chart.block.BlockFrame blockFrame5 = labelBlock2.getFrame();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(blockFrame5);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem21 = barRenderer18.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape22 = barRenderer18.getBaseShape();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer18.setSeriesOutlineStroke((int) (short) 0, stroke24);
        barRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D31, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.clone(shape35);
        barRenderer18.setBaseShape(shape36);
        java.lang.Boolean boolean39 = barRenderer18.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke42 = defaultDrawingSupplier41.getNextOutlineStroke();
        barRenderer18.setSeriesOutlineStroke((int) ' ', stroke42);
        categoryPlot15.setRangeGridlineStroke(stroke42);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker46.getLabelTextAnchor();
        categoryPlot15.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker46);
        categoryPlot15.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(textAnchor47);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font11);
        java.awt.Paint paint13 = labelBlock12.getPaint();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font9, paint13, 100.0f);
        java.awt.Paint paint16 = textFragment15.getPaint();
        numberAxis1.setTickMarkPaint(paint16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets18.calculateLeftOutset((double) (byte) -1);
        double double22 = rectangleInsets18.calculateRightInset((double) 100.0f);
        numberAxis1.setTickLabelInsets(rectangleInsets18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        org.jfree.chart.renderer.RendererState rendererState26 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo25.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D30 = rectangleInsets18.createOutsetRectangle(rectangle2D27, false, false);
        org.jfree.chart.util.Size2D size2D34 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor38 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition39 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor37, textBlockAnchor38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = categoryLabelPosition39.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D34, (double) (byte) 0, 0.0d, rectangleAnchor40);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity44 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) true, (java.awt.Shape) rectangle2D41, "LegendItemEntity: seriesKey=null, dataset=null", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets18.createInsetRectangle(rectangle2D41, true, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(textBlockAnchor38);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D47);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        java.lang.Number number4 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1L + "'", number3.equals(1L));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.lang.Object obj3 = valueMarker1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        boolean boolean9 = categoryPlot8.isRangeZoomable();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        java.awt.Stroke stroke11 = valueMarker1.getStroke();
        valueMarker1.setValue((-1.0d));
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleConstraint[RectangleConstraintType.RANGE: width=-1.0, height=0.05]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setDomainAxisLocation(axisLocation25, true);
        boolean boolean28 = categoryPlot24.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot24.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot24.getDataset();
        categoryPlot24.setAnchorValue((double) '#', false);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis36.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        double double42 = rectangleInsets40.calculateLeftOutset((double) (byte) -1);
        double double44 = rectangleInsets40.calculateRightInset((double) 100.0f);
        numberAxis36.setLabelInsets(rectangleInsets40);
        categoryPlot24.setAxisOffset(rectangleInsets40);
        textTitle15.setPadding(rectangleInsets40);
        java.lang.String str48 = textTitle15.getText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "ThreadContext" + "'", str48.equals("ThreadContext"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle1.setVerticalAlignment(verticalAlignment3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle1.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis8.setUpperBound((double) 8);
        numberAxis8.resizeRange((double) 100);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int14 = color13.getTransparency();
        int int15 = color13.getAlpha();
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.RendererState rendererState20 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color13.createContext(colorModel16, rectangle17, rectangle2D21, affineTransform22, renderingHints23);
        numberAxis8.setUpArrow((java.awt.Shape) rectangle2D21);
        boolean boolean26 = legendTitle1.equals((java.lang.Object) numberAxis8);
        org.junit.Assert.assertNotNull(verticalAlignment3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        float float9 = numberAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        numberAxis1.setTickUnit(numberTickUnit11, false, true);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        boolean boolean20 = categoryPlot19.isRangeZoomable();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets();
        double double24 = rectangleInsets22.calculateLeftOutset((double) (byte) -1);
        double double26 = rectangleInsets22.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        org.jfree.chart.renderer.RendererState rendererState29 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo28.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets22.createOutsetRectangle(rectangle2D30, true, true);
        categoryPlot19.drawBackgroundImage(graphics2D21, rectangle2D33);
        numberAxis1.setRightArrow((java.awt.Shape) rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        boolean boolean3 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis6.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double12 = rectangleInsets10.calculateLeftOutset((double) (byte) -1);
        double double14 = rectangleInsets10.calculateRightInset((double) 100.0f);
        numberAxis6.setLabelInsets(rectangleInsets10);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.plot.Plot plot21 = categoryPlot20.getRootPlot();
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        java.awt.Color color23 = java.awt.Color.GREEN;
        categoryPlot20.setRangeGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot20.getRenderer(0);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        categoryPlot20.setDataset(categoryDataset27);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot20.getFixedLegendItems();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot20.getDomainMarkers(layer30);
        try {
            barRenderer0.addAnnotation(categoryAnnotation4, layer30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(categoryItemRenderer26);
        org.junit.Assert.assertNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        int int9 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem14 = barRenderer11.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape15 = barRenderer11.getBaseShape();
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer11.setSeriesOutlineStroke((int) (short) 0, stroke17);
        barRenderer11.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer11.getNegativeItemLabelPositionFallback();
        categoryPlot4.setRenderer(1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem27 = barRenderer24.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape28 = barRenderer24.getBaseShape();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer24.setSeriesOutlineStroke((int) (short) 0, stroke30);
        barRenderer24.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo34);
        org.jfree.chart.renderer.RendererState rendererState36 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo35);
        java.awt.geom.Rectangle2D rectangle2D37 = plotRenderingInfo35.getDataArea();
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D37, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.clone(shape41);
        barRenderer24.setBaseShape(shape42);
        java.lang.Boolean boolean45 = barRenderer24.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier47 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke48 = defaultDrawingSupplier47.getNextOutlineStroke();
        barRenderer24.setSeriesOutlineStroke((int) ' ', stroke48);
        barRenderer11.setBaseOutlineStroke(stroke48);
        java.awt.Shape shape52 = barRenderer11.lookupSeriesShape(10);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(itemLabelPosition21);
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(boolean45);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(shape52);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) (byte) -1);
        double double16 = rectangleInsets12.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets12.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        axisState24.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        axisState29.moveCursor(0.0d, rectangleEdge31);
        axisState24.moveCursor((double) 100L, rectangleEdge31);
        java.util.List list35 = categoryAxis5.refreshTicks(graphics2D10, axisState11, rectangle2D20, rectangleEdge31);
        categoryAxis5.setCategoryLabelPositionOffset(100);
        categoryAxis5.setUpperMargin(2.0d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, (-0.25d), 54.0d, (-0.25d));
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis6.setRange(1.0d, (double) (byte) 10);
        boolean boolean10 = numberAxis6.isVerticalTickLabels();
        numberAxis6.setLabel("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        boolean boolean13 = blockBorder4.equals((java.lang.Object) numberAxis6);
        boolean boolean14 = numberAxis6.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        categoryPlot4.setWeight((int) (short) 0);
        int int7 = categoryPlot4.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleEdge.LEFT");
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom(100.0d);
        double double3 = axisSpace0.getRight();
        java.lang.Object obj4 = axisSpace0.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getCopyright();
        java.lang.String str2 = basicProjectInfo0.getLicenceName();
        java.lang.String str3 = basicProjectInfo0.getVersion();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("-100,35,-35,35,-35,100,35,100,35,35,100,35,100,-35,35,-35,35,-100,-35,-100,-35,-35,-100,-35,-100,-35", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font4);
        labelBlock5.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock5.setURLText("");
        java.awt.Font font13 = labelBlock5.getFont();
        boolean boolean14 = verticalAlignment2.equals((java.lang.Object) font13);
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle1.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle1.getPadding();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem19 = barRenderer16.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer16.setBaseSeriesVisibleInLegend(false);
        java.awt.Stroke stroke23 = barRenderer16.lookupSeriesOutlineStroke(0);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.lang.Boolean boolean26 = barRenderer16.getSeriesCreateEntities(0);
        barRenderer16.setAutoPopulateSeriesFillPaint(false);
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color32 = java.awt.Color.BLUE;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("{0}", font31, (java.awt.Paint) color32);
        barRenderer16.setSeriesItemLabelFont(4, font31, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = null;
        barRenderer16.setLegendItemURLGenerator(categorySeriesLabelGenerator36);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(boolean26);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font3);
        labelBlock4.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock4.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) labelBlock4, (java.lang.Object) axisLocation15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.axis.AxisLocation cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getDataArea();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D3, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        boolean boolean11 = legendItemEntity9.equals((java.lang.Object) "RectangleEdge.BOTTOM");
        org.jfree.data.general.Dataset dataset12 = legendItemEntity9.getDataset();
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(dataset12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (byte) 10, (double) 500, (double) (byte) 1, 0.0d);
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        java.awt.Shape shape9 = numberAxis1.getUpArrow();
        java.awt.Shape shape10 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor4 = valueMarker3.getLabelTextAnchor();
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker3.setOutlineStroke(stroke5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker3, jFreeChart7, (int) (byte) 0, (int) (byte) 100);
        org.jfree.chart.text.TextAnchor textAnchor11 = valueMarker3.getLabelTextAnchor();
        boolean boolean12 = lineBorder0.equals((java.lang.Object) valueMarker3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        categoryPlot4.setWeight(192);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot4.getRenderer(8);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        labelBlock2.setURLText("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean15 = labelBlock2.equals((java.lang.Object) valueMarker14);
        java.lang.Class class16 = null;
        try {
            java.util.EventListener[] eventListenerArray17 = valueMarker14.getListeners(class16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        projectInfo0.setLicenceText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        projectInfo0.setLicenceName("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        java.lang.String str6 = projectInfo0.getVersion();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets7.createOutsetRectangle(rectangle2D15, true, true);
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D18);
        int int20 = categoryPlot4.getDatasetCount();
        boolean boolean21 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Paint paint23 = categoryPlot4.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getDataArea();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D3, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray14, numberArray16, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ClassContext", "null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", numberArray19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity23 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "ClassContext", "ThreadContext", categoryDataset20, (java.lang.Comparable) 132.5d, (java.lang.Comparable) 8.0d);
        try {
            java.lang.Number number24 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset20);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float1 = categoryLabelPosition0.getWidthRatio();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.95f + "'", float1 == 0.95f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) 100L, (float) 2, 100.0f);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) -1);
        double double4 = rectangleInsets0.calculateRightInset((double) 100.0f);
        double double6 = rectangleInsets0.extendWidth((double) '4');
        org.jfree.chart.util.Size2D size2D9 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = categoryLabelPosition14.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D16 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D9, (double) (byte) 0, 0.0d, rectangleAnchor15);
        java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets0.createInsetRectangle(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 54.0d + "'", double6 == 54.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker1, jFreeChart5, (int) (byte) 0, (int) (byte) 100);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot15.setDomainAxisLocation(axisLocation16, true);
        boolean boolean19 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) categoryPlot15, true);
        jFreeChart23.clearSubtitles();
        chartProgressEvent8.setChart(jFreeChart23);
        chartProgressEvent8.setType((int) (byte) 100);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) (byte) 1, (int) (short) 10);
        java.awt.Image image18 = jFreeChart14.getBackgroundImage();
        java.awt.RenderingHints renderingHints19 = null;
        try {
            jFreeChart14.setRenderingHints(renderingHints19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNull(image18);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        categoryPlot4.clearDomainMarkers();
        java.awt.Color color21 = java.awt.Color.WHITE;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color21);
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        double double24 = axisSpace23.getRight();
        java.lang.String str25 = axisSpace23.toString();
        categoryPlot4.setFixedDomainAxisSpace(axisSpace23);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        labelBlock2.setURLText("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(1.0d);
        boolean boolean15 = labelBlock2.equals((java.lang.Object) valueMarker14);
        java.awt.Paint paint16 = labelBlock2.getPaint();
        org.jfree.chart.block.BlockFrame blockFrame17 = labelBlock2.getFrame();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(blockFrame17);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 100);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = valueMarker6.getLabelTextAnchor();
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker6.setStroke(stroke10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker6.setLabelOffsetType(lengthAdjustmentType13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker6.setLabelTextAnchor(textAnchor15);
        org.jfree.chart.axis.CategoryTick categoryTick18 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100.0f, textBlock1, textBlockAnchor3, textAnchor15, (double) 0.0f);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = categoryTick18.getLabelAnchor();
        java.lang.String str20 = categoryTick18.getText();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem24 = barRenderer21.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape25 = barRenderer21.getBaseShape();
        barRenderer21.setMaximumBarWidth((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = barRenderer21.getItemLabelGenerator((int) 'a', 192);
        barRenderer21.setAutoPopulateSeriesFillPaint(true);
        boolean boolean33 = categoryTick18.equals((java.lang.Object) barRenderer21);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot4.getDomainGridlinePosition();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot4.setRangeCrosshairStroke(stroke16);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getTransparency();
        int int2 = color0.getAlpha();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem12 = barRenderer9.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape13 = barRenderer9.getBaseShape();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer9.setSeriesOutlineStroke((int) (short) 0, stroke15);
        barRenderer9.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer9.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font23);
        labelBlock24.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock24.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color35 = java.awt.Color.orange;
        int int36 = color35.getBlue();
        labelBlock24.setPaint((java.awt.Paint) color35);
        barRenderer9.setBasePaint((java.awt.Paint) color35, false);
        java.awt.Color color40 = java.awt.Color.YELLOW;
        float[] floatArray44 = new float[] { 10, '#', (short) -1 };
        float[] floatArray45 = color40.getRGBColorComponents(floatArray44);
        float[] floatArray46 = color35.getColorComponents(floatArray44);
        float[] floatArray47 = color8.getColorComponents(floatArray44);
        float[] floatArray48 = java.awt.Color.RGBtoHSB(1, 0, (int) ' ', floatArray47);
        try {
            float[] floatArray49 = color0.getComponents(colorSpace4, floatArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        barRenderer0.setSeriesCreateEntities(192, (java.lang.Boolean) true);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = barRenderer0.getPlot();
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        barRenderer0.setSeriesOutlinePaint(0, (java.awt.Paint) color10, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) (byte) 1, (int) (short) 10);
        java.awt.Image image18 = jFreeChart14.getBackgroundImage();
        boolean boolean19 = jFreeChart14.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart14.createBufferedImage((-8388608), 0, (double) (byte) 0, 0.0d, chartRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-8388608) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(bufferedImage17);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        numberAxis1.resizeRange(0.5d, (double) 0.5f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        int int5 = barRenderer0.getRowCount();
        java.awt.Stroke stroke7 = barRenderer0.getSeriesStroke(3);
        java.awt.Paint paint10 = barRenderer0.getItemFillPaint(500, (int) (byte) 100);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        barRenderer0.setMaximumBarWidth((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator((int) 'a', 192);
        java.awt.Paint paint10 = barRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis7.setRange(1.0d, (double) (byte) 10);
        boolean boolean11 = numberAxis7.isVerticalTickLabels();
        double double12 = numberAxis7.getLowerBound();
        numberAxis7.setVisible(true);
        float float15 = numberAxis7.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        numberAxis7.setTickUnit(numberTickUnit17, false, true);
        numberAxis1.setTickUnit(numberTickUnit17);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity26 = new org.jfree.chart.entity.TickLabelEntity(shape23, "org.jfree.data.general.DatasetChangeEvent[source= ]", "");
        int int27 = numberTickUnit17.compareTo((java.lang.Object) shape23);
        int int28 = numberTickUnit17.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) '#');
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "", "hi!");
        centerArrangement1.add((org.jfree.chart.block.Block) labelBlock3, (java.lang.Object) "");
        java.lang.Object obj11 = null;
        flowArrangement0.add((org.jfree.chart.block.Block) labelBlock3, obj11);
        flowArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        java.util.List list15 = blockContainer14.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame16 = blockContainer14.getFrame();
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("CategoryLabelWidthType.CATEGORY");
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer14, (java.lang.Object) textFragment18);
        org.jfree.chart.LegendItemSource legendItemSource20 = null;
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle(legendItemSource20);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle21);
        java.lang.Object obj23 = legendTitle21.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle21.setLegendItemGraphicLocation(rectangleAnchor24);
        java.awt.Paint paint26 = null;
        legendTitle21.setBackgroundPaint(paint26);
        java.awt.Paint paint28 = legendTitle21.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis30.setRange(1.0d, (double) (byte) 10);
        boolean boolean34 = numberAxis30.getAutoRangeIncludesZero();
        java.awt.Stroke stroke35 = numberAxis30.getAxisLineStroke();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle21, (java.lang.Object) stroke35);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(blockFrame16);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        int int31 = barRenderer0.getColumnCount();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis35.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener39 = null;
        numberAxis35.removeChangeListener(axisChangeListener39);
        java.awt.Shape shape41 = numberAxis35.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis43.setRange(1.0d, (double) (byte) 10);
        boolean boolean47 = numberAxis43.getAutoRangeIncludesZero();
        java.awt.Stroke stroke48 = numberAxis43.getAxisLineStroke();
        numberAxis35.setAxisLineStroke(stroke48);
        barRenderer0.setSeriesStroke(15, stroke48, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(categoryURLGenerator32);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font4);
        labelBlock5.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock5.setURLText("");
        java.awt.Font font13 = labelBlock5.getFont();
        boolean boolean14 = verticalAlignment2.equals((java.lang.Object) font13);
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle1.getMargin();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = legendTitle1.getPosition();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) (byte) -1);
        double double16 = rectangleInsets12.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets12.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        axisState24.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        axisState29.moveCursor(0.0d, rectangleEdge31);
        axisState24.moveCursor((double) 100L, rectangleEdge31);
        java.util.List list35 = categoryAxis5.refreshTicks(graphics2D10, axisState11, rectangle2D20, rectangleEdge31);
        categoryAxis5.setCategoryLabelPositionOffset(100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions38 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition40 = categoryLabelPositions38.getLabelPosition(rectangleEdge39);
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions38);
        int int42 = categoryAxis5.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(categoryLabelPositions38);
        org.junit.Assert.assertNull(categoryLabelPosition40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("RectangleEdge.RIGHT");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("");
        java.lang.Object[][] objArray5 = jFreeChartResources0.getContents();
        try {
            java.lang.String[] strArray7 = jFreeChartResources0.getStringArray("null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.lang.Object obj3 = valueMarker1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis5.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.calculateLeftOutset((double) (byte) -1);
        double double13 = rectangleInsets9.calculateRightInset((double) 100.0f);
        numberAxis5.setLabelInsets(rectangleInsets9);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        org.jfree.chart.plot.Plot plot20 = categoryPlot19.getRootPlot();
        numberAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        categoryPlot19.setRangeGridlinePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot19.getRenderer(0);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot19.setDataset(categoryDataset26);
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot19);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(plot20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(categoryItemRenderer25);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        org.jfree.chart.block.BlockFrame blockFrame2 = blockContainer0.getFrame();
        java.util.List list3 = blockContainer0.getBlocks();
        org.jfree.chart.block.Arrangement arrangement4 = blockContainer0.getArrangement();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(blockFrame2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(arrangement4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        numberAxis1.setTickMarkInsideLength((float) (short) 0);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis12.setRange(1.0d, (double) (byte) 10);
        boolean boolean16 = numberAxis12.isVerticalTickLabels();
        boolean boolean17 = numberAxis12.isPositiveArrowVisible();
        org.jfree.data.Range range18 = numberAxis12.getDefaultAutoRange();
        java.lang.String str19 = range18.toString();
        numberAxis1.setDefaultAutoRange(range18);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[0.0,1.0]" + "'", str19.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(1.0d, numberFormat1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        boolean boolean2 = blockContainer0.equals((java.lang.Object) axisLocation1);
        java.awt.Font font5 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.awt.Paint paint9 = labelBlock8.getPaint();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("hi!", font5, paint9, 100.0f);
        java.awt.Paint paint12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint12);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(paint12);
        boolean boolean15 = blockContainer0.equals((java.lang.Object) blockBorder14);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        try {
            keyedObjects2D0.removeColumn(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font8);
        java.awt.Color color10 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font8, (java.awt.Paint) color10);
        numberAxis2.setTickLabelFont(font8);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str20 = categoryAxis18.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot17.setDomainAxis(categoryAxis18);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot17.setDataset(10, categoryDataset23);
        org.jfree.chart.plot.Plot plot25 = categoryPlot17.getParent();
        categoryPlot17.configureRangeAxes();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ", font8, (org.jfree.chart.plot.Plot) categoryPlot17, true);
        try {
            org.jfree.chart.plot.XYPlot xYPlot29 = jFreeChart28.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(plot25);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        double double6 = numberAxis1.getFixedAutoRange();
        boolean boolean7 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) (byte) -1);
        double double16 = rectangleInsets12.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets12.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        axisState24.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        axisState29.moveCursor(0.0d, rectangleEdge31);
        axisState24.moveCursor((double) 100L, rectangleEdge31);
        java.util.List list35 = categoryAxis5.refreshTicks(graphics2D10, axisState11, rectangle2D20, rectangleEdge31);
        double double36 = axisState11.getCursor();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle2);
        java.lang.Object obj4 = legendTitle2.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = legendTitle2.getPosition();
        boolean boolean8 = gradientPaintTransformType0.equals((java.lang.Object) legendTitle2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        categoryPlot4.setAnchorValue((double) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 'a', 0.5f);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        java.lang.Comparable comparable4 = legendItemEntity3.getSeriesKey();
        java.lang.Comparable comparable5 = legendItemEntity3.getSeriesKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(comparable4);
        org.junit.Assert.assertNull(comparable5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        int int31 = barRenderer0.getColumnCount();
        boolean boolean33 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator35 = barRenderer0.getSeriesItemLabelGenerator((int) (byte) 1);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator35);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        org.jfree.data.Range range7 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font9 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font11);
        java.awt.Paint paint13 = labelBlock12.getPaint();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font9, paint13, 100.0f);
        java.awt.Paint paint16 = textFragment15.getPaint();
        numberAxis1.setTickMarkPaint(paint16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets();
        double double20 = rectangleInsets18.calculateLeftOutset((double) (byte) -1);
        double double22 = rectangleInsets18.calculateRightInset((double) 100.0f);
        numberAxis1.setTickLabelInsets(rectangleInsets18);
        boolean boolean24 = numberAxis1.isVisible();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis26.setRange(1.0d, (double) (byte) 10);
        boolean boolean30 = numberAxis26.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis32.setRange(1.0d, (double) (byte) 10);
        boolean boolean36 = numberAxis32.isVerticalTickLabels();
        double double37 = numberAxis32.getLowerBound();
        numberAxis32.setVisible(true);
        org.jfree.chart.axis.TickUnits tickUnits40 = new org.jfree.chart.axis.TickUnits();
        numberAxis32.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits40);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo42 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str43 = basicProjectInfo42.getCopyright();
        java.lang.String str44 = basicProjectInfo42.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray45 = basicProjectInfo42.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo46 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray47 = basicProjectInfo46.getOptionalLibraries();
        basicProjectInfo46.setLicenceName("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        basicProjectInfo42.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo46);
        boolean boolean51 = tickUnits40.equals((java.lang.Object) basicProjectInfo42);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis53.setRange(1.0d, (double) (byte) 10);
        boolean boolean57 = numberAxis53.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis59.setRange(1.0d, (double) (byte) 10);
        boolean boolean63 = numberAxis59.isVerticalTickLabels();
        double double64 = numberAxis59.getLowerBound();
        numberAxis59.setVisible(true);
        float float67 = numberAxis59.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit69 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        numberAxis59.setTickUnit(numberTickUnit69, false, true);
        numberAxis53.setTickUnit(numberTickUnit69);
        tickUnits40.add((org.jfree.chart.axis.TickUnit) numberTickUnit69);
        numberAxis26.setTickUnit(numberTickUnit69);
        numberAxis1.setTickUnit(numberTickUnit69, false, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(libraryArray45);
        org.junit.Assert.assertNotNull(libraryArray47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 2.0f + "'", float67 == 2.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setUpperBound((double) 8);
        numberAxis2.resizeRange((double) 100);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        java.awt.Font font8 = numberAxis2.getLabelFont();
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ", font8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getFirstTextFragment();
        java.lang.String str11 = textFragment10.getText();
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartEntity: tooltip = " + "'", str11.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.lang.String str2 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str2.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font7 = numberAxis1.getLabelFont();
        java.awt.Paint paint8 = numberAxis1.getTickMarkPaint();
        numberAxis1.setLabelAngle(271.0d);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis1.setLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) -1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font4);
        labelBlock5.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock5.setURLText("");
        java.awt.Font font13 = labelBlock5.getFont();
        boolean boolean14 = verticalAlignment2.equals((java.lang.Object) font13);
        legendTitle1.setVerticalAlignment(verticalAlignment2);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        boolean boolean22 = categoryPlot21.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot21);
        jFreeChart23.setBorderVisible(false);
        boolean boolean26 = jFreeChart23.isNotify();
        boolean boolean27 = legendTitle1.equals((java.lang.Object) boolean26);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.setCursor((double) 4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) 'a');
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (byte) 0, 0.0d);
        int int6 = objectList0.indexOf((java.lang.Object) range5);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem7 = barRenderer4.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape8 = barRenderer4.getBaseShape();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer4.setSeriesOutlineStroke((int) (short) 0, stroke10);
        java.awt.Paint paint14 = barRenderer4.getItemFillPaint(0, (int) '#');
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 1.0f, 0.0d, (-0.25d), (double) 0.0f, paint14);
        java.awt.Paint paint16 = blockBorder15.getPaint();
        org.junit.Assert.assertNull(legendItem7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        double double3 = valueMarker1.getValue();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = valueMarker1.getLabelOffsetType();
        java.awt.Paint paint8 = valueMarker1.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        valueMarker1.notifyListeners(markerChangeEvent9);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        float float20 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem24 = barRenderer21.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape25 = barRenderer21.getBaseShape();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer21.setSeriesOutlineStroke((int) (short) 0, stroke27);
        barRenderer21.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer21.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("", font35);
        labelBlock36.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock36.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color47 = java.awt.Color.orange;
        int int48 = color47.getBlue();
        labelBlock36.setPaint((java.awt.Paint) color47);
        barRenderer21.setBasePaint((java.awt.Paint) color47, false);
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color47);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor54 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str55 = categoryAnchor54.toString();
        categoryPlot4.setDomainGridlinePosition(categoryAnchor54);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent59 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle58);
        java.lang.Object obj60 = legendTitle58.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle58.setLegendItemGraphicLocation(rectangleAnchor61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment63 = legendTitle58.getHorizontalAlignment();
        boolean boolean64 = categoryAnchor54.equals((java.lang.Object) legendTitle58);
        java.awt.Font font71 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock72 = new org.jfree.chart.block.LabelBlock("", font71);
        java.awt.Color color73 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine74 = new org.jfree.chart.text.TextLine("hi!", font71, (java.awt.Paint) color73);
        org.jfree.chart.block.BlockBorder blockBorder75 = new org.jfree.chart.block.BlockBorder(1.0d, (double) (-1.0f), (double) 0, 100.0d, (java.awt.Paint) color73);
        legendTitle58.setFrame((org.jfree.chart.block.BlockFrame) blockBorder75);
        java.lang.Object obj77 = legendTitle58.clone();
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(categoryAnchor54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "CategoryAnchor.END" + "'", str55.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(horizontalAlignment63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(obj77);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setUpperBound((double) 8);
        numberAxis2.resizeRange((double) 100);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        java.awt.Font font8 = numberAxis2.getLabelFont();
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ", font8);
        org.jfree.chart.text.TextFragment textFragment10 = textLine9.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment11 = textLine9.getFirstTextFragment();
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(textFragment10);
        org.junit.Assert.assertNotNull(textFragment11);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis2.setRange(1.0d, (double) (byte) 10);
        boolean boolean6 = numberAxis2.isVerticalTickLabels();
        boolean boolean7 = numberAxis2.isPositiveArrowVisible();
        org.jfree.data.Range range8 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis10.setRange(1.0d, (double) (byte) 10);
        boolean boolean14 = numberAxis10.isVerticalTickLabels();
        boolean boolean15 = numberAxis10.isPositiveArrowVisible();
        org.jfree.data.Range range16 = numberAxis10.getDefaultAutoRange();
        double double17 = range16.getCentralValue();
        numberAxis2.setRangeWithMargins(range16, false, true);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot27.setDomainAxisLocation(axisLocation28, true);
        boolean boolean31 = categoryPlot27.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot27.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("ThreadContext", font22, (org.jfree.chart.plot.Plot) categoryPlot27, true);
        org.jfree.chart.title.TextTitle textTitle36 = jFreeChart35.getTitle();
        java.awt.Paint paint37 = textTitle36.getBackgroundPaint();
        textTitle36.setText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.lang.Object obj43 = textTitle36.draw(graphics2D40, rectangle2D41, (java.lang.Object) lengthConstraintType42);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis46.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.axis.AxisCollection axisCollection50 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection50.add((org.jfree.chart.axis.Axis) numberAxis51, rectangleEdge52);
        org.jfree.chart.axis.TickUnitSource tickUnitSource54 = numberAxis51.getStandardTickUnits();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo55);
        org.jfree.chart.renderer.RendererState rendererState57 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = plotRenderingInfo56.getDataArea();
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D58, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.clone(shape62);
        numberAxis51.setUpArrow(shape63);
        double double65 = numberAxis51.getLabelAngle();
        numberAxis51.setFixedDimension((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis69.setUpperBound((double) 8);
        numberAxis69.resizeRange((double) 100);
        org.jfree.data.Range range74 = numberAxis69.getDefaultAutoRange();
        numberAxis51.setDefaultAutoRange(range74);
        double double76 = range74.getLength();
        numberAxis46.setRangeWithMargins(range74, false, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint81 = new org.jfree.chart.block.RectangleConstraint(range74, (double) 8);
        org.jfree.data.Range range82 = null;
        org.jfree.data.Range range83 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint84 = new org.jfree.chart.block.RectangleConstraint(range82, range83);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType85 = rectangleConstraint84.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint86 = new org.jfree.chart.block.RectangleConstraint(132.5d, range16, lengthConstraintType42, (double) 255, range74, lengthConstraintType85);
        org.jfree.data.Range range89 = org.jfree.data.Range.expand(range16, (double) 2.0f, 100.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(textTitle36);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(tickUnitSource54);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType85);
        org.junit.Assert.assertNotNull(range89);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        numberAxis1.removeChangeListener(axisChangeListener5);
        java.awt.Shape shape7 = numberAxis1.getRightArrow();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis9.setRange(1.0d, (double) (byte) 10);
        boolean boolean13 = numberAxis9.getAutoRangeIncludesZero();
        java.awt.Stroke stroke14 = numberAxis9.getAxisLineStroke();
        numberAxis1.setAxisLineStroke(stroke14);
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        java.lang.Object obj16 = textTitle15.clone();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        textTitle15.setBackgroundPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        int int5 = barRenderer0.getRowCount();
        barRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setPositiveArrowVisible(true);
        boolean boolean3 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor21 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor21, textAnchor22, textAnchor23, (double) 0.5f);
        org.jfree.chart.text.TextAnchor textAnchor26 = itemLabelPosition25.getRotationAnchor();
        barRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition25);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(itemLabelAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor8 = valueMarker7.getLabelTextAnchor();
        java.awt.Stroke stroke9 = valueMarker7.getStroke();
        java.awt.Stroke stroke10 = valueMarker7.getOutlineStroke();
        categoryPlot4.setRangeCrosshairStroke(stroke10);
        categoryPlot4.setAnchorValue((double) 0.5f);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem18 = barRenderer15.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer15.setBaseSeriesVisibleInLegend(false);
        java.awt.Shape shape23 = barRenderer15.getItemShape((int) ' ', (int) (byte) 0);
        categoryPlot4.setRenderer((int) (byte) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(legendItem18);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str10 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot7.setDomainAxis(categoryAxis8);
        double double12 = categoryAxis8.getCategoryMargin();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateLeftOutset((double) (byte) -1);
        double double19 = rectangleInsets15.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.RendererState rendererState22 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets15.createOutsetRectangle(rectangle2D23, true, true);
        org.jfree.chart.axis.AxisState axisState27 = new org.jfree.chart.axis.AxisState();
        axisState27.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState32 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge34);
        axisState32.moveCursor(0.0d, rectangleEdge34);
        axisState27.moveCursor((double) 100L, rectangleEdge34);
        java.util.List list38 = categoryAxis8.refreshTicks(graphics2D13, axisState14, rectangle2D23, rectangleEdge34);
        org.jfree.chart.axis.AxisState axisState40 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean43 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge42);
        axisState40.moveCursor(0.0d, rectangleEdge42);
        java.util.List list45 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D23, rectangleEdge42);
        categoryAxis0.setLowerMargin((double) 0.0f);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions48 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor50 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition51 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor49, textBlockAnchor50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = categoryLabelPosition51.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions53 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions48, categoryLabelPosition51);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions53);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(categoryLabelPositions48);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(textBlockAnchor50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(categoryLabelPositions53);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = legendTitle1.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke11 = barRenderer0.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis14.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        numberAxis14.removeChangeListener(axisChangeListener18);
        java.awt.Shape shape20 = numberAxis14.getRightArrow();
        barRenderer0.setSeriesShape(8, shape20, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer0.getPositiveItemLabelPosition(15, 0);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("", font28);
        java.awt.Paint paint30 = labelBlock29.getPaint();
        java.awt.Font font31 = labelBlock29.getFont();
        barRenderer0.setSeriesItemLabelFont(0, font31, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("LegendItemEntity: seriesKey=null, dataset=null", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "", "RectangleEdge.BOTTOM");
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo4);
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo1.getPlotArea();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        org.junit.Assert.assertNull(rectangle2D7);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot15.getRenderer(0);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot15.setDataset(categoryDataset22);
        boolean boolean24 = categoryPlot15.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot15.getRangeAxis(101);
        java.awt.Stroke stroke27 = categoryPlot15.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categoryItemRenderer21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker1, jFreeChart5, (int) (byte) 0, (int) (byte) 100);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot15.setDomainAxisLocation(axisLocation16, true);
        boolean boolean19 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) categoryPlot15, true);
        jFreeChart23.clearSubtitles();
        chartProgressEvent8.setChart(jFreeChart23);
        java.lang.Object obj26 = jFreeChart23.clone();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double3 = numberTickUnit2.getSize();
        java.lang.Object obj5 = keyedObjects2D0.getObject((java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis7.setUpperBound((double) 8);
        numberAxis7.setAutoRange(true);
        float float12 = numberAxis7.getTickMarkOutsideLength();
        boolean boolean13 = keyedObjects2D0.equals((java.lang.Object) float12);
        int int15 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        double double2 = numberAxis1.getFixedAutoRange();
        boolean boolean3 = numberAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = barRenderer0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str20 = categoryAxis18.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot17.setDomainAxis(categoryAxis18);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis25.setRange(1.0d, (double) (byte) 10);
        boolean boolean29 = numberAxis25.isVerticalTickLabels();
        double double30 = numberAxis25.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.renderer.RendererState rendererState34 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo33.getDataArea();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D35, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection40 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis42.setRange(1.0d, (double) (byte) 10);
        boolean boolean46 = numberAxis42.isVerticalTickLabels();
        boolean boolean47 = numberAxis42.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge48);
        axisCollection40.add((org.jfree.chart.axis.Axis) numberAxis42, rectangleEdge48);
        java.lang.String str51 = rectangleEdge48.toString();
        double double52 = numberAxis25.lengthToJava2D((double) 255, rectangle2D35, rectangleEdge48);
        org.jfree.chart.LegendItemSource legendItemSource53 = null;
        org.jfree.chart.title.LegendTitle legendTitle54 = new org.jfree.chart.title.LegendTitle(legendItemSource53);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent55 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle54);
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle54.setVerticalAlignment(verticalAlignment56);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = legendTitle54.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = legendTitle54.getLegendItemGraphicEdge();
        double double60 = categoryAxis18.getCategoryEnd((int) '#', 4, rectangle2D35, rectangleEdge59);
        barRenderer0.setSeriesShape((int) (short) 0, (java.awt.Shape) rectangle2D35, true);
        java.awt.Paint paint63 = barRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "RectangleEdge.RIGHT" + "'", str51.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment56);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(paint63);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer4);
        boolean boolean6 = categoryPlot5.isRangeZoomable();
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot5);
        jFreeChart7.setBorderVisible(false);
        jFreeChart7.setBackgroundImageAlignment((-1));
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateLeftOutset((double) (byte) -1);
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        double double17 = axisSpace16.getLeft();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.RendererState rendererState20 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D21, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection26 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.RIGHT;
        axisCollection26.add((org.jfree.chart.axis.Axis) numberAxis27, rectangleEdge28);
        java.awt.geom.Rectangle2D rectangle2D30 = axisSpace16.reserved(rectangle2D21, rectangleEdge28);
        java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets13.createInsetRectangle(rectangle2D21);
        try {
            jFreeChart7.draw(graphics2D12, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        categoryPlot4.setWeight(192);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot13.setDomainAxisLocation(axisLocation14, true);
        boolean boolean17 = categoryPlot13.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot13.setDatasetRenderingOrder(datasetRenderingOrder18);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("ThreadContext", font8, (org.jfree.chart.plot.Plot) categoryPlot13, true);
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart21.createBufferedImage((int) (byte) 1, (int) (short) 10);
        java.awt.Image image25 = jFreeChart21.getBackgroundImage();
        categoryPlot4.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart21);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertNull(image25);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis21.setUpperBound((double) 8);
        numberAxis21.resizeRange((double) 100);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        java.awt.Font font27 = numberAxis21.getLabelFont();
        java.awt.Paint paint28 = numberAxis21.getTickMarkPaint();
        org.jfree.data.Range range29 = categoryPlot15.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis21);
        numberAxis21.setLowerMargin((double) 1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(range29);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        double double9 = categoryAxis5.getCategoryMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateLeftOutset((double) (byte) -1);
        double double16 = rectangleInsets12.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        org.jfree.chart.renderer.RendererState rendererState19 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets12.createOutsetRectangle(rectangle2D20, true, true);
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState();
        axisState24.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState29 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        axisState29.moveCursor(0.0d, rectangleEdge31);
        axisState24.moveCursor((double) 100L, rectangleEdge31);
        java.util.List list35 = categoryAxis5.refreshTicks(graphics2D10, axisState11, rectangle2D20, rectangleEdge31);
        float float36 = categoryAxis5.getTickMarkInsideLength();
        org.jfree.data.KeyedObjects2D keyedObjects2D37 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit39 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 1);
        double double40 = numberTickUnit39.getSize();
        java.lang.Object obj42 = keyedObjects2D37.getObject((java.lang.Comparable) numberTickUnit39, (java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis5.setTickLabelFont((java.lang.Comparable) "CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ", font43);
        categoryAxis5.configure();
        categoryAxis5.setCategoryLabelPositionOffset((int) (byte) 100);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        java.lang.String str3 = labelBlock2.getURLText();
        double double4 = labelBlock2.getWidth();
        double double5 = labelBlock2.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge3);
        axisState1.moveCursor(0.0d, rectangleEdge3);
        java.util.List list6 = axisState1.getTicks();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker1, jFreeChart5, (int) (byte) 0, (int) (byte) 100);
        org.jfree.chart.JFreeChart jFreeChart9 = chartProgressEvent8.getChart();
        int int10 = chartProgressEvent8.getPercent();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(jFreeChart9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.isVerticalTickLabels();
        double double6 = numberAxis1.getLowerBound();
        numberAxis1.setVisible(true);
        numberAxis1.setTickMarkInsideLength((float) (short) 0);
        numberAxis1.setLabel("RectangleConstraint[RectangleConstraintType.RANGE: width=-1.0, height=0.05]");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem21 = barRenderer18.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape22 = barRenderer18.getBaseShape();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer18.setSeriesOutlineStroke((int) (short) 0, stroke24);
        barRenderer18.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D31, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.clone(shape35);
        barRenderer18.setBaseShape(shape36);
        java.lang.Boolean boolean39 = barRenderer18.getSeriesVisible(8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke42 = defaultDrawingSupplier41.getNextOutlineStroke();
        barRenderer18.setSeriesOutlineStroke((int) ' ', stroke42);
        categoryPlot15.setRangeGridlineStroke(stroke42);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker46.getLabelTextAnchor();
        categoryPlot15.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker46);
        try {
            valueMarker46.setAlpha((float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNull(legendItem21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(boolean39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(textAnchor47);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font14);
        labelBlock15.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock15.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color26 = java.awt.Color.orange;
        int int27 = color26.getBlue();
        labelBlock15.setPaint((java.awt.Paint) color26);
        barRenderer0.setBasePaint((java.awt.Paint) color26, false);
        int int31 = barRenderer0.getColumnCount();
        boolean boolean33 = barRenderer0.isSeriesItemLabelsVisible((int) (byte) 10);
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setSeriesItemLabelsVisible(0, false);
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor41 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor43 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor41, textAnchor42, textAnchor43, (double) 0.5f);
        org.jfree.chart.text.TextAnchor textAnchor46 = itemLabelPosition45.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition45);
        boolean boolean50 = barRenderer0.getItemVisible(100, (int) (byte) 0);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertNotNull(textAnchor46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str7 = categoryAxis5.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot4.setDomainAxis(categoryAxis5);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis12.setRange(1.0d, (double) (byte) 10);
        boolean boolean16 = numberAxis12.isVerticalTickLabels();
        double double17 = numberAxis12.getLowerBound();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo19);
        org.jfree.chart.renderer.RendererState rendererState21 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo20.getDataArea();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D22, (double) (byte) 100, (-1.0f), (float) '4');
        org.jfree.chart.axis.AxisCollection axisCollection27 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis29.setRange(1.0d, (double) (byte) 10);
        boolean boolean33 = numberAxis29.isVerticalTickLabels();
        boolean boolean34 = numberAxis29.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge35);
        axisCollection27.add((org.jfree.chart.axis.Axis) numberAxis29, rectangleEdge35);
        java.lang.String str38 = rectangleEdge35.toString();
        double double39 = numberAxis12.lengthToJava2D((double) 255, rectangle2D22, rectangleEdge35);
        org.jfree.chart.LegendItemSource legendItemSource40 = null;
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle(legendItemSource40);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent42 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.CENTER;
        legendTitle41.setVerticalAlignment(verticalAlignment43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendTitle41.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = legendTitle41.getLegendItemGraphicEdge();
        double double47 = categoryAxis5.getCategoryEnd((int) '#', 4, rectangle2D22, rectangleEdge46);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions48 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions49 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor51 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition52 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor50, textBlockAnchor51);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions53 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions49, categoryLabelPosition52);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions54 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions48, categoryLabelPosition52);
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions54);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "RectangleEdge.RIGHT" + "'", str38.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions49);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(textBlockAnchor51);
        org.junit.Assert.assertNotNull(categoryLabelPositions53);
        org.junit.Assert.assertNotNull(categoryLabelPositions54);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        boolean boolean5 = categoryPlot4.isRangeZoomable();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets();
        double double9 = rectangleInsets7.calculateLeftOutset((double) (byte) -1);
        double double11 = rectangleInsets7.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo12);
        org.jfree.chart.renderer.RendererState rendererState14 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo13.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets7.createOutsetRectangle(rectangle2D15, true, true);
        categoryPlot4.drawBackgroundImage(graphics2D6, rectangle2D18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        org.jfree.chart.renderer.RendererState rendererState24 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo23);
        boolean boolean25 = axisLocation21.equals((java.lang.Object) plotRenderingInfo23);
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot4.zoomRangeAxes((double) (byte) -1, plotRenderingInfo23, point2D26);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition30 = categoryLabelPositions28.getLabelPosition(rectangleEdge29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = categoryLabelPositions28.getLabelPosition(rectangleEdge31);
        boolean boolean34 = plotRenderingInfo23.equals((java.lang.Object) rectangleEdge31);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo23.getDataArea();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
        org.junit.Assert.assertNull(categoryLabelPosition30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.lang.Object obj3 = valueMarker1.clone();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        boolean boolean9 = categoryPlot8.isRangeZoomable();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot8);
        java.awt.Stroke stroke11 = valueMarker1.getStroke();
        java.awt.Stroke stroke12 = null;
        valueMarker1.setOutlineStroke(stroke12);
        valueMarker1.setValue(2.0d);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.plot.Plot plot5 = categoryPlot4.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        org.jfree.chart.renderer.RendererState rendererState10 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo9);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState13 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo12);
        plotRenderingInfo9.addSubplotInfo(plotRenderingInfo12);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo15);
        plotRenderingInfo12.addSubplotInfo(plotRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot4.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo12, point2D18);
        float float20 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem24 = barRenderer21.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape25 = barRenderer21.getBaseShape();
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer21.setSeriesOutlineStroke((int) (short) 0, stroke27);
        barRenderer21.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = barRenderer21.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("", font35);
        labelBlock36.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock36.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color47 = java.awt.Color.orange;
        int int48 = color47.getBlue();
        labelBlock36.setPaint((java.awt.Paint) color47);
        barRenderer21.setBasePaint((java.awt.Paint) color47, false);
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color47);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = categoryPlot4.getOrientation();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor54 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str55 = categoryAnchor54.toString();
        categoryPlot4.setDomainGridlinePosition(categoryAnchor54);
        categoryPlot4.setBackgroundAlpha((float) 15);
        org.jfree.chart.axis.AxisLocation axisLocation60 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation((int) '#', axisLocation60, false);
        org.junit.Assert.assertNotNull(plot5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNull(legendItem24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(categoryAnchor54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "CategoryAnchor.END" + "'", str55.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(axisLocation60);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.BOTTOM_LEFT", graphics2D1, (float) (short) -1, (float) (byte) 1, (double) 192, (float) '#', (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker1.setOutlineStroke(stroke3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) valueMarker1, jFreeChart5, (int) (byte) 0, (int) (byte) 100);
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot15.setDomainAxisLocation(axisLocation16, true);
        boolean boolean19 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder20);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("ThreadContext", font10, (org.jfree.chart.plot.Plot) categoryPlot15, true);
        jFreeChart23.clearSubtitles();
        chartProgressEvent8.setChart(jFreeChart23);
        java.awt.Color color26 = java.awt.Color.green;
        jFreeChart23.setBackgroundPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        org.jfree.chart.plot.Plot plot10 = categoryPlot9.getRootPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.chart.renderer.RendererState rendererState15 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState18 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo17);
        plotRenderingInfo14.addSubplotInfo(plotRenderingInfo17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        plotRenderingInfo17.addSubplotInfo(plotRenderingInfo21);
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot9.zoomDomainAxes((double) 2, 100.0d, plotRenderingInfo17, point2D23);
        float float25 = categoryPlot9.getForegroundAlpha();
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem29 = barRenderer26.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape30 = barRenderer26.getBaseShape();
        java.awt.Stroke stroke32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer26.setSeriesOutlineStroke((int) (short) 0, stroke32);
        barRenderer26.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = barRenderer26.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock41 = new org.jfree.chart.block.LabelBlock("", font40);
        labelBlock41.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        labelBlock41.setMargin(0.0d, 1.0d, (double) 255, (double) '#');
        java.awt.Color color52 = java.awt.Color.orange;
        int int53 = color52.getBlue();
        labelBlock41.setPaint((java.awt.Paint) color52);
        barRenderer26.setBasePaint((java.awt.Paint) color52, false);
        categoryPlot9.setDomainGridlinePaint((java.awt.Paint) color52);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot9);
        java.awt.Font font59 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator60 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator60, true);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNull(legendItem29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        barRenderer0.setMaximumBarWidth((double) 100.0f);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker5.getLabelTextAnchor();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker5.setOutlineStroke(stroke7);
        numberAxis1.setTickMarkStroke(stroke7);
        boolean boolean10 = numberAxis1.isPositiveArrowVisible();
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 10L);
        numberAxis1.setLeftArrow(shape13);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(markerAxisBand15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getDataArea();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D3, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 1.0f };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray14, numberArray16, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ClassContext", "null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", numberArray19);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity23 = new org.jfree.chart.entity.CategoryItemEntity(shape8, "ClassContext", "ThreadContext", categoryDataset20, (java.lang.Comparable) 132.5d, (java.lang.Comparable) 8.0d);
        org.jfree.data.KeyToGroupMap keyToGroupMap24 = null;
        try {
            org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset20, keyToGroupMap24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        categoryPlot4.setAnchorValue((double) '#', false);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis16.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets();
        double double22 = rectangleInsets20.calculateLeftOutset((double) (byte) -1);
        double double24 = rectangleInsets20.calculateRightInset((double) 100.0f);
        numberAxis16.setLabelInsets(rectangleInsets20);
        categoryPlot4.setAxisOffset(rectangleInsets20);
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot4.getDataset(0);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNull(categoryDataset28);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str10 = categoryAxis8.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot7.setDomainAxis(categoryAxis8);
        double double12 = categoryAxis8.getCategoryMargin();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets();
        double double17 = rectangleInsets15.calculateLeftOutset((double) (byte) -1);
        double double19 = rectangleInsets15.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.chart.renderer.RendererState rendererState22 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo21.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets15.createOutsetRectangle(rectangle2D23, true, true);
        org.jfree.chart.axis.AxisState axisState27 = new org.jfree.chart.axis.AxisState();
        axisState27.cursorRight((double) (short) 100);
        org.jfree.chart.axis.AxisState axisState32 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge34);
        axisState32.moveCursor(0.0d, rectangleEdge34);
        axisState27.moveCursor((double) 100L, rectangleEdge34);
        java.util.List list38 = categoryAxis8.refreshTicks(graphics2D13, axisState14, rectangle2D23, rectangleEdge34);
        org.jfree.chart.axis.AxisState axisState40 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean43 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge42);
        axisState40.moveCursor(0.0d, rectangleEdge42);
        java.util.List list45 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D23, rectangleEdge42);
        categoryAxis0.setLowerMargin((double) 0.0f);
        double double48 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        boolean boolean5 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity(shape7, "org.jfree.data.general.DatasetChangeEvent[source= ]", "");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        org.jfree.chart.renderer.RendererState rendererState13 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = plotRenderingInfo12.getDataArea();
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D14, (double) (byte) 100, (-1.0f), (float) '4');
        boolean boolean19 = org.jfree.chart.util.ShapeUtilities.equal(shape7, shape18);
        numberAxis1.setLeftArrow(shape18);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot27.setDomainAxisLocation(axisLocation28, true);
        boolean boolean31 = categoryPlot27.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot27.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("ThreadContext", font22, (org.jfree.chart.plot.Plot) categoryPlot27, true);
        java.awt.Color color36 = java.awt.Color.orange;
        int int37 = color36.getBlue();
        jFreeChart35.setBackgroundPaint((java.awt.Paint) color36);
        numberAxis1.setAxisLinePaint((java.awt.Paint) color36);
        java.awt.Paint paint40 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.plot.Plot plot41 = numberAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(plot41);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis3.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font9);
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("hi!", font9, (java.awt.Paint) color11);
        numberAxis3.setTickLabelFont(font9);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str21 = categoryAxis19.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot18.setDomainAxis(categoryAxis19);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot18.setDataset(10, categoryDataset24);
        org.jfree.chart.plot.Plot plot26 = categoryPlot18.getParent();
        categoryPlot18.configureRangeAxes();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ", font9, (org.jfree.chart.plot.Plot) categoryPlot18, true);
        org.jfree.chart.block.LabelBlock labelBlock30 = new org.jfree.chart.block.LabelBlock("CategoryLabelWidthType.CATEGORY", font9);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(plot26);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(1.0d);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker5.getLabelTextAnchor();
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        valueMarker5.setOutlineStroke(stroke7);
        numberAxis1.setTickMarkStroke(stroke7);
        boolean boolean10 = numberAxis1.isPositiveArrowVisible();
        boolean boolean11 = numberAxis1.isNegativeArrowVisible();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 10L);
        numberAxis1.setLeftArrow(shape13);
        numberAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot4.setDomainAxisLocation(axisLocation5, true);
        boolean boolean8 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot4.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        categoryPlot4.setDataset(categoryDataset12);
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot4.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot4.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem19 = barRenderer16.getLegendItem((int) 'a', (int) (byte) 10);
        barRenderer16.setBaseSeriesVisibleInLegend(false);
        java.awt.Stroke stroke23 = barRenderer16.lookupSeriesOutlineStroke(0);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        java.awt.Paint paint27 = barRenderer16.getItemLabelPaint((-8388608), (int) (byte) 100);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNull(legendItem19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.renderer.RendererState rendererState12 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo11.getDataArea();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.rotateShape((java.awt.Shape) rectangle2D13, (double) (byte) 100, (-1.0f), (float) '4');
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem23 = barRenderer20.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape24 = barRenderer20.getBaseShape();
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer20.setSeriesOutlineStroke((int) (short) 0, stroke26);
        barRenderer20.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor31, textAnchor32, textAnchor33, (double) 0.5f);
        barRenderer20.setSeriesPositiveItemLabelPosition(0, itemLabelPosition35);
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition35);
        java.awt.Shape shape40 = barRenderer0.getItemShape((int) ' ', 0);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(legendItem23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(shape40);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        org.jfree.chart.title.TextTitle textTitle15 = jFreeChart14.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getTextAlignment();
        textTitle15.setExpandToFitSpace(false);
        java.awt.Paint paint19 = textTitle15.getPaint();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot24.setDomainAxisLocation(axisLocation25, true);
        boolean boolean28 = categoryPlot24.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot24.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot24.getDataset();
        categoryPlot24.setAnchorValue((double) '#', false);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis36.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        double double42 = rectangleInsets40.calculateLeftOutset((double) (byte) -1);
        double double44 = rectangleInsets40.calculateRightInset((double) 100.0f);
        numberAxis36.setLabelInsets(rectangleInsets40);
        categoryPlot24.setAxisOffset(rectangleInsets40);
        textTitle15.setPadding(rectangleInsets40);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean49 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge48);
        java.lang.String str50 = rectangleEdge48.toString();
        textTitle15.setPosition(rectangleEdge48);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(textTitle15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "RectangleEdge.BOTTOM" + "'", str50.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("", font1);
        labelBlock2.setPadding((double) 0, (double) 2, (double) ' ', (double) (-1L));
        java.awt.Color color8 = java.awt.Color.YELLOW;
        int int9 = color8.getAlpha();
        labelBlock2.setPaint((java.awt.Paint) color8);
        labelBlock2.setURLText("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateLeftOutset((double) (byte) -1);
        double double17 = rectangleInsets13.calculateRightInset((double) 100.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.RendererState rendererState20 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets13.createOutsetRectangle(rectangle2D21, true, true);
        labelBlock2.setPadding(rectangleInsets13);
        java.awt.Font font26 = labelBlock2.getFont();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot31.setDomainAxisLocation(axisLocation32, true);
        boolean boolean35 = categoryPlot31.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot31.setDatasetRenderingOrder(datasetRenderingOrder36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot31.getDataset();
        boolean boolean39 = labelBlock2.equals((java.lang.Object) categoryPlot31);
        float float40 = categoryPlot31.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot6.setDomainAxisLocation(axisLocation7, true);
        boolean boolean10 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot6.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ThreadContext", font1, (org.jfree.chart.plot.Plot) categoryPlot6, true);
        java.awt.image.BufferedImage bufferedImage17 = jFreeChart14.createBufferedImage((int) (byte) 1, (int) (short) 10);
        org.jfree.chart.event.ChartChangeListener chartChangeListener18 = null;
        try {
            jFreeChart14.removeChangeListener(chartChangeListener18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(bufferedImage17);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 15);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "org.jfree.data.general.DatasetChangeEvent[source= ]");
        boolean boolean7 = legendTitle1.equals((java.lang.Object) shape4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer8.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean14 = barRenderer8.getSeriesCreateEntities(15);
        boolean boolean15 = legendTitle1.equals((java.lang.Object) barRenderer8);
        barRenderer8.setIncludeBaseInRange(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        numberAxis1.removeChangeListener(axisChangeListener5);
        java.awt.Shape shape7 = numberAxis1.getRightArrow();
        boolean boolean8 = numberAxis1.isPositiveArrowVisible();
        java.awt.Font font9 = numberAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, 0.0d, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", textAnchor3, textAnchor4, 0.0d);
        java.lang.Number number7 = numberTick6.getNumber();
        org.jfree.chart.axis.TickType tickType8 = numberTick6.getTickType();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertNull(tickType8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        barRenderer0.setMaximumBarWidth((-1.0d));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator((int) 'a', 192);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem13 = barRenderer10.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape14 = barRenderer10.getBaseShape();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer10.setSeriesOutlineStroke((int) (short) 0, stroke16);
        barRenderer10.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke21 = barRenderer10.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis24.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener28 = null;
        numberAxis24.removeChangeListener(axisChangeListener28);
        java.awt.Shape shape30 = numberAxis24.getRightArrow();
        barRenderer10.setSeriesShape(8, shape30, true);
        barRenderer0.setBaseShape(shape30, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint38 = barRenderer36.lookupSeriesOutlinePaint(8);
        boolean boolean39 = barRenderer36.isDrawBarOutline();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis42.setRange(1.0d, (double) (byte) 10);
        numberAxis42.setRangeAboutValue(0.0d, (double) 0.5f);
        numberAxis42.setNegativeArrowVisible(true);
        double double51 = numberAxis42.getUpperMargin();
        numberAxis42.setVisible(true);
        numberAxis42.setLabelToolTip("");
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets((double) 10, (double) ' ', (double) 100, (double) 0.5f);
        numberAxis42.setTickLabelInsets(rectangleInsets60);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier62 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke63 = defaultDrawingSupplier62.getNextOutlineStroke();
        numberAxis42.setTickMarkStroke(stroke63);
        barRenderer36.setSeriesOutlineStroke(4, stroke63, false);
        barRenderer0.setSeriesOutlineStroke(8, stroke63, false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setUpperBound((double) 8);
        numberAxis1.resizeRange((double) 100);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        java.awt.Font font7 = numberAxis1.getLabelFont();
        java.lang.String str8 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        java.awt.Paint paint7 = barRenderer0.getItemLabelPaint(10, 2);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets();
        double double7 = rectangleInsets5.calculateLeftOutset((double) (byte) -1);
        double double9 = rectangleInsets5.calculateRightInset((double) 100.0f);
        numberAxis1.setLabelInsets(rectangleInsets5);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        org.jfree.chart.plot.Plot plot16 = categoryPlot15.getRootPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        java.awt.Color color18 = java.awt.Color.GREEN;
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Stroke stroke20 = categoryPlot15.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesOutlinePaint(8);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator3);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer0.setSeriesToolTipGenerator((int) '4', categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis4.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("", font10);
        java.awt.Color color12 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("hi!", font10, (java.awt.Paint) color12);
        numberAxis4.setTickLabelFont(font10);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str22 = categoryAxis20.getCategoryLabelToolTip((java.lang.Comparable) 10.0d);
        categoryPlot19.setDomainAxis(categoryAxis20);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        categoryPlot19.setDataset(10, categoryDataset25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot19.getParent();
        categoryPlot19.configureRangeAxes();
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = ", font10, (org.jfree.chart.plot.Plot) categoryPlot19, true);
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", font10);
        java.awt.Color color32 = java.awt.Color.blue;
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer35 = new org.jfree.chart.text.G2TextMeasurer(graphics2D34);
        try {
            org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("CategoryLabelEntity: category=10, tooltip=, url=ChartEntity: tooltip = ", font10, (java.awt.Paint) color32, 100.0f, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = legendTitle1.getPosition();
        double double7 = legendTitle1.getHeight();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis1.setRange(1.0d, (double) (byte) 10);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font7);
        java.awt.Color color9 = java.awt.Color.CYAN;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("hi!", font7, (java.awt.Paint) color9);
        numberAxis1.setTickLabelFont(font7);
        java.awt.Shape shape12 = numberAxis1.getLeftArrow();
        java.awt.Paint paint13 = numberAxis1.getTickMarkPaint();
        boolean boolean14 = numberAxis1.isAxisLineVisible();
        org.jfree.data.Range range15 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem3 = barRenderer0.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape4 = barRenderer0.getBaseShape();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke6);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Stroke stroke11 = barRenderer0.getSeriesStroke(100);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        numberAxis14.setRange(1.0d, (double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        numberAxis14.removeChangeListener(axisChangeListener18);
        java.awt.Shape shape20 = numberAxis14.getRightArrow();
        barRenderer0.setSeriesShape(8, shape20, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.LegendItem legendItem27 = barRenderer24.getLegendItem((int) 'a', (int) (byte) 10);
        java.awt.Shape shape28 = barRenderer24.getBaseShape();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        barRenderer24.setSeriesOutlineStroke((int) (short) 0, stroke30);
        barRenderer24.setAutoPopulateSeriesOutlinePaint(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = barRenderer24.getPositiveItemLabelPosition((int) (byte) -1, (int) (byte) 1);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int39 = color38.getRed();
        barRenderer24.setSeriesPaint(10, (java.awt.Paint) color38);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer41.setSeriesCreateEntities(0, (java.lang.Boolean) true, true);
        java.lang.Boolean boolean47 = barRenderer41.getSeriesCreateEntities(15);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor48 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor50 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor48, textAnchor49, textAnchor50, (double) 0.5f);
        barRenderer41.setPositiveItemLabelPositionFallback(itemLabelPosition52);
        barRenderer24.setPositiveItemLabelPositionFallback(itemLabelPosition52);
        barRenderer0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition52);
        java.awt.Font font59 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Font font61 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock62 = new org.jfree.chart.block.LabelBlock("", font61);
        java.awt.Paint paint63 = labelBlock62.getPaint();
        org.jfree.chart.text.TextFragment textFragment65 = new org.jfree.chart.text.TextFragment("hi!", font59, paint63, 100.0f);
        java.awt.Color color66 = java.awt.Color.cyan;
        org.jfree.chart.text.TextFragment textFragment68 = new org.jfree.chart.text.TextFragment("", font59, (java.awt.Paint) color66, (float) 500);
        barRenderer0.setSeriesItemLabelFont(192, font59, true);
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertNull(legendItem3);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 192 + "'", int39 == 192);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertNotNull(itemLabelAnchor48);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertNotNull(textAnchor50);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(color66);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.lang.Object obj3 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        java.awt.Paint paint6 = null;
        legendTitle1.setBackgroundPaint(paint6);
        java.awt.Paint paint8 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray9 = legendTitle1.getSources();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(legendItemSourceArray9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        double double3 = size2D2.height;
        size2D2.width = 10;
        double double6 = size2D2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX(0.2d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0f };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0f };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ClassContext", "null version null.\nRectangleEdge.RIGHT.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", numberArray8);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset9);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset9, true);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.0d + "'", number10.equals(1.0d));
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, range1);
        double double3 = rectangleConstraint2.getHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedWidth((double) (byte) 0);
        org.jfree.chart.util.Size2D size2D8 = new org.jfree.chart.util.Size2D((double) 0L, (double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor11, textBlockAnchor12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = categoryLabelPosition13.getCategoryAnchor();
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (byte) 0, 0.0d, rectangleAnchor14);
        double double16 = size2D8.width;
        size2D8.width = (short) 100;
        try {
            org.jfree.chart.util.Size2D size2D19 = rectangleConstraint5.calculateConstrainedSize(size2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }
}

