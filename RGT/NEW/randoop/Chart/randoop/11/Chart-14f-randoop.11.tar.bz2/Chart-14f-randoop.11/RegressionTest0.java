import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.Color color0 = java.awt.Color.GREEN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        boolean boolean2 = categoryAnchor0.equals((java.lang.Object) textAnchor1);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateTopInset((double) ' ');
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createOutsetRectangle(rectangle2D7, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateBottomOutset((double) (-1L));
        double double7 = rectangleInsets4.getLeft();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-1L), (float) (byte) 10, (float) 0L);
        float[] floatArray4 = new float[] {};
        try {
            float[] floatArray5 = color3.getRGBColorComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color4 = java.awt.Color.GREEN;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color4, stroke5);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint2, stroke5);
        boolean boolean8 = categoryAnchor0.equals((java.lang.Object) stroke5);
        java.lang.String str9 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryAnchor.START" + "'", str9.equals("CategoryAnchor.START"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        org.jfree.data.general.Dataset dataset3 = datasetChangeEvent2.getDataset();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(dataset3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        try {
            categoryPlot6.addRangeMarker(5, marker15, layer16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            categoryPlot6.drawBackground(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        try {
            categoryPlot6.zoom((double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        categoryPlot6.setBackgroundImageAlignment(0);
        try {
            categoryPlot6.zoom((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        categoryMarker3.setAlpha((float) 1L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            categoryMarker3.setLabelOffsetType(lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        categoryPlot6.setForegroundAlpha((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis27, categoryItemRenderer28);
        categoryPlot29.setDrawSharedDomainAxis(false);
        java.awt.Color color33 = java.awt.Color.GREEN;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color33, stroke34);
        categoryPlot29.addDomainMarker(categoryMarker35);
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker35);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        try {
            categoryPlot6.drawBackground(graphics2D38, rectangle2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4194304) + "'", int1 == (-4194304));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(100, (int) '#', (int) 'a');
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot19.zoomDomainAxes(0.0d, plotRenderingInfo21, point2D22, true);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace25);
        java.awt.Stroke stroke27 = categoryPlot19.getDomainGridlineStroke();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace31 = categoryAxis1.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D28, rectangleEdge29, axisSpace30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis17.setLabelPaint((java.awt.Paint) color23);
        int int25 = categoryAxis17.getCategoryLabelPositionOffset();
        categoryPlot6.setDomainAxis((int) (short) 1, categoryAxis17);
        categoryPlot6.setDrawSharedDomainAxis(false);
        float float29 = categoryPlot6.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        try {
            categoryPlot6.zoom((double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        try {
            java.util.List list7 = categoryAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot7.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        int int13 = categoryPlot7.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        categoryPlot7.setParent((org.jfree.chart.plot.Plot) categoryPlot20);
        java.awt.Color color23 = java.awt.Color.GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color23, stroke24);
        java.lang.String str26 = color23.toString();
        categoryPlot20.setRangeCrosshairPaint((java.awt.Paint) color23);
        java.awt.Stroke stroke28 = null;
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color31 = color30.darker();
        java.awt.Color color32 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]", color30);
        java.awt.Paint paint34 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color36 = java.awt.Color.GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color36, stroke37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint34, stroke37);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10.0f, (java.awt.Paint) color23, stroke28, (java.awt.Paint) color30, stroke37, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str26.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color7);
        java.lang.Comparable comparable9 = null;
        try {
            java.awt.Paint paint10 = categoryAxis1.getTickLabelPaint(comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        float float27 = categoryPlot19.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        double double34 = rectangleInsets28.calculateRightOutset((double) (byte) 0);
        double double36 = rectangleInsets28.calculateTopOutset((double) '#');
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        java.lang.Comparable comparable6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        try {
            double double12 = categoryAxis0.getCategorySeriesMiddle(comparable6, (java.lang.Comparable) 4, categoryDataset8, 1.0d, rectangle2D10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot19.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot19.setRenderer(0, categoryItemRenderer23);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor21);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setTickMarkInsideLength((float) 5);
        categoryAxis33.setVisible(false);
        java.util.List list38 = categoryPlot6.getCategoriesForAxis(categoryAxis33);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Font font21 = null;
        try {
            categoryPlot6.setNoDataMessageFont(font21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot6.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot14.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17, true);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot14.setRangeCrosshairPaint((java.awt.Paint) color20);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis27, categoryItemRenderer28);
        categoryPlot29.setDrawSharedDomainAxis(false);
        java.awt.Color color33 = java.awt.Color.GREEN;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color33, stroke34);
        categoryPlot29.addDomainMarker(categoryMarker35);
        categoryPlot29.setRangeCrosshairValue((double) 8, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier40 = categoryPlot29.getDrawingSupplier();
        categoryPlot6.setDrawingSupplier(drawingSupplier40);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(drawingSupplier40);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color3 = java.awt.Color.GREEN;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color3, stroke4);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint1, stroke4);
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        valueMarker6.setLabelTextAnchor(textAnchor7);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setLabel("hi!");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int3 = java.awt.Color.HSBtoRGB((float) 0L, 0.0f, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        int int7 = categoryPlot6.getWeight();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setLabelURL("hi!");
        java.awt.Paint paint11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color13, stroke14);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint11, stroke14);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stroke14);
        categoryAxis0.setTickMarkStroke(stroke14);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.Plot plot20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot28.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31, true);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot28.setFixedDomainAxisSpace(axisSpace34);
        categoryPlot28.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot28.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace40 = categoryAxis0.reserveSpace(graphics2D19, plot20, rectangle2D21, rectangleEdge38, axisSpace39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setTickMarksVisible(false);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot14.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17, true);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot14.setFixedDomainAxisSpace(axisSpace20);
        categoryPlot14.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot14.getRangeAxisEdge();
        try {
            double double25 = categoryAxis0.getCategoryMiddle((int) (byte) -1, 255, rectangle2D7, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int3 = java.awt.Color.HSBtoRGB((float) 0, (float) (byte) 100, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        try {
            categoryPlot6.setBackgroundImageAlpha(100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        int int9 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace26);
        categoryPlot20.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot20.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            org.jfree.chart.axis.AxisState axisState32 = categoryAxis1.draw(graphics2D10, (double) (-16777216), rectangle2D12, rectangle2D13, rectangleEdge30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        float float33 = categoryPlot6.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        try {
            categoryPlot6.setRangeAxisLocation(axisLocation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.setRangeCrosshairValue((double) 8, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = categoryPlot6.getDrawingSupplier();
        try {
            categoryPlot6.mapDatasetToDomainAxis((int) (byte) -1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setLabelURL("hi!");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis0.getCategoryStart(0, 255, rectangle2D12, rectangleEdge13);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        try {
            int int14 = categoryPlot6.getRangeAxisIndex(valueAxis13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        java.awt.Paint paint6 = categoryMarker3.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setTickMarkInsideLength((float) 5);
        categoryAxis7.setAxisLineVisible(true);
        java.lang.String str12 = categoryAxis7.getLabelURL();
        boolean boolean13 = categoryMarker3.equals((java.lang.Object) categoryAxis7);
        categoryAxis7.setTickMarkOutsideLength((float) ' ');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        float[] floatArray4 = new float[] { 1.0f };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB(15, (int) (short) 0, (int) '4', floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setLabelURL("hi!");
        java.awt.Paint paint10 = null;
        try {
            categoryAxis0.setAxisLinePaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setLabelURL("hi!");
        java.awt.Paint paint11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color13, stroke14);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint11, stroke14);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) stroke14);
        categoryAxis0.setTickMarkStroke(stroke14);
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) '4');
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot19.getDatasetGroup();
        boolean boolean32 = categoryPlot19.isSubplot();
        java.awt.Paint paint33 = categoryPlot19.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot6.setRenderer(categoryItemRenderer7, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        boolean boolean14 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        categoryPlot22.setDrawSharedDomainAxis(false);
        java.awt.Color color26 = java.awt.Color.GREEN;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color26, stroke27);
        categoryPlot22.addDomainMarker(categoryMarker28);
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot6.removeDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) categoryMarker28, layer30);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color8);
        java.awt.color.ColorSpace colorSpace10 = null;
        float[] floatArray16 = new float[] { 1L, 0.0f, 255, (-254), (short) 10 };
        try {
            float[] floatArray17 = color8.getColorComponents(colorSpace10, floatArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot7.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        categoryPlot4.setRangeAxis(5, valueAxis6);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        float float33 = categoryPlot6.getBackgroundAlpha();
        categoryPlot6.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace36);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        try {
            double double4 = dateAxis0.dateToJava2D(date1, rectangle2D2, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot6.setDomainGridlinesVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent16);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        java.util.List list31 = categoryPlot19.getAnnotations();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        double double6 = categoryAxis0.getUpperMargin();
        java.lang.Object obj7 = categoryAxis0.clone();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        java.awt.Paint paint6 = categoryMarker3.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setTickMarkInsideLength((float) 5);
        categoryAxis7.setAxisLineVisible(true);
        java.lang.String str12 = categoryAxis7.getLabelURL();
        boolean boolean13 = categoryMarker3.equals((java.lang.Object) categoryAxis7);
        java.awt.Stroke stroke14 = categoryMarker3.getOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int3 = java.awt.Color.HSBtoRGB((float) 3, (float) 1, (float) 100L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-6553600) + "'", int3 == (-6553600));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        float float33 = categoryPlot6.getBackgroundAlpha();
        java.awt.Color color35 = java.awt.Color.GREEN;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color35, stroke36);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker37.setStroke(stroke38);
        org.jfree.chart.text.TextAnchor textAnchor40 = categoryMarker37.getLabelTextAnchor();
        java.awt.Paint paint41 = categoryMarker37.getOutlinePaint();
        java.lang.String str42 = categoryMarker37.getLabel();
        categoryPlot6.addDomainMarker(categoryMarker37);
        java.lang.Comparable comparable44 = categoryMarker37.getKey();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + (short) 10 + "'", comparable44.equals((short) 10));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(15, (int) (short) 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 2.0d, 0.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryMarker3.getLabelTextAnchor();
        java.awt.Paint paint7 = categoryMarker3.getOutlinePaint();
        java.lang.String str8 = categoryMarker3.getLabel();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener9 = null;
        categoryMarker3.removeChangeListener(markerChangeListener9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("CategoryAnchor.START");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        float float10 = categoryAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot14.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17, true);
        int int20 = categoryPlot14.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color23 = java.awt.Color.GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color23, stroke24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker25.setStroke(stroke26);
        boolean boolean28 = datasetRenderingOrder21.equals((java.lang.Object) categoryMarker25);
        org.jfree.chart.util.Layer layer29 = null;
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer29);
        int int31 = categoryPlot14.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        categoryPlot14.setDataset(categoryDataset32);
        org.jfree.data.general.DatasetGroup datasetGroup34 = categoryPlot14.getDatasetGroup();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomDomainAxes(0.0d, plotRenderingInfo44, point2D45, true);
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        categoryPlot42.setFixedDomainAxisSpace(axisSpace48);
        categoryPlot42.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot42.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace54 = dateAxis0.reserveSpace(graphics2D7, (org.jfree.chart.plot.Plot) categoryPlot14, rectangle2D35, rectangleEdge52, axisSpace53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(datasetGroup34);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis17.setLabelPaint((java.awt.Paint) color23);
        int int25 = categoryAxis17.getCategoryLabelPositionOffset();
        categoryPlot6.setDomainAxis((int) (short) 1, categoryAxis17);
        double double27 = categoryAxis17.getUpperMargin();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            java.awt.Color color1 = java.awt.Color.decode("DatasetRenderingOrder.FORWARD");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DatasetRenderingOrder.FORWARD\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot6.setRenderer(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        dateAxis0.setPositiveArrowVisible(true);
        java.util.TimeZone timeZone9 = null;
        try {
            dateAxis0.setTimeZone(timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        try {
            dateAxis5.setAutoRangeMinimumSize(0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.setRangeCrosshairValue((double) 8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot6.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray18 = null;
        try {
            categoryPlot6.setDomainAxes(categoryAxisArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxis17);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Font font5 = categoryAxis0.getTickLabelFont();
        java.awt.Font font6 = categoryAxis0.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot18.setFixedDomainAxisSpace(axisSpace24);
        categoryPlot18.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot18.getRangeAxisEdge();
        try {
            double double29 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 10L, (java.lang.Comparable) (byte) 1, categoryDataset9, (double) (short) -1, rectangle2D11, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot16.getOrientation();
        boolean boolean18 = categoryPlot6.equals((java.lang.Object) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot16.setDataset(categoryDataset19);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        java.awt.Paint paint29 = categoryPlot19.getDomainGridlinePaint();
        categoryPlot19.setBackgroundImageAlignment(10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Paint paint7 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        int int26 = categoryPlot20.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color30 = java.awt.Color.GREEN;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color30, stroke31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker32.setStroke(stroke33);
        boolean boolean35 = datasetRenderingOrder28.equals((java.lang.Object) categoryMarker32);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis40, categoryItemRenderer41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis37.setLabelPaint((java.awt.Paint) color43);
        categoryMarker32.setLabelPaint((java.awt.Paint) color43);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot20.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker32, layer46);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean49 = layer46.equals((java.lang.Object) lengthAdjustmentType48);
        java.awt.Color color50 = java.awt.Color.ORANGE;
        boolean boolean51 = layer46.equals((java.lang.Object) color50);
        java.util.Collection collection52 = categoryPlot6.getDomainMarkers(layer46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot6.setRenderer((int) (short) 10, categoryItemRenderer54);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot6.setRenderer(categoryItemRenderer7, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color13, stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker15.setStroke(stroke16);
        boolean boolean18 = datasetRenderingOrder11.equals((java.lang.Object) categoryMarker15);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis23, categoryItemRenderer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis20.setLabelPaint((java.awt.Paint) color26);
        categoryMarker15.setLabelPaint((java.awt.Paint) color26);
        float float29 = categoryMarker15.getAlpha();
        boolean boolean30 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot6.getDomainMarkers(layer31);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        categoryPlot6.clearDomainMarkers(0);
        categoryPlot6.setWeight(0);
        try {
            categoryPlot6.setBackgroundImageAlpha((float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setTickMarksVisible(false);
        categoryAxis0.setTickMarksVisible(true);
        int int7 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        java.awt.Font font10 = null;
        try {
            categoryAxis1.setTickLabelFont(font10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        dateAxis0.zoomRange((double) (-4194304), 2.0d);
        try {
            dateAxis0.zoomRange((double) 1, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (-8388610.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.geom.Point2D point2D12 = null;
        try {
            xYPlot7.setQuadrantOrigin(point2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateTopInset((double) ' ');
        double double8 = rectangleInsets4.trimWidth((double) (-1.0f));
        double double10 = rectangleInsets4.calculateLeftOutset(0.0d);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color14 = java.awt.Color.GREEN;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color14, stroke15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker16.setStroke(stroke17);
        boolean boolean19 = datasetRenderingOrder12.equals((java.lang.Object) categoryMarker16);
        java.awt.Font font20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker16.setLabelFont(font20);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType22 = categoryMarker16.getLabelOffsetType();
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color31 = java.awt.Color.GREEN;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color31, stroke32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker33.setStroke(stroke34);
        boolean boolean36 = datasetRenderingOrder29.equals((java.lang.Object) categoryMarker33);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis41, categoryItemRenderer42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis38.setLabelPaint((java.awt.Paint) color44);
        categoryMarker33.setLabelPaint((java.awt.Paint) color44);
        categoryMarker26.setOutlinePaint((java.awt.Paint) color44);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = categoryMarker26.getLabelOffsetType();
        try {
            java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets4.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType22, lengthAdjustmentType48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-111.0d) + "'", double8 == (-111.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRange(range13);
        org.jfree.data.Range range15 = dateAxis12.getRange();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer17);
        xYPlot18.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = xYPlot18.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot18.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot18.getDomainAxisEdge((int) '#');
        try {
            java.util.List list27 = dateAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) 100, (double) 15, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.Plot plot15 = plotChangeEvent14.getPlot();
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        plotChangeEvent14.setChart(jFreeChart16);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimHeight(1.0E-8d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.99999999d) + "'", double2 == (-7.99999999d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Font font5 = categoryAxis0.getTickLabelFont();
        java.awt.Font font6 = categoryAxis0.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21, true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot18.setFixedDomainAxisSpace(axisSpace24);
        categoryPlot18.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot18.getRangeAxisEdge();
        try {
            double double29 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 4, (java.lang.Comparable) false, categoryDataset9, (double) (-16777216), rectangle2D11, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color8 = java.awt.Color.GREEN;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker10.setStroke(stroke11);
        boolean boolean13 = datasetRenderingOrder6.equals((java.lang.Object) categoryMarker10);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis15.setLabelPaint((java.awt.Paint) color21);
        categoryMarker10.setLabelPaint((java.awt.Paint) color21);
        categoryMarker3.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = categoryMarker3.getLabelAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        categoryMarker12.notifyListeners(markerChangeEvent14);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = categoryMarker12.getLabelOffsetType();
        java.lang.String str17 = lengthAdjustmentType16.toString();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "EXPAND" + "'", str17.equals("EXPAND"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date7 = dateAxis0.getMaximumDate();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis11.setRange(range12);
        org.jfree.data.Range range14 = dateAxis11.getRange();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer16);
        xYPlot17.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot17.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot17.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot17.getDomainAxisEdge((int) '#');
        try {
            double double26 = dateAxis0.valueToJava2D(100.0d, rectangle2D9, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot19.getDataset(100);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        try {
            int int34 = categoryPlot19.getDomainAxisIndex(categoryAxis33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(categoryDataset32);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot12.zoomDomainAxes(0.0d, plotRenderingInfo14, point2D15, true);
        int int18 = categoryPlot12.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis23, categoryItemRenderer24);
        categoryPlot12.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        categoryPlot12.clearDomainAxes();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis14.setRange(range15);
        org.jfree.data.Range range17 = dateAxis14.getRange();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer19);
        xYPlot20.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = xYPlot20.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot20.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot20.getDomainAxisEdge((int) '#');
        try {
            java.util.List list29 = categoryAxis0.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        float float9 = categoryAxis1.getTickMarkOutsideLength();
        boolean boolean10 = categoryAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.calculateTopOutset(0.0d);
        double double9 = rectangleInsets4.calculateRightOutset(0.05d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        float float23 = categoryPlot6.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot6.zoomDomainAxes((double) 8, plotRenderingInfo25, point2D26, false);
        boolean boolean29 = categoryPlot6.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        int int29 = categoryPlot19.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot19.setInsets(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets30);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date7 = dateAxis0.getMaximumDate();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis11.setRange(range12);
        org.jfree.data.Range range14 = dateAxis11.getRange();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer16);
        xYPlot17.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = xYPlot17.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation23 = xYPlot17.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot17.getDomainAxisEdge((int) '#');
        try {
            double double26 = dateAxis0.valueToJava2D((double) 1.0f, rectangle2D9, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        int int26 = categoryPlot20.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color30 = java.awt.Color.GREEN;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color30, stroke31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker32.setStroke(stroke33);
        boolean boolean35 = datasetRenderingOrder28.equals((java.lang.Object) categoryMarker32);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis40, categoryItemRenderer41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis37.setLabelPaint((java.awt.Paint) color43);
        categoryMarker32.setLabelPaint((java.awt.Paint) color43);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot20.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker32, layer46);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean49 = layer46.equals((java.lang.Object) lengthAdjustmentType48);
        java.awt.Color color50 = java.awt.Color.ORANGE;
        boolean boolean51 = layer46.equals((java.lang.Object) color50);
        java.util.Collection collection52 = categoryPlot6.getDomainMarkers(layer46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        java.awt.geom.Point2D point2D56 = null;
        categoryPlot6.zoomDomainAxes((double) '4', (double) (short) 0, plotRenderingInfo55, point2D56);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation33 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation33, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot6.setRenderer(categoryItemRenderer7, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color13, stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker15.setStroke(stroke16);
        boolean boolean18 = datasetRenderingOrder11.equals((java.lang.Object) categoryMarker15);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis23, categoryItemRenderer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis20.setLabelPaint((java.awt.Paint) color26);
        categoryMarker15.setLabelPaint((java.awt.Paint) color26);
        float float29 = categoryMarker15.getAlpha();
        boolean boolean30 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        java.lang.Object obj31 = categoryMarker15.clone();
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range4, false, false);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot16.zoomDomainAxes(0.0d, plotRenderingInfo18, point2D19, true);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace22);
        categoryPlot16.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getRangeAxisEdge();
        try {
            double double27 = dateAxis0.valueToJava2D(0.0d, rectangle2D9, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        int int53 = xYPlot7.getIndexOf(xYItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = null;
        try {
            xYPlot7.setRangeAxisLocation(0, axisLocation55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        boolean boolean29 = xYPlot7.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot7.setFixedDomainAxisSpace(axisSpace30);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setTickMarksVisible(false);
        categoryAxis0.setTickMarksVisible(true);
        categoryAxis0.setTickLabelsVisible(true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        xYPlot7.setDomainCrosshairValue((double) 100L);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        int int23 = xYPlot7.indexOf(xYDataset22);
        java.awt.Stroke stroke24 = xYPlot7.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        float float23 = categoryPlot6.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot6.zoomDomainAxes((double) 8, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot6.zoomDomainAxes((-355.0d), (double) 1.0f, plotRenderingInfo33, point2D34);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        int int26 = categoryPlot20.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color30 = java.awt.Color.GREEN;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color30, stroke31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker32.setStroke(stroke33);
        boolean boolean35 = datasetRenderingOrder28.equals((java.lang.Object) categoryMarker32);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis40, categoryItemRenderer41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis37.setLabelPaint((java.awt.Paint) color43);
        categoryMarker32.setLabelPaint((java.awt.Paint) color43);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot20.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker32, layer46);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean49 = layer46.equals((java.lang.Object) lengthAdjustmentType48);
        java.awt.Color color50 = java.awt.Color.ORANGE;
        boolean boolean51 = layer46.equals((java.lang.Object) color50);
        java.util.Collection collection52 = categoryPlot6.getDomainMarkers(layer46);
        org.jfree.chart.event.PlotChangeListener plotChangeListener53 = null;
        categoryPlot6.addChangeListener(plotChangeListener53);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]");
        try {
            xYPlot7.setRangeAxis((-4194304), (org.jfree.chart.axis.ValueAxis) dateAxis24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        xYPlot7.setDomainCrosshairVisible(false);
        xYPlot7.setRangeCrosshairValue((double) ' ', true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        try {
            xYPlot7.zoomRangeAxes((double) 3, plotRenderingInfo17, point2D18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot6.zoomRangeAxes((double) 0, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setTickMarkInsideLength((float) 5);
        categoryAxis26.setVisible(false);
        boolean boolean31 = categoryPlot6.equals((java.lang.Object) categoryAxis26);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.Plot plot33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range37);
        org.jfree.data.Range range39 = dateAxis36.getRange();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis40, xYItemRenderer41);
        xYPlot42.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = xYPlot42.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot42.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot42.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace51 = null;
        org.jfree.chart.axis.AxisSpace axisSpace52 = categoryAxis26.reserveSpace(graphics2D32, plot33, rectangle2D34, rectangleEdge50, axisSpace51);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis54.setTickMarkInsideLength((float) 5);
        categoryAxis54.setVisible(false);
        java.awt.Font font59 = categoryAxis54.getTickLabelFont();
        categoryAxis26.setTickLabelFont((java.lang.Comparable) 1.0d, font59);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(axisSpace52);
        org.junit.Assert.assertNotNull(font59);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker4.setStroke(stroke5);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) categoryMarker4);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis12, categoryItemRenderer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis9.setLabelPaint((java.awt.Paint) color15);
        categoryMarker4.setLabelPaint((java.awt.Paint) color15);
        java.lang.Comparable comparable18 = categoryMarker4.getKey();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (short) 10 + "'", comparable18.equals((short) 10));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        valueMarker1.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        valueMarker1.notifyListeners(markerChangeEvent4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        double double6 = categoryAxis0.getUpperMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setTickMarkInsideLength((float) 5);
        categoryAxis7.setTickMarksVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis7.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions12);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot6.getAxisOffset();
        double double9 = rectangleInsets8.getTop();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis27, categoryItemRenderer28);
        categoryPlot29.setDrawSharedDomainAxis(false);
        java.awt.Color color33 = java.awt.Color.GREEN;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color33, stroke34);
        categoryPlot29.addDomainMarker(categoryMarker35);
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker35);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis42, categoryItemRenderer43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis39.setLabelPaint((java.awt.Paint) color45);
        categoryMarker35.setOutlinePaint((java.awt.Paint) color45);
        float[] floatArray48 = new float[] {};
        try {
            float[] floatArray49 = color45.getRGBColorComponents(floatArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(floatArray48);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        java.lang.Object obj29 = null;
        boolean boolean30 = categoryPlot19.equals(obj29);
        try {
            categoryPlot19.mapDatasetToDomainAxis((-6553600), (-6553600));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.Color color1 = java.awt.Color.getColor("CategoryAnchor.START");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker18.setStroke(stroke19);
        boolean boolean21 = datasetRenderingOrder14.equals((java.lang.Object) categoryMarker18);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis23.setLabelPaint((java.awt.Paint) color29);
        categoryMarker18.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker18, layer32);
        java.awt.Image image34 = categoryPlot6.getBackgroundImage();
        java.awt.Color color35 = java.awt.Color.magenta;
        categoryPlot6.setOutlinePaint((java.awt.Paint) color35);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Font font5 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setCategoryMargin((double) 1);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot7.getRangeAxisForDataset(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 11 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        categoryAxis1.setCategoryLabelPositionOffset(255);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomDomainAxes(0.0d, plotRenderingInfo26, point2D27, true);
        int int30 = categoryPlot24.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color33 = java.awt.Color.GREEN;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color33, stroke34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker35.setStroke(stroke36);
        boolean boolean38 = datasetRenderingOrder31.equals((java.lang.Object) categoryMarker35);
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot24.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker35, layer39);
        int int41 = categoryPlot24.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        categoryPlot24.setDataset(categoryDataset42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis44.setTickMarkInsideLength((float) 5);
        categoryAxis44.setVisible(false);
        boolean boolean49 = categoryPlot24.equals((java.lang.Object) categoryAxis44);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.plot.Plot plot51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range55 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis54.setRange(range55);
        org.jfree.data.Range range57 = dateAxis54.getRange();
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset53, (org.jfree.chart.axis.ValueAxis) dateAxis54, (org.jfree.chart.axis.ValueAxis) dateAxis58, xYItemRenderer59);
        xYPlot60.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = xYPlot60.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot60.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = xYPlot60.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        org.jfree.chart.axis.AxisSpace axisSpace70 = categoryAxis44.reserveSpace(graphics2D50, plot51, rectangle2D52, rectangleEdge68, axisSpace69);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        try {
            org.jfree.chart.axis.AxisState axisState72 = categoryAxis1.draw(graphics2D14, (double) 0.0f, rectangle2D16, rectangle2D17, rectangleEdge68, plotRenderingInfo71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(axisSpace70);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker4.setStroke(stroke5);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) categoryMarker4);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker4.setLabelFont(font8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = categoryMarker4.getLabelOffsetType();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomDomainAxes(0.0d, plotRenderingInfo19, point2D20, true);
        int int23 = categoryPlot17.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color26 = java.awt.Color.GREEN;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color26, stroke27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker28.setStroke(stroke29);
        boolean boolean31 = datasetRenderingOrder24.equals((java.lang.Object) categoryMarker28);
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot17.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker28, layer32);
        int int34 = categoryPlot17.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        categoryPlot17.setDataset(categoryDataset35);
        java.awt.Font font37 = categoryPlot17.getNoDataMessageFont();
        boolean boolean38 = lengthAdjustmentType10.equals((java.lang.Object) font37);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot7.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        int int13 = categoryPlot7.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        categoryPlot7.setParent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker27.setStroke(stroke28);
        boolean boolean30 = datasetRenderingOrder23.equals((java.lang.Object) categoryMarker27);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis32.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis35, categoryItemRenderer36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis32.setLabelPaint((java.awt.Paint) color38);
        categoryMarker27.setLabelPaint((java.awt.Paint) color38);
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean43 = categoryPlot7.removeRangeMarker(2, (org.jfree.chart.plot.Marker) categoryMarker27, layer41, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = categoryPlot7.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(plotOrientation44);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        double double12 = rectangleInsets11.getTop();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setDrawSharedDomainAxis(false);
        java.awt.Color color11 = java.awt.Color.GREEN;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color11, stroke12);
        categoryPlot7.addDomainMarker(categoryMarker13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot7.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis17.setLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double31 = rectangleInsets29.calculateTopInset((double) ' ');
        categoryAxis17.setTickLabelInsets(rectangleInsets29);
        categoryPlot7.setInsets(rectangleInsets29);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot7.getDomainAxisLocation(2);
        boolean boolean36 = textAnchor0.equals((java.lang.Object) 2);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot43.zoomDomainAxes(0.0d, plotRenderingInfo45, point2D46, true);
        int int49 = categoryPlot43.getRangeAxisCount();
        categoryPlot43.setBackgroundImageAlignment(0);
        boolean boolean52 = textAnchor0.equals((java.lang.Object) categoryPlot43);
        categoryPlot43.mapDatasetToDomainAxis((int) ' ', 255);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            categoryPlot6.drawBackground(graphics2D43, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        float float23 = categoryPlot6.getBackgroundImageAlpha();
        boolean boolean24 = categoryPlot6.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Layer.BACKGROUND");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Layer.BACKGROUND\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isVerticalTickLabels();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.data.Range range8 = dateAxis5.getRange();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer10);
        xYPlot11.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot11.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation17 = xYPlot11.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot11.getDomainAxisEdge((int) '#');
        try {
            double double20 = dateAxis0.lengthToJava2D(0.0d, rectangle2D3, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        float[] floatArray4 = new float[] { (byte) 1, 0L, 500 };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.data.Range range7 = null;
        try {
            dateAxis0.setRange(range7, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setLabelURL("hi!");
        double double10 = categoryAxis0.getLabelAngle();
        categoryAxis0.setTickMarkOutsideLength(1.0f);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot6.getDomainAxisLocation(2);
        boolean boolean35 = categoryPlot6.isDomainGridlinesVisible();
        java.awt.Font font36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot6.setNoDataMessageFont(font36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot6.zoomRangeAxes((double) 0.5f, plotRenderingInfo39, point2D40, true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setDrawSharedDomainAxis(false);
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color13, stroke14);
        categoryPlot9.addDomainMarker(categoryMarker15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot9.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis23, categoryItemRenderer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis20.setLabelPaint((java.awt.Paint) color26);
        int int28 = categoryAxis20.getCategoryLabelPositionOffset();
        categoryPlot9.setDomainAxis((int) (short) 1, categoryAxis20);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis20.setAxisLineStroke(stroke30);
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke30 };
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, strokeArray32, strokeArray33, shapeArray34);
        java.awt.Color color36 = java.awt.Color.RED;
        boolean boolean37 = defaultDrawingSupplier35.equals((java.lang.Object) color36);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker4.setStroke(stroke5);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) categoryMarker4);
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker4.setLabelFont(font8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = categoryMarker4.getLabelOffsetType();
        java.lang.String str11 = lengthAdjustmentType10.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "EXPAND" + "'", str11.equals("EXPAND"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis3.setRange(range4);
        org.jfree.data.Range range6 = dateAxis3.getRange();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer8);
        xYPlot9.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = xYPlot9.getAxisOffset();
        xYPlot9.clearAnnotations();
        java.awt.Paint paint15 = xYPlot9.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke16 = xYPlot9.getDomainZeroBaselineStroke();
        valueMarker1.setOutlineStroke(stroke16);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = dateAxis0.getTickLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        java.awt.Paint paint2 = null;
        try {
            valueMarker1.setPaint(paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        java.lang.Comparable comparable23 = categoryMarker17.getKey();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryMarker17.getLabelOffset();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (short) 10 + "'", comparable23.equals((short) 10));
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot6.setDomainGridlinesVisible(true);
        int int16 = categoryPlot6.getRangeAxisCount();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis6.setRange(range7);
        org.jfree.data.Range range9 = dateAxis6.getRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        xYPlot12.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot12.getAxisOffset();
        java.awt.Paint paint17 = xYPlot12.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double24 = rectangleInsets22.calculateTopInset((double) ' ');
        double double26 = rectangleInsets22.calculateLeftInset((double) (byte) 10);
        double double28 = rectangleInsets22.calculateRightInset(0.0d);
        xYPlot12.setInsets(rectangleInsets22, true);
        categoryAxis0.setTickLabelInsets(rectangleInsets22);
        java.lang.Comparable comparable32 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        xYPlot7.clearRangeMarkers((-4194304));
        xYPlot7.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = xYPlot7.getLegendItems();
        xYPlot7.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        int int36 = xYPlot7.getIndexOf(xYItemRenderer35);
        double double37 = xYPlot7.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.data.Range range8 = dateAxis5.getRange();
        dateAxis5.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date12 = dateAxis5.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = dateAxis5.getTickUnit();
        dateAxis4.setTickUnit(dateTickUnit13, true, true);
        dateAxis0.setTickUnit(dateTickUnit13, true, false);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTickUnit13);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        java.awt.Paint paint8 = categoryAxis0.getLabelPaint();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        boolean boolean14 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot6.getDomainAxis((int) (byte) 10);
        categoryPlot6.setOutlineVisible(false);
        org.jfree.chart.plot.Marker marker19 = null;
        try {
            categoryPlot6.addRangeMarker(marker19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(categoryAxis16);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot7.getRangeAxis((int) (short) 10);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot19.getDatasetGroup();
        boolean boolean32 = categoryPlot19.isSubplot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot19.zoomDomainAxes((double) 3, (double) (short) -1, plotRenderingInfo35, point2D36);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 255);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (int) (byte) 10, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21, true);
        int int24 = categoryPlot18.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color27 = java.awt.Color.GREEN;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color27, stroke28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker29.setStroke(stroke30);
        boolean boolean32 = datasetRenderingOrder25.equals((java.lang.Object) categoryMarker29);
        org.jfree.chart.util.Layer layer33 = null;
        categoryPlot18.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker29, layer33);
        java.awt.Stroke stroke35 = categoryMarker29.getStroke();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomDomainAxes(0.0d, plotRenderingInfo44, point2D45, true);
        int int48 = categoryPlot42.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder50 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color52 = java.awt.Color.GREEN;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color52, stroke53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker54.setStroke(stroke55);
        boolean boolean57 = datasetRenderingOrder50.equals((java.lang.Object) categoryMarker54);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis59.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis62, categoryItemRenderer63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis59.setLabelPaint((java.awt.Paint) color65);
        categoryMarker54.setLabelPaint((java.awt.Paint) color65);
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot42.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker54, layer68);
        xYPlot7.addDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker29, layer68);
        java.lang.Object obj71 = xYPlot7.clone();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertNotNull(obj71);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        xYPlot7.clearDomainAxes();
        boolean boolean27 = xYPlot7.isDomainGridlinesVisible();
        java.awt.Color color29 = java.awt.Color.PINK;
        int int30 = color29.getRed();
        try {
            xYPlot7.setQuadrantPaint(15, (java.awt.Paint) color29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (15) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 255 + "'", int30 == 255);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        int int13 = xYPlot7.getBackgroundImageAlignment();
        xYPlot7.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.LEFT" + "'", str1.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        java.lang.Object obj29 = null;
        boolean boolean30 = categoryPlot19.equals(obj29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot19.removeChangeListener(plotChangeListener31);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker18.setStroke(stroke19);
        boolean boolean21 = datasetRenderingOrder14.equals((java.lang.Object) categoryMarker18);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis23.setLabelPaint((java.awt.Paint) color29);
        categoryMarker18.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker18, layer32);
        java.awt.Image image34 = categoryPlot6.getBackgroundImage();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot6.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(sortOrder35);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot6.setRenderer((int) (byte) 10, categoryItemRenderer14, false);
        categoryPlot6.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color2 = color1.darker();
        java.awt.Color color3 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]", color1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        boolean boolean5 = color3.equals((java.lang.Object) color4);
        int int6 = color4.getRGB();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-12517377) + "'", int6 == (-12517377));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setDrawSharedDomainAxis(false);
        java.awt.Color color11 = java.awt.Color.GREEN;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color11, stroke12);
        categoryPlot7.addDomainMarker(categoryMarker13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot7.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis17.setLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double31 = rectangleInsets29.calculateTopInset((double) ' ');
        categoryAxis17.setTickLabelInsets(rectangleInsets29);
        categoryPlot7.setInsets(rectangleInsets29);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot7.getDomainAxisLocation(2);
        boolean boolean36 = textAnchor0.equals((java.lang.Object) 2);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot43.zoomDomainAxes(0.0d, plotRenderingInfo45, point2D46, true);
        int int49 = categoryPlot43.getRangeAxisCount();
        categoryPlot43.setBackgroundImageAlignment(0);
        boolean boolean52 = textAnchor0.equals((java.lang.Object) categoryPlot43);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder53 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color55 = java.awt.Color.GREEN;
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color55, stroke56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker57.setStroke(stroke58);
        boolean boolean60 = datasetRenderingOrder53.equals((java.lang.Object) categoryMarker57);
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis62.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, valueAxis65, categoryItemRenderer66);
        java.awt.Color color68 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis62.setLabelPaint((java.awt.Paint) color68);
        categoryMarker57.setLabelPaint((java.awt.Paint) color68);
        float float71 = categoryMarker57.getAlpha();
        boolean boolean72 = categoryPlot43.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker57);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + float71 + "' != '" + 1.0f + "'", float71 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double15 = rectangleInsets13.calculateTopInset((double) ' ');
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        double double18 = rectangleInsets13.calculateTopInset((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets13.createOutsetRectangle(rectangle2D19, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-12517377), (double) ' ', rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot6.setDataset(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker13 = null;
        try {
            boolean boolean14 = categoryPlot6.removeRangeMarker(marker13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = xYPlot7.getDrawingSupplier();
        java.awt.Stroke stroke30 = xYPlot7.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateBottomOutset((double) (-1L));
        double double8 = rectangleInsets4.calculateRightOutset((-1.0d));
        java.lang.Class<?> wildcardClass9 = rectangleInsets4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        xYPlot7.clearDomainAxes();
        xYPlot7.setRangeCrosshairValue((double) 10L);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.Point2D point2D19 = null;
        org.jfree.chart.plot.PlotState plotState20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            xYPlot7.draw(graphics2D17, rectangle2D18, point2D19, plotState20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot6.getAxisOffset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRenderer();
        categoryPlot6.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            categoryPlot6.setRangeAxisLocation((int) (short) -1, axisLocation13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color5 = color4.darker();
        categoryMarker3.setOutlinePaint((java.awt.Paint) color4);
        int int7 = color4.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot6.zoomDomainAxes((double) 0L, (double) 1.0f, plotRenderingInfo16, point2D17);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setTickMarksVisible(false);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis9.setRange(range10);
        org.jfree.data.Range range12 = dateAxis9.getRange();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer14);
        xYPlot15.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = xYPlot15.getAxisOffset();
        java.awt.Paint paint20 = xYPlot15.getRangeZeroBaselinePaint();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color27 = java.awt.Color.GREEN;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color27, stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint25, stroke28);
        boolean boolean31 = categoryAnchor23.equals((java.lang.Object) stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color22, stroke28);
        xYPlot15.setDomainCrosshairStroke(stroke28);
        xYPlot15.clearDomainAxes();
        boolean boolean35 = xYPlot15.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot15.getRangeAxisEdge();
        try {
            double double37 = categoryAxis0.getCategoryStart((-254), (-1), rectangle2D7, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        categoryAxis0.clearCategoryLabelToolTips();
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        dateAxis0.setPositiveArrowVisible(true);
        boolean boolean10 = dateAxis0.isHiddenValue((long) (short) -1);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot23.zoomDomainAxes(0.0d, plotRenderingInfo25, point2D26, true);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot23.setFixedDomainAxisSpace(axisSpace29);
        categoryPlot23.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot23.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            org.jfree.chart.axis.AxisState axisState35 = dateAxis0.draw(graphics2D13, (double) 2.0f, rectangle2D15, rectangle2D16, rectangleEdge33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        int int3 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot7.getDomainAxisForDataset(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 3 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateTopInset((double) ' ');
        double double8 = rectangleInsets4.calculateLeftInset((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets4.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) ' ', (double) (-4194304), (double) (-1.0f), (double) 10);
        double double15 = rectangleInsets14.getBottom();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        int int14 = xYPlot7.getIndexOf(xYItemRenderer13);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomDomainAxes(0.0d, plotRenderingInfo11, point2D12, true);
        categoryPlot9.setBackgroundImageAlpha(0.0f);
        categoryPlot9.setDomainGridlinesVisible(true);
        boolean boolean19 = dateAxis0.hasListener((java.util.EventListener) categoryPlot9);
        dateAxis0.resizeRange(0.0d, (double) 9);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        java.awt.Color color16 = java.awt.Color.black;
        xYPlot7.setDomainZeroBaselinePaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.FORWARD");
        double double2 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (-1L));
        double double5 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot19.getDatasetGroup();
        boolean boolean32 = categoryPlot19.isSubplot();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot19.getRendererForDataset(categoryDataset33);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(categoryItemRenderer34);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberTickUnit0);
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color8 = java.awt.Color.GREEN;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker10.setStroke(stroke11);
        boolean boolean13 = datasetRenderingOrder6.equals((java.lang.Object) categoryMarker10);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis15.setLabelPaint((java.awt.Paint) color21);
        categoryMarker10.setLabelPaint((java.awt.Paint) color21);
        categoryMarker3.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double31 = rectangleInsets29.calculateBottomOutset((double) (-1L));
        double double33 = rectangleInsets29.calculateRightOutset((-1.0d));
        java.lang.Class<?> wildcardClass34 = rectangleInsets29.getClass();
        try {
            java.util.EventListener[] eventListenerArray35 = categoryMarker3.getListeners((java.lang.Class) wildcardClass34);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.util.RectangleInsets; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 100.0d + "'", double31 == 100.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 10.0d + "'", double33 == 10.0d);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        xYPlot7.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRange(range29);
        org.jfree.data.Range range31 = dateAxis28.getRange();
        boolean boolean32 = dateAxis28.isVerticalTickLabels();
        int int33 = xYPlot7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis28);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot7.setRangeTickBandPaint((java.awt.Paint) color34);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Font font22 = dateAxis13.getTickLabelFont();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.FORWARD");
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) -1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("XY Plot");
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        categoryPlot6.clearDomainMarkers(0);
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color13, stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker15.setStroke(stroke16);
        java.awt.Paint paint18 = categoryMarker15.getOutlinePaint();
        categoryMarker15.setDrawAsLine(false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis25, categoryItemRenderer26);
        categoryPlot27.setDrawSharedDomainAxis(false);
        java.awt.Color color31 = java.awt.Color.GREEN;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color31, stroke32);
        categoryPlot27.addDomainMarker(categoryMarker33);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot27.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis41, categoryItemRenderer42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis38.setLabelPaint((java.awt.Paint) color44);
        int int46 = categoryAxis38.getCategoryLabelPositionOffset();
        categoryPlot27.setDomainAxis((int) (short) 1, categoryAxis38);
        categoryPlot27.setDrawSharedDomainAxis(false);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range53 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis52.setRange(range53);
        org.jfree.data.Range range55 = dateAxis52.getRange();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) dateAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis56, xYItemRenderer57);
        xYPlot58.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = xYPlot58.getAxisOffset();
        xYPlot58.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder65 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color67 = java.awt.Color.GREEN;
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker69 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color67, stroke68);
        java.awt.Stroke stroke70 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker69.setStroke(stroke70);
        boolean boolean72 = datasetRenderingOrder65.equals((java.lang.Object) categoryMarker69);
        java.awt.Font font73 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker69.setLabelFont(font73);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType75 = categoryMarker69.getLabelOffsetType();
        org.jfree.chart.util.Layer layer76 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean77 = xYPlot58.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker69, layer76);
        java.util.Collection collection78 = categoryPlot27.getDomainMarkers(2, layer76);
        boolean boolean79 = categoryPlot6.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker15, layer76);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(datasetRenderingOrder65);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertNotNull(lengthAdjustmentType75);
        org.junit.Assert.assertNotNull(layer76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(collection78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot13.zoomDomainAxes(0.0d, plotRenderingInfo15, point2D16, true);
        int int19 = categoryPlot13.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker24.setStroke(stroke25);
        boolean boolean27 = datasetRenderingOrder20.equals((java.lang.Object) categoryMarker24);
        org.jfree.chart.util.Layer layer28 = null;
        categoryPlot13.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker24, layer28);
        int int30 = categoryPlot13.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot13.setDataset(categoryDataset31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setTickMarkInsideLength((float) 5);
        categoryAxis33.setVisible(false);
        boolean boolean38 = categoryPlot13.equals((java.lang.Object) categoryAxis33);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.Plot plot40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range44 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis43.setRange(range44);
        org.jfree.data.Range range46 = dateAxis43.getRange();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer48);
        xYPlot49.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = xYPlot49.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation55 = xYPlot49.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = xYPlot49.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        org.jfree.chart.axis.AxisSpace axisSpace59 = categoryAxis33.reserveSpace(graphics2D39, plot40, rectangle2D41, rectangleEdge57, axisSpace58);
        try {
            double double60 = numberAxis1.java2DToValue((double) (short) 1, rectangle2D6, rectangleEdge57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(axisSpace59);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent43 = null;
        categoryPlot6.axisChanged(axisChangeEvent43);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        double double27 = rectangleInsets17.calculateBottomOutset(10.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRange(range16);
        org.jfree.data.Range range18 = dateAxis15.getRange();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        xYPlot21.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot21.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot21.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRange(range34);
        org.jfree.data.Range range36 = dateAxis33.getRange();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer38);
        xYPlot39.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = xYPlot39.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot39.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = xYPlot39.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot39.getDomainAxisForDataset((int) (byte) 0);
        valueAxis49.setNegativeArrowVisible(false);
        valueAxis49.setLowerMargin((double) 0);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range55 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis54.setRange(range55);
        org.jfree.data.Range range57 = dateAxis54.getRange();
        dateAxis54.resizeRange((-355.0d), (double) 2.0f);
        dateAxis54.setPositiveArrowVisible(true);
        boolean boolean64 = dateAxis54.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range66 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis65.setRange(range66);
        dateAxis65.zoomRange((double) (-4194304), 2.0d);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray71 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31, valueAxis49, dateAxis54, dateAxis65 };
        categoryPlot6.setRangeAxes(valueAxisArray71);
        org.jfree.chart.util.SortOrder sortOrder73 = categoryPlot6.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(valueAxis31);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(valueAxis49);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(valueAxisArray71);
        org.junit.Assert.assertNotNull(sortOrder73);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        xYPlot7.clearDomainAxes();
        int int15 = xYPlot7.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot7.getDomainAxis();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(valueAxis16);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12);
        java.awt.Stroke stroke14 = categoryPlot6.getDomainGridlineStroke();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot6.getRangeMarkers(layer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        boolean boolean21 = categoryPlot6.render(graphics2D17, rectangle2D18, (int) ' ', plotRenderingInfo20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = categoryPlot6.getDataset(1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryDataset23);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        categoryPlot19.setRangeCrosshairValue((double) (-1L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis17.setLabelPaint((java.awt.Paint) color23);
        int int25 = categoryAxis17.getCategoryLabelPositionOffset();
        categoryPlot6.setDomainAxis((int) (short) 1, categoryAxis17);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis17.setAxisLineStroke(stroke27);
        categoryAxis17.setCategoryLabelPositionOffset(15);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis8.setRange(range9);
        org.jfree.data.Range range11 = dateAxis8.getRange();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer13);
        java.awt.Shape shape15 = dateAxis12.getUpArrow();
        dateAxis0.setUpArrow(shape15);
        dateAxis0.setLowerMargin(0.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        boolean boolean51 = xYPlot7.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 255);
        boolean boolean4 = day0.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        java.awt.Paint paint43 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot6.getRangeMarkers(4, layer45);
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        int int50 = categoryPlot6.getIndexOf(categoryItemRenderer49);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker18.setStroke(stroke19);
        boolean boolean21 = datasetRenderingOrder14.equals((java.lang.Object) categoryMarker18);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker18.setLabelFont(font22);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = categoryMarker18.getLabelOffsetType();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean26 = xYPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis31, categoryItemRenderer32);
        categoryPlot33.setDrawSharedDomainAxis(false);
        java.awt.Color color37 = java.awt.Color.GREEN;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color37, stroke38);
        categoryPlot33.addDomainMarker(categoryMarker39);
        org.jfree.chart.axis.ValueAxis valueAxis41 = categoryPlot33.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis43.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis46, categoryItemRenderer47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis43.setLabelPaint((java.awt.Paint) color49);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double57 = rectangleInsets55.calculateTopInset((double) ' ');
        categoryAxis43.setTickLabelInsets(rectangleInsets55);
        categoryPlot33.setInsets(rectangleInsets55);
        double double61 = rectangleInsets55.calculateBottomOutset((double) 15);
        boolean boolean62 = layer25.equals((java.lang.Object) rectangleInsets55);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.0d + "'", double61 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        xYPlot7.clearRangeMarkers((-4194304));
        xYPlot7.configureRangeAxes();
        xYPlot7.setRangeCrosshairVisible(true);
        xYPlot7.clearDomainAxes();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        categoryPlot22.setDrawSharedDomainAxis(false);
        java.awt.Color color26 = java.awt.Color.GREEN;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color26, stroke27);
        categoryPlot22.addDomainMarker(categoryMarker28);
        org.jfree.chart.axis.ValueAxis valueAxis30 = categoryPlot22.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis32.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis35, categoryItemRenderer36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis32.setLabelPaint((java.awt.Paint) color38);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double46 = rectangleInsets44.calculateTopInset((double) ' ');
        categoryAxis32.setTickLabelInsets(rectangleInsets44);
        categoryPlot22.setInsets(rectangleInsets44);
        float float49 = categoryPlot22.getBackgroundAlpha();
        categoryPlot22.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent52 = null;
        categoryPlot22.markerChanged(markerChangeEvent52);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot22.getRangeAxis(0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder57 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color59 = java.awt.Color.GREEN;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color59, stroke60);
        java.awt.Stroke stroke62 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker61.setStroke(stroke62);
        boolean boolean64 = datasetRenderingOrder57.equals((java.lang.Object) categoryMarker61);
        java.awt.Font font65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker61.setLabelFont(font65);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = categoryMarker61.getLabelOffsetType();
        org.jfree.data.xy.XYDataset xYDataset68 = null;
        org.jfree.chart.axis.DateAxis dateAxis69 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range70 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis69.setRange(range70);
        org.jfree.data.Range range72 = dateAxis69.getRange();
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = null;
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot(xYDataset68, (org.jfree.chart.axis.ValueAxis) dateAxis69, (org.jfree.chart.axis.ValueAxis) dateAxis73, xYItemRenderer74);
        xYPlot75.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets79 = xYPlot75.getAxisOffset();
        xYPlot75.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder82 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color84 = java.awt.Color.GREEN;
        java.awt.Stroke stroke85 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker86 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color84, stroke85);
        java.awt.Stroke stroke87 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker86.setStroke(stroke87);
        boolean boolean89 = datasetRenderingOrder82.equals((java.lang.Object) categoryMarker86);
        java.awt.Font font90 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker86.setLabelFont(font90);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType92 = categoryMarker86.getLabelOffsetType();
        org.jfree.chart.util.Layer layer93 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean94 = xYPlot75.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker86, layer93);
        boolean boolean95 = categoryPlot22.removeDomainMarker(11, (org.jfree.chart.plot.Marker) categoryMarker61, layer93);
        try {
            categoryPlot6.addRangeMarker(marker15, layer93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + float49 + "' != '" + 1.0f + "'", float49 == 1.0f);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertNotNull(datasetRenderingOrder57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(lengthAdjustmentType67);
        org.junit.Assert.assertNotNull(range70);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(rectangleInsets79);
        org.junit.Assert.assertNotNull(datasetRenderingOrder82);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(font90);
        org.junit.Assert.assertNotNull(lengthAdjustmentType92);
        org.junit.Assert.assertNotNull(layer93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        xYPlot7.setBackgroundImageAlignment((int) 'a');
        boolean boolean28 = xYPlot7.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range4, false, false);
        try {
            dateAxis0.setRange((double) '#', (double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        double double6 = categoryAxis0.getUpperMargin();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot16.zoomDomainAxes(0.0d, plotRenderingInfo18, point2D19, true);
        int int22 = categoryPlot16.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis27, categoryItemRenderer28);
        categoryPlot16.setParent((org.jfree.chart.plot.Plot) categoryPlot29);
        java.awt.Color color32 = java.awt.Color.GREEN;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color32, stroke33);
        java.lang.String str35 = color32.toString();
        categoryPlot29.setRangeCrosshairPaint((java.awt.Paint) color32);
        org.jfree.chart.JFreeChart jFreeChart37 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot29, jFreeChart37);
        categoryPlot29.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup41 = categoryPlot29.getDatasetGroup();
        boolean boolean42 = categoryPlot29.isSubplot();
        double double43 = categoryPlot29.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot29.getRangeAxisEdge();
        try {
            double double45 = categoryAxis0.getCategoryEnd((int) (byte) 1, (-6553600), rectangle2D9, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str35.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        xYPlot7.setDomainCrosshairVisible(false);
        xYPlot7.setRangeCrosshairValue((double) ' ', true);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = xYPlot7.getRendererForDataset(xYDataset16);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(xYItemRenderer17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = null;
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis8.setRange(range9);
        org.jfree.data.Range range11 = dateAxis8.getRange();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer13);
        java.awt.Shape shape15 = dateAxis12.getUpArrow();
        dateAxis0.setUpArrow(shape15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis22.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot27.zoomDomainAxes(0.0d, plotRenderingInfo29, point2D30, true);
        int int33 = categoryPlot27.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis35.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis38, categoryItemRenderer39);
        categoryPlot27.setParent((org.jfree.chart.plot.Plot) categoryPlot40);
        java.awt.Color color43 = java.awt.Color.GREEN;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color43, stroke44);
        java.lang.String str46 = color43.toString();
        categoryPlot40.setRangeCrosshairPaint((java.awt.Paint) color43);
        org.jfree.chart.JFreeChart jFreeChart48 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot40, jFreeChart48);
        categoryPlot40.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup52 = categoryPlot40.getDatasetGroup();
        boolean boolean53 = categoryPlot40.isSubplot();
        double double54 = categoryPlot40.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot40.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        try {
            org.jfree.chart.axis.AxisState axisState57 = dateAxis0.draw(graphics2D17, 0.0d, rectangle2D19, rectangle2D20, rectangleEdge55, plotRenderingInfo56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str46.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        xYPlot7.clearRangeMarkers((-4194304));
        xYPlot7.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = xYPlot7.getLegendItems();
        xYPlot7.setDomainGridlinesVisible(false);
        xYPlot7.configureRangeAxes();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(legendItemCollection32);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        boolean boolean8 = categoryPlot7.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot7.getAxisOffset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot7.getRenderer();
        categoryPlot7.setDomainGridlinesVisible(false);
        boolean boolean13 = seriesRenderingOrder0.equals((java.lang.Object) false);
        java.lang.String str14 = seriesRenderingOrder0.toString();
        java.lang.String str15 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str14.equals("SeriesRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str15.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.setRangeCrosshairValue((double) 8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot6.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
        categoryPlot6.setRangeAxisLocation((int) ' ', axisLocation19, false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxis17);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit7, true, true);
        dateAxis0.setRangeWithMargins((-7.99999999d), (double) 100L);
        boolean boolean14 = dateAxis0.isAutoRange();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        org.jfree.chart.plot.Plot plot29 = categoryPlot19.getRootPlot();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(plot29);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        java.awt.Stroke stroke26 = categoryPlot6.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot6.zoomRangeAxes((double) (byte) 1, plotRenderingInfo28, point2D29, false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker4.setStroke(stroke5);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) categoryMarker4);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis12, categoryItemRenderer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis9.setLabelPaint((java.awt.Paint) color15);
        categoryMarker4.setLabelPaint((java.awt.Paint) color15);
        int int18 = color15.getBlue();
        java.awt.Color color19 = color15.brighter();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 128 + "'", int18 == 128);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        float float23 = categoryPlot6.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot6.zoomDomainAxes((double) 8, plotRenderingInfo25, point2D26, false);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis33, categoryItemRenderer34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis30.setLabelPaint((java.awt.Paint) color36);
        categoryPlot6.setDomainAxis(categoryAxis30);
        categoryPlot6.clearRangeMarkers((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color7 = java.awt.Color.GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color7, stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint5, stroke8);
        boolean boolean11 = categoryAnchor3.equals((java.lang.Object) stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color2, stroke8);
        boolean boolean13 = unitType0.equals((java.lang.Object) stroke8);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (byte) 100, 0.0d, (-111.0d));
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = xYPlot7.getDrawingSupplier();
        xYPlot7.setRangeCrosshairValue((double) 10L);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(drawingSupplier29);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setCategoryMargin((double) (-4194304));
        float float12 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setUpperMargin((double) 0L);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearAnnotations();
        boolean boolean14 = xYPlot7.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        int int23 = xYPlot7.indexOf(xYDataset22);
        xYPlot7.clearRangeMarkers();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.RIGHT" + "'", str1.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        xYPlot7.clearRangeMarkers((-4194304));
        xYPlot7.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = xYPlot7.getLegendItems();
        xYPlot7.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        int int36 = xYPlot7.getIndexOf(xYItemRenderer35);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        java.lang.String str42 = rectangleInsets41.toString();
        double double44 = rectangleInsets41.calculateTopOutset(0.0d);
        xYPlot7.setAxisOffset(rectangleInsets41);
        java.awt.Color color47 = java.awt.Color.GREEN;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color47, stroke48);
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker49.setStroke(stroke50);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder52 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color54 = java.awt.Color.GREEN;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color54, stroke55);
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker56.setStroke(stroke57);
        boolean boolean59 = datasetRenderingOrder52.equals((java.lang.Object) categoryMarker56);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis61.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis64, categoryItemRenderer65);
        java.awt.Color color67 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis61.setLabelPaint((java.awt.Paint) color67);
        categoryMarker56.setLabelPaint((java.awt.Paint) color67);
        categoryMarker49.setOutlinePaint((java.awt.Paint) color67);
        xYPlot7.setRangeGridlinePaint((java.awt.Paint) color67);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]" + "'", str42.equals("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]"));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(datasetRenderingOrder52);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(color67);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateTopInset((double) ' ');
        java.lang.Object obj7 = null;
        boolean boolean8 = rectangleInsets4.equals(obj7);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        java.awt.Stroke stroke27 = categoryPlot19.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation29 = categoryPlot19.getDomainAxisLocation(100);
        java.awt.Image image30 = categoryPlot19.getBackgroundImage();
        java.awt.Color color32 = java.awt.Color.GREEN;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color32, stroke33);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker34.setStroke(stroke35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color39 = java.awt.Color.GREEN;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color39, stroke40);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker41.setStroke(stroke42);
        boolean boolean44 = datasetRenderingOrder37.equals((java.lang.Object) categoryMarker41);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis46.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis49, categoryItemRenderer50);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis46.setLabelPaint((java.awt.Paint) color52);
        categoryMarker41.setLabelPaint((java.awt.Paint) color52);
        categoryMarker34.setOutlinePaint((java.awt.Paint) color52);
        boolean boolean56 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        org.jfree.chart.axis.AxisSpace axisSpace57 = categoryPlot19.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNull(image30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(axisSpace57);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        xYPlot7.clearRangeMarkers(128);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        float float33 = categoryPlot6.getBackgroundAlpha();
        categoryPlot6.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot6.markerChanged(markerChangeEvent36);
        org.jfree.chart.axis.ValueAxis valueAxis39 = categoryPlot6.getRangeAxis(0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent40);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getBackgroundImageAlignment();
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color17 = java.awt.Color.GREEN;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color17, stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint15, stroke18);
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean23 = categoryPlot6.removeRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker20, layer21, true);
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot6.setRenderer(categoryItemRenderer25, true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.FORWARD");
        double double2 = categoryAxis1.getFixedDimension();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (-1L));
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        categoryPlot20.setBackgroundImageAlpha(0.0f);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range30 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis29.setRange(range30);
        org.jfree.data.Range range32 = dateAxis29.getRange();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset28, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer34);
        xYPlot35.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = xYPlot35.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot35.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = xYPlot35.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis45 = xYPlot35.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range48 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis47.setRange(range48);
        org.jfree.data.Range range50 = dateAxis47.getRange();
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis51, xYItemRenderer52);
        xYPlot53.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = xYPlot53.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation59 = xYPlot53.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot53.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot53.getDomainAxisForDataset((int) (byte) 0);
        valueAxis63.setNegativeArrowVisible(false);
        valueAxis63.setLowerMargin((double) 0);
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range69 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis68.setRange(range69);
        org.jfree.data.Range range71 = dateAxis68.getRange();
        dateAxis68.resizeRange((-355.0d), (double) 2.0f);
        dateAxis68.setPositiveArrowVisible(true);
        boolean boolean78 = dateAxis68.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis79 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range80 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis79.setRange(range80);
        dateAxis79.zoomRange((double) (-4194304), 2.0d);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray85 = new org.jfree.chart.axis.ValueAxis[] { valueAxis45, valueAxis63, dateAxis68, dateAxis79 };
        categoryPlot20.setRangeAxes(valueAxisArray85);
        categoryPlot6.setRangeAxes(valueAxisArray85);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(valueAxis45);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(range71);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertNotNull(valueAxisArray85);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        categoryAxis1.setCategoryLabelPositionOffset(255);
        java.lang.Comparable comparable14 = null;
        java.awt.Paint paint15 = null;
        try {
            categoryAxis1.setTickLabelPaint(comparable14, paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        boolean boolean8 = dateAxis1.isPositiveArrowVisible();
        try {
            dateAxis1.setRangeWithMargins((double) 255, (-355.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (255.0) <= upper (-355.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        int int51 = xYPlot7.getDomainAxisCount();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        xYPlot7.clearRangeMarkers((-4194304));
        xYPlot7.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection32 = xYPlot7.getLegendItems();
        xYPlot7.setDomainGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        int int36 = xYPlot7.getIndexOf(xYItemRenderer35);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        java.lang.String str42 = rectangleInsets41.toString();
        double double44 = rectangleInsets41.calculateTopOutset(0.0d);
        xYPlot7.setAxisOffset(rectangleInsets41);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation46 = null;
        try {
            xYPlot7.addAnnotation(xYAnnotation46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]" + "'", str42.equals("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]"));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot19.getDomainGridlinePosition();
        boolean boolean22 = categoryPlot19.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range4, false, false);
        org.jfree.data.Range range8 = dateAxis0.getRange();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range11);
        org.jfree.data.Range range13 = dateAxis10.getRange();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer15);
        xYPlot16.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = xYPlot16.getAxisOffset();
        xYPlot16.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis28, categoryItemRenderer29);
        categoryPlot30.setDrawSharedDomainAxis(false);
        java.awt.Color color34 = java.awt.Color.GREEN;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color34, stroke35);
        categoryPlot30.addDomainMarker(categoryMarker36);
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot30.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis40.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis43, categoryItemRenderer44);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis40.setLabelPaint((java.awt.Paint) color46);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double54 = rectangleInsets52.calculateTopInset((double) ' ');
        categoryAxis40.setTickLabelInsets(rectangleInsets52);
        categoryPlot30.setInsets(rectangleInsets52);
        org.jfree.chart.axis.AxisLocation axisLocation58 = categoryPlot30.getDomainAxisLocation(2);
        xYPlot16.setDomainAxisLocation(0, axisLocation58);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis61.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis64, categoryItemRenderer65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot66.zoomDomainAxes(0.0d, plotRenderingInfo68, point2D69, true);
        org.jfree.chart.axis.AxisSpace axisSpace72 = null;
        categoryPlot66.setFixedDomainAxisSpace(axisSpace72);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent74 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot66);
        org.jfree.chart.plot.Plot plot75 = plotChangeEvent74.getPlot();
        plot75.setForegroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder78 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color80 = java.awt.Color.GREEN;
        java.awt.Stroke stroke81 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker82 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color80, stroke81);
        java.awt.Stroke stroke83 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker82.setStroke(stroke83);
        boolean boolean85 = datasetRenderingOrder78.equals((java.lang.Object) categoryMarker82);
        java.awt.Font font86 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker82.setLabelFont(font86);
        java.awt.Stroke stroke88 = categoryMarker82.getStroke();
        plot75.setOutlineStroke(stroke88);
        xYPlot16.setDomainCrosshairStroke(stroke88);
        dateAxis0.setAxisLineStroke(stroke88);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(plot75);
        org.junit.Assert.assertNotNull(datasetRenderingOrder78);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(font86);
        org.junit.Assert.assertNotNull(stroke88);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        int int13 = xYPlot7.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        try {
            xYPlot7.setRangeAxisLocation(axisLocation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis6.setRange(range7);
        org.jfree.data.Range range9 = dateAxis6.getRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        xYPlot12.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot12.getAxisOffset();
        java.awt.Paint paint17 = xYPlot12.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double24 = rectangleInsets22.calculateTopInset((double) ' ');
        double double26 = rectangleInsets22.calculateLeftInset((double) (byte) 10);
        double double28 = rectangleInsets22.calculateRightInset(0.0d);
        xYPlot12.setInsets(rectangleInsets22, true);
        categoryAxis0.setTickLabelInsets(rectangleInsets22);
        double double33 = rectangleInsets22.extendWidth(0.2d);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        try {
            rectangleInsets22.trim(rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 110.2d + "'", double33 == 110.2d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot19.getDatasetGroup();
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot19.setNoDataMessagePaint((java.awt.Paint) color32);
        boolean boolean34 = categoryPlot19.isRangeZoomable();
        java.lang.String str35 = categoryPlot19.getPlotType();
        categoryPlot19.setAnchorValue(4.0d, false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Category Plot" + "'", str35.equals("Category Plot"));
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        long long2 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot19.getDatasetGroup();
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot19.setNoDataMessagePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot19.getRangeAxis((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(valueAxis35);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot16.getOrientation();
        boolean boolean18 = categoryPlot6.equals((java.lang.Object) categoryPlot16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint23, stroke26);
        boolean boolean29 = categoryAnchor21.equals((java.lang.Object) stroke26);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color20, stroke26);
        categoryPlot6.setRangeCrosshairStroke(stroke26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot6.setRenderer(categoryItemRenderer32);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=255,b=0]");
        dateAxis1.zoomRange(2.0d, (double) 100);
        org.jfree.chart.axis.Timeline timeline5 = null;
        dateAxis1.setTimeline(timeline5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = categoryMarker3.getLabelOffsetType();
        try {
            categoryMarker3.setAlpha((float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        dateAxis0.setPositiveArrowVisible(true);
        java.awt.Paint paint9 = dateAxis0.getTickMarkPaint();
        double double10 = dateAxis0.getFixedAutoRange();
        java.lang.Class class11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRange(range13);
        org.jfree.data.Range range15 = dateAxis12.getRange();
        dateAxis12.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date19 = dateAxis12.getMaximumDate();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date19, timeZone20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis22.setRange(range23);
        org.jfree.data.Range range25 = dateAxis22.getRange();
        dateAxis22.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date29 = dateAxis22.getMaximumDate();
        try {
            dateAxis0.setRange(date19, date29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot19.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis23.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double37 = rectangleInsets35.calculateTopInset((double) ' ');
        categoryAxis23.setTickLabelInsets(rectangleInsets35);
        double double40 = rectangleInsets35.calculateTopInset((double) (short) -1);
        categoryPlot19.setInsets(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        xYPlot7.clearDomainAxes();
        java.awt.Paint paint15 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot7.setDomainGridlineStroke(stroke16);
        java.awt.Paint paint18 = xYPlot7.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot7.zoomDomainAxes(0.0d, plotRenderingInfo9, point2D10, true);
        int int13 = categoryPlot7.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        categoryPlot7.setParent((org.jfree.chart.plot.Plot) categoryPlot20);
        java.awt.Color color23 = java.awt.Color.GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color23, stroke24);
        java.lang.String str26 = color23.toString();
        categoryPlot20.setRangeCrosshairPaint((java.awt.Paint) color23);
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot20, jFreeChart28);
        java.awt.Paint paint30 = categoryPlot20.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis36, categoryItemRenderer37);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryAxis33.setTickLabelPaint((java.awt.Paint) color39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color39, stroke41);
        java.awt.Paint paint43 = null;
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str45 = datasetRenderingOrder44.toString();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis47.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis50, categoryItemRenderer51);
        categoryPlot52.setDrawSharedDomainAxis(false);
        java.awt.Color color56 = java.awt.Color.GREEN;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color56, stroke57);
        categoryPlot52.addDomainMarker(categoryMarker58);
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot52.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset62 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis63.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset62, categoryAxis63, valueAxis66, categoryItemRenderer67);
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis63.setLabelPaint((java.awt.Paint) color69);
        int int71 = categoryAxis63.getCategoryLabelPositionOffset();
        categoryPlot52.setDomainAxis((int) (short) 1, categoryAxis63);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis63.setAxisLineStroke(stroke73);
        boolean boolean75 = datasetRenderingOrder44.equals((java.lang.Object) stroke73);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "", paint30, stroke41, paint43, stroke73, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str26.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str45.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        xYPlot7.setDomainAxis((int) (short) 100, valueAxis14, false);
        java.awt.Stroke stroke17 = null;
        xYPlot7.setOutlineStroke(stroke17);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        xYPlot7.clearRangeMarkers((-4194304));
        xYPlot7.configureRangeAxes();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.plot.CrosshairState crosshairState36 = null;
        boolean boolean37 = xYPlot7.render(graphics2D32, rectangle2D33, (-12517377), plotRenderingInfo35, crosshairState36);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.setRangeCrosshairValue((double) 8, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = categoryPlot6.getDrawingSupplier();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot6.getRenderer(12);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.util.Date date8 = dateAxis5.getMaximumDate();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        categoryAxis0.setCategoryMargin((double) 3);
        categoryAxis0.setLowerMargin(1.0d);
        java.lang.String str10 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 12);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = categoryPlot6.getOrientation();
        categoryPlot6.setWeight(15);
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        categoryAxis1.setLabelAngle((-1.0d));
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot6.getAxisOffset();
        double double9 = rectangleInsets8.getBottom();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRange(range16);
        org.jfree.data.Range range18 = dateAxis15.getRange();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        xYPlot21.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        xYPlot21.clearAnnotations();
        java.awt.Paint paint27 = xYPlot21.getDomainZeroBaselinePaint();
        xYPlot21.clearDomainAxes();
        java.awt.Paint paint29 = xYPlot21.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot21.setDomainGridlineStroke(stroke30);
        xYPlot7.setDomainCrosshairStroke(stroke30);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRange(range18);
        org.jfree.data.Range range20 = dateAxis17.getRange();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer22);
        xYPlot23.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis32, categoryItemRenderer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot34.zoomDomainAxes(0.0d, plotRenderingInfo36, point2D37, true);
        int int40 = categoryPlot34.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder41 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color43 = java.awt.Color.GREEN;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color43, stroke44);
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker45.setStroke(stroke46);
        boolean boolean48 = datasetRenderingOrder41.equals((java.lang.Object) categoryMarker45);
        org.jfree.chart.util.Layer layer49 = null;
        categoryPlot34.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker45, layer49);
        java.awt.Stroke stroke51 = categoryMarker45.getStroke();
        org.jfree.data.category.CategoryDataset categoryDataset52 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis53.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset52, categoryAxis53, valueAxis56, categoryItemRenderer57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.awt.geom.Point2D point2D61 = null;
        categoryPlot58.zoomDomainAxes(0.0d, plotRenderingInfo60, point2D61, true);
        int int64 = categoryPlot58.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder66 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color68 = java.awt.Color.GREEN;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker70 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color68, stroke69);
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker70.setStroke(stroke71);
        boolean boolean73 = datasetRenderingOrder66.equals((java.lang.Object) categoryMarker70);
        org.jfree.data.category.CategoryDataset categoryDataset74 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis75.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset74, categoryAxis75, valueAxis78, categoryItemRenderer79);
        java.awt.Color color81 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis75.setLabelPaint((java.awt.Paint) color81);
        categoryMarker70.setLabelPaint((java.awt.Paint) color81);
        org.jfree.chart.util.Layer layer84 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot58.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker70, layer84);
        xYPlot23.addDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker45, layer84);
        try {
            categoryPlot6.addRangeMarker((-4194304), marker15, layer84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder66);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(layer84);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateTopInset((double) ' ');
        double double8 = rectangleInsets4.calculateLeftInset((double) (byte) 10);
        double double10 = rectangleInsets4.calculateRightInset(0.0d);
        double double12 = rectangleInsets4.calculateTopInset((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot6.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot6.getIndexOf(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        int int5 = categoryAxis0.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color9 = java.awt.Color.GREEN;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color9, stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker11.setStroke(stroke12);
        boolean boolean14 = datasetRenderingOrder7.equals((java.lang.Object) categoryMarker11);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        categoryMarker11.setLabelPaint((java.awt.Paint) color22);
        int int25 = color22.getBlue();
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) '#', (java.awt.Paint) color22);
        int int27 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 128 + "'", int25 == 128);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        xYPlot7.clearRangeMarkers((-4194304));
        xYPlot7.configureRangeAxes();
        xYPlot7.setRangeCrosshairVisible(true);
        java.awt.Stroke stroke34 = xYPlot7.getDomainZeroBaselineStroke();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        try {
            xYPlot7.drawBackground(graphics2D35, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        categoryAxis1.setCategoryLabelPositionOffset(255);
        categoryAxis1.setCategoryMargin((-7.0d));
        java.lang.String str17 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setDrawSharedDomainAxis(false);
        java.awt.Color color11 = java.awt.Color.GREEN;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color11, stroke12);
        categoryPlot7.addDomainMarker(categoryMarker13);
        categoryPlot7.setRangeCrosshairValue((double) 8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot7.getDomainAxis();
        categoryPlot7.setWeight(10);
        boolean boolean21 = textAnchor0.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(categoryAxis18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        float float33 = categoryPlot6.getBackgroundAlpha();
        categoryPlot6.setBackgroundImageAlpha((float) (byte) 1);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        categoryPlot6.markerChanged(markerChangeEvent36);
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot6.getDataset((-254));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNull(categoryDataset39);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        double double34 = rectangleInsets28.calculateRightOutset((double) (byte) 0);
        double double36 = rectangleInsets28.extendHeight((double) 100.0f);
        double double37 = rectangleInsets28.getLeft();
        double double38 = rectangleInsets28.getBottom();
        double double40 = rectangleInsets28.calculateRightOutset((double) (short) -1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 201.0d + "'", double36 == 201.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 100.0d + "'", double38 == 100.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 10.0d + "'", double40 == 10.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        float float23 = categoryPlot6.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot6.zoomDomainAxes((double) 8, plotRenderingInfo25, point2D26, false);
        int int29 = categoryPlot6.getDomainAxisCount();
        categoryPlot6.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        dateAxis0.setPositiveArrowVisible(true);
        boolean boolean10 = dateAxis0.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis11.setRange(range12);
        org.jfree.data.Range range14 = dateAxis11.getRange();
        dateAxis11.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date18 = dateAxis11.getMaximumDate();
        dateAxis0.setMinimumDate(date18);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str1.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color28 = java.awt.Color.GREEN;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color28, stroke29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker30.setStroke(stroke31);
        boolean boolean33 = datasetRenderingOrder26.equals((java.lang.Object) categoryMarker30);
        java.awt.Font font34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker30.setLabelFont(font34);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = categoryMarker30.getLabelOffsetType();
        categoryMarker30.setLabel("DatasetRenderingOrder.FORWARD");
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState44 = null;
        boolean boolean45 = xYPlot7.render(graphics2D40, rectangle2D41, 4, plotRenderingInfo43, crosshairState44);
        org.jfree.chart.axis.AxisLocation axisLocation46 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation(axisLocation46, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        xYPlot7.setDomainCrosshairVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Color color23 = java.awt.Color.GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color23, stroke24);
        categoryPlot19.addDomainMarker(categoryMarker25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot19.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis29.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis32, categoryItemRenderer33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis29.setLabelPaint((java.awt.Paint) color35);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double43 = rectangleInsets41.calculateTopInset((double) ' ');
        categoryAxis29.setTickLabelInsets(rectangleInsets41);
        categoryPlot19.setInsets(rectangleInsets41);
        double double47 = rectangleInsets41.calculateRightOutset((double) (byte) 0);
        double double49 = rectangleInsets41.extendHeight((double) 100.0f);
        double double51 = rectangleInsets41.trimHeight((double) (-254));
        xYPlot7.setAxisOffset(rectangleInsets41);
        xYPlot7.clearAnnotations();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.0d + "'", double47 == 10.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 201.0d + "'", double49 == 201.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + (-355.0d) + "'", double51 == (-355.0d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color28 = java.awt.Color.GREEN;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color28, stroke29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker30.setStroke(stroke31);
        boolean boolean33 = datasetRenderingOrder26.equals((java.lang.Object) categoryMarker30);
        java.awt.Font font34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker30.setLabelFont(font34);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = categoryMarker30.getLabelOffsetType();
        categoryMarker30.setLabel("DatasetRenderingOrder.FORWARD");
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        java.awt.Paint paint40 = xYPlot7.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot19.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis28, categoryItemRenderer29);
        categoryAxis25.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis25.getTickLabelInsets();
        categoryAxis25.setCategoryMargin((double) (-4194304));
        float float36 = categoryAxis25.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis38.setRange(range39);
        org.jfree.data.Range range41 = dateAxis38.getRange();
        dateAxis38.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date45 = dateAxis38.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = dateAxis38.getTickUnit();
        dateAxis37.setTickUnit(dateTickUnit46, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer50);
        categoryPlot19.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37, false);
        java.util.List list54 = categoryPlot19.getCategories();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 2.0f + "'", float36 == 2.0f);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNull(list54);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range8);
        java.text.DateFormat dateFormat10 = dateAxis1.getDateFormatOverride();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        int int26 = categoryPlot20.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis31, categoryItemRenderer32);
        categoryPlot20.setParent((org.jfree.chart.plot.Plot) categoryPlot33);
        java.awt.Color color36 = java.awt.Color.GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color36, stroke37);
        java.lang.String str39 = color36.toString();
        categoryPlot33.setRangeCrosshairPaint((java.awt.Paint) color36);
        org.jfree.chart.JFreeChart jFreeChart41 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot33, jFreeChart41);
        categoryPlot33.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup45 = categoryPlot33.getDatasetGroup();
        boolean boolean46 = categoryPlot33.isSubplot();
        double double47 = categoryPlot33.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot33.getRangeAxisEdge();
        try {
            java.util.List list49 = dateAxis1.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str39.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        java.lang.Object obj12 = categoryAxis1.clone();
        int int13 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        categoryAxis14.setVisible(false);
        java.awt.Paint paint19 = categoryAxis14.getTickMarkPaint();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range22 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis21.setRange(range22);
        org.jfree.data.Range range24 = dateAxis21.getRange();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) dateAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer26);
        xYPlot27.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = xYPlot27.getAxisOffset();
        xYPlot27.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRange(range34);
        org.jfree.data.Range range36 = dateAxis33.getRange();
        dateAxis33.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date40 = dateAxis33.getMaximumDate();
        int int41 = xYPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        int int43 = xYPlot27.indexOf(xYDataset42);
        boolean boolean44 = categoryAxis14.hasListener((java.util.EventListener) xYPlot27);
        float float45 = xYPlot27.getForegroundAlpha();
        java.awt.Color color46 = java.awt.Color.RED;
        xYPlot27.setNoDataMessagePaint((java.awt.Paint) color46);
        categoryAxis1.setLabelPaint((java.awt.Paint) color46);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range51 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis50.setRange(range51);
        org.jfree.data.Range range53 = dateAxis50.getRange();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer55);
        xYPlot56.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = xYPlot56.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot56.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot56.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis66 = xYPlot56.getDomainAxisForDataset((int) (byte) 0);
        java.lang.String str67 = xYPlot56.getPlotType();
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        java.util.List list70 = null;
        xYPlot56.drawRangeTickBands(graphics2D68, rectangle2D69, list70);
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis74.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, valueAxis77, categoryItemRenderer78);
        java.awt.Color color80 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryAxis74.setTickLabelPaint((java.awt.Paint) color80);
        java.awt.Stroke stroke82 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker83 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color80, stroke82);
        xYPlot56.setRangeZeroBaselineStroke(stroke82);
        categoryAxis1.setTickMarkStroke(stroke82);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 1.0f + "'", float45 == 1.0f);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(valueAxis66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "XY Plot" + "'", str67.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(stroke82);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        java.awt.Paint paint43 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot6.getDataset();
        org.jfree.chart.event.PlotChangeListener plotChangeListener45 = null;
        categoryPlot6.addChangeListener(plotChangeListener45);
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range49 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis48.setRange(range49);
        org.jfree.data.Range range51 = dateAxis48.getRange();
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) dateAxis48, (org.jfree.chart.axis.ValueAxis) dateAxis52, xYItemRenderer53);
        xYPlot54.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = xYPlot54.getAxisOffset();
        java.awt.Paint paint59 = xYPlot54.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double66 = rectangleInsets64.calculateTopInset((double) ' ');
        double double68 = rectangleInsets64.calculateLeftInset((double) (byte) 10);
        double double70 = rectangleInsets64.calculateRightInset(0.0d);
        xYPlot54.setInsets(rectangleInsets64, true);
        org.jfree.data.xy.XYDataset xYDataset74 = null;
        xYPlot54.setDataset((int) 'a', xYDataset74);
        xYPlot54.clearRangeMarkers((-4194304));
        xYPlot54.configureRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection79 = xYPlot54.getLegendItems();
        categoryPlot6.setFixedLegendItems(legendItemCollection79);
        categoryPlot6.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.0d + "'", double68 == 100.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 10.0d + "'", double70 == 10.0d);
        org.junit.Assert.assertNotNull(legendItemCollection79);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot6.getDataset(4);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis30, categoryItemRenderer31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis27.setLabelPaint((java.awt.Paint) color33);
        int int35 = categoryAxis27.getCategoryLabelPositionOffset();
        categoryPlot6.setDomainAxis(15, categoryAxis27);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        categoryPlot6.setDomainGridlinesVisible(true);
        categoryPlot6.clearDomainMarkers(9);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeIncludesZero(true);
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color6 = java.awt.Color.GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color6, stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint4, stroke7);
        boolean boolean10 = categoryAnchor2.equals((java.lang.Object) stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color1, stroke7);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot12.setDomainAxes(categoryAxisArray13);
        boolean boolean15 = valueMarker11.equals((java.lang.Object) categoryPlot12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getRangeAxisEdge((-16777216));
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRange(range18);
        org.jfree.data.Range range20 = dateAxis17.getRange();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer22);
        xYPlot23.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = xYPlot23.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot23.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot23.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot23.getDomainAxisForDataset((int) (byte) 0);
        xYPlot7.setDomainAxis(valueAxis33);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(valueAxis33);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        java.lang.String str3 = datasetChangeEvent2.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=java.awt.Color[r=255,g=175,b=175]]" + "'", str3.equals("org.jfree.data.general.DatasetChangeEvent[source=java.awt.Color[r=255,g=175,b=175]]"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot19.getDataset(100);
        org.jfree.chart.util.SortOrder sortOrder33 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setTickMarkInsideLength((float) 5);
        boolean boolean37 = sortOrder33.equals((java.lang.Object) categoryAxis34);
        categoryPlot19.setRowRenderingOrder(sortOrder33);
        java.lang.String str39 = sortOrder33.toString();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "SortOrder.DESCENDING" + "'", str39.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot16.zoomDomainAxes(0.0d, plotRenderingInfo18, point2D19, true);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace22);
        categoryPlot16.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getRangeAxisEdge();
        try {
            java.util.List list27 = dateAxis0.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis0.setTimeline(timeline9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color17 = java.awt.Color.GREEN;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color17, stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint15, stroke18);
        boolean boolean21 = categoryAnchor13.equals((java.lang.Object) stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color12, stroke18);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot29.zoomDomainAxes(0.0d, plotRenderingInfo31, point2D32, true);
        categoryPlot29.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot29.getIndexOf(categoryItemRenderer37);
        valueMarker22.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot29);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        java.lang.Class class41 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range43 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis42.setRange(range43);
        org.jfree.data.Range range45 = dateAxis42.getRange();
        dateAxis42.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date49 = dateAxis42.getMaximumDate();
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date49, timeZone50);
        dateAxis0.setMinimumDate(date49);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNull(regularTimePeriod51);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12);
        java.awt.Stroke stroke14 = categoryPlot6.getDomainGridlineStroke();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = categoryPlot6.getDomainGridlinePosition();
        java.lang.String str16 = categoryAnchor15.toString();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str16.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker18.setStroke(stroke19);
        boolean boolean21 = datasetRenderingOrder14.equals((java.lang.Object) categoryMarker18);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis23.setLabelPaint((java.awt.Paint) color29);
        categoryMarker18.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker18, layer32);
        java.util.List list34 = categoryPlot6.getCategories();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = categoryPlot6.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(list34);
        org.junit.Assert.assertNotNull(drawingSupplier35);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        boolean boolean29 = xYPlot7.isRangeCrosshairLockedOnData();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint34 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color36 = java.awt.Color.GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color36, stroke37);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint34, stroke37);
        boolean boolean40 = categoryAnchor32.equals((java.lang.Object) stroke37);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color31, stroke37);
        xYPlot7.setRangeZeroBaselineStroke(stroke37);
        boolean boolean43 = xYPlot7.isDomainCrosshairVisible();
        double double44 = xYPlot7.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(categoryAnchor32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        categoryPlot6.clearDomainMarkers(0);
        categoryPlot6.setWeight(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot6.zoomRangeAxes((double) (short) -1, plotRenderingInfo14, point2D15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRange(range19);
        org.jfree.data.Range range21 = dateAxis18.getRange();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer23);
        xYPlot24.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = xYPlot24.getAxisOffset();
        xYPlot24.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis36, categoryItemRenderer37);
        categoryPlot38.setDrawSharedDomainAxis(false);
        java.awt.Color color42 = java.awt.Color.GREEN;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color42, stroke43);
        categoryPlot38.addDomainMarker(categoryMarker44);
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot38.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis48.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis51, categoryItemRenderer52);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis48.setLabelPaint((java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double62 = rectangleInsets60.calculateTopInset((double) ' ');
        categoryAxis48.setTickLabelInsets(rectangleInsets60);
        categoryPlot38.setInsets(rectangleInsets60);
        org.jfree.chart.axis.AxisLocation axisLocation66 = categoryPlot38.getDomainAxisLocation(2);
        xYPlot24.setDomainAxisLocation(0, axisLocation66);
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot24.getDomainAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        int int70 = xYPlot24.getIndexOf(xYItemRenderer69);
        java.awt.Paint paint71 = xYPlot24.getDomainGridlinePaint();
        categoryPlot6.setBackgroundPaint(paint71);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(valueAxis68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot6.setDomainAxisLocation((int) '#', axisLocation15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot6.getRenderer();
        categoryPlot6.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.setRangeCrosshairValue((double) 8, false);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot6.addChangeListener(plotChangeListener18);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        xYPlot7.clearRangeMarkers((-4194304));
        xYPlot7.configureRangeAxes();
        java.awt.Color color33 = java.awt.Color.RED;
        try {
            xYPlot7.setQuadrantPaint(255, (java.awt.Paint) color33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (255) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot6.setDataset(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        boolean boolean12 = categoryPlot6.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot6.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot6.setRenderer((int) (short) 100, categoryItemRenderer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot6.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        categoryPlot0.setRangeCrosshairValue((double) '#', true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        boolean boolean14 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot6.getDomainAxis((int) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis18.setRange(range19);
        org.jfree.data.Range range21 = dateAxis18.getRange();
        dateAxis18.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date25 = dateAxis18.getMaximumDate();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean27 = dateAxis18.equals((java.lang.Object) categoryAxis26);
        try {
            categoryPlot6.setDomainAxis((-12517377), categoryAxis26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, (double) (short) 100, (double) 100L, (double) 8);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot13.zoomDomainAxes(0.0d, plotRenderingInfo15, point2D16, true);
        int int19 = categoryPlot13.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color23 = java.awt.Color.GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color23, stroke24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker25.setStroke(stroke26);
        boolean boolean28 = datasetRenderingOrder21.equals((java.lang.Object) categoryMarker25);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis33, categoryItemRenderer34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis30.setLabelPaint((java.awt.Paint) color36);
        categoryMarker25.setLabelPaint((java.awt.Paint) color36);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot13.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker25, layer39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean42 = layer39.equals((java.lang.Object) lengthAdjustmentType41);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets5.createAdjustedRectangle(rectangle2D6, lengthAdjustmentType41, lengthAdjustmentType43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker18.setStroke(stroke19);
        boolean boolean21 = datasetRenderingOrder14.equals((java.lang.Object) categoryMarker18);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker18.setLabelFont(font22);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = categoryMarker18.getLabelOffsetType();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean26 = xYPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer25);
        java.awt.Stroke stroke27 = categoryMarker18.getStroke();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        dateAxis1.setRange((-111.0d), (double) (short) 0);
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis1.setTickUnit(dateTickUnit11, false, false);
        java.util.Date date15 = dateAxis1.getMaximumDate();
        dateAxis1.setAutoTickUnitSelection(false, false);
        org.jfree.chart.axis.Timeline timeline19 = null;
        dateAxis1.setTimeline(timeline19);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleAnchor.RIGHT");
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis4.setRange(range5);
        org.jfree.data.Range range7 = dateAxis4.getRange();
        boolean boolean8 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis4.setStandardTickUnits(tickUnitSource9);
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis4.setTickUnit(dateTickUnit11, true, true);
        java.util.Date date15 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit11);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(dateTickUnit11);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        xYPlot7.drawAnnotations(graphics2D8, rectangle2D9, plotRenderingInfo10);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder12 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        xYPlot7.setRenderer(xYItemRenderer13);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder12);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        double double34 = rectangleInsets28.calculateBottomOutset((double) 15);
        double double36 = rectangleInsets28.calculateBottomOutset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets28.createOutsetRectangle(rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeIncludesZero(true);
        java.lang.Object obj6 = numberAxis1.clone();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis8.setAutoRangeStickyZero(false);
        numberAxis8.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis14.setAutoRangeStickyZero(false);
        boolean boolean17 = numberAxis14.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = numberAxis14.getTickUnit();
        numberAxis8.setTickUnit(numberTickUnit18, false, false);
        numberAxis1.setTickUnit(numberTickUnit18);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(numberTickUnit18);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        java.awt.Paint paint29 = categoryPlot19.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot19.zoomDomainAxes((double) 255, plotRenderingInfo31, point2D32, false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.plot.Plot plot15 = plotChangeEvent14.getPlot();
        java.lang.String str16 = plotChangeEvent14.toString();
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        categoryAxis24.setAxisLineVisible(true);
        int int29 = categoryAxis24.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color33 = java.awt.Color.GREEN;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color33, stroke34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker35.setStroke(stroke36);
        boolean boolean38 = datasetRenderingOrder31.equals((java.lang.Object) categoryMarker35);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis40.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis43, categoryItemRenderer44);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis40.setLabelPaint((java.awt.Paint) color46);
        categoryMarker35.setLabelPaint((java.awt.Paint) color46);
        int int49 = color46.getBlue();
        categoryAxis24.setTickLabelPaint((java.lang.Comparable) '#', (java.awt.Paint) color46);
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color46);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 128 + "'", int49 == 128);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color6 = java.awt.Color.GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color6, stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint4, stroke7);
        boolean boolean10 = categoryAnchor2.equals((java.lang.Object) stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color1, stroke7);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21, true);
        categoryPlot18.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot18.getIndexOf(categoryItemRenderer26);
        valueMarker11.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot18);
        java.awt.Paint paint29 = valueMarker11.getLabelPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        java.lang.Class<?> wildcardClass1 = textAnchor0.getClass();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        float[] floatArray3 = new float[] {};
        try {
            float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) '4', (int) ' ', floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        boolean boolean14 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot6.getDataset();
        java.awt.Stroke stroke16 = null;
        try {
            categoryPlot6.setRangeCrosshairStroke(stroke16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(categoryDataset15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot6.setDataset(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        boolean boolean12 = categoryPlot6.isDomainGridlinesVisible();
        categoryPlot6.setRangeCrosshairValue((double) 100.0f, true);
        try {
            categoryPlot6.mapDatasetToRangeAxis((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        org.jfree.data.Range range10 = dateAxis7.getRange();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        xYPlot13.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot13.getAxisOffset();
        xYPlot13.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range20);
        org.jfree.data.Range range22 = dateAxis19.getRange();
        dateAxis19.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        int int27 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        int int29 = xYPlot13.indexOf(xYDataset28);
        boolean boolean30 = categoryAxis0.hasListener((java.util.EventListener) xYPlot13);
        float float31 = xYPlot13.getForegroundAlpha();
        java.awt.Stroke stroke32 = null;
        xYPlot13.setOutlineStroke(stroke32);
        boolean boolean34 = xYPlot13.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray1 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        categoryPlot0.axisChanged(axisChangeEvent3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryPlot0.getInsets();
        org.junit.Assert.assertNotNull(categoryAxisArray1);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        dateAxis0.setPositiveArrowVisible(true);
        boolean boolean10 = dateAxis0.isHiddenValue((long) (short) -1);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape11);
        org.jfree.chart.plot.Plot plot13 = dateAxis0.getPlot();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(plot13);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        xYPlot7.setRangeZeroBaselineVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        java.awt.geom.Point2D point2D56 = null;
        xYPlot7.zoomDomainAxes((double) 8, plotRenderingInfo55, point2D56);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot16.getOrientation();
        boolean boolean18 = categoryPlot6.equals((java.lang.Object) categoryPlot16);
        java.awt.Color color19 = java.awt.Color.red;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color19);
        java.awt.color.ColorSpace colorSpace21 = color19.getColorSpace();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace21);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        java.awt.Paint paint29 = categoryPlot19.getDomainGridlinePaint();
        categoryPlot19.setDrawSharedDomainAxis(true);
        try {
            categoryPlot19.mapDatasetToDomainAxis((-12517377), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot19.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot19.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertNotNull(categoryAxis32);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryMarker3.getLabelTextAnchor();
        java.awt.Paint paint7 = categoryMarker3.getOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryMarker3.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.CENTER;
        boolean boolean10 = rectangleInsets8.equals((java.lang.Object) rectangleAnchor9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis7.setAutoRangeStickyZero(false);
        boolean boolean10 = numberAxis7.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis7.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit11, false, false);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis1.getTickUnit();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNotNull(numberTickUnit15);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        java.awt.Font font14 = categoryPlot6.getNoDataMessageFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot6.zoomDomainAxes((double) (byte) 100, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot6.addChangeListener(plotChangeListener20);
        categoryPlot6.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot7.getDomainAxisForDataset((int) (byte) 0);
        valueAxis17.setNegativeArrowVisible(false);
        float float20 = valueAxis17.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        valueMarker1.setValue((double) 2.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot6.setRangeAxisLocation(4, axisLocation14);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot6.getRangeAxisForDataset(4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.String str2 = valueMarker1.getLabel();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot7.getRangeAxisForDataset(500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 500 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        xYPlot7.setRangeCrosshairVisible(true);
        java.awt.geom.Point2D point2D18 = null;
        try {
            xYPlot7.setQuadrantOrigin(point2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        categoryPlot6.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        float float8 = xYPlot7.getForegroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis10.setRange(range11);
        org.jfree.data.Range range13 = dateAxis10.getRange();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer15);
        xYPlot16.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = xYPlot16.getAxisOffset();
        xYPlot16.clearAnnotations();
        java.awt.Paint paint22 = xYPlot16.getDomainZeroBaselinePaint();
        xYPlot16.clearDomainAxes();
        java.awt.Paint paint24 = xYPlot16.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot16.setDomainGridlineStroke(stroke25);
        xYPlot7.setRangeGridlineStroke(stroke25);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        float float23 = categoryPlot6.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot6.zoomDomainAxes((double) 8, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range32);
        org.jfree.data.Range range34 = dateAxis31.getRange();
        dateAxis31.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date38 = dateAxis31.getMaximumDate();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean40 = dateAxis31.equals((java.lang.Object) categoryAxis39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis31.setTimeZone(timeZone41);
        org.jfree.data.Range range43 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 0.5f + "'", float23 == 0.5f);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(range43);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] { color0 };
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setDrawSharedDomainAxis(false);
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color13, stroke14);
        categoryPlot9.addDomainMarker(categoryMarker15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot9.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis23, categoryItemRenderer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis20.setLabelPaint((java.awt.Paint) color26);
        int int28 = categoryAxis20.getCategoryLabelPositionOffset();
        categoryPlot9.setDomainAxis((int) (short) 1, categoryAxis20);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis20.setAxisLineStroke(stroke30);
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke30 };
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, strokeArray32, strokeArray33, shapeArray34);
        java.awt.Stroke stroke36 = defaultDrawingSupplier35.getNextStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(valueAxis17);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot7.getDomainAxisForDataset((int) (byte) 0);
        valueAxis17.setNegativeArrowVisible(false);
        valueAxis17.setLowerMargin((double) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray23 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot22.setDomainAxes(categoryAxisArray23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        categoryPlot22.axisChanged(axisChangeEvent25);
        valueAxis17.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.data.Range range28 = valueAxis17.getRange();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNotNull(categoryAxisArray23);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color5 = java.awt.Color.GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color5, stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint3, stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int11 = color10.getTransparency();
        float[] floatArray16 = new float[] { 1L, 100.0f, (-1L), 8 };
        float[] floatArray17 = color10.getRGBComponents(floatArray16);
        float[] floatArray18 = color1.getRGBColorComponents(floatArray17);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("EXPAND", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        int int9 = categoryAxis1.getCategoryLabelPositionOffset();
        java.lang.Object obj10 = categoryAxis1.clone();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis12.setRange(range13);
        org.jfree.data.Range range15 = dateAxis12.getRange();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer17);
        xYPlot18.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = xYPlot18.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot18.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot18.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot18.getDomainAxisForDataset((int) (byte) 0);
        java.lang.String str29 = xYPlot18.getPlotType();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.util.List list32 = null;
        xYPlot18.drawRangeTickBands(graphics2D30, rectangle2D31, list32);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis36.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis39, categoryItemRenderer40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryAxis36.setTickLabelPaint((java.awt.Paint) color42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0L, (java.awt.Paint) color42, stroke44);
        xYPlot18.setRangeZeroBaselineStroke(stroke44);
        org.jfree.chart.axis.AxisSpace axisSpace47 = xYPlot18.getFixedDomainAxisSpace();
        xYPlot18.clearRangeMarkers();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot18);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "XY Plot" + "'", str29.equals("XY Plot"));
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(axisSpace47);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        dateAxis0.setUpperBound((double) 11);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        java.awt.Paint paint26 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot6.zoomDomainAxes((double) 100L, (double) 'a', plotRenderingInfo29, point2D30);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        java.awt.Paint paint43 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot6.getDataset();
        org.jfree.chart.event.PlotChangeListener plotChangeListener45 = null;
        categoryPlot6.addChangeListener(plotChangeListener45);
        org.jfree.data.general.DatasetGroup datasetGroup47 = categoryPlot6.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertNull(datasetGroup47);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        categoryPlot6.clearDomainMarkers(0);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot6.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot7.getDomainAxisForDataset((int) (byte) 0);
        java.awt.Paint paint18 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot7.getFixedLegendItems();
        java.awt.Stroke stroke20 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        xYPlot7.removeChangeListener(plotChangeListener21);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        int int29 = categoryPlot19.getBackgroundImageAlignment();
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot19.getDatasetGroup();
        boolean boolean31 = categoryPlot19.isOutlineVisible();
        float float32 = categoryPlot19.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.5f + "'", float32 == 0.5f);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        boolean boolean51 = xYPlot7.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color28 = java.awt.Color.GREEN;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color28, stroke29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker30.setStroke(stroke31);
        boolean boolean33 = datasetRenderingOrder26.equals((java.lang.Object) categoryMarker30);
        java.awt.Font font34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker30.setLabelFont(font34);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = categoryMarker30.getLabelOffsetType();
        categoryMarker30.setLabel("DatasetRenderingOrder.FORWARD");
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis41.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot46.zoomDomainAxes(0.0d, plotRenderingInfo48, point2D49, true);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot46.setRangeCrosshairPaint((java.awt.Paint) color52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis55.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, valueAxis58, categoryItemRenderer59);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        java.awt.geom.Point2D point2D63 = null;
        categoryPlot60.zoomDomainAxes(0.0d, plotRenderingInfo62, point2D63, true);
        int int66 = categoryPlot60.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder68 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color70 = java.awt.Color.GREEN;
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color70, stroke71);
        java.awt.Stroke stroke73 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker72.setStroke(stroke73);
        boolean boolean75 = datasetRenderingOrder68.equals((java.lang.Object) categoryMarker72);
        org.jfree.data.category.CategoryDataset categoryDataset76 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis77 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis77.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer81 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot82 = new org.jfree.chart.plot.CategoryPlot(categoryDataset76, categoryAxis77, valueAxis80, categoryItemRenderer81);
        java.awt.Color color83 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis77.setLabelPaint((java.awt.Paint) color83);
        categoryMarker72.setLabelPaint((java.awt.Paint) color83);
        org.jfree.chart.util.Layer layer86 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot60.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker72, layer86);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType88 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean89 = layer86.equals((java.lang.Object) lengthAdjustmentType88);
        java.awt.Color color90 = java.awt.Color.ORANGE;
        boolean boolean91 = layer86.equals((java.lang.Object) color90);
        java.util.Collection collection92 = categoryPlot46.getDomainMarkers(layer86);
        java.util.Collection collection93 = xYPlot7.getRangeMarkers(layer86);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder68);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(layer86);
        org.junit.Assert.assertNotNull(lengthAdjustmentType88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(collection92);
        org.junit.Assert.assertNull(collection93);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer(1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertNull(categoryItemRenderer4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date7 = dateAxis0.getMaximumDate();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition8 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(dateTickMarkPosition8);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        valueAxis51.setTickMarkOutsideLength((float) 'a');
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        categoryAxis2.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis2.getTickLabelInsets();
        categoryAxis2.setCategoryMargin((double) (-4194304));
        float float13 = categoryAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRange(range16);
        org.jfree.data.Range range18 = dateAxis15.getRange();
        dateAxis15.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date22 = dateAxis15.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis15.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit23, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer27);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color31 = java.awt.Color.GREEN;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color31, stroke32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker33.setStroke(stroke34);
        boolean boolean36 = datasetRenderingOrder29.equals((java.lang.Object) categoryMarker33);
        java.awt.Font font37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker33.setLabelFont(font37);
        org.jfree.chart.text.TextAnchor textAnchor39 = categoryMarker33.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        categoryMarker33.setLabelAnchor(rectangleAnchor40);
        boolean boolean42 = categoryPlot28.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker33);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis52.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis55, categoryItemRenderer56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot57.zoomDomainAxes(0.0d, plotRenderingInfo59, point2D60, true);
        org.jfree.chart.axis.AxisSpace axisSpace63 = null;
        categoryPlot57.setFixedDomainAxisSpace(axisSpace63);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent65 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot57);
        org.jfree.chart.plot.Plot plot66 = plotChangeEvent65.getPlot();
        plot66.setForegroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder69 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color71 = java.awt.Color.GREEN;
        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker73 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color71, stroke72);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker73.setStroke(stroke74);
        boolean boolean76 = datasetRenderingOrder69.equals((java.lang.Object) categoryMarker73);
        java.awt.Font font77 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker73.setLabelFont(font77);
        java.awt.Stroke stroke79 = categoryMarker73.getStroke();
        plot66.setOutlineStroke(stroke79);
        xYPlot7.setDomainCrosshairStroke(stroke79);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent82 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot7);
        boolean boolean83 = xYPlot7.isDomainZoomable();
        java.awt.Graphics2D graphics2D84 = null;
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        java.awt.geom.Point2D point2D86 = null;
        org.jfree.chart.plot.PlotState plotState87 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        try {
            xYPlot7.draw(graphics2D84, rectangle2D85, point2D86, plotState87, plotRenderingInfo88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(plot66);
        org.junit.Assert.assertNotNull(datasetRenderingOrder69);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot7.getDomainAxisForDataset((int) (byte) 0);
        valueAxis17.setNegativeArrowVisible(false);
        valueAxis17.setLowerMargin((double) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray23 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot22.setDomainAxes(categoryAxisArray23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        categoryPlot22.axisChanged(axisChangeEvent25);
        valueAxis17.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.data.Range range28 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        valueAxis17.setDefaultAutoRange(range28);
        valueAxis17.setLowerBound((double) 0.0f);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNotNull(categoryAxisArray23);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainCrosshairPaint();
        xYPlot7.clearRangeMarkers((-12517377));
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        xYPlot7.setRenderer(xYItemRenderer16);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getMiddleMillisecond();
//        int int2 = day0.getMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560452399999L + "'", long1 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=128,g=255,b=255]"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color3 = java.awt.Color.GREEN;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color3, stroke4);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint1, stroke4);
        java.lang.String str7 = valueMarker6.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setTickMarkInsideLength((float) 5);
        categoryAxis26.setVisible(false);
        boolean boolean31 = categoryPlot6.equals((java.lang.Object) categoryAxis26);
        float float32 = categoryAxis26.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer(1);
        categoryPlot0.setNoDataMessage("java.awt.Color[r=128,g=255,b=255]");
        org.junit.Assert.assertNull(categoryItemRenderer4);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        double double5 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        boolean boolean8 = dateAxis1.isPositiveArrowVisible();
        java.text.DateFormat dateFormat9 = null;
        dateAxis1.setDateFormatOverride(dateFormat9);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setLabelURL("hi!");
        categoryAxis0.configure();
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color6 = java.awt.Color.GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color6, stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint4, stroke7);
        boolean boolean10 = categoryAnchor2.equals((java.lang.Object) stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color1, stroke7);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21, true);
        categoryPlot18.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot18.getIndexOf(categoryItemRenderer26);
        valueMarker11.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot18);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis32.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis35, categoryItemRenderer36);
        categoryAxis32.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = categoryAxis32.getTickLabelInsets();
        categoryAxis32.setCategoryMargin((double) (-4194304));
        float float43 = categoryAxis32.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range46 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis45.setRange(range46);
        org.jfree.data.Range range48 = dateAxis45.getRange();
        dateAxis45.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date52 = dateAxis45.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit53 = dateAxis45.getTickUnit();
        dateAxis44.setTickUnit(dateTickUnit53, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis44, categoryItemRenderer57);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis61.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis64, categoryItemRenderer65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        java.awt.geom.Point2D point2D69 = null;
        categoryPlot66.zoomDomainAxes(0.0d, plotRenderingInfo68, point2D69, true);
        int int72 = categoryPlot66.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder74 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color76 = java.awt.Color.GREEN;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color76, stroke77);
        java.awt.Stroke stroke79 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker78.setStroke(stroke79);
        boolean boolean81 = datasetRenderingOrder74.equals((java.lang.Object) categoryMarker78);
        org.jfree.data.category.CategoryDataset categoryDataset82 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis83 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis83.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis86 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer87 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot(categoryDataset82, categoryAxis83, valueAxis86, categoryItemRenderer87);
        java.awt.Color color89 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis83.setLabelPaint((java.awt.Paint) color89);
        categoryMarker78.setLabelPaint((java.awt.Paint) color89);
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot66.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker78, layer92);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType94 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean95 = layer92.equals((java.lang.Object) lengthAdjustmentType94);
        java.util.Collection collection96 = categoryPlot58.getDomainMarkers(0, layer92);
        java.util.Collection collection97 = categoryPlot18.getRangeMarkers((int) (byte) 1, layer92);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 2.0f + "'", float43 == 2.0f);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(dateTickUnit53);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder74);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertNotNull(lengthAdjustmentType94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNull(collection96);
        org.junit.Assert.assertNull(collection97);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        java.awt.Paint paint43 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot6.getRangeAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot6.zoomRangeAxes((double) 5, plotRenderingInfo47, point2D48);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(legendItemCollection44);
        org.junit.Assert.assertNull(valueAxis45);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        categoryMarker3.setAlpha((float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryMarker3.getLabelOffset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        xYPlot7.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range29 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis28.setRange(range29);
        org.jfree.data.Range range31 = dateAxis28.getRange();
        boolean boolean32 = dateAxis28.isVerticalTickLabels();
        int int33 = xYPlot7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        try {
            xYPlot7.zoomDomainAxes(4.0d, plotRenderingInfo35, point2D36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        dateAxis0.setPositiveArrowVisible(true);
        boolean boolean10 = dateAxis0.isHiddenValue((long) (short) -1);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis0.setLeftArrow(shape11);
        dateAxis0.configure();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isVerticalTickLabels();
        xYPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        xYPlot7.setDomainAxisLocation(10, axisLocation18, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke14 = xYPlot7.getDomainZeroBaselineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot22.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25, true);
        int int28 = categoryPlot22.getRangeAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot22.setRenderer((int) (byte) 10, categoryItemRenderer30, false);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str34 = axisLocation33.toString();
        categoryPlot22.setDomainAxisLocation(axisLocation33, false);
        xYPlot7.setRangeAxisLocation((int) '#', axisLocation33, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str34.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=255,b=0]");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        dateAxis1.configure();
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }
}

