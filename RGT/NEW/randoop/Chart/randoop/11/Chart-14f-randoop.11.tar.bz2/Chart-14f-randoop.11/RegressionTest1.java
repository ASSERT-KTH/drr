import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        xYPlot7.setDomainCrosshairVisible(false);
        xYPlot7.setRangeCrosshairValue((double) ' ', true);
        org.jfree.chart.axis.AxisSpace axisSpace16 = xYPlot7.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color6 = java.awt.Color.GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color6, stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint4, stroke7);
        boolean boolean10 = categoryAnchor2.equals((java.lang.Object) stroke7);
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color1, stroke7);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21, true);
        categoryPlot18.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot18.getIndexOf(categoryItemRenderer26);
        valueMarker11.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot18);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis30.setRange(range31);
        org.jfree.data.Range range33 = dateAxis30.getRange();
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset29, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis34, xYItemRenderer35);
        xYPlot36.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = xYPlot36.getAxisOffset();
        boolean boolean41 = valueMarker11.equals((java.lang.Object) rectangleInsets40);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(categoryAnchor2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 255);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateTopInset((double) ' ');
        double double8 = rectangleInsets4.calculateLeftInset((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets4.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) ' ', (double) (-4194304), (double) (-1.0f), (double) 10);
        double double15 = rectangleInsets14.getRight();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(5);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis7, categoryItemRenderer8);
        boolean boolean10 = categoryPlot9.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot9.setDataset(categoryDataset11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRendererForDataset(categoryDataset13);
        boolean boolean15 = categoryPlot9.isDomainGridlinesVisible();
        objectList1.set((int) (short) 10, (java.lang.Object) boolean15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        boolean boolean22 = xYPlot7.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        int int24 = xYPlot7.indexOf(xYDataset23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot7.getRendererForDataset(xYDataset25);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(xYItemRenderer26);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.setRangeCrosshairValue((double) 8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot6.getDomainAxis();
        categoryPlot6.setRangeCrosshairLockedOnData(false);
        boolean boolean20 = categoryPlot6.isRangeZoomable();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        valueAxis51.setInverted(true);
        valueAxis51.setInverted(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier56 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint57 = defaultDrawingSupplier56.getNextFillPaint();
        java.awt.Shape shape58 = defaultDrawingSupplier56.getNextShape();
        valueAxis51.setDownArrow(shape58);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(shape58);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Shape shape8 = null;
        try {
            dateAxis5.setDownArrow(shape8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = categoryPlot19.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis28, categoryItemRenderer29);
        categoryAxis25.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis25.getTickLabelInsets();
        categoryAxis25.setCategoryMargin((double) (-4194304));
        float float36 = categoryAxis25.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range39 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis38.setRange(range39);
        org.jfree.data.Range range41 = dateAxis38.getRange();
        dateAxis38.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date45 = dateAxis38.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = dateAxis38.getTickUnit();
        dateAxis37.setTickUnit(dateTickUnit46, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis37, categoryItemRenderer50);
        categoryPlot19.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) dateAxis37, false);
        java.util.List list54 = categoryPlot19.getAnnotations();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 2.0f + "'", float36 == 2.0f);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNotNull(list54);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis7.setAutoRangeStickyZero(false);
        boolean boolean10 = numberAxis7.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis7.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit11, true, true);
        java.lang.Object obj15 = numberAxis1.clone();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(markerAxisBand16);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("XY Plot");
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot6.getRangeAxis((int) (short) -1);
        categoryPlot6.setOutlineVisible(true);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot6.getColumnRenderingOrder();
        java.lang.String str31 = sortOrder30.toString();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "SortOrder.ASCENDING" + "'", str31.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, dataset1);
        java.lang.Object obj3 = datasetChangeEvent2.getSource();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        xYPlot7.setRangeCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot7.getRendererForDataset(xYDataset18);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNull(xYItemRenderer19);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        java.awt.Paint paint43 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot6.getFixedLegendItems();
        java.util.List list45 = categoryPlot6.getAnnotations();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(legendItemCollection44);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        xYPlot7.setDomainCrosshairVisible(false);
        boolean boolean13 = xYPlot7.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRange(range16);
        org.jfree.data.Range range18 = dateAxis15.getRange();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        xYPlot21.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        xYPlot21.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis33, categoryItemRenderer34);
        categoryPlot35.setDrawSharedDomainAxis(false);
        java.awt.Color color39 = java.awt.Color.GREEN;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color39, stroke40);
        categoryPlot35.addDomainMarker(categoryMarker41);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot35.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis45.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis48, categoryItemRenderer49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis45.setLabelPaint((java.awt.Paint) color51);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double59 = rectangleInsets57.calculateTopInset((double) ' ');
        categoryAxis45.setTickLabelInsets(rectangleInsets57);
        categoryPlot35.setInsets(rectangleInsets57);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot35.getDomainAxisLocation(2);
        xYPlot21.setDomainAxisLocation(0, axisLocation63);
        xYPlot7.setRangeAxisLocation(axisLocation63, true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        int int26 = categoryPlot20.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color29 = java.awt.Color.GREEN;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color29, stroke30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker31.setStroke(stroke32);
        boolean boolean34 = datasetRenderingOrder27.equals((java.lang.Object) categoryMarker31);
        org.jfree.chart.util.Layer layer35 = null;
        categoryPlot20.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker31, layer35);
        int int37 = categoryPlot20.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot20.setDataset(categoryDataset38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis40.setTickMarkInsideLength((float) 5);
        categoryAxis40.setVisible(false);
        boolean boolean45 = categoryPlot20.equals((java.lang.Object) categoryAxis40);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.plot.Plot plot47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range51 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis50.setRange(range51);
        org.jfree.data.Range range53 = dateAxis50.getRange();
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset49, (org.jfree.chart.axis.ValueAxis) dateAxis50, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer55);
        xYPlot56.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = xYPlot56.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation62 = xYPlot56.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot56.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        org.jfree.chart.axis.AxisSpace axisSpace66 = categoryAxis40.reserveSpace(graphics2D46, plot47, rectangle2D48, rectangleEdge64, axisSpace65);
        xYPlot7.setFixedDomainAxisSpace(axisSpace66, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(range53);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(axisSpace66);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot16.getOrientation();
        boolean boolean18 = categoryPlot6.equals((java.lang.Object) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = categoryPlot25.getOrientation();
        categoryPlot16.setOrientation(plotOrientation26);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis5, categoryItemRenderer6);
        categoryAxis2.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis2.getTickLabelInsets();
        categoryAxis2.setCategoryMargin((double) (-4194304));
        float float13 = categoryAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRange(range16);
        org.jfree.data.Range range18 = dateAxis15.getRange();
        dateAxis15.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date22 = dateAxis15.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis15.getTickUnit();
        dateAxis14.setTickUnit(dateTickUnit23, true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, categoryItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot39.zoomDomainAxes(0.0d, plotRenderingInfo41, point2D42, true);
        int int45 = categoryPlot39.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis47.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis50, categoryItemRenderer51);
        categoryPlot39.setParent((org.jfree.chart.plot.Plot) categoryPlot52);
        java.awt.Color color55 = java.awt.Color.GREEN;
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color55, stroke56);
        java.lang.String str58 = color55.toString();
        categoryPlot52.setRangeCrosshairPaint((java.awt.Paint) color55);
        org.jfree.chart.JFreeChart jFreeChart60 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot52, jFreeChart60);
        categoryPlot52.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup64 = categoryPlot52.getDatasetGroup();
        boolean boolean65 = categoryPlot52.isSubplot();
        double double66 = categoryPlot52.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = categoryPlot52.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        try {
            org.jfree.chart.axis.AxisState axisState69 = dateAxis14.draw(graphics2D29, (double) 500, rectangle2D31, rectangle2D32, rectangleEdge67, plotRenderingInfo68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTickUnit23);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str58.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot7.getDomainAxisForDataset((int) (byte) 0);
        java.awt.Paint paint18 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot7.getFixedLegendItems();
        float float20 = xYPlot7.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getRangeAxisEdge((-16777216));
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRange(range18);
        java.awt.Shape shape20 = dateAxis17.getDownArrow();
        dateAxis17.setNegativeArrowVisible(false);
        xYPlot7.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        xYPlot7.setBackgroundImageAlignment((int) 'a');
        xYPlot7.setRangeCrosshairLockedOnData(false);
        xYPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot7.getRenderer(2);
        xYPlot7.mapDatasetToDomainAxis((int) (short) 100, (int) 'a');
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(xYItemRenderer33);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        org.jfree.data.Range range10 = dateAxis7.getRange();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        xYPlot13.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot13.getAxisOffset();
        xYPlot13.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range20);
        org.jfree.data.Range range22 = dateAxis19.getRange();
        dateAxis19.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        int int27 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        int int29 = xYPlot13.indexOf(xYDataset28);
        boolean boolean30 = categoryAxis0.hasListener((java.util.EventListener) xYPlot13);
        float float31 = xYPlot13.getForegroundAlpha();
        org.jfree.chart.util.UnitType unitType32 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color39 = java.awt.Color.GREEN;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color39, stroke40);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint37, stroke40);
        boolean boolean43 = categoryAnchor35.equals((java.lang.Object) stroke40);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color34, stroke40);
        boolean boolean45 = unitType32.equals((java.lang.Object) stroke40);
        xYPlot13.setDomainZeroBaselineStroke(stroke40);
        xYPlot13.setWeight(13);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        try {
            xYPlot13.setDomainAxisLocation((-254), axisLocation50, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNotNull(unitType32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit7, true, true);
        dateAxis0.setRangeWithMargins((-7.99999999d), (double) 100L);
        dateAxis0.setAutoTickUnitSelection(true);
        dateAxis0.setTickMarkInsideLength((float) 5);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color1 = color0.darker();
        int int2 = color1.getTransparency();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomDomainAxes(0.0d, plotRenderingInfo11, point2D12, true);
        int int15 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color18 = java.awt.Color.GREEN;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color18, stroke19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker20.setStroke(stroke21);
        boolean boolean23 = datasetRenderingOrder16.equals((java.lang.Object) categoryMarker20);
        org.jfree.chart.util.Layer layer24 = null;
        categoryPlot9.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer24);
        int int26 = categoryPlot9.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        categoryPlot9.setDataset(categoryDataset27);
        boolean boolean29 = color1.equals((java.lang.Object) categoryDataset27);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        java.awt.Paint paint52 = xYPlot7.getDomainZeroBaselinePaint();
        double double53 = xYPlot7.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        categoryAxis0.setCategoryMargin((double) 3);
        categoryAxis0.setLowerMargin(1.0d);
        java.lang.String str10 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 12);
        java.awt.Paint paint12 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot16.getOrientation();
        boolean boolean18 = categoryPlot6.equals((java.lang.Object) categoryPlot16);
        java.awt.Color color19 = java.awt.Color.red;
        categoryPlot6.setDomainGridlinePaint((java.awt.Paint) color19);
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryPlot6.setDomainGridlineStroke(stroke21);
        java.awt.Stroke stroke23 = categoryPlot6.getDomainGridlineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        try {
            boolean boolean26 = categoryPlot6.removeAnnotation(categoryAnnotation24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = dateAxis14.isVerticalTickLabels();
        xYPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRange(range18);
        org.jfree.data.Range range20 = dateAxis17.getRange();
        boolean boolean21 = dateAxis17.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis17.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range25 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRange(range25);
        java.awt.Shape shape27 = dateAxis24.getDownArrow();
        org.jfree.data.Range range28 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis24.setRange(range28, false, false);
        dateAxis17.setRange(range28);
        dateAxis14.setRange(range28, false, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.FORWARD");
        java.awt.Stroke stroke2 = categoryAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.calculateRightInset(4.0d);
        double double9 = rectangleInsets4.calculateLeftInset((-7.0d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(5);
        java.lang.Object obj3 = objectList1.get(3);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        java.awt.Paint paint43 = categoryPlot6.getRangeGridlinePaint();
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot6.getRangeMarkers(4, layer45);
        float float47 = categoryPlot6.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 1.0f + "'", float47 == 1.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(5);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot16.zoomDomainAxes(0.0d, plotRenderingInfo18, point2D19, true);
        int int22 = categoryPlot16.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis27, categoryItemRenderer28);
        categoryPlot16.setParent((org.jfree.chart.plot.Plot) categoryPlot29);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor31 = categoryPlot29.getDomainGridlinePosition();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = null;
        categoryPlot29.setFixedLegendItems(legendItemCollection33);
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomDomainAxes(0.0d, plotRenderingInfo44, point2D45, true);
        int int48 = categoryPlot42.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis50.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis53, categoryItemRenderer54);
        categoryPlot42.setParent((org.jfree.chart.plot.Plot) categoryPlot55);
        java.awt.Color color58 = java.awt.Color.GREEN;
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color58, stroke59);
        java.lang.String str61 = color58.toString();
        categoryPlot55.setRangeCrosshairPaint((java.awt.Paint) color58);
        java.awt.Stroke stroke63 = categoryPlot55.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation65 = categoryPlot55.getDomainAxisLocation(100);
        org.jfree.chart.axis.AxisLocation axisLocation66 = axisLocation65.getOpposite();
        try {
            categoryPlot29.setRangeAxisLocation((int) (short) -1, axisLocation66, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor31);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str61.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(axisLocation65);
        org.junit.Assert.assertNotNull(axisLocation66);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        xYPlot7.setRenderer(12, xYItemRenderer15, true);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Paint paint21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color23 = java.awt.Color.GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color23, stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint21, stroke24);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke24);
        xYPlot7.setOutlineStroke(stroke24);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 255);
//        int int3 = day0.getDayOfMonth();
//        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis5.setTickMarkInsideLength((float) 5);
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis8, categoryItemRenderer9);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
//        java.awt.geom.Point2D point2D13 = null;
//        categoryPlot10.zoomDomainAxes(0.0d, plotRenderingInfo12, point2D13, true);
//        int int16 = categoryPlot10.getRangeAxisCount();
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
//        java.awt.Color color19 = java.awt.Color.GREEN;
//        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
//        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        categoryMarker21.setStroke(stroke22);
//        boolean boolean24 = datasetRenderingOrder17.equals((java.lang.Object) categoryMarker21);
//        org.jfree.chart.util.Layer layer25 = null;
//        categoryPlot10.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker21, layer25);
//        float float27 = categoryPlot10.getBackgroundImageAlpha();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
//        java.awt.geom.Point2D point2D30 = null;
//        categoryPlot10.zoomDomainAxes((double) 8, plotRenderingInfo29, point2D30, false);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
//        java.awt.Color color35 = java.awt.Color.GREEN;
//        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color35, stroke36);
//        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        categoryMarker37.setStroke(stroke38);
//        boolean boolean40 = datasetRenderingOrder33.equals((java.lang.Object) categoryMarker37);
//        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        categoryMarker37.setLabelFont(font41);
//        categoryPlot10.setNoDataMessageFont(font41);
//        boolean boolean44 = day0.equals((java.lang.Object) font41);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNotNull(stroke22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.5f + "'", float27 == 0.5f);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
//        org.junit.Assert.assertNotNull(color35);
//        org.junit.Assert.assertNotNull(stroke36);
//        org.junit.Assert.assertNotNull(stroke38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(font41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker18.setStroke(stroke19);
        boolean boolean21 = datasetRenderingOrder14.equals((java.lang.Object) categoryMarker18);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker18.setLabelFont(font22);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = categoryMarker18.getLabelOffsetType();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean26 = xYPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer25);
        boolean boolean28 = categoryMarker18.equals((java.lang.Object) 5);
        categoryMarker18.setDrawAsLine(true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        boolean boolean29 = xYPlot7.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.util.List list32 = null;
        xYPlot7.drawRangeTickBands(graphics2D30, rectangle2D31, list32);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation34 = null;
        try {
            boolean boolean36 = xYPlot7.removeAnnotation(xYAnnotation34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint4 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        boolean boolean8 = dateAxis1.isNegativeArrowVisible();
        boolean boolean10 = dateAxis1.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int2 = color1.getTransparency();
        float[] floatArray7 = new float[] { 1L, 100.0f, (-1L), 8 };
        float[] floatArray8 = color1.getRGBComponents(floatArray7);
        float[] floatArray9 = color0.getColorComponents(floatArray7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double15 = rectangleInsets13.calculateTopInset((double) ' ');
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        categoryAxis1.setUpperMargin((double) 10.0f);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color20 = color19.darker();
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color20);
        int int22 = color20.getRGB();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-16754343) + "'", int22 == (-16754343));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21, true);
        int int24 = categoryPlot18.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color27 = java.awt.Color.GREEN;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color27, stroke28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker29.setStroke(stroke30);
        boolean boolean32 = datasetRenderingOrder25.equals((java.lang.Object) categoryMarker29);
        org.jfree.chart.util.Layer layer33 = null;
        categoryPlot18.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker29, layer33);
        java.awt.Stroke stroke35 = categoryMarker29.getStroke();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomDomainAxes(0.0d, plotRenderingInfo44, point2D45, true);
        int int48 = categoryPlot42.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder50 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color52 = java.awt.Color.GREEN;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color52, stroke53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker54.setStroke(stroke55);
        boolean boolean57 = datasetRenderingOrder50.equals((java.lang.Object) categoryMarker54);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis59.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis62, categoryItemRenderer63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis59.setLabelPaint((java.awt.Paint) color65);
        categoryMarker54.setLabelPaint((java.awt.Paint) color65);
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot42.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker54, layer68);
        xYPlot7.addDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker29, layer68);
        org.jfree.chart.text.TextAnchor textAnchor71 = categoryMarker29.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertNotNull(textAnchor71);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        double double2 = numberAxis1.getUpperBound();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis3.setTickMarkInsideLength((float) 5);
        categoryAxis3.setAxisLineVisible(true);
        java.lang.String str8 = categoryAxis3.getLabelURL();
        categoryAxis3.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis3.setLabelURL("hi!");
        double double13 = categoryAxis3.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis15.setAutoRangeStickyZero(false);
        boolean boolean18 = numberAxis15.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis15.getTickUnit();
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) numberTickUnit19, "EXPAND");
        numberAxis1.setTickUnit(numberTickUnit19, false, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(numberTickUnit19);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setTickMarkInsideLength((float) 5);
        categoryAxis26.setVisible(false);
        boolean boolean31 = categoryPlot6.equals((java.lang.Object) categoryAxis26);
        categoryAxis26.setMaximumCategoryLabelLines((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot7.getDomainAxisForDataset((int) (byte) 0);
        java.lang.String str18 = xYPlot7.getPlotType();
        xYPlot7.setDomainCrosshairVisible(false);
        java.awt.Paint paint21 = xYPlot7.getRangeGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis24.setAutoRangeStickyZero(false);
        boolean boolean27 = numberAxis24.getAutoRangeIncludesZero();
        numberAxis24.setAutoRangeIncludesZero(true);
        xYPlot7.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "XY Plot" + "'", str18.equals("XY Plot"));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot6.getDomainAxisLocation(2);
        boolean boolean35 = categoryPlot6.isDomainGridlinesVisible();
        java.awt.Font font36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot6.setNoDataMessageFont(font36);
        org.jfree.chart.LegendItemCollection legendItemCollection38 = categoryPlot6.getFixedLegendItems();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNull(legendItemCollection38);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        java.awt.Stroke stroke3 = categoryAxis0.getTickMarkStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        categoryAxis0.setCategoryMargin((double) 3);
        categoryAxis0.setLowerMargin(1.0d);
        java.lang.String str10 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 12);
        categoryAxis0.setVisible(false);
        java.awt.Color color13 = java.awt.Color.GREEN;
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color13);
        java.awt.color.ColorSpace colorSpace15 = color13.getColorSpace();
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot14.zoomDomainAxes(0.0d, plotRenderingInfo16, point2D17, true);
        int int20 = categoryPlot14.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color23 = java.awt.Color.GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color23, stroke24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker25.setStroke(stroke26);
        boolean boolean28 = datasetRenderingOrder21.equals((java.lang.Object) categoryMarker25);
        org.jfree.chart.util.Layer layer29 = null;
        categoryPlot14.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer29);
        int int31 = categoryPlot14.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        categoryPlot14.setDataset(categoryDataset32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setTickMarkInsideLength((float) 5);
        categoryAxis34.setVisible(false);
        boolean boolean39 = categoryPlot14.equals((java.lang.Object) categoryAxis34);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.Plot plot41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range45 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis44.setRange(range45);
        org.jfree.data.Range range47 = dateAxis44.getRange();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis48, xYItemRenderer49);
        xYPlot50.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = xYPlot50.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation56 = xYPlot50.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = xYPlot50.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        org.jfree.chart.axis.AxisSpace axisSpace60 = categoryAxis34.reserveSpace(graphics2D40, plot41, rectangle2D42, rectangleEdge58, axisSpace59);
        xYPlot7.setFixedDomainAxisSpace(axisSpace59, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        xYPlot7.zoomRangeAxes((double) (short) 100, plotRenderingInfo64, point2D65);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(axisSpace60);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot6.setRenderer((int) (byte) 10, categoryItemRenderer14, false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRange(range18);
        java.awt.Shape shape20 = dateAxis17.getDownArrow();
        dateAxis17.setNegativeArrowVisible(false);
        org.jfree.data.Range range23 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis17);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        dateAxis0.setPositiveArrowVisible(true);
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis0.setTimeline(timeline9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color17 = java.awt.Color.GREEN;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color17, stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint15, stroke18);
        boolean boolean21 = categoryAnchor13.equals((java.lang.Object) stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color12, stroke18);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot29.zoomDomainAxes(0.0d, plotRenderingInfo31, point2D32, true);
        categoryPlot29.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot29.getIndexOf(categoryItemRenderer37);
        valueMarker22.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot29);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        java.lang.Class<?> wildcardClass41 = categoryPlot29.getClass();
        try {
            categoryPlot29.setBackgroundImageAlpha((float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot6.setDataset(categoryDataset8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getDomainAxisLocation();
        int int13 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        boolean boolean21 = categoryPlot20.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot20.setDataset(categoryDataset22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot20.getRendererForDataset(categoryDataset24);
        boolean boolean26 = categoryPlot20.isDomainGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray28 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer27 };
        categoryPlot20.setRenderers(categoryItemRendererArray28);
        categoryPlot6.setRenderers(categoryItemRendererArray28);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray28);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        int int9 = color7.getGreen();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 128 + "'", int9 == 128);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        double double3 = dateAxis0.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.data.Range range8 = dateAxis5.getRange();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer10);
        xYPlot11.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot11.getAxisOffset();
        xYPlot11.clearAnnotations();
        java.awt.Paint paint17 = xYPlot11.getDomainCrosshairPaint();
        dateAxis0.setTickMarkPaint(paint17);
        dateAxis0.configure();
        dateAxis0.setFixedDimension((double) 1.0f);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot7.getRangeAxisForDataset(0);
        int int28 = xYPlot7.getRangeAxisCount();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        dateAxis0.zoomRange((double) (-4194304), 2.0d);
        boolean boolean6 = dateAxis0.isVisible();
        dateAxis0.setLabel("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]");
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        categoryAxis1.setTickMarksVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis1.getCategoryLabelPositions();
        boolean boolean7 = rectangleAnchor0.equals((java.lang.Object) categoryAxis1);
        java.lang.String str8 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleAnchor.LEFT" + "'", str8.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        valueMarker1.setValue(0.0d);
        java.awt.Color color4 = java.awt.Color.red;
        valueMarker1.setLabelPaint((java.awt.Paint) color4);
        java.awt.Color color6 = color4.brighter();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double15 = rectangleInsets13.calculateTopInset((double) ' ');
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        java.awt.Stroke stroke17 = categoryAxis1.getTickMarkStroke();
        boolean boolean18 = categoryAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        java.awt.Shape shape10 = dateAxis7.getDownArrow();
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range11, false, false);
        dateAxis0.setRange(range11);
        java.util.Date date16 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis17.setRange(range18);
        org.jfree.data.Range range20 = dateAxis17.getRange();
        dateAxis17.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date24 = dateAxis17.getMaximumDate();
        try {
            dateAxis0.setRange(date16, date24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint8 = defaultDrawingSupplier7.getNextFillPaint();
        java.awt.Shape shape9 = defaultDrawingSupplier7.getNextShape();
        dateAxis0.setLeftArrow(shape9);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        org.jfree.data.Range range10 = dateAxis7.getRange();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        xYPlot13.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot13.getAxisOffset();
        xYPlot13.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range20);
        org.jfree.data.Range range22 = dateAxis19.getRange();
        dateAxis19.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        int int27 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        int int29 = xYPlot13.indexOf(xYDataset28);
        boolean boolean30 = categoryAxis0.hasListener((java.util.EventListener) xYPlot13);
        xYPlot13.setRangeCrosshairValue((double) 11);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color2 = java.awt.Color.GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker4.setStroke(stroke5);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) categoryMarker4);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis12, categoryItemRenderer13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis9.setLabelPaint((java.awt.Paint) color15);
        categoryMarker4.setLabelPaint((java.awt.Paint) color15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis22, categoryItemRenderer23);
        categoryPlot24.setDrawSharedDomainAxis(false);
        java.awt.Color color28 = java.awt.Color.GREEN;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color28, stroke29);
        categoryPlot24.addDomainMarker(categoryMarker30);
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot24.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis37, categoryItemRenderer38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis34.setLabelPaint((java.awt.Paint) color40);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double48 = rectangleInsets46.calculateTopInset((double) ' ');
        categoryAxis34.setTickLabelInsets(rectangleInsets46);
        categoryPlot24.setInsets(rectangleInsets46);
        org.jfree.chart.axis.AxisLocation axisLocation52 = categoryPlot24.getDomainAxisLocation(2);
        boolean boolean53 = categoryPlot24.isDomainGridlinesVisible();
        java.awt.Font font54 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot24.setNoDataMessageFont(font54);
        categoryMarker4.setLabelFont(font54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(font54);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelURL();
        categoryAxis0.setMaximumCategoryLabelLines((int) ' ');
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 4);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomDomainAxes(0.0d, plotRenderingInfo22, point2D23, true);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace26);
        categoryPlot20.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot20.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            org.jfree.chart.axis.AxisState axisState32 = categoryAxis0.draw(graphics2D10, 0.0d, rectangle2D12, rectangle2D13, rectangleEdge30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double15 = rectangleInsets13.calculateTopInset((double) ' ');
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        categoryAxis1.setUpperMargin((double) 10.0f);
        java.awt.Color color19 = java.awt.Color.GREEN;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=0,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=0,b=128]"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.setDrawSharedDomainAxis(true);
        int int10 = categoryPlot6.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis17.setLabelPaint((java.awt.Paint) color23);
        int int25 = categoryAxis17.getCategoryLabelPositionOffset();
        categoryPlot6.setDomainAxis((int) (short) 1, categoryAxis17);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace27);
        boolean boolean29 = categoryPlot6.isDomainZoomable();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        org.jfree.data.Range range10 = dateAxis7.getRange();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        xYPlot13.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot13.getAxisOffset();
        xYPlot13.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range20);
        org.jfree.data.Range range22 = dateAxis19.getRange();
        dateAxis19.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        int int27 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        int int29 = xYPlot13.indexOf(xYDataset28);
        boolean boolean30 = categoryAxis0.hasListener((java.util.EventListener) xYPlot13);
        float float31 = xYPlot13.getForegroundAlpha();
        org.jfree.chart.util.UnitType unitType32 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color39 = java.awt.Color.GREEN;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color39, stroke40);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint37, stroke40);
        boolean boolean43 = categoryAnchor35.equals((java.lang.Object) stroke40);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color34, stroke40);
        boolean boolean45 = unitType32.equals((java.lang.Object) stroke40);
        xYPlot13.setDomainZeroBaselineStroke(stroke40);
        xYPlot13.setWeight(13);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        xYPlot13.setRangeAxis((int) (byte) 100, valueAxis50);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNotNull(unitType32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis16.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double30 = rectangleInsets28.calculateTopInset((double) ' ');
        categoryAxis16.setTickLabelInsets(rectangleInsets28);
        categoryPlot6.setInsets(rectangleInsets28);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot6.getDomainAxisLocation(2);
        java.awt.Color color36 = java.awt.Color.GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker38.setStroke(stroke39);
        categoryMarker38.setAlpha((float) 1L);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range45 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis44.setRange(range45);
        org.jfree.data.Range range47 = dateAxis44.getRange();
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis48, xYItemRenderer49);
        xYPlot50.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = xYPlot50.getAxisOffset();
        xYPlot50.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder57 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color59 = java.awt.Color.GREEN;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker61 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color59, stroke60);
        java.awt.Stroke stroke62 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker61.setStroke(stroke62);
        boolean boolean64 = datasetRenderingOrder57.equals((java.lang.Object) categoryMarker61);
        java.awt.Font font65 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker61.setLabelFont(font65);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = categoryMarker61.getLabelOffsetType();
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean69 = xYPlot50.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker61, layer68);
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker38, layer68);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType71 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        categoryMarker38.setLabelOffsetType(lengthAdjustmentType71);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(datasetRenderingOrder57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(lengthAdjustmentType67);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType71);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        xYPlot7.setRangeZeroBaselineVisible(true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation54 = null;
        try {
            boolean boolean55 = xYPlot7.removeAnnotation(xYAnnotation54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit7, true, true);
        dateAxis0.setRangeWithMargins((-7.99999999d), (double) 100L);
        org.jfree.data.Range range14 = dateAxis0.getDefaultAutoRange();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range17);
        org.jfree.data.Range range19 = dateAxis16.getRange();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer21);
        xYPlot22.mapDatasetToRangeAxis((int) (byte) 0, 0);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        xYPlot22.drawAnnotations(graphics2D26, rectangle2D27, plotRenderingInfo28);
        boolean boolean30 = xYPlot22.isOutlineVisible();
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot22);
        java.text.DateFormat dateFormat32 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(dateFormat32);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot6.setRenderer(categoryItemRenderer7, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot6.getRenderer();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color13 = java.awt.Color.GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color13, stroke14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker15.setStroke(stroke16);
        boolean boolean18 = datasetRenderingOrder11.equals((java.lang.Object) categoryMarker15);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis23, categoryItemRenderer24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis20.setLabelPaint((java.awt.Paint) color26);
        categoryMarker15.setLabelPaint((java.awt.Paint) color26);
        float float29 = categoryMarker15.getAlpha();
        boolean boolean30 = categoryPlot6.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker15);
        boolean boolean31 = categoryPlot6.isOutlineVisible();
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        dateAxis0.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date7 = dateAxis0.getMaximumDate();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean9 = dateAxis0.equals((java.lang.Object) categoryAxis8);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        dateAxis0.setTimeZone(timeZone10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint13 = defaultDrawingSupplier12.getNextFillPaint();
        java.awt.Shape shape14 = defaultDrawingSupplier12.getNextShape();
        dateAxis0.setUpArrow(shape14);
        java.lang.Object obj16 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit7, true, true);
        dateAxis0.configure();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot22.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25, true);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace28);
        categoryPlot22.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot22.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            org.jfree.chart.axis.AxisState axisState34 = dateAxis0.draw(graphics2D12, (double) '#', rectangle2D14, rectangle2D15, rectangleEdge32, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.calculateRightInset(4.0d);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]" + "'", str5.equals("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertNotNull(unitType8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        java.lang.String str14 = axisLocation13.toString();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str14.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double15 = rectangleInsets13.calculateTopInset((double) ' ');
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        double double18 = rectangleInsets13.calculateTopOutset((double) 100L);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            rectangleInsets13.trim(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        xYPlot7.setDomainCrosshairLockedOnData(true);
        java.awt.Paint paint54 = xYPlot7.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        xYPlot7.clearDomainAxes();
        int int27 = xYPlot7.getDomainAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = xYPlot7.getLegendItems();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection28);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        int int29 = categoryPlot19.getBackgroundImageAlignment();
        boolean boolean30 = categoryPlot19.getDrawSharedDomainAxis();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 15 + "'", int29 == 15);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot7.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        boolean boolean15 = xYPlot7.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis20, categoryItemRenderer21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot22.zoomDomainAxes(0.0d, plotRenderingInfo24, point2D25, true);
        int int28 = categoryPlot22.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis33, categoryItemRenderer34);
        categoryPlot22.setParent((org.jfree.chart.plot.Plot) categoryPlot35);
        java.awt.Color color38 = java.awt.Color.GREEN;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color38, stroke39);
        java.lang.String str41 = color38.toString();
        categoryPlot35.setRangeCrosshairPaint((java.awt.Paint) color38);
        org.jfree.chart.JFreeChart jFreeChart43 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot35, jFreeChart43);
        java.lang.Object obj45 = null;
        boolean boolean46 = categoryPlot35.equals(obj45);
        int int47 = categoryPlot35.getDomainAxisCount();
        xYPlot7.setParent((org.jfree.chart.plot.Plot) categoryPlot35);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str41.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        boolean boolean29 = xYPlot7.isRangeGridlinesVisible();
        java.awt.Paint paint30 = xYPlot7.getDomainZeroBaselinePaint();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range32 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis31.setRange(range32);
        double double34 = dateAxis31.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range37 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis36.setRange(range37);
        org.jfree.data.Range range39 = dateAxis36.getRange();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis40, xYItemRenderer41);
        xYPlot42.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = xYPlot42.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot42.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot42.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot42.getDomainAxisForDataset((int) (byte) 0);
        valueAxis52.setNegativeArrowVisible(false);
        valueAxis52.setLowerMargin((double) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray58 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot57.setDomainAxes(categoryAxisArray58);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent60 = null;
        categoryPlot57.axisChanged(axisChangeEvent60);
        valueAxis52.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot57);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray63 = new org.jfree.chart.axis.ValueAxis[] { dateAxis31, valueAxis52 };
        xYPlot7.setRangeAxes(valueAxisArray63);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(valueAxis52);
        org.junit.Assert.assertNotNull(categoryAxisArray58);
        org.junit.Assert.assertNotNull(valueAxisArray63);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        java.awt.Stroke stroke23 = categoryMarker17.getStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color26 = java.awt.Color.GREEN;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color26, stroke27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker28.setStroke(stroke29);
        boolean boolean31 = datasetRenderingOrder24.equals((java.lang.Object) categoryMarker28);
        java.awt.Font font32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker28.setLabelFont(font32);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = categoryMarker28.getLabelOffsetType();
        org.jfree.chart.text.TextAnchor textAnchor35 = categoryMarker28.getLabelTextAnchor();
        categoryMarker17.setLabelTextAnchor(textAnchor35);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis38.setAutoRangeStickyZero(false);
        boolean boolean41 = numberAxis38.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit42 = numberAxis38.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis44.setAutoRangeStickyZero(false);
        boolean boolean47 = numberAxis44.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit48 = numberAxis44.getTickUnit();
        numberAxis38.setTickUnit(numberTickUnit48, true, true);
        categoryMarker17.setKey((java.lang.Comparable) true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(lengthAdjustmentType34);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(numberTickUnit42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(numberTickUnit48);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        xYPlot7.clearDomainAxes();
        xYPlot7.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot7.getDomainAxis();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomDomainAxes(0.0d, plotRenderingInfo20, point2D21, true);
        int int24 = categoryPlot18.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color27 = java.awt.Color.GREEN;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color27, stroke28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker29.setStroke(stroke30);
        boolean boolean32 = datasetRenderingOrder25.equals((java.lang.Object) categoryMarker29);
        org.jfree.chart.util.Layer layer33 = null;
        categoryPlot18.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker29, layer33);
        java.awt.Stroke stroke35 = categoryMarker29.getStroke();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomDomainAxes(0.0d, plotRenderingInfo44, point2D45, true);
        int int48 = categoryPlot42.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder50 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color52 = java.awt.Color.GREEN;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color52, stroke53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker54.setStroke(stroke55);
        boolean boolean57 = datasetRenderingOrder50.equals((java.lang.Object) categoryMarker54);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis59.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis62, categoryItemRenderer63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis59.setLabelPaint((java.awt.Paint) color65);
        categoryMarker54.setLabelPaint((java.awt.Paint) color65);
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot42.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker54, layer68);
        xYPlot7.addDomainMarker(4, (org.jfree.chart.plot.Marker) categoryMarker29, layer68);
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range73 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis72.setRange(range73);
        org.jfree.data.Range range75 = dateAxis72.getRange();
        dateAxis72.resizeRange((-355.0d), (double) 2.0f);
        dateAxis72.setPositiveArrowVisible(true);
        java.util.Date date81 = dateAxis72.getMaximumDate();
        xYPlot7.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) dateAxis72, true);
        xYPlot7.clearDomainAxes();
        xYPlot7.configureRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        java.awt.geom.Point2D point2D88 = null;
        xYPlot7.zoomRangeAxes((double) 15, plotRenderingInfo87, point2D88);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertNotNull(date81);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double15 = rectangleInsets13.calculateTopInset((double) ' ');
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        categoryAxis1.setUpperMargin((double) 10.0f);
        java.awt.Paint paint20 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 1);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range26 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis25.setRange(range26);
        org.jfree.data.Range range28 = dateAxis25.getRange();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer30);
        xYPlot31.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = xYPlot31.getAxisOffset();
        xYPlot31.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot31.getRangeAxisEdge((-16777216));
        try {
            double double40 = categoryAxis1.getCategoryStart(255, (int) (short) 100, rectangle2D23, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot7.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        boolean boolean15 = xYPlot7.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot7.getDataset();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range20);
        org.jfree.data.Range range22 = dateAxis19.getRange();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer24);
        xYPlot25.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = xYPlot25.getAxisOffset();
        xYPlot25.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis34.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis37, categoryItemRenderer38);
        categoryPlot39.setDrawSharedDomainAxis(false);
        java.awt.Color color43 = java.awt.Color.GREEN;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color43, stroke44);
        categoryPlot39.addDomainMarker(categoryMarker45);
        org.jfree.chart.axis.ValueAxis valueAxis47 = categoryPlot39.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis49.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis52, categoryItemRenderer53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis49.setLabelPaint((java.awt.Paint) color55);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double63 = rectangleInsets61.calculateTopInset((double) ' ');
        categoryAxis49.setTickLabelInsets(rectangleInsets61);
        categoryPlot39.setInsets(rectangleInsets61);
        org.jfree.chart.axis.AxisLocation axisLocation67 = categoryPlot39.getDomainAxisLocation(2);
        xYPlot25.setDomainAxisLocation(0, axisLocation67);
        org.jfree.chart.axis.ValueAxis valueAxis69 = xYPlot25.getDomainAxis();
        java.awt.Paint paint70 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        valueAxis69.setTickLabelPaint(paint70);
        try {
            xYPlot7.setDomainAxis((-16777216), valueAxis69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertNotNull(valueAxis69);
        org.junit.Assert.assertNotNull(paint70);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            java.awt.Color color1 = java.awt.Color.decode("UnitType.RELATIVE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UnitType.RELATIVE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis15.setRange(range16);
        org.jfree.data.Range range18 = dateAxis15.getRange();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer20);
        xYPlot21.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = xYPlot21.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot21.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot21.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis33.setRange(range34);
        org.jfree.data.Range range36 = dateAxis33.getRange();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer38);
        xYPlot39.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = xYPlot39.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot39.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = xYPlot39.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot39.getDomainAxisForDataset((int) (byte) 0);
        valueAxis49.setNegativeArrowVisible(false);
        valueAxis49.setLowerMargin((double) 0);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range55 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis54.setRange(range55);
        org.jfree.data.Range range57 = dateAxis54.getRange();
        dateAxis54.resizeRange((-355.0d), (double) 2.0f);
        dateAxis54.setPositiveArrowVisible(true);
        boolean boolean64 = dateAxis54.isHiddenValue((long) (short) -1);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range66 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis65.setRange(range66);
        dateAxis65.zoomRange((double) (-4194304), 2.0d);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray71 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31, valueAxis49, dateAxis54, dateAxis65 };
        categoryPlot6.setRangeAxes(valueAxisArray71);
        categoryPlot6.setForegroundAlpha((float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = categoryPlot6.getDomainAxisForDataset((int) (short) -1);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(valueAxis31);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(valueAxis49);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertNotNull(valueAxisArray71);
        org.junit.Assert.assertNotNull(categoryAxis76);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setTickMarksVisible(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        double double6 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        try {
            categoryPlot6.setDomainAxisLocation(axisLocation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot6.getDataset();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot6.render(graphics2D27, rectangle2D28, 12, plotRenderingInfo30);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker17.setStroke(stroke18);
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) categoryMarker17);
        org.jfree.chart.util.Layer layer21 = null;
        categoryPlot6.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker17, layer21);
        int int23 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot6.setDataset(categoryDataset24);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot6.getRangeAxis((int) (short) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot6.setRenderer(8, categoryItemRenderer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        int int32 = categoryPlot6.getIndexOf(categoryItemRenderer31);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        boolean boolean22 = xYPlot7.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        int int24 = xYPlot7.indexOf(xYDataset23);
        xYPlot7.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot32.zoomDomainAxes(0.0d, plotRenderingInfo34, point2D35, true);
        int int38 = categoryPlot32.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color41 = java.awt.Color.GREEN;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color41, stroke42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker43.setStroke(stroke44);
        boolean boolean46 = datasetRenderingOrder39.equals((java.lang.Object) categoryMarker43);
        org.jfree.chart.util.Layer layer47 = null;
        categoryPlot32.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker43, layer47);
        int int49 = categoryPlot32.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        categoryPlot32.setDataset(categoryDataset50);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis52.setTickMarkInsideLength((float) 5);
        categoryAxis52.setVisible(false);
        boolean boolean57 = categoryPlot32.equals((java.lang.Object) categoryAxis52);
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.plot.Plot plot59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis62.setRange(range63);
        org.jfree.data.Range range65 = dateAxis62.getRange();
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset61, (org.jfree.chart.axis.ValueAxis) dateAxis62, (org.jfree.chart.axis.ValueAxis) dateAxis66, xYItemRenderer67);
        xYPlot68.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = xYPlot68.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation74 = xYPlot68.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = xYPlot68.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace77 = null;
        org.jfree.chart.axis.AxisSpace axisSpace78 = categoryAxis52.reserveSpace(graphics2D58, plot59, rectangle2D60, rectangleEdge76, axisSpace77);
        xYPlot7.setFixedRangeAxisSpace(axisSpace78, false);
        java.awt.Stroke stroke81 = xYPlot7.getOutlineStroke();
        xYPlot7.setRangeCrosshairValue((double) (-4194304), false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(axisSpace78);
        org.junit.Assert.assertNotNull(stroke81);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker18.setStroke(stroke19);
        boolean boolean21 = datasetRenderingOrder14.equals((java.lang.Object) categoryMarker18);
        java.awt.Font font22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker18.setLabelFont(font22);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = categoryMarker18.getLabelOffsetType();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean26 = xYPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer25);
        boolean boolean28 = categoryMarker18.equals((java.lang.Object) 5);
        java.lang.Comparable comparable29 = categoryMarker18.getKey();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + (short) 10 + "'", comparable29.equals((short) 10));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis7.setAutoRangeStickyZero(false);
        boolean boolean10 = numberAxis7.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis7.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit11, false, false);
        boolean boolean15 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker12.setStroke(stroke13);
        java.awt.Paint paint15 = categoryMarker12.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        categoryAxis16.setAxisLineVisible(true);
        java.lang.String str21 = categoryAxis16.getLabelURL();
        boolean boolean22 = categoryMarker12.equals((java.lang.Object) categoryAxis16);
        categoryPlot6.setDomainAxis(categoryAxis16);
        java.util.List list24 = categoryPlot6.getCategories();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(list24);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        categoryPlot6.setFixedDomainAxisSpace(axisSpace12);
        java.awt.Stroke stroke14 = categoryPlot6.getDomainGridlineStroke();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot6.getRangeMarkers(layer15);
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str18 = axisLocation17.toString();
        categoryPlot6.setRangeAxisLocation(axisLocation17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str18.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot12.zoomDomainAxes(0.0d, plotRenderingInfo14, point2D15, true);
        int int18 = categoryPlot12.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis20.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis23, categoryItemRenderer24);
        categoryPlot12.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        java.awt.Color color28 = java.awt.Color.GREEN;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color28, stroke29);
        java.lang.String str31 = color28.toString();
        categoryPlot25.setRangeCrosshairPaint((java.awt.Paint) color28);
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot25, jFreeChart33);
        categoryPlot25.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup37 = categoryPlot25.getDatasetGroup();
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color38);
        boolean boolean40 = categoryPlot25.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace41 = categoryPlot25.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot25.setDomainGridlinePosition(categoryAnchor42);
        boolean boolean44 = defaultDrawingSupplier5.equals((java.lang.Object) categoryAnchor42);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str31.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        xYPlot7.clearDomainAxes();
        java.awt.Paint paint15 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot7.setDomainGridlineStroke(stroke16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        int int19 = xYPlot7.getDomainAxisIndex(valueAxis18);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        boolean boolean26 = xYPlot7.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke27 = xYPlot7.getDomainGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot7.getDomainAxis((-12517377));
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        categoryPlot6.setRangeCrosshairValue((double) 8, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier17 = categoryPlot6.getDrawingSupplier();
        try {
            categoryPlot6.zoom((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(drawingSupplier17);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        boolean boolean29 = xYPlot7.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.util.List list32 = null;
        xYPlot7.drawRangeTickBands(graphics2D30, rectangle2D31, list32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.util.List list36 = null;
        xYPlot7.drawDomainTickBands(graphics2D34, rectangle2D35, list36);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYPlot7.rendererChanged(rendererChangeEvent38);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        boolean boolean29 = xYPlot7.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot7.getDomainAxisLocation((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis36, categoryItemRenderer37);
        categoryPlot38.setDrawSharedDomainAxis(false);
        java.awt.Color color42 = java.awt.Color.GREEN;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color42, stroke43);
        categoryPlot38.addDomainMarker(categoryMarker44);
        org.jfree.chart.axis.ValueAxis valueAxis46 = categoryPlot38.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis48.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis51, categoryItemRenderer52);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis48.setLabelPaint((java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double62 = rectangleInsets60.calculateTopInset((double) ' ');
        categoryAxis48.setTickLabelInsets(rectangleInsets60);
        categoryPlot38.setInsets(rectangleInsets60);
        org.jfree.chart.axis.AxisLocation axisLocation66 = categoryPlot38.getDomainAxisLocation(2);
        java.lang.String str67 = axisLocation66.toString();
        xYPlot7.setDomainAxisLocation(axisLocation66);
        org.jfree.data.xy.XYDataset xYDataset70 = null;
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range72 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis71.setRange(range72);
        org.jfree.data.Range range74 = dateAxis71.getRange();
        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer76 = null;
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot(xYDataset70, (org.jfree.chart.axis.ValueAxis) dateAxis71, (org.jfree.chart.axis.ValueAxis) dateAxis75, xYItemRenderer76);
        xYPlot77.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = xYPlot77.getAxisOffset();
        xYPlot77.clearAnnotations();
        java.awt.Paint paint83 = xYPlot77.getDomainCrosshairPaint();
        try {
            xYPlot7.setQuadrantPaint(100, paint83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (100) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(valueAxis46);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str67.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertNotNull(rectangleInsets81);
        org.junit.Assert.assertNotNull(paint83);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Paint paint12 = categoryPlot6.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        dateAxis0.zoomRange((double) (-4194304), 2.0d);
        boolean boolean6 = dateAxis0.isAutoRange();
        double double7 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-4194304.0d) + "'", double7 == (-4194304.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        java.awt.Paint paint13 = xYPlot7.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke14 = xYPlot7.getDomainZeroBaselineStroke();
        java.awt.Color color17 = java.awt.Color.GREEN;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color17, stroke18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker19.setStroke(stroke20);
        categoryMarker19.setAlpha((float) 1L);
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = xYPlot7.removeDomainMarker(128, (org.jfree.chart.plot.Marker) categoryMarker19, layer24);
        xYPlot7.setDomainCrosshairValue(0.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color24 = java.awt.Color.GREEN;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color24, stroke25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker26.setStroke(stroke27);
        boolean boolean29 = datasetRenderingOrder22.equals((java.lang.Object) categoryMarker26);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        categoryMarker26.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot6.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker26, layer40, true);
        java.awt.Paint paint43 = categoryPlot6.getRangeGridlinePaint();
        java.awt.Paint paint44 = categoryPlot6.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker3.setStroke(stroke4);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color8 = java.awt.Color.GREEN;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color8, stroke9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker10.setStroke(stroke11);
        boolean boolean13 = datasetRenderingOrder6.equals((java.lang.Object) categoryMarker10);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis18, categoryItemRenderer19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis15.setLabelPaint((java.awt.Paint) color21);
        categoryMarker10.setLabelPaint((java.awt.Paint) color21);
        categoryMarker3.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = categoryMarker3.getLabelOffsetType();
        java.lang.String str26 = lengthAdjustmentType25.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(lengthAdjustmentType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "EXPAND" + "'", str26.equals("EXPAND"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot6.getAxisOffset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot6.getRenderer();
        categoryPlot6.setBackgroundImageAlignment((-16777216));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, (double) (short) 100, (double) 100L, (double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100, 2.0d, (double) (-4194304), (double) 5);
        double double12 = rectangleInsets10.trimHeight((-111.0d));
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4194093.0d + "'", double12 == 4194093.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis7.setAutoRangeStickyZero(false);
        boolean boolean10 = numberAxis7.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis7.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit11, true, true);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis16.setAutoRangeStickyZero(false);
        boolean boolean19 = numberAxis16.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = numberAxis16.getTickUnit();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis16.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit21, true, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberTickUnit20);
        org.junit.Assert.assertNotNull(numberTickUnit21);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        dateAxis1.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date8 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis1.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit9, true, true);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        boolean boolean17 = dateAxis13.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis13.setStandardTickUnits(tickUnitSource18);
        boolean boolean21 = dateAxis13.isHiddenValue(0L);
        java.awt.Color color22 = java.awt.Color.gray;
        dateAxis13.setLabelPaint((java.awt.Paint) color22);
        dateAxis0.setLabelPaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        xYPlot7.drawAnnotations(graphics2D8, rectangle2D9, plotRenderingInfo10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot7.drawAnnotations(graphics2D12, rectangle2D13, plotRenderingInfo14);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        org.jfree.chart.util.UnitType unitType8 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color15 = java.awt.Color.GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color15, stroke16);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint13, stroke16);
        boolean boolean19 = categoryAnchor11.equals((java.lang.Object) stroke16);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color10, stroke16);
        boolean boolean21 = unitType8.equals((java.lang.Object) stroke16);
        xYPlot7.setRangeGridlineStroke(stroke16);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Point2D point2D25 = null;
        org.jfree.chart.plot.PlotState plotState26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            xYPlot7.draw(graphics2D23, rectangle2D24, point2D25, plotState26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(unitType8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double6 = rectangleInsets4.calculateTopInset((double) ' ');
        double double8 = rectangleInsets4.calculateLeftInset((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType9 = rectangleInsets4.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets(unitType9, (double) ' ', (double) (-4194304), (double) (-1.0f), (double) 10);
        java.lang.String str15 = unitType9.toString();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UnitType.ABSOLUTE" + "'", str15.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        categoryPlot0.setAnchorValue(0.05d, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(categoryAnchor6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        boolean boolean7 = categoryPlot6.isRangeCrosshairLockedOnData();
        categoryPlot6.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot16.getOrientation();
        boolean boolean18 = categoryPlot6.equals((java.lang.Object) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot6.getDataset((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryDataset20);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis52.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis55, categoryItemRenderer56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot57.zoomDomainAxes(0.0d, plotRenderingInfo59, point2D60, true);
        org.jfree.chart.axis.AxisSpace axisSpace63 = null;
        categoryPlot57.setFixedDomainAxisSpace(axisSpace63);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent65 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot57);
        org.jfree.chart.plot.Plot plot66 = plotChangeEvent65.getPlot();
        plot66.setForegroundAlpha((float) (short) 10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder69 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color71 = java.awt.Color.GREEN;
        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker73 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color71, stroke72);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker73.setStroke(stroke74);
        boolean boolean76 = datasetRenderingOrder69.equals((java.lang.Object) categoryMarker73);
        java.awt.Font font77 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker73.setLabelFont(font77);
        java.awt.Stroke stroke79 = categoryMarker73.getStroke();
        plot66.setOutlineStroke(stroke79);
        xYPlot7.setDomainCrosshairStroke(stroke79);
        boolean boolean82 = xYPlot7.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(plot66);
        org.junit.Assert.assertNotNull(datasetRenderingOrder69);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = numberAxis1.getTickUnit();
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        double double8 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        int int53 = xYPlot7.getIndexOf(xYItemRenderer52);
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYPlot7.setRangeZeroBaselineStroke(stroke54);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double19 = rectangleInsets17.calculateTopInset((double) ' ');
        double double21 = rectangleInsets17.calculateLeftInset((double) (byte) 10);
        double double23 = rectangleInsets17.calculateRightInset(0.0d);
        xYPlot7.setInsets(rectangleInsets17, true);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset((int) 'a', xYDataset27);
        boolean boolean29 = xYPlot7.isRangeCrosshairLockedOnData();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.util.List list32 = null;
        xYPlot7.drawRangeTickBands(graphics2D30, rectangle2D31, list32);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis35.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis38, categoryItemRenderer39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot40.zoomDomainAxes(0.0d, plotRenderingInfo42, point2D43, true);
        int int46 = categoryPlot40.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis48.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis51, categoryItemRenderer52);
        categoryPlot40.setParent((org.jfree.chart.plot.Plot) categoryPlot53);
        java.awt.Color color56 = java.awt.Color.GREEN;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color56, stroke57);
        java.lang.String str59 = color56.toString();
        categoryPlot53.setRangeCrosshairPaint((java.awt.Paint) color56);
        java.awt.Stroke stroke61 = categoryPlot53.getRangeGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot53.getDomainAxisLocation(100);
        org.jfree.chart.axis.AxisLocation axisLocation64 = axisLocation63.getOpposite();
        xYPlot7.setDomainAxisLocation(axisLocation64, true);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str59.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(axisLocation64);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, (double) (short) 100, (double) 100L, (double) 8);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double14 = rectangleInsets12.calculateTopInset((double) ' ');
        double double16 = rectangleInsets12.trimWidth((double) (-1.0f));
        boolean boolean17 = chartChangeEventType7.equals((java.lang.Object) rectangleInsets12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100L, jFreeChart6, chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent18.setType(chartChangeEventType19);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-111.0d) + "'", double16 == (-111.0d));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        categoryPlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot6.setDomainAxisLocation((int) '#', axisLocation15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot6.getRenderer();
        boolean boolean18 = categoryPlot6.isDomainZoomable();
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis3.setTickMarkInsideLength((float) 5);
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis6, categoryItemRenderer7);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
//        java.awt.geom.Point2D point2D11 = null;
//        categoryPlot8.zoomDomainAxes(0.0d, plotRenderingInfo10, point2D11, true);
//        int int14 = categoryPlot8.getRangeAxisCount();
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
//        java.awt.Color color18 = java.awt.Color.GREEN;
//        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color18, stroke19);
//        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        categoryMarker20.setStroke(stroke21);
//        boolean boolean23 = datasetRenderingOrder16.equals((java.lang.Object) categoryMarker20);
//        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis25.setTickMarkInsideLength((float) 5);
//        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis28, categoryItemRenderer29);
//        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
//        categoryAxis25.setLabelPaint((java.awt.Paint) color31);
//        categoryMarker20.setLabelPaint((java.awt.Paint) color31);
//        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.BACKGROUND;
//        categoryPlot8.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker20, layer34);
//        boolean boolean36 = day0.equals((java.lang.Object) categoryPlot8);
//        java.util.Date date37 = day0.getStart();
//        java.util.Calendar calendar38 = null;
//        try {
//            long long39 = day0.getLastMillisecond(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNotNull(stroke19);
//        org.junit.Assert.assertNotNull(stroke21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(color31);
//        org.junit.Assert.assertNotNull(layer34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        org.jfree.data.Range range3 = dateAxis0.getRange();
        boolean boolean4 = dateAxis0.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit7, true, true);
        dateAxis0.setRangeWithMargins((-7.99999999d), (double) 100L);
        org.jfree.data.Range range14 = dateAxis0.getDefaultAutoRange();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range17);
        org.jfree.data.Range range19 = dateAxis16.getRange();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer21);
        org.jfree.data.Range range23 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range23);
        dateAxis0.setDefaultAutoRange(range23);
        dateAxis0.setTickMarkInsideLength((float) (-4194304));
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range23);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        int int23 = xYPlot7.indexOf(xYDataset22);
        java.awt.Paint paint24 = xYPlot7.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        org.jfree.data.Range range10 = dateAxis7.getRange();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        xYPlot13.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot13.getAxisOffset();
        xYPlot13.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range20);
        org.jfree.data.Range range22 = dateAxis19.getRange();
        dateAxis19.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        int int27 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        int int29 = xYPlot13.indexOf(xYDataset28);
        boolean boolean30 = categoryAxis0.hasListener((java.util.EventListener) xYPlot13);
        float float31 = xYPlot13.getForegroundAlpha();
        java.awt.Color color32 = java.awt.Color.RED;
        xYPlot13.setNoDataMessagePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis34.setRange(range35);
        org.jfree.data.Range range37 = dateAxis34.getRange();
        dateAxis34.resizeRange((-355.0d), (double) 2.0f);
        dateAxis34.setPositiveArrowVisible(true);
        boolean boolean44 = dateAxis34.isHiddenValue((long) (short) -1);
        java.awt.Shape shape45 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setLeftArrow(shape45);
        int int47 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis34);
        xYPlot13.mapDatasetToDomainAxis(7, (int) (short) 100);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        org.jfree.chart.plot.Plot plot52 = valueAxis51.getPlot();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
        org.junit.Assert.assertNotNull(plot52);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        categoryAxis0.setCategoryMargin((double) 3);
        categoryAxis0.setLowerMargin(1.0d);
        boolean boolean9 = categoryAxis0.isTickMarksVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setDrawSharedDomainAxis(false);
        java.awt.Color color20 = java.awt.Color.GREEN;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color20, stroke21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker22.setStroke(stroke23);
        java.awt.Paint paint25 = categoryMarker22.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setTickMarkInsideLength((float) 5);
        categoryAxis26.setAxisLineVisible(true);
        java.lang.String str31 = categoryAxis26.getLabelURL();
        boolean boolean32 = categoryMarker22.equals((java.lang.Object) categoryAxis26);
        categoryPlot16.setDomainAxis(categoryAxis26);
        boolean boolean34 = categoryAxis0.equals((java.lang.Object) categoryPlot16);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        dateAxis0.zoomRange((double) (-4194304), 2.0d);
        org.jfree.chart.axis.Timeline timeline6 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(timeline6);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker18.setStroke(stroke19);
        boolean boolean21 = datasetRenderingOrder14.equals((java.lang.Object) categoryMarker18);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis23.setLabelPaint((java.awt.Paint) color29);
        categoryMarker18.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot6.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker18, layer32);
        java.awt.Color color35 = java.awt.Color.GREEN;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color35, stroke36);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker37.setStroke(stroke38);
        org.jfree.chart.text.TextAnchor textAnchor40 = categoryMarker37.getLabelTextAnchor();
        java.awt.Paint paint41 = categoryMarker37.getOutlinePaint();
        categoryPlot6.setDomainGridlinePaint(paint41);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        xYPlot7.setBackgroundImageAlignment((int) (short) 1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color17 = java.awt.Color.GREEN;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color17, stroke18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker19.setStroke(stroke20);
        boolean boolean22 = datasetRenderingOrder15.equals((java.lang.Object) categoryMarker19);
        xYPlot7.setDatasetRenderingOrder(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) -1, (int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0f);
        org.jfree.chart.JFreeChart jFreeChart2 = chartChangeEvent1.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent1.getType();
        org.junit.Assert.assertNull(jFreeChart2);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color28 = java.awt.Color.GREEN;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color28, stroke29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker30.setStroke(stroke31);
        boolean boolean33 = datasetRenderingOrder26.equals((java.lang.Object) categoryMarker30);
        java.awt.Font font34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker30.setLabelFont(font34);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = categoryMarker30.getLabelOffsetType();
        categoryMarker30.setLabel("DatasetRenderingOrder.FORWARD");
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.CrosshairState crosshairState44 = null;
        boolean boolean45 = xYPlot7.render(graphics2D40, rectangle2D41, 4, plotRenderingInfo43, crosshairState44);
        boolean boolean46 = xYPlot7.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace47 = xYPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot7.getDomainAxisLocation((int) (byte) 100);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(axisSpace47);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryPlot6.setRangeCrosshairPaint((java.awt.Paint) color12);
        java.awt.Font font14 = categoryPlot6.getNoDataMessageFont();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot6.getRendererForDataset(categoryDataset15);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range1);
        double double3 = dateAxis0.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis5.setRange(range6);
        org.jfree.data.Range range8 = dateAxis5.getRange();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer10);
        xYPlot11.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot11.getAxisOffset();
        xYPlot11.clearAnnotations();
        java.awt.Paint paint17 = xYPlot11.getDomainCrosshairPaint();
        dateAxis0.setTickMarkPaint(paint17);
        dateAxis0.configure();
        try {
            dateAxis0.setRangeWithMargins((double) 1, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setDrawSharedDomainAxis(false);
        java.awt.Color color10 = java.awt.Color.GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color10, stroke11);
        categoryPlot6.addDomainMarker(categoryMarker12);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot6.getRangeAxis();
        org.jfree.data.general.DatasetGroup datasetGroup15 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot6.getRenderer();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        java.awt.Paint paint12 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        java.awt.Paint paint12 = xYPlot7.getRangeZeroBaselinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color19, stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke20);
        boolean boolean23 = categoryAnchor15.equals((java.lang.Object) stroke20);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color14, stroke20);
        xYPlot7.setDomainCrosshairStroke(stroke20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color28 = java.awt.Color.GREEN;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color28, stroke29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker30.setStroke(stroke31);
        boolean boolean33 = datasetRenderingOrder26.equals((java.lang.Object) categoryMarker30);
        java.awt.Font font34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryMarker30.setLabelFont(font34);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = categoryMarker30.getLabelOffsetType();
        categoryMarker30.setLabel("DatasetRenderingOrder.FORWARD");
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = xYPlot7.getFixedLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str42 = axisLocation41.toString();
        xYPlot7.setRangeAxisLocation(axisLocation41, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAnchor15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str42.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkInsideLength((float) 5);
        categoryAxis0.setVisible(false);
        java.awt.Paint paint5 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range8 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis7.setRange(range8);
        org.jfree.data.Range range10 = dateAxis7.getRange();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer12);
        xYPlot13.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = xYPlot13.getAxisOffset();
        xYPlot13.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis19.setRange(range20);
        org.jfree.data.Range range22 = dateAxis19.getRange();
        dateAxis19.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date26 = dateAxis19.getMaximumDate();
        int int27 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        int int29 = xYPlot13.indexOf(xYDataset28);
        boolean boolean30 = categoryAxis0.hasListener((java.util.EventListener) xYPlot13);
        float float31 = xYPlot13.getForegroundAlpha();
        java.awt.Color color32 = java.awt.Color.RED;
        xYPlot13.setNoDataMessagePaint((java.awt.Paint) color32);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis34.setRange(range35);
        org.jfree.data.Range range37 = dateAxis34.getRange();
        dateAxis34.resizeRange((-355.0d), (double) 2.0f);
        dateAxis34.setPositiveArrowVisible(true);
        boolean boolean44 = dateAxis34.isHiddenValue((long) (short) -1);
        java.awt.Shape shape45 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        dateAxis34.setLeftArrow(shape45);
        int int47 = xYPlot13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range49 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis48.setRange(range49);
        org.jfree.data.Range range51 = dateAxis48.getRange();
        boolean boolean52 = dateAxis48.isVerticalTickLabels();
        org.jfree.chart.axis.TickUnitSource tickUnitSource53 = null;
        dateAxis48.setStandardTickUnits(tickUnitSource53);
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range57 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis56.setRange(range57);
        org.jfree.data.Range range59 = dateAxis56.getRange();
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis56, (org.jfree.chart.axis.ValueAxis) dateAxis60, xYItemRenderer61);
        java.awt.Shape shape63 = dateAxis60.getUpArrow();
        dateAxis48.setUpArrow(shape63);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range67 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis66.setRange(range67);
        org.jfree.data.Range range69 = dateAxis66.getRange();
        dateAxis66.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date73 = dateAxis66.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit74 = dateAxis66.getTickUnit();
        dateAxis65.setTickUnit(dateTickUnit74, true, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition78 = dateAxis65.getTickMarkPosition();
        dateAxis48.setTickMarkPosition(dateTickMarkPosition78);
        dateAxis34.setTickMarkPosition(dateTickMarkPosition78);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(range67);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(dateTickUnit74);
        org.junit.Assert.assertNotNull(dateTickMarkPosition78);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
        valueMarker1.setValue(4194093.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        int int9 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) "SeriesRenderingOrder.REVERSE");
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot7.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot7.getDomainAxisForDataset((int) (byte) 0);
        java.awt.Paint paint18 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot7.getFixedLegendItems();
        java.awt.Stroke stroke20 = xYPlot7.getRangeCrosshairStroke();
        java.lang.String str21 = xYPlot7.getNoDataMessage();
        xYPlot7.configureDomainAxes();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = null;
        xYPlot7.markerChanged(markerChangeEvent23);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color7);
        categoryAxis1.setFixedDimension(0.0d);
        float float11 = categoryAxis1.getTickMarkOutsideLength();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis16.setRange(range17);
        org.jfree.data.Range range19 = dateAxis16.getRange();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer21);
        xYPlot22.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot22.getAxisOffset();
        xYPlot22.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        categoryPlot36.setDrawSharedDomainAxis(false);
        java.awt.Color color40 = java.awt.Color.GREEN;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color40, stroke41);
        categoryPlot36.addDomainMarker(categoryMarker42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = categoryPlot36.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis46.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis49, categoryItemRenderer50);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis46.setLabelPaint((java.awt.Paint) color52);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double60 = rectangleInsets58.calculateTopInset((double) ' ');
        categoryAxis46.setTickLabelInsets(rectangleInsets58);
        categoryPlot36.setInsets(rectangleInsets58);
        org.jfree.chart.axis.AxisLocation axisLocation64 = categoryPlot36.getDomainAxisLocation(2);
        xYPlot22.setDomainAxisLocation(0, axisLocation64);
        org.jfree.chart.axis.ValueAxis valueAxis66 = xYPlot22.getDomainAxis();
        xYPlot22.setDomainCrosshairLockedOnData(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = xYPlot22.getDomainAxisEdge();
        try {
            double double70 = categoryAxis1.getCategoryEnd((int) (byte) -1, 1, rectangle2D14, rectangleEdge69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation64);
        org.junit.Assert.assertNotNull(valueAxis66);
        org.junit.Assert.assertNotNull(rectangleEdge69);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double15 = rectangleInsets13.calculateTopInset((double) ' ');
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        categoryAxis1.setUpperMargin((double) 10.0f);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color20 = color19.darker();
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        boolean boolean29 = categoryPlot28.isRangeCrosshairLockedOnData();
        categoryPlot28.setDrawSharedDomainAxis(true);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis36, categoryItemRenderer37);
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = categoryPlot38.getOrientation();
        boolean boolean40 = categoryPlot28.equals((java.lang.Object) categoryPlot38);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.Paint paint45 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color47 = java.awt.Color.GREEN;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color47, stroke48);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint45, stroke48);
        boolean boolean51 = categoryAnchor43.equals((java.lang.Object) stroke48);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((-111.0d), (java.awt.Paint) color42, stroke48);
        categoryPlot28.setRangeCrosshairStroke(stroke48);
        categoryAxis1.setAxisLineStroke(stroke48);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(categoryAnchor43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        int int12 = categoryPlot6.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis17, categoryItemRenderer18);
        categoryPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Color color22 = java.awt.Color.GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color22, stroke23);
        java.lang.String str25 = color22.toString();
        categoryPlot19.setRangeCrosshairPaint((java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot19, jFreeChart27);
        categoryPlot19.setAnchorValue((double) 1);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot19.getDatasetGroup();
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot19.setNoDataMessagePaint((java.awt.Paint) color32);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double40 = rectangleInsets38.calculateTopInset((double) ' ');
        double double42 = rectangleInsets38.calculateLeftInset((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType43 = rectangleInsets38.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets(unitType43, (double) ' ', (double) (-4194304), (double) (-1.0f), (double) 10);
        categoryPlot19.setInsets(rectangleInsets48, true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=0,g=255,b=0]"));
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertNotNull(unitType43);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Color color0 = java.awt.Color.PINK;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getRangeAxisEdge((-16777216));
        java.lang.Class<?> wildcardClass16 = rectangleEdge15.getClass();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        java.awt.Color color3 = java.awt.Color.GREEN;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color3, stroke4);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint1, stroke4);
        double double7 = valueMarker6.getValue();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        categoryAxis1.setCategoryMargin((double) 0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 10L);
        categoryAxis1.setCategoryLabelPositionOffset(255);
        categoryAxis1.setCategoryMargin((-7.0d));
        org.jfree.chart.plot.Plot plot16 = categoryAxis1.getPlot();
        java.awt.Color color18 = java.awt.Color.GREEN;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color18, stroke19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker20.setStroke(stroke21);
        java.awt.Paint paint23 = categoryMarker20.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setTickMarkInsideLength((float) 5);
        categoryAxis24.setAxisLineVisible(true);
        java.lang.String str29 = categoryAxis24.getLabelURL();
        boolean boolean30 = categoryMarker20.equals((java.lang.Object) categoryAxis24);
        java.awt.Font font31 = categoryAxis24.getLabelFont();
        categoryAxis1.setLabelFont(font31);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("Layer.BACKGROUND");
        numberAxis7.setAutoRangeStickyZero(false);
        boolean boolean10 = numberAxis7.getAutoRangeIncludesZero();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis7.getTickUnit();
        numberAxis1.setTickUnit(numberTickUnit11, false, false);
        try {
            numberAxis1.setAutoRangeMinimumSize((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(numberTickUnit11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1L, (double) (short) 100, (double) 100L, (double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100, 2.0d, (double) (-4194304), (double) 5);
        double double12 = rectangleInsets10.extendHeight((double) 1);
        double double13 = rectangleInsets10.getTop();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-4194203.0d) + "'", double12 == (-4194203.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        boolean boolean4 = sortOrder0.equals((java.lang.Object) categoryAxis1);
        java.lang.Comparable comparable5 = null;
        try {
            java.awt.Font font6 = categoryAxis1.getTickLabelFont(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(7, categoryItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis6.setRange(range7);
        org.jfree.data.Range range9 = dateAxis6.getRange();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer11);
        xYPlot12.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = xYPlot12.getAxisOffset();
        xYPlot12.clearAnnotations();
        java.awt.Paint paint18 = xYPlot12.getDomainZeroBaselinePaint();
        java.awt.Stroke stroke19 = xYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot12.setDomainAxisLocation(axisLocation20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot28.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31, true);
        int int34 = categoryPlot28.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color37 = java.awt.Color.GREEN;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color37, stroke38);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker39.setStroke(stroke40);
        boolean boolean42 = datasetRenderingOrder35.equals((java.lang.Object) categoryMarker39);
        org.jfree.chart.util.Layer layer43 = null;
        categoryPlot28.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker39, layer43);
        int int45 = categoryPlot28.getRangeAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        categoryPlot28.setDataset(categoryDataset46);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis48.setTickMarkInsideLength((float) 5);
        categoryAxis48.setVisible(false);
        boolean boolean53 = categoryPlot28.equals((java.lang.Object) categoryAxis48);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.plot.Plot plot55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range59 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis58.setRange(range59);
        org.jfree.data.Range range61 = dateAxis58.getRange();
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) dateAxis58, (org.jfree.chart.axis.ValueAxis) dateAxis62, xYItemRenderer63);
        xYPlot64.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = xYPlot64.getAxisOffset();
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot64.getRangeAxisLocation(8);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = xYPlot64.getDomainAxisEdge((int) '#');
        org.jfree.chart.axis.AxisSpace axisSpace73 = null;
        org.jfree.chart.axis.AxisSpace axisSpace74 = categoryAxis48.reserveSpace(graphics2D54, plot55, rectangle2D56, rectangleEdge72, axisSpace73);
        xYPlot12.setFixedDomainAxisSpace(axisSpace74);
        categoryPlot0.setFixedRangeAxisSpace(axisSpace74, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(range59);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(axisSpace74);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double15 = rectangleInsets13.calculateTopInset((double) ' ');
        categoryAxis1.setTickLabelInsets(rectangleInsets13);
        double double18 = rectangleInsets13.calculateTopOutset((double) 100L);
        java.lang.String str19 = rectangleInsets13.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets13);
        org.jfree.chart.JFreeChart jFreeChart21 = chartChangeEvent20.getChart();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]" + "'", str19.equals("RectangleInsets[t=1.0,l=100.0,b=100.0,r=10.0]"));
        org.junit.Assert.assertNull(jFreeChart21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomDomainAxes(0.0d, plotRenderingInfo8, point2D9, true);
        boolean boolean12 = categoryPlot6.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis13.setRange(range14);
        org.jfree.data.Range range16 = dateAxis13.getRange();
        dateAxis13.resizeRange((-355.0d), (double) 2.0f);
        java.util.Date date20 = dateAxis13.getMaximumDate();
        int int21 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis23.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot28.zoomDomainAxes(0.0d, plotRenderingInfo30, point2D31, true);
        categoryPlot28.setBackgroundImageAlpha(0.0f);
        java.awt.Paint paint36 = categoryPlot28.getRangeCrosshairPaint();
        dateAxis13.setTickMarkPaint(paint36);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = xYPlot7.getAxisOffset();
        xYPlot7.setDomainCrosshairLockedOnData(false);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Color color25 = java.awt.Color.GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color25, stroke26);
        categoryPlot21.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot21.getRangeAxis();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis34, categoryItemRenderer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis31.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 100.0f, (double) 100L, (double) (byte) 10);
        double double45 = rectangleInsets43.calculateTopInset((double) ' ');
        categoryAxis31.setTickLabelInsets(rectangleInsets43);
        categoryPlot21.setInsets(rectangleInsets43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot21.getDomainAxisLocation(2);
        xYPlot7.setDomainAxisLocation(0, axisLocation49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = xYPlot7.getDomainAxis();
        xYPlot7.setDomainCrosshairLockedOnData(true);
        java.awt.Paint paint54 = xYPlot7.getDomainTickBandPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation55 = xYPlot7.getOrientation();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(valueAxis51);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(plotOrientation55);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRange(range2);
        org.jfree.data.Range range4 = dateAxis1.getRange();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer6);
        xYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 0);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot7.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        boolean boolean15 = xYPlot7.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset16 = xYPlot7.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomDomainAxes(0.0d, plotRenderingInfo26, point2D27, true);
        int int30 = categoryPlot24.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color34 = java.awt.Color.GREEN;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 10, (java.awt.Paint) color34, stroke35);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryMarker36.setStroke(stroke37);
        boolean boolean39 = datasetRenderingOrder32.equals((java.lang.Object) categoryMarker36);
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis41.setTickMarkInsideLength((float) 5);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis44, categoryItemRenderer45);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis41.setLabelPaint((java.awt.Paint) color47);
        categoryMarker36.setLabelPaint((java.awt.Paint) color47);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot24.addRangeMarker((-4194304), (org.jfree.chart.plot.Marker) categoryMarker36, layer50);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType52 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        boolean boolean53 = layer50.equals((java.lang.Object) lengthAdjustmentType52);
        java.awt.Color color54 = java.awt.Color.ORANGE;
        boolean boolean55 = layer50.equals((java.lang.Object) color54);
        java.util.Collection collection56 = xYPlot7.getDomainMarkers((int) (short) -1, layer50);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNotNull(lengthAdjustmentType52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(collection56);
    }
}

