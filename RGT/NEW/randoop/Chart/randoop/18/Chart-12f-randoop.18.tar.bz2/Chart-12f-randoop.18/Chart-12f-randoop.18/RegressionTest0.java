import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 100.0f, (double) (short) 0, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = null;
        try {
            piePlot1.setLabelDistributor(abstractPieLabelDistributor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(10.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Color color1 = java.awt.Color.green;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        int int3 = color2.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(10.0d);
        double double4 = rectangleInsets0.calculateRightOutset((double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets0.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        java.awt.Stroke stroke5 = null;
        try {
            piePlot1.setLabelLinkStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getInteriorGap();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            piePlot1.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray2 = new float[] { (short) 1 };
        try {
            float[] floatArray3 = color0.getRGBComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot7.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint11 = piePlot7.getLabelPaint();
        boolean boolean12 = piePlot1.equals((java.lang.Object) piePlot7);
        piePlot7.setBackgroundAlpha((-1.0f));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        piePlot1.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setInteriorGap(0.0d);
        java.awt.Font font10 = null;
        try {
            piePlot2.setNoDataMessageFont(font10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        chartChangeEvent1.setType(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1L) + "'", obj2.equals((-1L)));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.TOP" + "'", str1.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        try {
            java.awt.image.BufferedImage bufferedImage11 = jFreeChart8.createBufferedImage((int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (32) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        java.awt.Paint paint10 = piePlot1.getLabelShadowPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "", "RectangleEdge.TOP", "hi!");
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = java.awt.Color.green;
        float[] floatArray9 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray10 = color2.getRGBColorComponents(floatArray9);
        try {
            float[] floatArray11 = color0.getComponents(colorSpace1, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.util.List list9 = null;
        try {
            jFreeChart8.setSubtitles(list9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        java.awt.RenderingHints renderingHints23 = null;
        try {
            jFreeChart7.setRenderingHints(renderingHints23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean16 = chartColor14.equals((java.lang.Object) 0);
        int int17 = chartColor14.getAlpha();
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) int17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 255 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(10.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L));
        java.lang.String str2 = chartChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=-1]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=-1]"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = null;
        try {
            jFreeChart7.titleChanged(titleChangeEvent10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Color color1 = java.awt.Color.getColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color2 = java.awt.Color.getColor("java.awt.Color[r=255,g=255,b=255]", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        java.lang.String str5 = projectInfo0.toString();
        projectInfo0.setLicenceName("hi!");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str5.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord22 = abstractPieLabelDistributor20.getPieLabelRecord((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        piePlot1.handleClick(100, 0, plotRenderingInfo10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            piePlot1.drawBackground(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.08d, (double) 100L, 100.0d, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        int int17 = piePlot1.getPieIndex();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.event.ChartChangeListener chartChangeListener10 = null;
        try {
            jFreeChart8.addChangeListener(chartChangeListener10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        try {
            piePlot1.setBackgroundImageAlpha((float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = null;
        try {
            piePlot1.setInsets(rectangleInsets11, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Rotation.ANTICLOCKWISE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = piePlot1.getShadowYOffset();
        try {
            piePlot1.setBackgroundImageAlpha((float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        try {
            org.jfree.chart.plot.XYPlot xYPlot24 = jFreeChart7.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        piePlot1.handleClick((int) (short) 10, (int) (short) 10, plotRenderingInfo8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset13 = null;
        java.lang.String str15 = standardPieSectionLabelGenerator12.generateSectionLabel(pieDataset13, (java.lang.Comparable) (-1));
        boolean boolean17 = standardPieSectionLabelGenerator12.equals((java.lang.Object) (short) 100);
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) boolean17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: false incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        java.lang.Comparable comparable8 = null;
        try {
            java.awt.Paint paint9 = piePlot1.getSectionOutlinePaint(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(10.0d);
        double double4 = rectangleInsets0.calculateLeftInset((double) (short) 100);
        double double6 = rectangleInsets0.extendHeight((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color1 = java.awt.Color.getColor("{0}");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        try {
            jFreeChart7.handleClick((int) 'a', 0, chartRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.lang.String str25 = horizontalAlignment24.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment26, 0.0d, (double) 'a');
        org.jfree.chart.block.BlockContainer blockContainer30 = null;
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = null;
        try {
            org.jfree.chart.util.Size2D size2D33 = columnArrangement29.arrange(blockContainer30, graphics2D31, rectangleConstraint32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "HorizontalAlignment.CENTER" + "'", str25.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment26);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D13, (double) 0.0f, (double) (byte) -1, rectangleAnchor16);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNull(rectangle2D17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        piePlot1.zoom((double) 0L);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double12 = rectangleInsets10.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        double double23 = legendTitle22.getContentYOffset();
        legendTitle22.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle22.getBounds();
        rectangleInsets10.trim(rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.plot.PiePlot piePlot31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState34 = piePlot1.initialise(graphics2D9, rectangle2D26, piePlot31, (java.lang.Integer) 15, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Image image17 = piePlot12.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot12);
        java.lang.Object obj19 = jFreeChart18.clone();
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart18.getLegend();
        legendTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart18);
        jFreeChart18.setBackgroundImageAlpha(0.0f);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot29.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color33);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = null;
        piePlot29.axisChanged(axisChangeEvent35);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot29);
        double double38 = legendTitle37.getContentYOffset();
        legendTitle37.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D41 = legendTitle37.getBounds();
        rectangleInsets25.trim(rectangle2D41);
        try {
            jFreeChart18.draw(graphics2D24, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        java.awt.Stroke stroke10 = jFreeChart8.getBorderStroke();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        java.awt.image.BufferedImage bufferedImage14 = jFreeChart8.createBufferedImage(15, 10, chartRenderingInfo13);
        org.jfree.chart.event.ChartChangeListener chartChangeListener15 = null;
        try {
            jFreeChart8.addChangeListener(chartChangeListener15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(bufferedImage14);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke8);
        org.jfree.chart.title.Title title11 = null;
        try {
            jFreeChart7.addSubtitle((int) 'a', title11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        piePlot6.axisChanged(axisChangeEvent12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean20 = chartColor18.equals((java.lang.Object) 0);
        piePlot6.setLabelPaint((java.awt.Paint) chartColor18);
        boolean boolean22 = projectInfo0.equals((java.lang.Object) chartColor18);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        multiplePiePlot0.setDataset(categoryDataset4);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.util.List list13 = null;
        try {
            jFreeChart8.setSubtitles(list13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        double double10 = rectangleInsets5.getRight();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) -1, (float) ' ', (float) 1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        legendTitle9.setWidth((double) 0L);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        piePlot19.axisChanged(axisChangeEvent25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        double double28 = legendTitle27.getContentYOffset();
        legendTitle27.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle27.getBounds();
        try {
            legendTitle9.draw(graphics2D17, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.fireChartChanged();
        java.awt.Paint paint12 = null;
        jFreeChart9.setBackgroundPaint(paint12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart9);
        jFreeChart9.setTextAntiAlias(true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ChartChangeEventType.DATASET_UPDATED", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        boolean boolean6 = standardPieSectionLabelGenerator1.equals((java.lang.Object) (short) 100);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        java.lang.String str9 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset7, (java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "{0}");
        java.lang.String str23 = chartEntity22.getShapeCoords();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0,0,1,1" + "'", str23.equals("0,0,1,1"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Font font7 = piePlot4.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets8.calculateLeftOutset(10.0d);
        piePlot4.setSimpleLabelOffset(rectangleInsets8);
        org.jfree.chart.util.Rotation rotation12 = org.jfree.chart.util.Rotation.CLOCKWISE;
        piePlot4.setDirection(rotation12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Font font18 = piePlot15.getLabelFont();
        piePlot4.setLabelFont(font18);
        try {
            objectList1.set(0, (java.lang.Object) piePlot4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rotation12);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 100, 0.14d, (double) 10L, (double) 0.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        java.awt.Stroke stroke7 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (byte) 10);
        java.awt.Font font8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot1.setLabelFont(font8);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("NOID", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color2 = java.awt.Color.getColor("0,0,1,1", (int) (short) -1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Pie Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.awt.Font font10 = textTitle9.getFont();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = piePlot12.getLabelLinkStyle();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean15 = pieLabelLinkStyle13.equals((java.lang.Object) paint14);
        textTitle9.setBackgroundPaint(paint14);
        java.lang.String str17 = textTitle9.getText();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "NOID" + "'", str17.equals("NOID"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor8);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double6 = rectangleInsets4.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color12 = java.awt.Color.green;
        piePlot8.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        piePlot8.axisChanged(axisChangeEvent14);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot8);
        double double17 = legendTitle16.getContentYOffset();
        legendTitle16.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle16.getBounds();
        rectangleInsets4.trim(rectangle2D20);
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D20, "{0}");
        java.awt.geom.Point2D point2D27 = null;
        org.jfree.chart.plot.PlotState plotState28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            multiplePiePlot0.draw(graphics2D3, rectangle2D20, point2D27, plotState28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color10);
        jFreeChart7.setTextAntiAlias(true);
        try {
            org.jfree.chart.title.Title title15 = jFreeChart7.getSubtitle((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot1.getLabelDistributor();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord22 = abstractPieLabelDistributor20.getPieLabelRecord((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int3 = java.awt.Color.HSBtoRGB((float) 3, (float) 255, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.awt.Paint paint9 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        double double2 = textTitle1.getHeight();
        textTitle1.setText("");
        java.lang.String str5 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int3 = java.awt.Color.HSBtoRGB(1.0f, (float) 0, (float) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        boolean boolean6 = standardPieSectionLabelGenerator1.equals((java.lang.Object) (short) 100);
        java.text.AttributedString attributedString8 = standardPieSectionLabelGenerator1.getAttributedLabel(100);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(attributedString8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        java.lang.String str21 = chartEntity20.getURLText();
        java.lang.String str22 = chartEntity20.getShapeType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "rect" + "'", str22.equals("rect"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        double double2 = textTitle1.getHeight();
        textTitle1.setText("");
        textTitle1.setToolTipText("RectangleEdge.LEFT");
        java.awt.Color color7 = java.awt.Color.GREEN;
        textTitle1.setPaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color3 = java.awt.Color.green;
        float[] floatArray10 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray11 = color3.getRGBColorComponents(floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (byte) 100, (int) (byte) 10, floatArray11);
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (byte) 100, dataset13);
        org.jfree.data.general.Dataset dataset15 = datasetChangeEvent14.getDataset();
        java.lang.String str16 = datasetChangeEvent14.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNull(dataset15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=100]" + "'", str16.equals("org.jfree.data.general.DatasetChangeEvent[source=100]"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot1.markerChanged(markerChangeEvent8);
        float float10 = piePlot1.getBackgroundAlpha();
        float float11 = piePlot1.getBackgroundImageAlpha();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int13 = color12.getGreen();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue((java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            lineBorder0.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color11 = java.awt.Color.green;
        piePlot7.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color11);
        boolean boolean13 = piePlot1.equals((java.lang.Object) 1);
        piePlot1.setOutlineVisible(true);
        boolean boolean16 = piePlot1.isCircular();
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (int) '4');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Number number4 = defaultKeyedValues2D1.getValue((int) '#', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle14 = jFreeChart8.getTitle();
        float float15 = jFreeChart8.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double19 = rectangleInsets17.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        piePlot21.addChangeListener(plotChangeListener22);
        java.awt.Color color25 = java.awt.Color.green;
        piePlot21.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color25);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        piePlot21.axisChanged(axisChangeEvent27);
        org.jfree.chart.title.LegendTitle legendTitle29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot21);
        double double30 = legendTitle29.getContentYOffset();
        legendTitle29.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D33 = legendTitle29.getBounds();
        rectangleInsets17.trim(rectangle2D33);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        try {
            jFreeChart8.draw(graphics2D16, rectangle2D33, chartRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(textTitle14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "{0}");
        java.lang.String str23 = chartEntity22.getShapeType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "rect" + "'", str23.equals("rect"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str2 = projectInfo1.getCopyright();
        java.awt.Image image3 = null;
        projectInfo1.setLogo(image3);
        boolean boolean5 = datasetGroup0.equals((java.lang.Object) image3);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.NumberFormat numberFormat2 = standardPieSectionLabelGenerator1.getPercentFormat();
        java.lang.Object obj3 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        piePlot1.setOutlineVisible(true);
        piePlot1.setIgnoreZeroValues(true);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        int int7 = piePlot1.getPieIndex();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = null;
        try {
            piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        double double7 = piePlot1.getInteriorGap();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        piePlot1.setDataset(pieDataset8);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        piePlot1.handleClick((int) (short) 10, (-254), plotRenderingInfo5);
        org.junit.Assert.assertNotNull(drawingSupplier2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            piePlot1.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        float float22 = jFreeChart19.getBackgroundImageAlpha();
        boolean boolean23 = jFreeChart19.isBorderVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color10);
        java.lang.Object obj12 = jFreeChart7.clone();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleEdge.LEFT", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "java.awt.Color[r=255,g=255,b=255]");
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("0,0,1,1", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        java.lang.String str5 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color10);
        jFreeChart7.setTextAntiAlias(true);
        boolean boolean14 = jFreeChart7.isBorderVisible();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        org.jfree.data.general.DatasetGroup datasetGroup10 = piePlot1.getDatasetGroup();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNull(datasetGroup10);
        org.junit.Assert.assertNull(pieURLGenerator11);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Image image11 = piePlot6.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot6);
        java.lang.Object obj13 = jFreeChart12.clone();
        jFreeChart12.fireChartChanged();
        java.awt.Paint paint15 = null;
        jFreeChart12.setBackgroundPaint(paint15);
        java.awt.Paint paint17 = jFreeChart12.getBackgroundPaint();
        java.lang.Object obj18 = null;
        boolean boolean19 = jFreeChart12.equals(obj18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart12.createBufferedImage(15, (int) (byte) 10, 3, chartRenderingInfo23);
        multiplePiePlot0.setPieChart(jFreeChart12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double31 = rectangleInsets29.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        piePlot33.addChangeListener(plotChangeListener34);
        java.awt.Color color37 = java.awt.Color.green;
        piePlot33.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color37);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent39 = null;
        piePlot33.axisChanged(axisChangeEvent39);
        org.jfree.chart.title.LegendTitle legendTitle41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot33);
        double double42 = legendTitle41.getContentYOffset();
        legendTitle41.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D45 = legendTitle41.getBounds();
        rectangleInsets29.trim(rectangle2D45);
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D45);
        java.awt.geom.Point2D point2D48 = null;
        org.jfree.chart.plot.PlotState plotState49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        try {
            multiplePiePlot0.draw(graphics2D28, rectangle2D45, point2D48, plotState49, plotRenderingInfo50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot15.getLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator23);
        java.lang.String str25 = piePlot1.getPlotType();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Pie Plot" + "'", str25.equals("Pie Plot"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        int int10 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = null;
        try {
            jFreeChart16.setPadding(rectangleInsets18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        java.awt.Font font9 = piePlot1.getLabelFont();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getRowKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean28 = chartColor26.equals((java.lang.Object) 0);
        piePlot14.setLabelPaint((java.awt.Paint) chartColor26);
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) chartColor26);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double36 = rectangleInsets34.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot(pieDataset37);
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        piePlot38.addChangeListener(plotChangeListener39);
        java.awt.Color color42 = java.awt.Color.green;
        piePlot38.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color42);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = null;
        piePlot38.axisChanged(axisChangeEvent44);
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot38);
        double double47 = legendTitle46.getContentYOffset();
        legendTitle46.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D50 = legendTitle46.getBounds();
        rectangleInsets34.trim(rectangle2D50);
        org.jfree.chart.entity.ChartEntity chartEntity54 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D50, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity57 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D50, "", "Other");
        lineBorder32.draw(graphics2D33, rectangle2D50);
        try {
            piePlot1.drawOutline(graphics2D31, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.block.BlockFrame blockFrame1 = null;
        try {
            textTitle0.setFrame(blockFrame1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("TableOrder.BY_ROW");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key TableOrder.BY_ROW");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot11.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot11.axisChanged(axisChangeEvent17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle19.getVerticalAlignment();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = null;
        org.jfree.chart.util.Size2D size2D23 = legendTitle19.arrange(graphics2D21, rectangleConstraint22);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle19);
        flowArrangement0.add(block1, (java.lang.Object) legendTitle19);
        flowArrangement0.clear();
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D23);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(10.0d);
        double double3 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D1.getRowKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        boolean boolean8 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke16 = null;
        piePlot10.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot10.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateLeftOutset(10.0d);
        double double25 = rectangleInsets21.calculateLeftInset((double) (short) 100);
        piePlot10.setInsets(rectangleInsets21, false);
        piePlot1.setInsets(rectangleInsets21, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets30.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        piePlot34.addChangeListener(plotChangeListener35);
        java.awt.Color color38 = java.awt.Color.green;
        piePlot34.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color38);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent40 = null;
        piePlot34.axisChanged(axisChangeEvent40);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot34);
        double double43 = legendTitle42.getContentYOffset();
        legendTitle42.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D46 = legendTitle42.getBounds();
        rectangleInsets30.trim(rectangle2D46);
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "{0}");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets21.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType53, lengthAdjustmentType54);
        double double56 = rectangleInsets21.getBottom();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets21.createOutsetRectangle(rectangle2D57, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getCopyright();
        java.awt.Image image4 = null;
        projectInfo2.setLogo(image4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo2.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) licences0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues2D1.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getRowKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = piePlot1.getLabelLinkStyle();
        piePlot1.setStartAngle((double) 0L);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Image image17 = piePlot12.getBackgroundImage();
        java.lang.Object obj18 = piePlot12.clone();
        boolean boolean19 = piePlot12.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        piePlot21.addChangeListener(plotChangeListener22);
        java.awt.Color color24 = java.awt.Color.green;
        piePlot21.setBackgroundPaint((java.awt.Paint) color24);
        java.awt.Stroke stroke27 = null;
        piePlot21.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke27);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator29 = piePlot21.getLegendLabelGenerator();
        piePlot21.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double34 = rectangleInsets32.calculateLeftOutset(10.0d);
        double double36 = rectangleInsets32.calculateLeftInset((double) (short) 100);
        piePlot21.setInsets(rectangleInsets32, false);
        piePlot12.setInsets(rectangleInsets32, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double43 = rectangleInsets41.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        piePlot45.addChangeListener(plotChangeListener46);
        java.awt.Color color49 = java.awt.Color.green;
        piePlot45.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color49);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = null;
        piePlot45.axisChanged(axisChangeEvent51);
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot45);
        double double54 = legendTitle53.getContentYOffset();
        legendTitle53.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D57 = legendTitle53.getBounds();
        rectangleInsets41.trim(rectangle2D57);
        org.jfree.chart.entity.ChartEntity chartEntity61 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D57, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity63 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D57, "{0}");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets32.createAdjustedRectangle(rectangle2D57, lengthAdjustmentType64, lengthAdjustmentType65);
        piePlot1.setLegendItemShape((java.awt.Shape) rectangle2D66);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D66);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getInteriorGap();
        piePlot1.setIgnoreZeroValues(false);
        java.awt.Paint paint9 = piePlot1.getNoDataMessagePaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Font font14 = piePlot11.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets15.calculateLeftOutset(10.0d);
        piePlot11.setSimpleLabelOffset(rectangleInsets15);
        double double20 = rectangleInsets15.extendHeight(0.0d);
        piePlot1.setLabelPadding(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getInteriorGap();
        java.awt.Paint paint7 = piePlot1.getLabelLinkPaint();
        java.awt.Paint paint8 = piePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        pieSectionEntity20.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library library28 = new org.jfree.chart.ui.Library("", "Other", "java.awt.Color[r=255,g=255,b=255]", "RectangleEdge.TOP");
        java.lang.String str29 = library28.getName();
        boolean boolean30 = pieSectionEntity20.equals((java.lang.Object) str29);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator31 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator32 = null;
        try {
            java.lang.String str33 = pieSectionEntity20.getImageMapAreaTag(toolTipTagFragmentGenerator31, uRLTagFragmentGenerator32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 100L, (double) 1.0f, (double) 0.5f);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot10);
        double double19 = legendTitle18.getContentYOffset();
        legendTitle18.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle18.getBounds();
        rectangleInsets6.trim(rectangle2D22);
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D22, "{0}");
        try {
            blockBorder4.draw(graphics2D5, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle1.getMargin();
        double double17 = rectangleInsets15.calculateBottomOutset((double) 10L);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord8 = null;
        try {
            abstractPieLabelDistributor7.addPieLabelRecord(pieLabelRecord8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle1.getMargin();
        java.lang.String str16 = textTitle1.getToolTipText();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary("Other");
        java.lang.String str3 = projectInfo0.getInfo();
        projectInfo0.setInfo("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot1.markerChanged(markerChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot1.getLegendItems();
        piePlot1.setStartAngle((double) 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("{0}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key {0}");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 0, (float) (-1), 10.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke8);
        java.awt.RenderingHints renderingHints10 = jFreeChart7.getRenderingHints();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot12.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        piePlot12.axisChanged(axisChangeEvent18);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot12);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color26 = java.awt.Color.green;
        piePlot23.setBackgroundPaint((java.awt.Paint) color26);
        java.awt.Image image28 = piePlot23.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot23);
        java.lang.Object obj30 = jFreeChart29.clone();
        org.jfree.chart.title.LegendTitle legendTitle31 = jFreeChart29.getLegend();
        legendTitle20.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart29);
        jFreeChart29.setBackgroundImageAlpha(0.0f);
        try {
            jFreeChart7.setTextAntiAlias((java.lang.Object) jFreeChart29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.JFreeChart@7e1c1b54 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(renderingHints10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(legendTitle31);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        legendTitle9.setWidth((double) 0L);
        java.awt.Font font17 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateLeftOutset(10.0d);
        double double22 = rectangleInsets18.calculateRightOutset((double) (short) 10);
        legendTitle9.setLegendItemGraphicPadding(rectangleInsets18);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Rotation.ANTICLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Rotation.ANTICLOCKWISE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = piePlot1.getLabelLinkStyle();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean4 = pieLabelLinkStyle2.equals((java.lang.Object) paint3);
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean9 = pieLabelLinkStyle2.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset1.getRowKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Image image17 = piePlot12.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot12);
        java.lang.Object obj19 = jFreeChart18.clone();
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart18.getLegend();
        legendTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart18);
        int int22 = jFreeChart18.getBackgroundImageAlignment();
        jFreeChart18.setNotify(false);
        boolean boolean25 = jFreeChart18.isNotify();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = piePlot1.getShadowYOffset();
        java.awt.Color color11 = java.awt.Color.red;
        piePlot1.setLabelPaint((java.awt.Paint) color11);
        piePlot1.setLabelGap((double) 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart10.createBufferedImage(10, 0, 10, chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (10) and height (0) must be > 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        double double10 = rectangleInsets5.extendHeight(0.0d);
        double double12 = rectangleInsets5.calculateTopInset((double) 10);
        double double14 = rectangleInsets5.calculateBottomInset((double) 255);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Font font14 = piePlot11.getLabelFont();
        piePlot4.setNoDataMessageFont(font14);
        boolean boolean16 = rotation0.equals((java.lang.Object) piePlot4);
        piePlot4.setSectionOutlinesVisible(true);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleEdge.TOP\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        float[] floatArray3 = null;
        float[] floatArray4 = color1.getColorComponents(floatArray3);
        boolean boolean5 = blockBorder0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeRow((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset1.getRowKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot3.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3.axisChanged(axisChangeEvent9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3);
        double double12 = legendTitle11.getContentYOffset();
        legendTitle11.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D15 = legendTitle11.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str17 = rectangleEdge16.toString();
        double double18 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D15, rectangleEdge16);
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D15);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) blockContainer1, (java.lang.Object) chartEntity19);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.entity.ChartEntity cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleEdge.LEFT" + "'", str17.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Image image17 = piePlot12.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot12);
        java.lang.Object obj19 = jFreeChart18.clone();
        org.jfree.chart.title.LegendTitle legendTitle20 = jFreeChart18.getLegend();
        legendTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart18);
        int int22 = jFreeChart18.getBackgroundImageAlignment();
        jFreeChart18.setNotify(false);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent25 = null;
        try {
            jFreeChart18.titleChanged(titleChangeEvent25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(legendTitle20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        double double4 = rectangleInsets0.calculateTopOutset(0.0d);
        double double6 = rectangleInsets0.calculateBottomInset((double) (byte) -1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (byte) -1, (java.lang.Comparable) "RectangleEdge.TOP");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: RectangleEdge.TOP");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke8);
        java.awt.RenderingHints renderingHints10 = jFreeChart7.getRenderingHints();
        org.jfree.chart.title.Title title12 = null;
        try {
            jFreeChart7.addSubtitle(0, title12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(renderingHints10);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        double double10 = rectangleInsets5.extendHeight(0.0d);
        double double12 = rectangleInsets5.calculateTopInset((double) 10);
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets5.getUnitType();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot13.notifyListeners(plotChangeEvent16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color24 = java.awt.Color.green;
        piePlot20.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = null;
        piePlot20.axisChanged(axisChangeEvent26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot20);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = legendTitle28.getVerticalAlignment();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = null;
        org.jfree.chart.util.Size2D size2D32 = legendTitle28.arrange(graphics2D30, rectangleConstraint31);
        jFreeChart18.addSubtitle((org.jfree.chart.title.Title) legendTitle28);
        org.jfree.chart.title.TextTitle textTitle34 = jFreeChart18.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle34.getTextAlignment();
        textTitle34.setPadding((double) (short) 0, (double) 1L, (double) (short) 1, (double) (short) 100);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) textTitle34);
        java.util.List list42 = null;
        try {
            jFreeChart8.setSubtitles(list42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(textTitle34);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        piePlot23.notifyListeners(plotChangeEvent26);
        try {
            jFreeChart19.setTextAntiAlias((java.lang.Object) piePlot23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.PiePlot@71885e35 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle9.setVerticalAlignment(verticalAlignment15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle9.setLegendItemGraphicLocation(rectangleAnchor17);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("org.jfree.chart.event.ChartChangeEvent[source=-1]");
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color10);
        boolean boolean12 = jFreeChart7.isNotify();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        boolean boolean14 = jFreeChart8.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color20 = java.awt.Color.green;
        piePlot16.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color20);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        piePlot16.axisChanged(axisChangeEvent22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        double double25 = legendTitle24.getContentYOffset();
        legendTitle24.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D28 = legendTitle24.getBounds();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity35 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D28, pieDataset29, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        pieSectionEntity35.setPieIndex((int) ' ');
        java.lang.String str38 = pieSectionEntity35.toString();
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) pieSectionEntity35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: PieSection: 32, -1( ) incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "PieSection: 32, -1( )" + "'", str38.equals("PieSection: 32, -1( )"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color17 = java.awt.Color.green;
        piePlot13.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        piePlot13.axisChanged(axisChangeEvent19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot13);
        double double22 = legendTitle21.getContentYOffset();
        legendTitle21.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D25 = legendTitle21.getBounds();
        rectangleInsets9.trim(rectangle2D25);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D25);
        try {
            piePlot1.drawBackground(graphics2D8, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getCopyright();
        java.awt.Image image7 = null;
        projectInfo5.setLogo(image7);
        projectInfo3.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        try {
            objectList1.set((int) (byte) 0, (java.lang.Object) projectInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        java.awt.Color color18 = java.awt.Color.lightGray;
        piePlot1.setOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint21 = piePlot1.getLabelBackgroundPaint();
        java.lang.String str22 = piePlot1.getNoDataMessage();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator23 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(pieURLGenerator23);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) legendTitle9, dataset16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = legendTitle9.getPosition();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = null;
        try {
            legendTitle9.setLegendItemGraphicPadding(rectangleInsets15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        java.awt.Paint paint20 = piePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle9.getItemContainer();
        java.awt.Font font15 = null;
        try {
            legendTitle9.setItemFont(font15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("{0}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key {0}");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: -1.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.util.List list2 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
        org.junit.Assert.assertNull(list2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint7 = piePlot1.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        boolean boolean8 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke16 = null;
        piePlot10.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot10.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateLeftOutset(10.0d);
        double double25 = rectangleInsets21.calculateLeftInset((double) (short) 100);
        piePlot10.setInsets(rectangleInsets21, false);
        piePlot1.setInsets(rectangleInsets21, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets30.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        piePlot34.addChangeListener(plotChangeListener35);
        java.awt.Color color38 = java.awt.Color.green;
        piePlot34.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color38);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent40 = null;
        piePlot34.axisChanged(axisChangeEvent40);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot34);
        double double43 = legendTitle42.getContentYOffset();
        legendTitle42.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D46 = legendTitle42.getBounds();
        rectangleInsets30.trim(rectangle2D46);
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "{0}");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets21.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType53, lengthAdjustmentType54);
        double double57 = rectangleInsets21.extendWidth((double) (byte) 0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        legendTitle9.setLegendItemGraphicPadding(rectangleInsets11);
        org.jfree.chart.block.BlockFrame blockFrame13 = legendTitle9.getFrame();
        double double14 = legendTitle9.getHeight();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        try {
            objectList1.set((int) (byte) 10, (java.lang.Object) stroke3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Font font6 = piePlot1.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = java.awt.Color.green;
        piePlot8.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = null;
        piePlot8.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke14);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot8.getLegendLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator16);
        piePlot1.setMaximumLabelWidth((double) 15);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        int int3 = defaultCategoryDataset1.getRowCount();
        defaultCategoryDataset1.validateObject();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = blockContainer0.arrange(graphics2D1, rectangleConstraint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot1.markerChanged(markerChangeEvent8);
        float float10 = piePlot1.getBackgroundAlpha();
        double double11 = piePlot1.getInteriorGap();
        piePlot1.setInteriorGap(0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.calculateLeftOutset(10.0d);
        piePlot2.setSimpleLabelOffset(rectangleInsets6);
        boolean boolean10 = flowArrangement0.equals((java.lang.Object) rectangleInsets6);
        double double12 = rectangleInsets6.calculateTopInset(0.08d);
        double double13 = rectangleInsets6.getBottom();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        double double6 = rectangleInsets5.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke11 = null;
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke11);
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot5);
        try {
            defaultKeyedValues2D1.removeRow(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Rotation.ANTICLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Rotation.ANTICLOCKWISE, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        try {
            java.lang.Number number6 = defaultKeyedValues2D1.getValue(10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Font font6 = piePlot1.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = java.awt.Color.green;
        piePlot8.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = null;
        piePlot8.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke14);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot8.getLegendLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator16);
        piePlot1.setCircular(false);
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        piePlot22.addChangeListener(plotChangeListener23);
        java.awt.Color color26 = java.awt.Color.green;
        piePlot22.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot22);
        java.awt.Paint paint29 = piePlot22.getLabelBackgroundPaint();
        piePlot1.setNoDataMessagePaint(paint29);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        boolean boolean12 = jFreeChart10.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        java.awt.Font font20 = piePlot14.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent21.setType(chartChangeEventType22);
        org.jfree.chart.plot.Plot plot24 = plotChangeEvent21.getPlot();
        org.jfree.chart.plot.Plot plot25 = plotChangeEvent21.getPlot();
        jFreeChart10.plotChanged(plotChangeEvent21);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertNotNull(plot24);
        org.junit.Assert.assertNotNull(plot25);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getCopyright();
        java.awt.Image image4 = null;
        projectInfo2.setLogo(image4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        org.jfree.chart.ui.Library library7 = null;
        try {
            projectInfo0.addOptionalLibrary(library7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        try {
            java.lang.Number number4 = defaultCategoryDataset0.getValue((int) (byte) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color11 = java.awt.Color.green;
        piePlot7.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        piePlot7.axisChanged(axisChangeEvent13);
        org.jfree.chart.title.LegendTitle legendTitle15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot7);
        double double16 = legendTitle15.getContentYOffset();
        legendTitle15.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D19 = legendTitle15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str21 = rectangleEdge20.toString();
        double double22 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D19, rectangleEdge20);
        try {
            blockBorder4.draw(graphics2D5, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleEdge.LEFT" + "'", str21.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke11 = null;
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke11);
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot5);
        org.jfree.chart.util.Rotation rotation14 = piePlot5.getDirection();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rotation14);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart19.addProgressListener(chartProgressListener22);
        jFreeChart19.setNotify(false);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart19.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        boolean boolean23 = pieSectionEntity20.equals((java.lang.Object) (byte) 1);
        int int24 = pieSectionEntity20.getPieIndex();
        int int25 = pieSectionEntity20.getSectionIndex();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets7.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot11.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot11.axisChanged(axisChangeEvent17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11);
        double double20 = legendTitle19.getContentYOffset();
        legendTitle19.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D23 = legendTitle19.getBounds();
        rectangleInsets7.trim(rectangle2D23);
        org.jfree.chart.util.UnitType unitType25 = rectangleInsets7.getUnitType();
        double double27 = rectangleInsets7.calculateBottomOutset((double) 255);
        piePlot1.setSimpleLabelOffset(rectangleInsets7);
        java.awt.Paint paint29 = piePlot1.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(unitType25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        defaultCategoryDataset2.addValue(0.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 3);
        defaultCategoryDataset2.validateObject();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        defaultKeyedValues2D1.clear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = null;
        piePlot23.setLegendLabelURLGenerator(pieURLGenerator24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.PiePlotState piePlotState28 = piePlot1.initialise(graphics2D20, rectangle2D21, piePlot23, (java.lang.Integer) 100, plotRenderingInfo27);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator29 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(piePlotState28);
        org.junit.Assert.assertNull(pieURLGenerator29);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        piePlot13.setLabelLinksVisible(false);
        java.awt.Stroke stroke18 = piePlot13.getOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) '#', (double) (-1.0f), (double) 1.0f, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color13);
        piePlot1.setCircular(false, false);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.incrementValue((double) 0, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 0.08d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0.08");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        piePlot1.setNoDataMessage("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Number number3 = defaultCategoryDataset0.getValue((java.lang.Comparable) 8, (java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 100.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot5.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color9);
        java.awt.Font font11 = piePlot5.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot5.getLabelPadding();
        piePlot1.setInsets(rectangleInsets12, true);
        java.lang.Object obj15 = null;
        boolean boolean16 = piePlot1.equals(obj15);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            java.awt.Color color1 = java.awt.Color.decode("PieLabelLinkStyle.STANDARD");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"PieLabelLinkStyle.STANDARD\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.RenderingHints renderingHints11 = jFreeChart10.getRenderingHints();
        jFreeChart10.fireChartChanged();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(renderingHints11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot1.getLabelDistributor();
        java.awt.Color color21 = java.awt.Color.PINK;
        java.awt.Color color22 = color21.darker();
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        float float8 = piePlot1.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets16.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color24 = java.awt.Color.green;
        piePlot20.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = null;
        piePlot20.axisChanged(axisChangeEvent26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot20);
        double double29 = legendTitle28.getContentYOffset();
        legendTitle28.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle28.getBounds();
        rectangleInsets16.trim(rectangle2D32);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D32, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D32, "", "Other");
        lineBorder14.draw(graphics2D15, rectangle2D32);
        java.awt.geom.Point2D point2D41 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        try {
            jFreeChart10.draw(graphics2D13, rectangle2D32, point2D41, chartRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.lang.Class<?> wildcardClass10 = legendItemCollection9.getClass();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        jFreeChart10.setAntiAlias(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot7.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint11 = piePlot7.getLabelPaint();
        boolean boolean12 = piePlot1.equals((java.lang.Object) piePlot7);
        double double13 = piePlot7.getMinimumArcAngleToDraw();
        org.jfree.chart.util.Rotation rotation14 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str15 = rotation14.toString();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        piePlot18.addChangeListener(plotChangeListener19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        piePlot18.notifyListeners(plotChangeEvent21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot18);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        piePlot25.addChangeListener(plotChangeListener26);
        java.awt.Font font28 = piePlot25.getLabelFont();
        piePlot18.setNoDataMessageFont(font28);
        boolean boolean30 = rotation14.equals((java.lang.Object) piePlot18);
        piePlot7.setDirection(rotation14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-5d + "'", double13 == 1.0E-5d);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str15.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot15.getLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator23);
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = java.awt.Color.getColor("hi!", color26);
        piePlot1.setLabelPaint((java.awt.Paint) color27);
        piePlot1.setBackgroundAlpha(0.5f);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) legendTitle9, dataset16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = legendTitle9.getHorizontalAlignment();
        java.awt.Font font19 = legendTitle9.getItemFont();
        java.lang.Class<?> wildcardClass20 = font19.getClass();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("Rotation.ANTICLOCKWISE", "");
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        jFreeChart19.fireChartChanged();
        java.awt.Paint paint22 = null;
        jFreeChart19.setBackgroundPaint(paint22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart19);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        java.lang.Object obj26 = jFreeChart19.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        double double11 = rectangleInsets5.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        java.awt.Stroke stroke10 = jFreeChart8.getBorderStroke();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color17 = java.awt.Color.green;
        piePlot13.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        piePlot13.axisChanged(axisChangeEvent19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot13);
        double double22 = legendTitle21.getContentYOffset();
        legendTitle21.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D25 = legendTitle21.getBounds();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity32 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D25, pieDataset26, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.awt.geom.Point2D point2D33 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        try {
            jFreeChart8.draw(graphics2D11, rectangle2D25, point2D33, chartRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.RenderingHints renderingHints9 = jFreeChart8.getRenderingHints();
        java.awt.Color color10 = java.awt.Color.magenta;
        jFreeChart8.setBorderPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Image image17 = piePlot12.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot12);
        java.awt.RenderingHints renderingHints19 = jFreeChart18.getRenderingHints();
        boolean boolean20 = rectangleInsets5.equals((java.lang.Object) renderingHints19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        piePlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color29 = java.awt.Color.green;
        piePlot25.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color29);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = null;
        piePlot25.axisChanged(axisChangeEvent31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot25);
        double double34 = legendTitle33.getContentYOffset();
        legendTitle33.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle33.getBounds();
        rectangleInsets21.trim(rectangle2D37);
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D37, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets5.createOutsetRectangle(rectangle2D37, true, false);
        double double46 = rectangleInsets5.trimWidth((double) 8);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(renderingHints19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 8.0d + "'", double46 == 8.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("rect", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart11.createBufferedImage((int) (byte) 1, 1, (int) '#', chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Color color0 = java.awt.Color.white;
        java.lang.String str1 = color0.toString();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        java.awt.Color color7 = java.awt.Color.green;
        float[] floatArray14 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray15 = color7.getRGBColorComponents(floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB((int) '#', (int) '4', 1, floatArray14);
        float[] floatArray17 = color0.getColorComponents(colorSpace3, floatArray14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=255,g=255,b=255]"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "hi!", "hi!", image3, "", "", "hi!");
        projectInfo7.setInfo("PieLabelLinkStyle.STANDARD");
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        legendTitle9.setLegendItemGraphicPadding(rectangleInsets11);
        double double13 = legendTitle9.getWidth();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        piePlot1.setLabelGap((double) (byte) 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.fireChartChanged();
        java.awt.Paint paint12 = null;
        jFreeChart9.setBackgroundPaint(paint12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str16 = chartChangeEventType15.toString();
        chartChangeEvent14.setType(chartChangeEventType15);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str16.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("RectangleEdge.TOP");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        double double8 = piePlot1.getStartAngle();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 90.0d + "'", double8 == 90.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        try {
            java.lang.Number number5 = defaultCategoryDataset1.getValue(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "PieSection: 32, -1( )");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Image image11 = piePlot6.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot6);
        java.lang.Object obj13 = jFreeChart12.clone();
        jFreeChart12.fireChartChanged();
        java.awt.Paint paint15 = null;
        jFreeChart12.setBackgroundPaint(paint15);
        java.awt.Paint paint17 = jFreeChart12.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle18 = jFreeChart12.getTitle();
        float float19 = jFreeChart12.getBackgroundImageAlpha();
        boolean boolean20 = piePlot1.equals((java.lang.Object) jFreeChart12);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(textTitle18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        java.awt.Image image17 = piePlot1.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord19 = null;
        try {
            abstractPieLabelDistributor18.addPieLabelRecord(pieLabelRecord19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke9);
        jFreeChart7.removeLegend();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot0.getLabelGenerator();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent10 = null;
        try {
            jFreeChart8.titleChanged(titleChangeEvent10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        defaultCategoryDataset2.clear();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Color color3 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        java.awt.Font font12 = piePlot6.getLabelFont();
        piePlot2.setNoDataMessageFont(font12);
        boolean boolean14 = tableOrder0.equals((java.lang.Object) font12);
        boolean boolean16 = tableOrder0.equals((java.lang.Object) 0.5f);
        java.lang.String str17 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TableOrder.BY_COLUMN" + "'", str17.equals("TableOrder.BY_COLUMN"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L));
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent1.setType(chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent1.toString();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        piePlot7.notifyListeners(plotChangeEvent10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot7);
        boolean boolean14 = jFreeChart12.equals((java.lang.Object) '4');
        java.awt.Color color15 = java.awt.Color.DARK_GRAY;
        jFreeChart12.setBackgroundPaint((java.awt.Paint) color15);
        jFreeChart12.setTextAntiAlias(true);
        boolean boolean19 = jFreeChart12.isNotify();
        org.jfree.chart.title.Title title21 = jFreeChart12.getSubtitle(0);
        chartChangeEvent1.setChart(jFreeChart12);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=-1]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(title21);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.awt.Font font25 = textTitle23.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle23.getTextAlignment();
        textTitle23.setNotify(false);
        boolean boolean29 = textTitle23.getNotify();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.lang.Comparable comparable21 = pieSectionEntity20.getSectionKey();
        java.lang.String str22 = pieSectionEntity20.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + ' ' + "'", comparable21.equals(' '));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "PieSection: 1, -1( )" + "'", str22.equals("PieSection: 1, -1( )"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        piePlot1.setBackgroundAlpha((float) '4');
        piePlot1.setNoDataMessage("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = piePlot15.getLabelLinkStyle();
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean18 = pieLabelLinkStyle16.equals((java.lang.Object) paint17);
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle16);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo20 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo20.setName("0,0,1,1");
        boolean boolean23 = pieLabelLinkStyle16.equals((java.lang.Object) basicProjectInfo20);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getColumnKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.lang.String str25 = horizontalAlignment24.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment26, 0.0d, (double) 'a');
        java.lang.Object obj30 = null;
        boolean boolean31 = columnArrangement29.equals(obj30);
        columnArrangement29.clear();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "HorizontalAlignment.CENTER" + "'", str25.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.lang.String str11 = verticalAlignment10.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "VerticalAlignment.CENTER" + "'", str11.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot1.markerChanged(markerChangeEvent8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot15);
        double double24 = legendTitle23.getContentYOffset();
        legendTitle23.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D27 = legendTitle23.getBounds();
        rectangleInsets11.trim(rectangle2D27);
        org.jfree.chart.entity.ChartEntity chartEntity31 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27, "{0}");
        piePlot1.drawBackgroundImage(graphics2D10, rectangle2D27);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("NOID", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getName();
        java.lang.String str5 = contributor2.getName();
        java.lang.String str6 = contributor2.getEmail();
        java.lang.String str7 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NOID" + "'", str3.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "NOID" + "'", str4.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NOID" + "'", str5.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        org.jfree.data.general.DatasetGroup datasetGroup10 = piePlot1.getDatasetGroup();
        piePlot1.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNull(datasetGroup10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        piePlot10.notifyListeners(plotChangeEvent13);
        org.jfree.data.general.DatasetGroup datasetGroup15 = piePlot10.getDatasetGroup();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator16 = piePlot10.getLegendLabelURLGenerator();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        piePlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color22 = java.awt.Color.green;
        piePlot18.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color22);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        piePlot18.axisChanged(axisChangeEvent24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot18);
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean32 = chartColor30.equals((java.lang.Object) 0);
        piePlot18.setLabelPaint((java.awt.Paint) chartColor30);
        piePlot10.setLabelLinkPaint((java.awt.Paint) chartColor30);
        piePlot1.setBaseSectionPaint((java.awt.Paint) chartColor30);
        java.lang.String str36 = chartColor30.toString();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(datasetGroup15);
        org.junit.Assert.assertNull(pieURLGenerator16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.chart.ChartColor[r=100,g=0,b=10]" + "'", str36.equals("org.jfree.chart.ChartColor[r=100,g=0,b=10]"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.lang.String str25 = horizontalAlignment24.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment26, 0.0d, (double) 'a');
        columnArrangement29.clear();
        java.lang.Object obj31 = null;
        boolean boolean32 = columnArrangement29.equals(obj31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        double double35 = textTitle34.getHeight();
        textTitle34.setText("");
        java.awt.Color color38 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        piePlot41.addChangeListener(plotChangeListener42);
        java.awt.Color color44 = java.awt.Color.green;
        piePlot41.setBackgroundPaint((java.awt.Paint) color44);
        java.awt.Image image46 = piePlot41.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot41);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart47.setBorderStroke(stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double52 = rectangleInsets50.calculateLeftOutset(10.0d);
        double double54 = rectangleInsets50.calculateRightOutset((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder55 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color38, stroke48, rectangleInsets50);
        columnArrangement29.add((org.jfree.chart.block.Block) textTitle34, (java.lang.Object) stroke48);
        textTitle34.setID("ChartEntity: tooltip = null");
        java.awt.Graphics2D graphics2D59 = null;
        try {
            org.jfree.chart.util.Size2D size2D60 = textTitle34.arrange(graphics2D59);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "HorizontalAlignment.CENTER" + "'", str25.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(image46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 1, (int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary("");
        projectInfo0.setLicenceText("RectangleEdge.LEFT");
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) '#', (double) 1L, (double) (byte) 1, 10.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke11 = null;
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke11);
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot5);
        int int14 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Comparable comparable16 = defaultKeyedValues2D1.getRowKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '#');
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("http://www.jfree.org/jfreechart/index.html", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        defaultKeyedValues2D1.setValue((java.lang.Number) 255, (java.lang.Comparable) 0L, (java.lang.Comparable) 100L);
        try {
            java.lang.Comparable comparable9 = defaultKeyedValues2D1.getRowKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle9.setLegendItemGraphicAnchor(rectangleAnchor10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D12);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray14 = legendTitle9.getSources();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(legendItemSourceArray14);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) legendTitle9, dataset16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = legendTitle9.getHorizontalAlignment();
        boolean boolean20 = legendTitle9.equals((java.lang.Object) "org.jfree.data.general.DatasetChangeEvent[source=100]");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        piePlot3.notifyListeners(plotChangeEvent6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart8.setBorderStroke(stroke9);
        java.lang.Object obj11 = jFreeChart8.getTextAntiAlias();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rotation0, jFreeChart8);
        java.lang.String str13 = chartChangeEvent12.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=Rotation.ANTICLOCKWISE]" + "'", str13.equals("org.jfree.chart.event.ChartChangeEvent[source=Rotation.ANTICLOCKWISE]"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary("Other");
        projectInfo0.setName("Other");
        projectInfo0.setName("ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        try {
            java.lang.String str4 = jFreeChartResources0.getString("http://www.jfree.org/jfreechart/index.html");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key http://www.jfree.org/jfreechart/index.html");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        double double4 = rectangleInsets0.calculateTopOutset(0.0d);
        double double6 = rectangleInsets0.extendWidth((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = piePlot1.getShadowYOffset();
        java.awt.Color color11 = java.awt.Color.red;
        piePlot1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        piePlot14.notifyListeners(plotChangeEvent17);
        double double19 = piePlot14.getInteriorGap();
        piePlot14.setIgnoreZeroValues(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot14.getDrawingSupplier();
        piePlot1.setDrawingSupplier(drawingSupplier22);
        piePlot1.setForegroundAlpha((float) (byte) 0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.08d + "'", double19 == 0.08d);
        org.junit.Assert.assertNotNull(drawingSupplier22);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getTransparency();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot3.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color12 = java.awt.Color.green;
        float[] floatArray19 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray20 = color12.getRGBColorComponents(floatArray19);
        float[] floatArray21 = color11.getRGBComponents(floatArray20);
        float[] floatArray22 = color7.getColorComponents(colorSpace10, floatArray21);
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        piePlot24.addChangeListener(plotChangeListener25);
        java.awt.Color color28 = java.awt.Color.green;
        piePlot24.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color28);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = null;
        piePlot24.axisChanged(axisChangeEvent30);
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot24);
        org.jfree.chart.ChartColor chartColor36 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean38 = chartColor36.equals((java.lang.Object) 0);
        piePlot24.setLabelPaint((java.awt.Paint) chartColor36);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color44 = java.awt.Color.green;
        float[] floatArray51 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray52 = color44.getRGBColorComponents(floatArray51);
        float[] floatArray53 = java.awt.Color.RGBtoHSB((int) '#', (int) '4', 1, floatArray51);
        float[] floatArray54 = color40.getComponents(floatArray51);
        java.awt.Color color58 = java.awt.Color.green;
        float[] floatArray65 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray66 = color58.getRGBColorComponents(floatArray65);
        float[] floatArray67 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (byte) 100, (int) (byte) 10, floatArray66);
        float[] floatArray68 = color40.getColorComponents(floatArray66);
        float[] floatArray69 = chartColor36.getRGBComponents(floatArray68);
        float[] floatArray70 = color0.getComponents(colorSpace10, floatArray69);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray70);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle14 = jFreeChart8.getTitle();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets16.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color24 = java.awt.Color.green;
        piePlot20.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = null;
        piePlot20.axisChanged(axisChangeEvent26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot20);
        double double29 = legendTitle28.getContentYOffset();
        legendTitle28.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle28.getBounds();
        rectangleInsets16.trim(rectangle2D32);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D32, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        piePlot41.addChangeListener(plotChangeListener42);
        java.awt.Color color45 = java.awt.Color.green;
        piePlot41.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color45);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent47 = null;
        piePlot41.axisChanged(axisChangeEvent47);
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot41);
        double double50 = legendTitle49.getContentYOffset();
        legendTitle49.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D53 = legendTitle49.getBounds();
        rectangleInsets37.trim(rectangle2D53);
        org.jfree.chart.entity.ChartEntity chartEntity57 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D53, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D53, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity60 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D53);
        org.jfree.data.general.PieDataset pieDataset62 = null;
        org.jfree.chart.plot.PiePlot piePlot63 = new org.jfree.chart.plot.PiePlot(pieDataset62);
        org.jfree.chart.event.PlotChangeListener plotChangeListener64 = null;
        piePlot63.addChangeListener(plotChangeListener64);
        java.awt.Color color66 = java.awt.Color.green;
        piePlot63.setBackgroundPaint((java.awt.Paint) color66);
        java.awt.Image image68 = piePlot63.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart69 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot63);
        java.lang.Object obj70 = jFreeChart69.clone();
        org.jfree.chart.title.LegendTitle legendTitle71 = jFreeChart69.getLegend();
        org.jfree.chart.block.BlockBorder blockBorder72 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle71.setFrame((org.jfree.chart.block.BlockFrame) blockBorder72);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle71.setLegendItemGraphicAnchor(rectangleAnchor74);
        java.awt.geom.Point2D point2D76 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D53, rectangleAnchor74);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = null;
        try {
            jFreeChart8.draw(graphics2D15, rectangle2D32, point2D76, chartRenderingInfo77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(textTitle14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNull(image68);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertNotNull(legendTitle71);
        org.junit.Assert.assertNotNull(blockBorder72);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNotNull(point2D76);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Font font7 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent8.setType(chartChangeEventType9);
        org.jfree.chart.plot.Plot plot11 = plotChangeEvent8.getPlot();
        org.jfree.chart.plot.Plot plot12 = plotChangeEvent8.getPlot();
        org.jfree.chart.JFreeChart jFreeChart13 = plotChangeEvent8.getChart();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertNull(jFreeChart13);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot12.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        java.awt.Font font18 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        jFreeChart10.plotChanged(plotChangeEvent19);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean10 = jFreeChart8.equals((java.lang.Object) color9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.event.ChartChangeListener chartChangeListener13 = null;
        try {
            jFreeChart8.addChangeListener(chartChangeListener13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        piePlot6.axisChanged(axisChangeEvent12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6);
        double double15 = legendTitle14.getContentYOffset();
        legendTitle14.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle14.getBounds();
        rectangleInsets2.trim(rectangle2D18);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "", "Other");
        lineBorder0.draw(graphics2D1, rectangle2D18);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = lineBorder0.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "hi!", "hi!", image3, "", "", "hi!");
        projectInfo7.addOptionalLibrary("UnitType.ABSOLUTE");
        projectInfo7.addOptionalLibrary("");
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("org.jfree.data.UnknownKeyException: HorizontalAlignment.CENTER", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 0, (double) 10.0f, (double) 0L, (double) (byte) 100);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        java.lang.String str5 = projectInfo0.getLicenceText();
        java.lang.String str6 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        boolean boolean3 = strokeMap0.containsKey((java.lang.Comparable) "{0}");
        java.lang.Object obj4 = strokeMap0.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str6 = projectInfo5.getCopyright();
        boolean boolean7 = strokeMap0.equals((java.lang.Object) str6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Other");
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        org.jfree.data.general.DatasetGroup datasetGroup10 = piePlot1.getDatasetGroup();
        piePlot1.setPieIndex(1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator13);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNull(datasetGroup10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        projectInfo0.setCopyright("");
        java.lang.String str7 = projectInfo0.getVersion();
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        int int3 = java.awt.Color.HSBtoRGB((float) 0, 0.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-32) + "'", int3 == (-32));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.Object obj2 = null;
        boolean boolean3 = textTitle1.equals(obj2);
        textTitle1.setID("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Color color3 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        java.awt.Font font12 = piePlot6.getLabelFont();
        piePlot2.setNoDataMessageFont(font12);
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("NOID", font12);
        java.lang.Object obj15 = textTitle14.clone();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100L, 0.025d, 10.0d, (double) (-1));
        double double6 = rectangleInsets4.calculateRightInset((double) 0.5f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) -1, 100.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("PieSection: 1, -1( )");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key PieSection: 1, -1( )");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        pieSectionEntity20.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        pieSectionEntity20.setSectionIndex(0);
        java.lang.String str26 = pieSectionEntity20.toString();
        pieSectionEntity20.setSectionKey((java.lang.Comparable) "rect");
        pieSectionEntity20.setSectionIndex((-254));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PieSection: 1, 0( )" + "'", str26.equals("PieSection: 1, 0( )"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot1.getDatasetGroup();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean23 = chartColor21.equals((java.lang.Object) 0);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor21);
        piePlot1.setLabelLinkPaint((java.awt.Paint) chartColor21);
        java.awt.Color color26 = chartColor21.darker();
        int int27 = color26.getRGB();
        java.awt.color.ColorSpace colorSpace28 = color26.getColorSpace();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-12189689) + "'", int27 == (-12189689));
        org.junit.Assert.assertNotNull(colorSpace28);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        boolean boolean8 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke16 = null;
        piePlot10.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot10.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateLeftOutset(10.0d);
        double double25 = rectangleInsets21.calculateLeftInset((double) (short) 100);
        piePlot10.setInsets(rectangleInsets21, false);
        piePlot1.setInsets(rectangleInsets21, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets30.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        piePlot34.addChangeListener(plotChangeListener35);
        java.awt.Color color38 = java.awt.Color.green;
        piePlot34.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color38);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent40 = null;
        piePlot34.axisChanged(axisChangeEvent40);
        org.jfree.chart.title.LegendTitle legendTitle42 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot34);
        double double43 = legendTitle42.getContentYOffset();
        legendTitle42.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D46 = legendTitle42.getBounds();
        rectangleInsets30.trim(rectangle2D46);
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity52 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D46, "{0}");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType53 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets21.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType53, lengthAdjustmentType54);
        double double56 = rectangleInsets21.getBottom();
        double double58 = rectangleInsets21.trimWidth((double) (-1.0f));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-1.0d) + "'", double58 == (-1.0d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        boolean boolean23 = pieSectionEntity20.equals((java.lang.Object) (byte) 1);
        int int24 = pieSectionEntity20.getPieIndex();
        java.lang.String str25 = pieSectionEntity20.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "PieSection: 1, -1( )" + "'", str25.equals("PieSection: 1, -1( )"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint9 = piePlot2.getLabelBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        piePlot12.setMaximumLabelWidth((double) 10.0f);
        double double17 = piePlot12.getMaximumLabelWidth();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot20.addChangeListener(plotChangeListener21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        piePlot20.notifyListeners(plotChangeEvent23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot20);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart25.setBorderStroke(stroke26);
        piePlot12.setOutlineStroke(stroke26);
        piePlot2.setSectionOutlineStroke((java.lang.Comparable) "HorizontalAlignment.CENTER", stroke26);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator30 = piePlot2.getToolTipGenerator();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 10.0d + "'", double17 == 10.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(pieToolTipGenerator30);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        java.lang.String str2 = projectInfo0.getLicenceText();
        java.lang.String str3 = projectInfo0.getCopyright();
        java.lang.String str4 = projectInfo0.getInfo();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.data.general.DatasetChangeEvent[source=100]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        piePlot1.setOutlineVisible(true);
        boolean boolean16 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.RenderingHints renderingHints9 = jFreeChart8.getRenderingHints();
        java.lang.Object obj10 = jFreeChart8.getTextAntiAlias();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        try {
            defaultKeyedValues2D1.removeRow((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        java.lang.Object obj14 = null;
        boolean boolean15 = jFreeChart8.equals(obj14);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo19 = null;
        java.awt.image.BufferedImage bufferedImage20 = jFreeChart8.createBufferedImage(15, (int) (byte) 10, 3, chartRenderingInfo19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        try {
            jFreeChart8.handleClick(1, (int) (short) 1, chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(bufferedImage20);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(15, (int) (short) 1, (-254));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        textTitle23.setPadding((double) (short) 0, (double) 1L, (double) (short) 1, (double) (short) 100);
        java.lang.String str30 = textTitle23.getToolTipText();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Other");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Other, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        defaultKeyedValues2D1.setValue((java.lang.Number) 255, (java.lang.Comparable) 0L, (java.lang.Comparable) 100L);
        try {
            java.lang.Comparable comparable9 = defaultKeyedValues2D1.getColumnKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.String str14 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset12, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset15, (java.lang.Comparable) (-1L));
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        java.awt.Color color19 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = defaultCategoryDataset20.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color19, (org.jfree.data.general.Dataset) defaultCategoryDataset20);
        piePlot1.datasetChanged(datasetChangeEvent23);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(datasetGroup22);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) legendTitle9, dataset16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = legendTitle9.getHorizontalAlignment();
        java.awt.Font font19 = legendTitle9.getItemFont();
        boolean boolean20 = legendTitle9.getNotify();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Color color2 = java.awt.Color.getColor("PieSection: 1, 0( )", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        java.awt.Color color6 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 15);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color6);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block9 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        piePlot12.notifyListeners(plotChangeEvent15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        piePlot19.axisChanged(axisChangeEvent25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = legendTitle27.getVerticalAlignment();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = null;
        org.jfree.chart.util.Size2D size2D31 = legendTitle27.arrange(graphics2D29, rectangleConstraint30);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) legendTitle27);
        flowArrangement8.add(block9, (java.lang.Object) legendTitle27);
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, (org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement34);
        java.awt.Color color36 = java.awt.Color.BLUE;
        boolean boolean37 = flowArrangement34.equals((java.lang.Object) color36);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(size2D31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle14 = jFreeChart8.getTitle();
        float float15 = jFreeChart8.getBackgroundImageAlpha();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        piePlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color22 = java.awt.Color.green;
        piePlot18.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color22);
        java.awt.Font font24 = piePlot18.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("NOID", font24);
        java.awt.Font font26 = textTitle25.getFont();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle29 = piePlot28.getLabelLinkStyle();
        java.awt.Paint paint30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean31 = pieLabelLinkStyle29.equals((java.lang.Object) paint30);
        textTitle25.setBackgroundPaint(paint30);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) textTitle25);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(textTitle14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "http://www.jfree.org/jfreechart/index.html", "", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        basicProjectInfo4.setVersion("TableOrder.BY_ROW");
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16);
        java.lang.String str19 = chartEntity18.getURLText();
        java.lang.String str20 = chartEntity18.getShapeCoords();
        java.lang.String str21 = chartEntity18.getURLText();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0,0,1,1" + "'", str20.equals("0,0,1,1"));
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.RenderingHints renderingHints9 = jFreeChart8.getRenderingHints();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets19.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color27 = java.awt.Color.green;
        piePlot23.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color27);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = null;
        piePlot23.axisChanged(axisChangeEvent29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23);
        double double32 = legendTitle31.getContentYOffset();
        legendTitle31.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D35 = legendTitle31.getBounds();
        rectangleInsets19.trim(rectangle2D35);
        textTitle18.setBounds(rectangle2D35);
        java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets16.createOutsetRectangle(rectangle2D35);
        try {
            jFreeChart8.draw(graphics2D10, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D38);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        strokeMap0.clear();
        java.lang.Object obj2 = strokeMap0.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleEdge.TOP", "", "ChartChangeEventType.DATASET_UPDATED");
        java.lang.String str5 = basicProjectInfo4.getCopyright();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet4 = jFreeChartResources0.keySet();
        try {
            java.lang.String str6 = jFreeChartResources0.getString("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getLegendItemGraphicPadding();
        double double12 = rectangleInsets10.extendWidth((double) 255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 259.0d + "'", double12 == 259.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        double double4 = rectangleInsets0.calculateTopOutset(0.0d);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Image image11 = piePlot6.getBackgroundImage();
        java.lang.Object obj12 = piePlot6.clone();
        boolean boolean13 = piePlot6.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot15.setBackgroundPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke21 = null;
        piePlot15.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke21);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot15.getLegendLabelGenerator();
        piePlot15.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double28 = rectangleInsets26.calculateLeftOutset(10.0d);
        double double30 = rectangleInsets26.calculateLeftInset((double) (short) 100);
        piePlot15.setInsets(rectangleInsets26, false);
        piePlot6.setInsets(rectangleInsets26, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double37 = rectangleInsets35.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset38 = null;
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot(pieDataset38);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        piePlot39.addChangeListener(plotChangeListener40);
        java.awt.Color color43 = java.awt.Color.green;
        piePlot39.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color43);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent45 = null;
        piePlot39.axisChanged(axisChangeEvent45);
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot39);
        double double48 = legendTitle47.getContentYOffset();
        legendTitle47.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D51 = legendTitle47.getBounds();
        rectangleInsets35.trim(rectangle2D51);
        org.jfree.chart.entity.ChartEntity chartEntity55 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D51, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity57 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D51, "{0}");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets26.createAdjustedRectangle(rectangle2D51, lengthAdjustmentType58, lengthAdjustmentType59);
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets0.createInsetRectangle(rectangle2D51, false, false);
        double double65 = rectangleInsets0.calculateBottomOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        piePlot3.notifyListeners(plotChangeEvent6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot3);
        boolean boolean10 = jFreeChart8.equals((java.lang.Object) '4');
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color11);
        jFreeChart8.setTextAntiAlias(true);
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = null;
        try {
            org.jfree.chart.util.Size2D size2D18 = textTitle0.arrange(graphics2D16, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.awt.Font font25 = textTitle23.getFont();
        java.awt.Paint paint26 = textTitle23.getBackgroundPaint();
        java.awt.Paint paint27 = textTitle23.getPaint();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = defaultCategoryDataset0.getGroup();
        try {
            defaultCategoryDataset0.removeRow(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        int int13 = jFreeChart10.getSubtitleCount();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = null;
        try {
            java.awt.image.BufferedImage bufferedImage16 = jFreeChart10.createBufferedImage(0, (int) ' ', chartRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (32) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Font font7 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent8.setType(chartChangeEventType9);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot13.notifyListeners(plotChangeEvent16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot13);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart18.setBorderStroke(stroke19);
        java.lang.Object obj21 = jFreeChart18.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart18.getLegend();
        plotChangeEvent8.setChart(jFreeChart18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        try {
            java.awt.image.BufferedImage bufferedImage29 = jFreeChart18.createBufferedImage((int) (short) 10, (-12189689), (double) (short) 10, (double) 0.5f, chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (10) and height (-12189689) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(legendTitle22);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.calculateLeftOutset(10.0d);
        piePlot2.setSimpleLabelOffset(rectangleInsets6);
        boolean boolean10 = flowArrangement0.equals((java.lang.Object) rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color17 = java.awt.Color.green;
        piePlot13.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        piePlot13.axisChanged(axisChangeEvent19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = legendTitle21.getVerticalAlignment();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_RED;
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle21, (java.lang.Object) color23);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle10 = null;
        jFreeChart7.setTitle(textTitle10);
        jFreeChart7.setBackgroundImageAlignment((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = legendTitle23.getVerticalAlignment();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = null;
        org.jfree.chart.util.Size2D size2D27 = legendTitle23.arrange(graphics2D25, rectangleConstraint26);
        double double28 = legendTitle23.getWidth();
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle23);
        java.awt.RenderingHints renderingHints30 = jFreeChart7.getRenderingHints();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent31 = null;
        try {
            jFreeChart7.titleChanged(titleChangeEvent31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(renderingHints30);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-12189689));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot15.getLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator23);
        java.awt.Color color26 = java.awt.Color.green;
        java.awt.Color color27 = java.awt.Color.getColor("hi!", color26);
        piePlot1.setLabelPaint((java.awt.Paint) color27);
        double double29 = piePlot1.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.025d + "'", double29 == 0.025d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle9.getItemContainer();
        java.lang.Object obj15 = blockContainer14.clone();
        blockContainer14.clear();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = null;
        try {
            org.jfree.chart.util.Size2D size2D19 = blockContainer14.arrange(graphics2D17, rectangleConstraint18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("0,0,1,1");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key 0,0,1,1");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        double double8 = piePlot1.getLabelLinkMargin();
        float float9 = piePlot1.getForegroundAlpha();
        piePlot1.setCircular(true, false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.14d, 1.0d, (double) 15, 0.0d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean28 = chartColor26.equals((java.lang.Object) 0);
        piePlot14.setLabelPaint((java.awt.Paint) chartColor26);
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) chartColor26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = piePlot1.getDrawingSupplier();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        piePlot35.addChangeListener(plotChangeListener36);
        java.awt.Color color39 = java.awt.Color.green;
        piePlot35.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color39);
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot35);
        java.awt.Paint paint42 = piePlot35.getBackgroundPaint();
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "0,0,1,1", paint42);
        java.awt.Font font44 = null;
        try {
            piePlot1.setNoDataMessageFont(font44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(drawingSupplier31);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("NOID");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key NOID");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        boolean boolean4 = multiplePiePlot0.isOutlineVisible();
        org.jfree.chart.util.TableOrder tableOrder5 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder5);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = piePlot8.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot8.getToolTipGenerator();
        java.awt.Paint paint11 = piePlot8.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = piePlot13.getToolTipGenerator();
        java.awt.Paint paint17 = piePlot13.getLabelPaint();
        java.awt.Paint paint18 = piePlot13.getLabelOutlinePaint();
        piePlot8.setLabelOutlinePaint(paint18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace21 = color20.getColorSpace();
        piePlot8.setBaseSectionPaint((java.awt.Paint) color20);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator23 = null;
        piePlot8.setToolTipGenerator(pieToolTipGenerator23);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        java.awt.Color color27 = java.awt.Color.green;
        piePlot26.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        piePlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color34 = java.awt.Color.green;
        piePlot30.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color34);
        java.awt.Font font36 = piePlot30.getLabelFont();
        piePlot26.setNoDataMessageFont(font36);
        piePlot8.setNoDataMessageFont(font36);
        multiplePiePlot0.setNoDataMessageFont(font36);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(tableOrder5);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(pieToolTipGenerator16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(colorSpace21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font36);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle10 = null;
        jFreeChart7.setTitle(textTitle10);
        jFreeChart7.setBackgroundImageAlignment((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = legendTitle23.getVerticalAlignment();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = null;
        org.jfree.chart.util.Size2D size2D27 = legendTitle23.arrange(graphics2D25, rectangleConstraint26);
        double double28 = legendTitle23.getWidth();
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle23);
        org.jfree.chart.title.LegendTitle legendTitle30 = jFreeChart7.getLegend();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(legendTitle30);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        java.lang.String str5 = projectInfo0.toString();
        java.util.List list6 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str5.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        java.lang.String str2 = datasetGroup0.getID();
        org.jfree.chart.ui.Licences licences3 = new org.jfree.chart.ui.Licences();
        java.lang.String str4 = licences3.getGPL();
        boolean boolean5 = datasetGroup0.equals((java.lang.Object) licences3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOID" + "'", str2.equals("NOID"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.String str14 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset12, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset15, (java.lang.Comparable) (-1L));
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        piePlot1.setCircular(false, false);
        java.awt.Paint paint22 = piePlot1.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean28 = chartColor26.equals((java.lang.Object) 0);
        piePlot14.setLabelPaint((java.awt.Paint) chartColor26);
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) chartColor26);
        org.jfree.data.general.PieDataset pieDataset31 = piePlot1.getDataset();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator32 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(pieDataset31);
        org.junit.Assert.assertNull(pieURLGenerator32);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color5 = java.awt.Color.green;
        float[] floatArray12 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray13 = color5.getRGBColorComponents(floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) '#', (int) '4', 1, floatArray12);
        float[] floatArray15 = color1.getComponents(floatArray12);
        java.awt.Color color19 = java.awt.Color.green;
        float[] floatArray26 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray27 = color19.getRGBColorComponents(floatArray26);
        float[] floatArray28 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (byte) 100, (int) (byte) 10, floatArray27);
        float[] floatArray29 = color1.getColorComponents(floatArray27);
        float[] floatArray30 = color0.getRGBComponents(floatArray29);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        boolean boolean14 = jFreeChart8.getAntiAlias();
        try {
            org.jfree.chart.plot.XYPlot xYPlot15 = jFreeChart8.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        try {
            java.lang.Object obj4 = jFreeChartResources0.getObject("java.awt.Color[r=255,g=255,b=255]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=255,g=255,b=255]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        piePlot1.setShadowYOffset((double) 15);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator8);
        java.awt.Paint paint10 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("HorizontalAlignment.CENTER");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("HorizontalAlignment.CENTER");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.Throwable[] throwableArray5 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        pieSectionEntity20.setPieIndex((int) ' ');
        org.jfree.data.general.PieDataset pieDataset23 = null;
        pieSectionEntity20.setDataset(pieDataset23);
        java.lang.String str25 = pieSectionEntity20.getShapeType();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "rect" + "'", str25.equals("rect"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Stroke stroke6 = piePlot1.getOutlineStroke();
        piePlot1.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        java.lang.String str2 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.getLicenceText();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        projectInfo3.setVersion("RectangleEdge.LEFT");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        piePlot1.zoom((double) 0L);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        piePlot10.notifyListeners(plotChangeEvent13);
        java.awt.Stroke stroke16 = piePlot10.getSectionOutlineStroke((java.lang.Comparable) (byte) 10);
        int int17 = piePlot10.getPieIndex();
        java.awt.Paint paint18 = piePlot10.getShadowPaint();
        java.awt.Paint paint19 = piePlot10.getBaseSectionPaint();
        piePlot1.setBaseSectionPaint(paint19);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        pieSectionEntity20.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library library28 = new org.jfree.chart.ui.Library("", "Other", "java.awt.Color[r=255,g=255,b=255]", "RectangleEdge.TOP");
        java.lang.String str29 = library28.getName();
        boolean boolean30 = pieSectionEntity20.equals((java.lang.Object) str29);
        java.awt.Shape shape31 = pieSectionEntity20.getArea();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getCopyright();
        java.awt.Image image4 = null;
        projectInfo2.setLogo(image4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        java.lang.String str7 = projectInfo2.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray8 = projectInfo2.getLibraries();
        java.lang.String str9 = projectInfo2.toString();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str9.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str15 = rectangleEdge14.toString();
        double double16 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D13, rectangleEdge14);
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D13);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        piePlot19.setMaximumLabelWidth((double) 10.0f);
        piePlot19.setShadowYOffset((double) 1L);
        boolean boolean26 = chartEntity17.equals((java.lang.Object) 1L);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.LEFT" + "'", str15.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart19.addProgressListener(chartProgressListener22);
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart19.createBufferedImage((int) (short) 10, 8);
        java.awt.Image image27 = null;
        jFreeChart19.setBackgroundImage(image27);
        org.jfree.chart.event.ChartProgressListener chartProgressListener29 = null;
        jFreeChart19.removeProgressListener(chartProgressListener29);
        try {
            java.awt.image.BufferedImage bufferedImage33 = jFreeChart19.createBufferedImage((-254), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-254) and height (52) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("Rotation.CLOCKWISE", "PieLabelLinkStyle.STANDARD", "Other", "HorizontalAlignment.CENTER", "RectangleEdge.LEFT");
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        pieSectionEntity20.setPieIndex((int) ' ');
        org.jfree.data.general.PieDataset pieDataset23 = null;
        pieSectionEntity20.setDataset(pieDataset23);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        pieSectionEntity20.setDataset(pieDataset25);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        java.util.List list4 = defaultKeyedValues2D1.getColumnKeys();
        try {
            java.lang.Number number7 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (short) 100, (java.lang.Comparable) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        java.awt.Image image17 = piePlot1.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = piePlot1.getLabelDistributor();
        double double19 = piePlot1.getStartAngle();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        java.awt.Color color22 = java.awt.Color.green;
        piePlot21.setBackgroundPaint((java.awt.Paint) color22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        piePlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color29 = java.awt.Color.green;
        piePlot25.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color29);
        java.awt.Font font31 = piePlot25.getLabelFont();
        piePlot21.setNoDataMessageFont(font31);
        piePlot1.setNoDataMessageFont(font31);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 90.0d + "'", double19 == 90.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot7.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot7.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = piePlot12.getToolTipGenerator();
        java.awt.Paint paint16 = piePlot12.getLabelPaint();
        java.awt.Paint paint17 = piePlot12.getLabelOutlinePaint();
        piePlot7.setLabelOutlinePaint(paint17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        piePlot7.setBaseSectionPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = null;
        piePlot7.setToolTipGenerator(pieToolTipGenerator22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Color color26 = java.awt.Color.green;
        piePlot25.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot29.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color33);
        java.awt.Font font35 = piePlot29.getLabelFont();
        piePlot25.setNoDataMessageFont(font35);
        piePlot7.setNoDataMessageFont(font35);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = null", font5, (org.jfree.chart.plot.Plot) piePlot7, true);
        org.jfree.chart.title.LegendTitle legendTitle40 = jFreeChart39.getLegend();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(pieToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(legendTitle40);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("UnitType.RELATIVE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart19.addProgressListener(chartProgressListener22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            jFreeChart19.draw(graphics2D24, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        piePlot3.notifyListeners(plotChangeEvent6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot3);
        boolean boolean10 = jFreeChart8.equals((java.lang.Object) '4');
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color11);
        jFreeChart8.setTextAntiAlias(true);
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint16 = textTitle0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        jFreeChart19.fireChartChanged();
        java.awt.Paint paint22 = null;
        jFreeChart19.setBackgroundPaint(paint22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart19);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        piePlot1.setCircular(false, false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator29 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator29);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.fireChartChanged();
        java.awt.Paint paint12 = null;
        jFreeChart9.setBackgroundPaint(paint12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart9);
        boolean boolean15 = jFreeChart9.isNotify();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getColumnCount();
        defaultKeyedValues2D2.clear();
        defaultKeyedValues2D2.setValue((java.lang.Number) 255, (java.lang.Comparable) 0L, (java.lang.Comparable) 100L);
        boolean boolean9 = color0.equals((java.lang.Object) 255);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        java.awt.Color color18 = java.awt.Color.lightGray;
        piePlot1.setOutlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = piePlot1.getLabelShadowPaint();
        try {
            piePlot1.setBackgroundImageAlpha((float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(10.0d);
        double double4 = rectangleInsets0.calculateLeftInset((double) (short) 100);
        double double6 = rectangleInsets0.calculateBottomOutset(0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Font font7 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent8.setType(chartChangeEventType9);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot13.notifyListeners(plotChangeEvent16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot13);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart18.setBorderStroke(stroke19);
        java.lang.Object obj21 = jFreeChart18.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart18.getLegend();
        plotChangeEvent8.setChart(jFreeChart18);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart18.removeProgressListener(chartProgressListener24);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(legendTitle22);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        java.awt.Paint paint10 = piePlot1.getOutlinePaint();
        boolean boolean11 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Image image17 = piePlot12.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot12);
        java.awt.RenderingHints renderingHints19 = jFreeChart18.getRenderingHints();
        boolean boolean20 = rectangleInsets5.equals((java.lang.Object) renderingHints19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        piePlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color29 = java.awt.Color.green;
        piePlot25.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color29);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = null;
        piePlot25.axisChanged(axisChangeEvent31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot25);
        double double34 = legendTitle33.getContentYOffset();
        legendTitle33.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle33.getBounds();
        rectangleInsets21.trim(rectangle2D37);
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D37, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets5.createOutsetRectangle(rectangle2D37, true, false);
        double double46 = rectangleInsets5.calculateRightOutset((double) (byte) 100);
        double double48 = rectangleInsets5.trimHeight((double) (byte) -1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(renderingHints19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-1.0d) + "'", double48 == (-1.0d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.lang.String str25 = horizontalAlignment24.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment26, 0.0d, (double) 'a');
        columnArrangement29.clear();
        org.jfree.chart.block.BlockContainer blockContainer31 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement29);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "HorizontalAlignment.CENTER" + "'", str25.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment26);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        double double10 = rectangleInsets5.extendWidth(10.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        java.lang.String str5 = projectInfo0.getLicenceText();
        java.lang.String str6 = projectInfo0.getLicenceText();
        java.lang.String str7 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(10.0d);
        double double4 = rectangleInsets0.calculateLeftInset((double) (short) 100);
        double double6 = rectangleInsets0.calculateTopInset((double) 100.0f);
        double double8 = rectangleInsets0.calculateBottomInset((double) (-16777216));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.String str7 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset5, (java.lang.Comparable) (-1L));
        org.jfree.data.general.PieDataset pieDataset8 = null;
        try {
            java.text.AttributedString attributedString10 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset8, (java.lang.Comparable) "org.jfree.data.general.DatasetChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color11 = java.awt.Color.green;
        piePlot7.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color11);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = null;
        piePlot7.axisChanged(axisChangeEvent13);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot7.getLegendLabelGenerator();
        double double16 = piePlot7.getMaximumLabelWidth();
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot7.setLabelLinkPaint(paint17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot7.setBaseSectionOutlineStroke(stroke19);
        piePlot1.setBaseSectionOutlineStroke(stroke19);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.text.NumberFormat numberFormat24 = standardPieSectionLabelGenerator23.getPercentFormat();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator23);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.14d + "'", double16 == 0.14d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(numberFormat24);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L));
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent1.setType(chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent1.toString();
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=-1]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=-1]"));
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke8);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D11 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int12 = defaultKeyedValues2D11.getColumnCount();
        defaultKeyedValues2D11.clear();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot15.setBackgroundPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke21 = null;
        piePlot15.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke21);
        boolean boolean23 = defaultKeyedValues2D11.equals((java.lang.Object) piePlot15);
        int int24 = defaultKeyedValues2D11.getRowCount();
        java.util.List list25 = defaultKeyedValues2D11.getColumnKeys();
        jFreeChart7.setSubtitles(list25);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot1.getDatasetGroup();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean23 = chartColor21.equals((java.lang.Object) 0);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor21);
        piePlot1.setLabelLinkPaint((java.awt.Paint) chartColor21);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color26);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        piePlot19.axisChanged(axisChangeEvent25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        piePlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot30.setBackgroundPaint((java.awt.Paint) color33);
        java.awt.Image image35 = piePlot30.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot30);
        java.lang.Object obj37 = jFreeChart36.clone();
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart36.getLegend();
        legendTitle27.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart36);
        jFreeChart36.setBackgroundImageAlpha(0.0f);
        boolean boolean42 = legendTitle17.equals((java.lang.Object) jFreeChart36);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        piePlot45.addChangeListener(plotChangeListener46);
        java.awt.Color color49 = java.awt.Color.green;
        piePlot45.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color49);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = null;
        piePlot45.axisChanged(axisChangeEvent51);
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot45);
        double double54 = legendTitle53.getContentYOffset();
        legendTitle53.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D57 = legendTitle53.getBounds();
        try {
            jFreeChart36.draw(graphics2D43, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(image35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(legendTitle38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        pieSectionEntity20.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.ui.Library library28 = new org.jfree.chart.ui.Library("", "Other", "java.awt.Color[r=255,g=255,b=255]", "RectangleEdge.TOP");
        java.lang.String str29 = library28.getName();
        boolean boolean30 = pieSectionEntity20.equals((java.lang.Object) str29);
        org.jfree.data.general.PieDataset pieDataset31 = pieSectionEntity20.getDataset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(pieDataset31);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int3 = java.awt.Color.HSBtoRGB((-1.0f), (float) 10, 1.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-246) + "'", int3 == (-246));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = piePlot1.getDrawingSupplier();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        java.awt.Font font20 = piePlot14.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.plot.Plot plot22 = plotChangeEvent21.getPlot();
        piePlot1.notifyListeners(plotChangeEvent21);
        boolean boolean24 = piePlot1.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        piePlot1.handleClick(100, 0, plotRenderingInfo10);
        piePlot1.setBackgroundAlpha((float) (-32));
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        boolean boolean14 = blockBorder11.equals((java.lang.Object) false);
        java.awt.Paint paint15 = blockBorder11.getPaint();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        piePlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color22 = java.awt.Color.green;
        piePlot18.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot18);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean26 = jFreeChart24.equals((java.lang.Object) color25);
        java.awt.Stroke stroke27 = jFreeChart24.getBorderStroke();
        boolean boolean28 = blockBorder11.equals((java.lang.Object) stroke27);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        java.lang.String str24 = textTitle23.getText();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.lang.Object obj11 = null;
        boolean boolean12 = verticalAlignment10.equals(obj11);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightOutset((double) 0.5f);
        double double4 = rectangleInsets0.trimHeight((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.0d) + "'", double4 == (-2.0d));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        boolean boolean6 = standardPieSectionLabelGenerator1.equals((java.lang.Object) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getTop();
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) rectangleInsets7);
        double double10 = rectangleInsets7.getBottom();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getCopyright();
        java.awt.Image image4 = null;
        projectInfo2.setLogo(image4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("HorizontalAlignment.CENTER", "", "ChartEntity: tooltip = null", "PieLabelLinkStyle.STANDARD", "Rotation.ANTICLOCKWISE");
        basicProjectInfo12.setVersion("ChartEntity: tooltip = null");
        basicProjectInfo12.addOptionalLibrary("PieSection: 1, 0( )");
        projectInfo2.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo12);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection6 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot7.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        java.awt.Paint paint11 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.String str14 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset12, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset15, (java.lang.Comparable) (-1L));
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        piePlot1.setCircular(false, false);
        piePlot1.setOutlineVisible(false);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        piePlot1.setDataset(pieDataset24);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke11 = null;
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke11);
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot5);
        int int14 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Comparable comparable16 = defaultKeyedValues2D1.getRowKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.String str14 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset12, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset15, (java.lang.Comparable) (-1L));
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        java.text.AttributedString attributedString20 = standardPieSectionLabelGenerator11.getAttributedLabel((int) (short) 0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(attributedString20);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot1.getDatasetGroup();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean23 = chartColor21.equals((java.lang.Object) 0);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor21);
        piePlot1.setLabelLinkPaint((java.awt.Paint) chartColor21);
        double double26 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.14d + "'", double26 == 0.14d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        defaultCategoryDataset2.addValue(0.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 3);
        try {
            defaultCategoryDataset2.incrementValue((double) (short) 0, (java.lang.Comparable) (byte) 0, (java.lang.Comparable) "PieSection: 1, 0( )");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: PieSection: 1, 0( )");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        int int4 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot0.getParent();
        multiplePiePlot0.setLimit((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        int int3 = defaultCategoryDataset1.getRowCount();
        try {
            defaultCategoryDataset1.removeColumn((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator20);
        java.lang.Comparable comparable22 = null;
        try {
            java.awt.Paint paint23 = piePlot1.getSectionOutlinePaint(comparable22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        double double10 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot1.setLabelLinkPaint(paint11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        piePlot14.notifyListeners(plotChangeEvent17);
        java.awt.Paint paint19 = piePlot14.getLabelPaint();
        piePlot1.setShadowPaint(paint19);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14d + "'", double10 == 0.14d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (int) (byte) 0);
        java.awt.Color color3 = color2.darker();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        java.lang.String str2 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.getLicenceText();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        projectInfo0.setVersion("VerticalAlignment.CENTER");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(pieURLGenerator12);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10L, (double) (byte) -1, (double) (-32), (double) 0.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        java.awt.Paint paint11 = textTitle9.getBackgroundPaint();
        double double12 = textTitle9.getContentYOffset();
        org.jfree.chart.block.BlockFrame blockFrame13 = textTitle9.getFrame();
        java.awt.Paint paint14 = textTitle9.getPaint();
        textTitle9.setExpandToFitSpace(true);
        java.awt.Font font17 = textTitle9.getFont();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart19.addProgressListener(chartProgressListener22);
        jFreeChart19.setNotify(false);
        int int26 = jFreeChart19.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) '4');
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot0.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder7 = null;
        try {
            multiplePiePlot0.setDataExtractOrder(tableOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        defaultCategoryDataset2.addValue(0.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 3);
        try {
            java.lang.Comparable comparable9 = defaultCategoryDataset2.getColumnKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        try {
            java.awt.Paint paint6 = defaultDrawingSupplier5.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Image image17 = piePlot12.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot12);
        java.awt.RenderingHints renderingHints19 = jFreeChart18.getRenderingHints();
        boolean boolean20 = rectangleInsets5.equals((java.lang.Object) renderingHints19);
        double double22 = rectangleInsets5.extendWidth((double) 10);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(renderingHints19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle10 = null;
        jFreeChart7.setTitle(textTitle10);
        java.util.List list12 = null;
        try {
            jFreeChart7.setSubtitles(list12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        java.lang.String str21 = chartEntity20.getShapeType();
        chartEntity20.setToolTipText("org.jfree.data.UnknownKeyException: HorizontalAlignment.CENTER");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "rect" + "'", str21.equals("rect"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        org.jfree.chart.util.ObjectList objectList14 = new org.jfree.chart.util.ObjectList(10);
        boolean boolean15 = piePlot1.equals((java.lang.Object) objectList14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle9.getItemContainer();
        org.jfree.chart.block.Arrangement arrangement15 = blockContainer14.getArrangement();
        boolean boolean16 = blockContainer14.isEmpty();
        blockContainer14.clear();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets19.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color27 = java.awt.Color.green;
        piePlot23.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color27);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = null;
        piePlot23.axisChanged(axisChangeEvent29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23);
        double double32 = legendTitle31.getContentYOffset();
        legendTitle31.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D35 = legendTitle31.getBounds();
        rectangleInsets19.trim(rectangle2D35);
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D35, "NOID");
        try {
            blockContainer14.draw(graphics2D18, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(arrangement15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        boolean boolean8 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke16 = null;
        piePlot10.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot10.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateLeftOutset(10.0d);
        double double25 = rectangleInsets21.calculateLeftInset((double) (short) 100);
        piePlot10.setInsets(rectangleInsets21, false);
        piePlot1.setInsets(rectangleInsets21, false);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor30 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor30);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        try {
            java.lang.Comparable comparable9 = defaultKeyedValues2D1.getRowKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot11.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot11.axisChanged(axisChangeEvent17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle19.getVerticalAlignment();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = null;
        org.jfree.chart.util.Size2D size2D23 = legendTitle19.arrange(graphics2D21, rectangleConstraint22);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle19);
        flowArrangement0.add(block1, (java.lang.Object) legendTitle19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle19.getSources();
        legendTitle19.setPadding(10.0d, (double) (byte) 10, (double) '4', (double) 2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray32 = legendTitle19.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle19.getItemLabelPadding();
        double double35 = rectangleInsets33.calculateTopInset(10.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(legendItemSourceArray32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.0d + "'", double35 == 2.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.calculateLeftOutset(10.0d);
        piePlot2.setSimpleLabelOffset(rectangleInsets6);
        boolean boolean10 = flowArrangement0.equals((java.lang.Object) rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        flowArrangement0.clear();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        java.lang.Object obj10 = standardPieSectionLabelGenerator8.clone();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets15.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        piePlot19.axisChanged(axisChangeEvent25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        double double28 = legendTitle27.getContentYOffset();
        legendTitle27.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle27.getBounds();
        rectangleInsets15.trim(rectangle2D31);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D31, "NOID");
        java.awt.geom.Point2D point2D35 = null;
        org.jfree.chart.plot.PlotState plotState36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            piePlot1.draw(graphics2D14, rectangle2D31, point2D35, plotState36, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        jFreeChart7.setBorderVisible(true);
        java.util.List list11 = jFreeChart7.getSubtitles();
        boolean boolean12 = jFreeChart7.isBorderVisible();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle1.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        piePlot19.notifyListeners(plotChangeEvent22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot19);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        piePlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color30 = java.awt.Color.green;
        piePlot26.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color30);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent32 = null;
        piePlot26.axisChanged(axisChangeEvent32);
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot26);
        org.jfree.chart.util.VerticalAlignment verticalAlignment35 = legendTitle34.getVerticalAlignment();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = null;
        org.jfree.chart.util.Size2D size2D38 = legendTitle34.arrange(graphics2D36, rectangleConstraint37);
        jFreeChart24.addSubtitle((org.jfree.chart.title.Title) legendTitle34);
        org.jfree.chart.title.TextTitle textTitle40 = jFreeChart24.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = textTitle40.getTextAlignment();
        java.lang.String str42 = horizontalAlignment41.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement46 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment41, verticalAlignment43, 0.0d, (double) 'a');
        org.jfree.chart.block.ColumnArrangement columnArrangement49 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment16, verticalAlignment43, (double) 255, (double) 0.0f);
        textTitle1.setTextAlignment(horizontalAlignment16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment51 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment52 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement55 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment51, verticalAlignment52, (double) 10L, (double) 10.0f);
        org.jfree.chart.block.ColumnArrangement columnArrangement58 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment16, verticalAlignment52, (double) 3, (double) 0L);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(verticalAlignment35);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertNotNull(textTitle40);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "HorizontalAlignment.CENTER" + "'", str42.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertNotNull(horizontalAlignment51);
        org.junit.Assert.assertNotNull(verticalAlignment52);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        java.lang.String str21 = chartEntity20.getShapeType();
        java.awt.Shape shape22 = chartEntity20.getArea();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator23 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator24 = null;
        try {
            java.lang.String str25 = chartEntity20.getImageMapAreaTag(toolTipTagFragmentGenerator23, uRLTagFragmentGenerator24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "rect" + "'", str21.equals("rect"));
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle10 = null;
        jFreeChart7.setTitle(textTitle10);
        java.awt.Image image12 = null;
        jFreeChart7.setBackgroundImage(image12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        piePlot1.setLabelLinksVisible(false);
        float float12 = piePlot1.getForegroundAlpha();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator10);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        boolean boolean5 = jFreeChartResources0.containsKey("org.jfree.data.UnknownKeyException: HorizontalAlignment.CENTER");
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 10);
        pieLabelDistributor1.distributeLabels(8.0d, 0.4d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("org.jfree.data.UnknownKeyException: HorizontalAlignment.CENTER", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }
}

