import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = java.awt.Color.green;
        piePlot9.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Image image14 = piePlot9.getBackgroundImage();
        java.lang.Object obj15 = piePlot9.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot9.notifyListeners(plotChangeEvent16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset20 = null;
        java.lang.String str22 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset20, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset23 = null;
        java.lang.String str25 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset23, (java.lang.Comparable) (-1L));
        piePlot9.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color27);
        boolean boolean29 = standardPieSectionLabelGenerator19.equals((java.lang.Object) color27);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator31 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator31);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        try {
            defaultKeyedValues2D1.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot7.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot7.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = piePlot12.getToolTipGenerator();
        java.awt.Paint paint16 = piePlot12.getLabelPaint();
        java.awt.Paint paint17 = piePlot12.getLabelOutlinePaint();
        piePlot7.setLabelOutlinePaint(paint17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        piePlot7.setBaseSectionPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = null;
        piePlot7.setToolTipGenerator(pieToolTipGenerator22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Color color26 = java.awt.Color.green;
        piePlot25.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot29.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color33);
        java.awt.Font font35 = piePlot29.getLabelFont();
        piePlot25.setNoDataMessageFont(font35);
        piePlot7.setNoDataMessageFont(font35);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = null", font5, (org.jfree.chart.plot.Plot) piePlot7, true);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator40 = null;
        piePlot7.setToolTipGenerator(pieToolTipGenerator40);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(pieToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection6 = multiplePiePlot0.getLegendItems();
        int int7 = multiplePiePlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        java.util.List list4 = defaultKeyedValues2D1.getColumnKeys();
        java.util.List list5 = defaultKeyedValues2D1.getRowKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        int int13 = jFreeChart8.getBackgroundImageAlignment();
        jFreeChart8.setTitle("org.jfree.chart.ChartColor[r=100,g=0,b=10]");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot1.getDatasetGroup();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean23 = chartColor21.equals((java.lang.Object) 0);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor21);
        piePlot1.setLabelLinkPaint((java.awt.Paint) chartColor21);
        java.awt.Color color26 = chartColor21.darker();
        java.awt.Color color27 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28);
        org.jfree.data.general.DatasetGroup datasetGroup30 = defaultCategoryDataset28.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color27, (org.jfree.data.general.Dataset) defaultCategoryDataset28);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        boolean boolean33 = defaultCategoryDataset28.equals((java.lang.Object) color32);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        piePlot36.addChangeListener(plotChangeListener37);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent39 = null;
        piePlot36.notifyListeners(plotChangeEvent39);
        org.jfree.chart.JFreeChart jFreeChart41 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot36);
        boolean boolean43 = jFreeChart41.equals((java.lang.Object) '4');
        java.awt.Color color44 = java.awt.Color.DARK_GRAY;
        jFreeChart41.setBackgroundPaint((java.awt.Paint) color44);
        jFreeChart41.setTextAntiAlias(true);
        boolean boolean48 = jFreeChart41.isNotify();
        jFreeChart41.setAntiAlias(false);
        boolean boolean51 = defaultCategoryDataset28.hasListener((java.util.EventListener) jFreeChart41);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent52 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color26, (org.jfree.data.general.Dataset) defaultCategoryDataset28);
        java.lang.Comparable comparable53 = null;
        try {
            defaultCategoryDataset28.removeValue(comparable53, (java.lang.Comparable) "TableOrder.BY_ROW");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(datasetGroup30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        float float2 = piePlot1.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        java.awt.Color color26 = java.awt.Color.MAGENTA;
        piePlot19.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot19);
        boolean boolean29 = rectangleInsets0.equals((java.lang.Object) jFreeChart28);
        double double31 = rectangleInsets0.calculateBottomOutset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        int int4 = multiplePiePlot0.getBackgroundImageAlignment();
        java.awt.Color color5 = java.awt.Color.blue;
        int int6 = color5.getTransparency();
        java.awt.Color color7 = color5.brighter();
        multiplePiePlot0.setBackgroundPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        double double4 = rectangleInsets0.calculateTopOutset(0.0d);
        double double5 = rectangleInsets0.getTop();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        java.lang.String str10 = standardPieSectionLabelGenerator7.generateSectionLabel(pieDataset8, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset11 = null;
        java.lang.String str13 = standardPieSectionLabelGenerator7.generateSectionLabel(pieDataset11, (java.lang.Comparable) (-1L));
        java.lang.Object obj14 = null;
        boolean boolean15 = standardPieSectionLabelGenerator7.equals(obj14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double18 = rectangleInsets16.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color24 = java.awt.Color.green;
        piePlot20.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = null;
        piePlot20.axisChanged(axisChangeEvent26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot20);
        double double29 = legendTitle28.getContentYOffset();
        legendTitle28.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle28.getBounds();
        rectangleInsets16.trim(rectangle2D32);
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D32, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D32, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity40 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D32, "Pie Plot");
        boolean boolean41 = standardPieSectionLabelGenerator7.equals((java.lang.Object) rectangle2D32);
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets0.createOutsetRectangle(rectangle2D32, true, false);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangle2D44);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        java.awt.Paint paint13 = blockBorder11.getPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getMaximumLabelWidth();
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        java.lang.Object obj10 = piePlot1.clone();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) lineBorder2);
        java.awt.Stroke stroke4 = lineBorder2.getStroke();
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        boolean boolean8 = piePlot1.getSimpleLabels();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        piePlot12.notifyListeners(plotChangeEvent15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot12);
        piePlot12.setInteriorGap(0.0d);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        piePlot22.addChangeListener(plotChangeListener23);
        java.awt.Color color25 = java.awt.Color.green;
        piePlot22.setBackgroundPaint((java.awt.Paint) color25);
        java.awt.Image image27 = piePlot22.getBackgroundImage();
        java.lang.Object obj28 = piePlot22.clone();
        boolean boolean29 = piePlot22.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        piePlot31.addChangeListener(plotChangeListener32);
        java.awt.Color color34 = java.awt.Color.green;
        piePlot31.setBackgroundPaint((java.awt.Paint) color34);
        java.awt.Stroke stroke37 = null;
        piePlot31.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke37);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator39 = piePlot31.getLegendLabelGenerator();
        piePlot31.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double44 = rectangleInsets42.calculateLeftOutset(10.0d);
        double double46 = rectangleInsets42.calculateLeftInset((double) (short) 100);
        piePlot31.setInsets(rectangleInsets42, false);
        piePlot22.setInsets(rectangleInsets42, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double53 = rectangleInsets51.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset54 = null;
        org.jfree.chart.plot.PiePlot piePlot55 = new org.jfree.chart.plot.PiePlot(pieDataset54);
        org.jfree.chart.event.PlotChangeListener plotChangeListener56 = null;
        piePlot55.addChangeListener(plotChangeListener56);
        java.awt.Color color59 = java.awt.Color.green;
        piePlot55.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color59);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent61 = null;
        piePlot55.axisChanged(axisChangeEvent61);
        org.jfree.chart.title.LegendTitle legendTitle63 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot55);
        double double64 = legendTitle63.getContentYOffset();
        legendTitle63.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D67 = legendTitle63.getBounds();
        rectangleInsets51.trim(rectangle2D67);
        org.jfree.chart.entity.ChartEntity chartEntity71 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D67, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity73 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D67, "{0}");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType75 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets42.createAdjustedRectangle(rectangle2D67, lengthAdjustmentType74, lengthAdjustmentType75);
        org.jfree.data.general.PieDataset pieDataset77 = null;
        org.jfree.chart.plot.PiePlot piePlot78 = new org.jfree.chart.plot.PiePlot(pieDataset77);
        org.jfree.chart.event.PlotChangeListener plotChangeListener79 = null;
        piePlot78.addChangeListener(plotChangeListener79);
        java.awt.Color color82 = java.awt.Color.green;
        piePlot78.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color82);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent84 = null;
        piePlot78.axisChanged(axisChangeEvent84);
        org.jfree.chart.title.LegendTitle legendTitle86 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot78);
        org.jfree.chart.ChartColor chartColor90 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean92 = chartColor90.equals((java.lang.Object) 0);
        piePlot78.setLabelPaint((java.awt.Paint) chartColor90);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo95 = null;
        org.jfree.chart.plot.PiePlotState piePlotState96 = piePlot12.initialise(graphics2D20, rectangle2D67, piePlot78, (java.lang.Integer) 3, plotRenderingInfo95);
        piePlot1.drawBackgroundImage(graphics2D9, rectangle2D67);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(piePlotState96);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean10 = jFreeChart8.equals((java.lang.Object) color9);
        jFreeChart8.setAntiAlias(false);
        try {
            org.jfree.chart.plot.XYPlot xYPlot13 = jFreeChart8.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) "java.awt.Color[r=255,g=255,b=255]");
        strokeMap0.clear();
        strokeMap0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Font font7 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent8.setType(chartChangeEventType9);
        java.lang.String str11 = chartChangeEventType9.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str11.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        defaultKeyedValues2D1.setValue((java.lang.Number) 255, (java.lang.Comparable) 0L, (java.lang.Comparable) 100L);
        java.lang.Comparable comparable8 = null;
        try {
            int int9 = defaultKeyedValues2D1.getRowIndex(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        boolean boolean11 = textTitle9.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart7.setNotify(false);
        jFreeChart7.setNotify(true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get(0);
        java.lang.Object obj4 = objectList1.clone();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        piePlot6.axisChanged(axisChangeEvent12);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator14 = piePlot6.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        piePlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color21 = java.awt.Color.green;
        piePlot18.setBackgroundPaint((java.awt.Paint) color21);
        java.awt.Image image23 = piePlot18.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot18);
        java.lang.Object obj25 = jFreeChart24.clone();
        jFreeChart24.fireChartChanged();
        java.awt.Paint paint27 = null;
        jFreeChart24.setBackgroundPaint(paint27);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart24);
        piePlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        boolean boolean31 = objectList1.equals((java.lang.Object) jFreeChart24);
        objectList1.clear();
        int int33 = objectList1.size();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator14);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(image23);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean28 = chartColor26.equals((java.lang.Object) 0);
        piePlot14.setLabelPaint((java.awt.Paint) chartColor26);
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) chartColor26);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = piePlot1.getDrawingSupplier();
        piePlot1.setCircular(false, false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(drawingSupplier31);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) -1, 15, (-12189689));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        piePlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = java.awt.Color.green;
        piePlot26.setBackgroundPaint((java.awt.Paint) color29);
        java.awt.Image image31 = piePlot26.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot26);
        java.lang.Object obj33 = jFreeChart32.clone();
        org.jfree.chart.title.LegendTitle legendTitle34 = jFreeChart32.getLegend();
        org.jfree.chart.block.BlockBorder blockBorder35 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle34.setFrame((org.jfree.chart.block.BlockFrame) blockBorder35);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle34.setLegendItemGraphicAnchor(rectangleAnchor37);
        java.awt.geom.Point2D point2D39 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor37);
        java.lang.String str40 = rectangleAnchor37.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(image31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(legendTitle34);
        org.junit.Assert.assertNotNull(blockBorder35);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(point2D39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str40.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot1.getLegendLabelToolTipGenerator();
        try {
            piePlot1.setBackgroundImageAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator17);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        boolean boolean3 = jFreeChartResources0.containsKey("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        java.lang.Object[][] objArray5 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strEnumeration4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        pieSectionEntity20.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        pieSectionEntity20.setSectionIndex(0);
        java.lang.Object obj26 = pieSectionEntity20.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot15.setBackgroundPaint((java.awt.Paint) color18);
        java.awt.Stroke stroke21 = null;
        piePlot15.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke21);
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        piePlot15.setLabelFont(font23);
        piePlot1.setLabelFont(font23);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        boolean boolean12 = jFreeChart10.isBorderVisible();
        java.awt.Image image13 = jFreeChart10.getBackgroundImage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart10.createBufferedImage((-16777216), (int) (byte) 100, (int) (byte) -1, chartRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        boolean boolean12 = piePlot1.getIgnoreNullValues();
        piePlot1.setSimpleLabels(false);
        double double15 = piePlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = null;
        piePlot23.setLegendLabelURLGenerator(pieURLGenerator24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.PiePlotState piePlotState28 = piePlot1.initialise(graphics2D20, rectangle2D21, piePlot23, (java.lang.Integer) 100, plotRenderingInfo27);
        try {
            piePlot1.setInteriorGap((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (100.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(piePlotState28);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = piePlot1.getDrawingSupplier();
        java.awt.Paint paint13 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray23 = legendTitle17.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle17.getMargin();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(legendItemSourceArray23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Set<java.lang.String> strSet2 = jFreeChartResources0.keySet();
        boolean boolean4 = jFreeChartResources0.containsKey("");
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        piePlot6.axisChanged(axisChangeEvent12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6);
        double double15 = legendTitle14.getContentYOffset();
        legendTitle14.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle14.getBounds();
        rectangleInsets2.trim(rectangle2D18);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "", "Other");
        lineBorder0.draw(graphics2D1, rectangle2D18);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = lineBorder0.getInsets();
        java.awt.Paint paint28 = lineBorder0.getPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.clearSubtitles();
        boolean boolean11 = jFreeChart8.getAntiAlias();
        jFreeChart8.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getInsets();
        piePlot1.setShadowYOffset(0.0d);
        java.lang.Object obj9 = piePlot1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot7.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot7.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = piePlot12.getToolTipGenerator();
        java.awt.Paint paint16 = piePlot12.getLabelPaint();
        java.awt.Paint paint17 = piePlot12.getLabelOutlinePaint();
        piePlot7.setLabelOutlinePaint(paint17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        piePlot7.setBaseSectionPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = null;
        piePlot7.setToolTipGenerator(pieToolTipGenerator22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Color color26 = java.awt.Color.green;
        piePlot25.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot29.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color33);
        java.awt.Font font35 = piePlot29.getLabelFont();
        piePlot25.setNoDataMessageFont(font35);
        piePlot7.setNoDataMessageFont(font35);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = null", font5, (org.jfree.chart.plot.Plot) piePlot7, true);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        try {
            jFreeChart39.setTextAntiAlias((java.lang.Object) stroke40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.awt.BasicStroke@a220003e incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(pieToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge1);
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart7.getLegend(0);
        java.awt.Paint paint10 = jFreeChart7.getBorderPaint();
        org.junit.Assert.assertNotNull(legendTitle9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.String str14 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset12, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset15, (java.lang.Comparable) (-1L));
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color19);
        boolean boolean21 = standardPieSectionLabelGenerator11.equals((java.lang.Object) color19);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        java.awt.Font font26 = piePlot23.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double29 = rectangleInsets27.calculateLeftOutset(10.0d);
        piePlot23.setSimpleLabelOffset(rectangleInsets27);
        java.lang.String str31 = rectangleInsets27.toString();
        double double33 = rectangleInsets27.extendHeight((double) 1L);
        boolean boolean34 = standardPieSectionLabelGenerator11.equals((java.lang.Object) double33);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str31.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        java.awt.Paint paint11 = textTitle9.getBackgroundPaint();
        double double12 = textTitle9.getContentYOffset();
        java.lang.String str13 = textTitle9.getToolTipText();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = textTitle9.arrange(graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        double double7 = piePlot1.getInteriorGap();
        java.awt.Paint paint9 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 10);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        boolean boolean8 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke16 = null;
        piePlot10.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot10.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateLeftOutset(10.0d);
        double double25 = rectangleInsets21.calculateLeftInset((double) (short) 100);
        piePlot10.setInsets(rectangleInsets21, false);
        piePlot1.setInsets(rectangleInsets21, false);
        piePlot1.setForegroundAlpha((float) (short) 100);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "Rotation.ANTICLOCKWISE", (java.awt.Paint) color33);
        int int35 = color33.getAlpha();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 255 + "'", int35 == 255);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle14 = jFreeChart8.getTitle();
        java.lang.Object obj15 = textTitle14.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(textTitle14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        jFreeChart19.setTitle("ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.title.TextTitle textTitle24 = jFreeChart19.getTitle();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(textTitle24);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        boolean boolean14 = jFreeChart8.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        piePlot16.setMaximumLabelWidth((double) 10.0f);
        piePlot16.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        piePlot24.addChangeListener(plotChangeListener25);
        piePlot24.setLabelLinksVisible(false);
        java.awt.Stroke stroke29 = piePlot24.getOutlineStroke();
        piePlot16.setOutlineStroke(stroke29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle31);
        java.awt.Paint paint33 = legendTitle31.getBackgroundPaint();
        java.lang.Object obj34 = legendTitle31.clone();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean10 = jFreeChart8.equals((java.lang.Object) color9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.green;
        float[] floatArray20 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray21 = color13.getRGBColorComponents(floatArray20);
        float[] floatArray22 = color11.getComponents(floatArray20);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("NOID", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getEmail();
        java.lang.String str5 = contributor2.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NOID" + "'", str3.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NOID" + "'", str5.equals("NOID"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        int int7 = piePlot1.getPieIndex();
        piePlot1.setMaximumLabelWidth((double) (short) 10);
        try {
            piePlot1.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        float float6 = piePlot1.getForegroundAlpha();
        java.awt.Color color7 = java.awt.Color.WHITE;
        piePlot1.setLabelPaint((java.awt.Paint) color7);
        java.awt.Color color9 = color7.darker();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        java.awt.Color color14 = java.awt.Color.PINK;
        java.awt.Color color15 = color14.darker();
        piePlot1.setSectionPaint((java.lang.Comparable) 100L, (java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart7.getLegend(0);
        org.jfree.chart.plot.Plot plot10 = jFreeChart7.getPlot();
        org.junit.Assert.assertNotNull(legendTitle9);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TableOrder.BY_ROW", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        java.lang.Object obj7 = defaultDrawingSupplier6.clone();
        piePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shapeArray5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        projectInfo0.addOptionalLibrary("");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart7.setNotify(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener10 = null;
        jFreeChart7.addProgressListener(chartProgressListener10);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        java.awt.Font font21 = piePlot15.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("NOID", font21);
        java.lang.String str23 = textTitle22.getToolTipText();
        java.awt.Paint paint24 = textTitle22.getBackgroundPaint();
        textTitle22.setMargin((double) '#', 100.0d, 0.0d, (double) 100L);
        try {
            jFreeChart7.addSubtitle(10, (org.jfree.chart.title.Title) textTitle22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNull(paint24);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        java.awt.Color color18 = java.awt.Color.lightGray;
        piePlot1.setOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart20.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setInteriorGap(0.0d);
        java.awt.Paint paint10 = piePlot2.getLabelLinkPaint();
        java.awt.Color color12 = java.awt.Color.gray;
        piePlot2.setSectionOutlinePaint((java.lang.Comparable) 100L, (java.awt.Paint) color12);
        int int14 = color12.getGreen();
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-254), 0.0f, (float) 1);
        int int4 = color3.getRed();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues2D1.getRowKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = blockBorder17.getInsets();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        piePlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color29 = java.awt.Color.green;
        piePlot25.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color29);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = null;
        piePlot25.axisChanged(axisChangeEvent31);
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot25);
        double double34 = legendTitle33.getContentYOffset();
        legendTitle33.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D37 = legendTitle33.getBounds();
        rectangleInsets21.trim(rectangle2D37);
        textTitle20.setBounds(rectangle2D37);
        java.awt.geom.Rectangle2D rectangle2D40 = rectangleInsets18.createOutsetRectangle(rectangle2D37);
        legendTitle10.setBounds(rectangle2D40);
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D40, "", "Rotation.CLOCKWISE");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        java.awt.Image image17 = piePlot1.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = piePlot1.getLabelDistributor();
        double double19 = piePlot1.getStartAngle();
        float float20 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle21 = piePlot1.getLabelLinkStyle();
        double double22 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 90.0d + "'", double19 == 90.0d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        boolean boolean4 = multiplePiePlot0.isOutlineVisible();
        org.jfree.chart.util.TableOrder tableOrder5 = org.jfree.chart.util.TableOrder.BY_ROW;
        multiplePiePlot0.setDataExtractOrder(tableOrder5);
        multiplePiePlot0.setForegroundAlpha((float) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(tableOrder5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        piePlot1.zoom((double) 0L);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        org.jfree.data.general.DatasetGroup datasetGroup9 = piePlot1.getDatasetGroup();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot11.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot11.axisChanged(axisChangeEvent17);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator19 = piePlot11.getLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator19);
        piePlot1.setShadowXOffset((double) 10L);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleEdge.TOP", "", "ChartChangeEventType.DATASET_UPDATED");
        basicProjectInfo4.setInfo("Other");
        basicProjectInfo4.setLicenceName("");
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        legendTitle9.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Paint paint13 = legendTitle9.getItemPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot1.getLabelDistributor();
        java.awt.Paint paint21 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint23 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 4.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getPadding();
        java.lang.Object obj11 = textTitle9.clone();
        textTitle9.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Paint paint7 = defaultDrawingSupplier5.getNextFillPaint();
        java.awt.Shape shape8 = defaultDrawingSupplier5.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        double double2 = textTitle1.getHeight();
        textTitle1.setID("ChartChangeEventType.DATASET_UPDATED");
        java.lang.String str5 = textTitle1.getID();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str5.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("org.jfree.chart.ChartColor[r=100,g=0,b=10]");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Color color3 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot2.getToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=-1]", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean7 = jFreeChart6.getAntiAlias();
        jFreeChart6.setBackgroundImageAlpha((float) 8);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.lang.Object obj7 = defaultDrawingSupplier5.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.String str3 = multiplePiePlot0.getPlotType();
        java.awt.Paint paint4 = multiplePiePlot0.getAggregatedItemsPaint();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Multiple Pie Plot" + "'", str3.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(paint4);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo0);
//        java.util.List list3 = null;
//        projectInfo0.setContributors(list3);
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("Pie Plot", "java.awt.Color[r=255,g=255,b=255]", "PieSection: 32, -1( )", "Rotation.CLOCKWISE");
//        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo9);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = piePlot1.getDrawingSupplier();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot1.getLegendLabelURLGenerator();
        piePlot1.setForegroundAlpha(0.0f);
        piePlot1.setShadowXOffset(1.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNull(pieURLGenerator13);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        float float6 = piePlot1.getForegroundAlpha();
        java.awt.Stroke stroke7 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color13);
        boolean boolean16 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.String str7 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset5, (java.lang.Comparable) (-1L));
        java.lang.Object obj8 = null;
        boolean boolean9 = standardPieSectionLabelGenerator1.equals(obj8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double12 = rectangleInsets10.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        double double23 = legendTitle22.getContentYOffset();
        legendTitle22.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle22.getBounds();
        rectangleInsets10.trim(rectangle2D26);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity32 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D26, "Pie Plot");
        boolean boolean35 = standardPieSectionLabelGenerator1.equals((java.lang.Object) rectangle2D26);
        java.lang.Object obj36 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(obj36);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke8);
        java.lang.Object obj10 = jFreeChart7.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color17 = java.awt.Color.green;
        piePlot13.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        piePlot13.axisChanged(axisChangeEvent19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot13);
        double double22 = legendTitle21.getContentYOffset();
        legendTitle21.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D25 = legendTitle21.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str27 = rectangleEdge26.toString();
        double double28 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D25, rectangleEdge26);
        boolean boolean29 = legendTitle11.equals((java.lang.Object) rectangleEdge26);
        boolean boolean30 = legendTitle11.getNotify();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleEdge.LEFT" + "'", str27.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        double double4 = rectangleInsets0.calculateLeftInset(0.08d);
        double double6 = rectangleInsets0.extendWidth((double) 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        piePlot6.axisChanged(axisChangeEvent12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6);
        double double15 = legendTitle14.getContentYOffset();
        legendTitle14.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle14.getBounds();
        rectangleInsets2.trim(rectangle2D18);
        textTitle1.setBounds(rectangle2D18);
        java.lang.String str21 = textTitle1.getText();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str21.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        legendTitle9.setMargin(0.0d, (double) (-1.0f), (double) 15, (double) (short) 0);
        org.jfree.chart.block.BlockContainer blockContainer20 = legendTitle9.getItemContainer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.Size2D size2D22 = legendTitle9.arrange(graphics2D21);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockContainer20);
        org.junit.Assert.assertNotNull(size2D22);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        piePlot1.zoom((double) 0L);
        java.lang.Object obj7 = piePlot1.clone();
        try {
            piePlot1.setInteriorGap(3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (3.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        java.lang.String str3 = rectangleInsets0.toString();
        double double4 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str3.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.lang.Comparable comparable21 = pieSectionEntity20.getSectionKey();
        java.lang.Comparable comparable22 = pieSectionEntity20.getSectionKey();
        java.lang.String str23 = pieSectionEntity20.getURLText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + ' ' + "'", comparable21.equals(' '));
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + ' ' + "'", comparable22.equals(' '));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=-1]" + "'", str23.equals("org.jfree.chart.event.ChartChangeEvent[source=-1]"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        boolean boolean9 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Color color8 = java.awt.Color.green;
        float[] floatArray15 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray16 = color8.getRGBColorComponents(floatArray15);
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color8);
        float float18 = jFreeChart7.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot0.getLegendItems();
        boolean boolean4 = multiplePiePlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle9.setLegendItemGraphicAnchor(rectangleAnchor10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D12);
        org.jfree.chart.block.BlockBorder blockBorder14 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = blockBorder14.getInsets();
        legendTitle9.setFrame((org.jfree.chart.block.BlockFrame) blockBorder14);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockBorder14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean10 = jFreeChart8.equals((java.lang.Object) color9);
        float float11 = jFreeChart8.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        java.awt.Paint paint6 = piePlot1.getLabelPaint();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        double double8 = piePlot1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.14d + "'", double8 == 0.14d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = color0.darker();
        int int2 = color1.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-5080454) + "'", int2 == (-5080454));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        boolean boolean3 = jFreeChartResources0.containsKey("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray6 = jFreeChartResources0.getStringArray("PieSection: 32, -1( )");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key PieSection: 32, -1( )");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strEnumeration4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Font font6 = piePlot1.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        piePlot8.setMaximumLabelWidth((double) 10.0f);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        piePlot14.notifyListeners(plotChangeEvent17);
        double double19 = piePlot14.getInteriorGap();
        piePlot14.setIgnoreZeroValues(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot14.getDrawingSupplier();
        piePlot8.setDrawingSupplier(drawingSupplier22);
        java.awt.Color color25 = java.awt.Color.DARK_GRAY;
        int int26 = color25.getAlpha();
        piePlot8.setSectionPaint((java.lang.Comparable) (-1.0d), (java.awt.Paint) color25);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.08d + "'", double19 == 0.08d);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        boolean boolean11 = jFreeChart9.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle12 = null;
        jFreeChart9.setTitle(textTitle12);
        jFreeChart9.setBackgroundImageAlignment((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot17.addChangeListener(plotChangeListener18);
        java.awt.Color color21 = java.awt.Color.green;
        piePlot17.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color21);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        piePlot17.axisChanged(axisChangeEvent23);
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = legendTitle25.getVerticalAlignment();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = null;
        org.jfree.chart.util.Size2D size2D29 = legendTitle25.arrange(graphics2D27, rectangleConstraint28);
        double double30 = legendTitle25.getWidth();
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle25);
        java.awt.Font font32 = legendTitle25.getItemFont();
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("hi!", font32);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("UnitType.RELATIVE", font32);
        java.lang.String str35 = textTitle34.getText();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "UnitType.RELATIVE" + "'", str35.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = null;
        standardPieSectionLabelGenerator0.setAttributedLabel((int) (short) 0, attributedString2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        java.lang.String str6 = standardPieSectionLabelGenerator0.generateSectionLabel(pieDataset4, (java.lang.Comparable) "Rotation.CLOCKWISE");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color12 = java.awt.Color.green;
        piePlot8.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color12);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        piePlot8.axisChanged(axisChangeEvent14);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot8);
        double double17 = legendTitle16.getContentYOffset();
        legendTitle16.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D20 = legendTitle16.getBounds();
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity27 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D20, pieDataset21, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        pieSectionEntity27.setPieIndex((int) ' ');
        java.lang.String str30 = pieSectionEntity27.toString();
        boolean boolean31 = standardPieSectionLabelGenerator0.equals((java.lang.Object) str30);
        java.awt.Color color32 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset33);
        org.jfree.data.general.DatasetGroup datasetGroup35 = defaultCategoryDataset33.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color32, (org.jfree.data.general.Dataset) defaultCategoryDataset33);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        boolean boolean38 = defaultCategoryDataset33.equals((java.lang.Object) color37);
        int int40 = defaultCategoryDataset33.getRowIndex((java.lang.Comparable) 10L);
        boolean boolean41 = standardPieSectionLabelGenerator0.equals((java.lang.Object) int40);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "PieSection: 32, -1( )" + "'", str30.equals("PieSection: 32, -1( )"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(datasetGroup35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        java.awt.Image image17 = piePlot1.getBackgroundImage();
        boolean boolean18 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        piePlot6.axisChanged(axisChangeEvent12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6);
        double double15 = legendTitle14.getContentYOffset();
        legendTitle14.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle14.getBounds();
        rectangleInsets2.trim(rectangle2D18);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "", "Other");
        lineBorder0.draw(graphics2D1, rectangle2D18);
        java.awt.Stroke stroke27 = lineBorder0.getStroke();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke11 = null;
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke11);
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot5);
        int int14 = defaultKeyedValues2D1.getRowCount();
        int int15 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleEdge.TOP", "", "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Color color8 = java.awt.Color.getColor("hi!", color7);
        boolean boolean9 = projectInfo5.equals((java.lang.Object) "hi!");
        projectInfo5.setCopyright("");
        java.lang.String str12 = projectInfo5.getVersion();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        basicProjectInfo4.setVersion("java.awt.Color[r=255,g=255,b=255]");
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Font font7 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = piePlot1.getLabelPadding();
        double double10 = rectangleInsets8.calculateTopOutset((double) (byte) -1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) '4');
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot0.getPieChart();
        org.jfree.data.category.CategoryDataset categoryDataset7 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart6);
        org.junit.Assert.assertNull(categoryDataset7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getMaximumLabelWidth();
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        piePlot12.notifyListeners(plotChangeEvent15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot12);
        jFreeChart17.setNotify(false);
        plot9.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        org.jfree.chart.plot.Plot plot21 = jFreeChart17.getPlot();
        jFreeChart17.fireChartChanged();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(plot21);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setPieIndex(2);
        piePlot1.setSimpleLabels(true);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = java.awt.Color.green;
        piePlot9.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Image image14 = piePlot9.getBackgroundImage();
        java.lang.Object obj15 = piePlot9.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot9.notifyListeners(plotChangeEvent16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset20 = null;
        java.lang.String str22 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset20, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset23 = null;
        java.lang.String str25 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset23, (java.lang.Comparable) (-1L));
        piePlot9.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color27);
        boolean boolean29 = standardPieSectionLabelGenerator19.equals((java.lang.Object) color27);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        boolean boolean36 = piePlot1.equals((java.lang.Object) (-1));
        java.awt.Stroke stroke37 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(2.0d, (double) (-32), 10.0d, 90.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle14 = piePlot13.getLabelLinkStyle();
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle14);
        java.awt.Image image16 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle14);
        org.junit.Assert.assertNull(image16);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("PieSection: 1, 0( )", "RectangleAnchor.TOP_LEFT", "hi!", "org.jfree.chart.ChartColor[r=100,g=0,b=10]");
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        boolean boolean4 = piePlot1.isOutlineVisible();
        try {
            piePlot1.setInteriorGap((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (100.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart19.addProgressListener(chartProgressListener22);
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart19.createBufferedImage((int) (short) 10, 8);
        java.awt.Image image27 = null;
        jFreeChart19.setBackgroundImage(image27);
        org.jfree.chart.event.ChartProgressListener chartProgressListener29 = null;
        jFreeChart19.removeProgressListener(chartProgressListener29);
        java.lang.Object obj31 = jFreeChart19.getTextAntiAlias();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(bufferedImage26);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color13);
        java.awt.Paint paint17 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) (short) 0);
        boolean boolean18 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent15 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.jfree.chart.title.Title title16 = titleChangeEvent15.getTitle();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(title16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Image image11 = piePlot6.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot6);
        java.lang.Object obj13 = jFreeChart12.clone();
        jFreeChart12.fireChartChanged();
        java.awt.Paint paint15 = null;
        jFreeChart12.setBackgroundPaint(paint15);
        java.awt.Paint paint17 = jFreeChart12.getBackgroundPaint();
        java.lang.Object obj18 = null;
        boolean boolean19 = jFreeChart12.equals(obj18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart12.createBufferedImage(15, (int) (byte) 10, 3, chartRenderingInfo23);
        multiplePiePlot0.setPieChart(jFreeChart12);
        java.lang.Object obj26 = jFreeChart12.clone();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        boolean boolean10 = piePlot1.getSimpleLabels();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.ChartChangeEvent[source=Rotation.ANTICLOCKWISE]");
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        java.awt.Stroke stroke7 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) (byte) 10);
        int int8 = piePlot1.getPieIndex();
        java.awt.Paint paint9 = piePlot1.getShadowPaint();
        try {
            piePlot1.setInteriorGap((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (10.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) legendTitle9, dataset16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle9.arrange(graphics2D19, rectangleConstraint20);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = null;
        try {
            piePlot1.setNoDataMessagePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        java.awt.Image image9 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, 1, (-246));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextPaint();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        java.awt.image.BufferedImage bufferedImage25 = jFreeChart7.createBufferedImage((int) (byte) 10, (int) (byte) 1);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart7.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(bufferedImage25);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.lang.String str25 = horizontalAlignment24.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment26, 0.0d, (double) 'a');
        columnArrangement29.clear();
        columnArrangement29.clear();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "HorizontalAlignment.CENTER" + "'", str25.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment26);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        piePlot1.setBackgroundAlpha((float) '4');
        piePlot1.setNoDataMessage("RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle16 = piePlot15.getLabelLinkStyle();
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean18 = pieLabelLinkStyle16.equals((java.lang.Object) paint17);
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle16);
        java.awt.Paint paint20 = piePlot1.getLabelShadowPaint();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        java.awt.Font font26 = piePlot23.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double29 = rectangleInsets27.calculateLeftOutset(10.0d);
        piePlot23.setSimpleLabelOffset(rectangleInsets27);
        double double32 = rectangleInsets27.extendHeight(0.0d);
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder(paint20, stroke21, rectangleInsets27);
        java.awt.Paint paint34 = lineBorder33.getPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(drawingSupplier5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getInteriorGap();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = java.awt.Color.green;
        piePlot9.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Image image14 = piePlot9.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot9);
        java.lang.Object obj16 = jFreeChart15.clone();
        jFreeChart15.fireChartChanged();
        java.awt.Paint paint18 = null;
        jFreeChart15.setBackgroundPaint(paint18);
        java.awt.Paint paint20 = jFreeChart15.getBackgroundPaint();
        org.jfree.chart.title.TextTitle textTitle21 = jFreeChart15.getTitle();
        float float22 = jFreeChart15.getBackgroundImageAlpha();
        java.awt.Stroke stroke23 = jFreeChart15.getBorderStroke();
        piePlot1.setLabelOutlineStroke(stroke23);
        boolean boolean25 = piePlot1.getIgnoreZeroValues();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        piePlot27.addChangeListener(plotChangeListener28);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent30 = null;
        piePlot27.notifyListeners(plotChangeEvent30);
        double double32 = piePlot27.getInteriorGap();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        piePlot35.addChangeListener(plotChangeListener36);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent38 = null;
        piePlot35.notifyListeners(plotChangeEvent38);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot35);
        boolean boolean42 = jFreeChart40.equals((java.lang.Object) '4');
        java.awt.Color color43 = java.awt.Color.DARK_GRAY;
        jFreeChart40.setBackgroundPaint((java.awt.Paint) color43);
        piePlot27.setLabelShadowPaint((java.awt.Paint) color43);
        piePlot1.setParent((org.jfree.chart.plot.Plot) piePlot27);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertNotNull(textTitle21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.08d + "'", double32 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setLicenceText("PieLabelLinkStyle.STANDARD");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color5 = java.awt.Color.green;
        java.awt.Color color6 = java.awt.Color.getColor("hi!", color5);
        boolean boolean7 = projectInfo3.equals((java.lang.Object) "hi!");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        boolean boolean14 = jFreeChart8.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        piePlot16.setMaximumLabelWidth((double) 10.0f);
        piePlot16.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        piePlot24.addChangeListener(plotChangeListener25);
        piePlot24.setLabelLinksVisible(false);
        java.awt.Stroke stroke29 = piePlot24.getOutlineStroke();
        piePlot16.setOutlineStroke(stroke29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle31);
        java.awt.Color color33 = java.awt.Color.blue;
        int int34 = color33.getTransparency();
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color33);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        pieSectionEntity20.setPieIndex((int) ' ');
        java.lang.String str23 = pieSectionEntity20.toString();
        java.lang.String str24 = pieSectionEntity20.getToolTipText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PieSection: 32, -1( )" + "'", str23.equals("PieSection: 32, -1( )"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "NOID" + "'", str24.equals("NOID"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.lang.Object obj4 = piePlot1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        java.awt.Color color6 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultCategoryDataset7.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color6, (org.jfree.data.general.Dataset) defaultCategoryDataset7);
        piePlot1.datasetChanged(datasetChangeEvent10);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(datasetGroup9);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        float float9 = piePlot1.getBackgroundImageAlpha();
        double double10 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = piePlot1.getLabelPadding();
        double double13 = rectangleInsets11.calculateBottomInset(3.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo0);
//        projectInfo0.setInfo("{0}");
//        java.awt.Image image5 = projectInfo0.getLogo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
//        org.junit.Assert.assertNotNull(image5);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        int int6 = piePlot1.getBackgroundImageAlignment();
        double double7 = piePlot1.getStartAngle();
        try {
            piePlot1.setBackgroundImageAlpha((-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot2.axisChanged(axisChangeEvent8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor11);
        try {
            java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int3 = java.awt.Color.HSBtoRGB((float) 100, (float) 2, (float) 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1783) + "'", int3 == (-1783));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle9.getItemContainer();
        java.lang.Object obj15 = blockContainer14.clone();
        org.jfree.chart.block.BlockFrame blockFrame16 = blockContainer14.getFrame();
        double double17 = blockContainer14.getContentYOffset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(blockFrame16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot5.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        piePlot5.axisChanged(axisChangeEvent11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = legendTitle13.getVerticalAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = null;
        org.jfree.chart.util.Size2D size2D17 = legendTitle13.arrange(graphics2D15, rectangleConstraint16);
        double double18 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle13.getLegendItemGraphicEdge();
        org.jfree.data.general.Dataset dataset20 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) legendTitle13, dataset20);
        java.awt.Paint paint22 = legendTitle13.getItemPaint();
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 1L, (double) 10, 0.0d, (double) (-12189689), paint22);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        java.awt.Stroke stroke12 = jFreeChart10.getBorderStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = jFreeChart10.getPadding();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) '4');
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        piePlot1.setLabelShadowPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, 0.0f, (float) 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-15) + "'", int3 == (-15));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setBackgroundImageAlignment(255);
        double double6 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        try {
            java.lang.Object obj4 = jFreeChartResources0.getObject("TableOrder.BY_COLUMN");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key TableOrder.BY_COLUMN");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleEdge0.equals(obj1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        defaultKeyedValues2D1.setValue((java.lang.Number) (short) 100, (java.lang.Comparable) 0.08d, (java.lang.Comparable) "0,0,1,1");
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) "http://www.jfree.org/jfreechart/index.html", (java.lang.Comparable) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getTop();
        double double3 = rectangleInsets0.extendWidth(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        projectInfo0.setLicenceText("hi!");
//        projectInfo0.setInfo("Other");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        double double11 = rectangleInsets5.calculateLeftOutset((double) 8);
        double double12 = rectangleInsets5.getBottom();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot13.notifyListeners(plotChangeEvent16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color24 = java.awt.Color.green;
        piePlot20.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color24);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = null;
        piePlot20.axisChanged(axisChangeEvent26);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot20);
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = legendTitle28.getVerticalAlignment();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = null;
        org.jfree.chart.util.Size2D size2D32 = legendTitle28.arrange(graphics2D30, rectangleConstraint31);
        jFreeChart18.addSubtitle((org.jfree.chart.title.Title) legendTitle28);
        org.jfree.chart.title.TextTitle textTitle34 = jFreeChart18.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = textTitle34.getTextAlignment();
        textTitle34.setPadding((double) (short) 0, (double) 1L, (double) (short) 1, (double) (short) 100);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) textTitle34);
        float float42 = jFreeChart8.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(verticalAlignment29);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertNotNull(textTitle34);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.5f + "'", float42 == 0.5f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke11 = null;
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke11);
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot5);
        int int14 = defaultKeyedValues2D1.getRowCount();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset17 = null;
        java.lang.String str19 = standardPieSectionLabelGenerator16.generateSectionLabel(pieDataset17, (java.lang.Comparable) (-1));
        boolean boolean21 = standardPieSectionLabelGenerator16.equals((java.lang.Object) (short) 100);
        java.text.AttributedString attributedString23 = null;
        standardPieSectionLabelGenerator16.setAttributedLabel((int) (short) 10, attributedString23);
        boolean boolean25 = defaultKeyedValues2D1.equals((java.lang.Object) attributedString23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot5.notifyListeners(plotChangeEvent8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot5.getInsets();
        piePlot5.setShadowYOffset(0.0d);
        java.awt.Paint paint13 = piePlot5.getLabelBackgroundPaint();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) (-1L), (double) 8, (double) 0L, (double) (byte) 1, paint13);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.awt.Color color0 = java.awt.Color.gray;
        float[] floatArray3 = new float[] { 255, (-246) };
        try {
            float[] floatArray4 = color0.getComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot1.axisChanged(axisChangeEvent10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart9.setBorderStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets12.calculateLeftOutset(10.0d);
        double double16 = rectangleInsets12.calculateRightOutset((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke10, rectangleInsets12);
        double double19 = rectangleInsets12.extendHeight(0.14d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.14d + "'", double19 == 0.14d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        int int8 = defaultKeyedValues2D1.getRowCount();
        int int10 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100);
        defaultKeyedValues2D1.addValue((java.lang.Number) (-2.0d), (java.lang.Comparable) "Other", (java.lang.Comparable) "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        piePlot10.notifyListeners(plotChangeEvent13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot10);
        boolean boolean17 = jFreeChart15.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle18 = null;
        jFreeChart15.setTitle(textTitle18);
        jFreeChart15.setBackgroundImageAlignment((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color27 = java.awt.Color.green;
        piePlot23.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color27);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = null;
        piePlot23.axisChanged(axisChangeEvent29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23);
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = legendTitle31.getVerticalAlignment();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint34 = null;
        org.jfree.chart.util.Size2D size2D35 = legendTitle31.arrange(graphics2D33, rectangleConstraint34);
        double double36 = legendTitle31.getWidth();
        jFreeChart15.addSubtitle((org.jfree.chart.title.Title) legendTitle31);
        java.awt.Font font38 = legendTitle31.getItemFont();
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("hi!", font38);
        piePlot1.setLabelFont(font38);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(size2D35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint paint18 = legendTitle17.getItemPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        int int8 = defaultKeyedValues2D1.getRowCount();
        int int9 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        java.lang.String str2 = projectInfo0.getLicenceText();
        java.lang.String str3 = projectInfo0.getCopyright();
        projectInfo0.setLicenceText("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent3);
        int int5 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot8.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot12.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        java.awt.Font font18 = piePlot12.getLabelFont();
        piePlot8.setNoDataMessageFont(font18);
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("NOID", font18);
        multiplePiePlot0.setNoDataMessageFont(font18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        java.awt.Paint paint5 = blockBorder4.getPaint();
        java.awt.Paint paint6 = blockBorder4.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder4.getInsets();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets0.getUnitType();
        double double20 = rectangleInsets0.calculateBottomOutset((double) 255);
        double double22 = rectangleInsets0.trimWidth(90.0d);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D26 = rectangleInsets0.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType24, lengthAdjustmentType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 90.0d + "'", double22 == 90.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.String str7 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset5, (java.lang.Comparable) (-1L));
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str9 = projectInfo8.getLicenceText();
        boolean boolean10 = standardPieSectionLabelGenerator1.equals((java.lang.Object) projectInfo8);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot12.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        java.awt.Font font18 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent19.setType(chartChangeEventType20);
        org.jfree.chart.plot.Plot plot22 = plotChangeEvent19.getPlot();
        org.jfree.chart.plot.Plot plot23 = plotChangeEvent19.getPlot();
        boolean boolean24 = standardPieSectionLabelGenerator1.equals((java.lang.Object) plotChangeEvent19);
        java.lang.String str25 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNotNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.RenderingHints renderingHints9 = jFreeChart8.getRenderingHints();
        java.util.List list10 = null;
        try {
            jFreeChart8.setSubtitles(list10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(renderingHints9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset1.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        boolean boolean6 = defaultCategoryDataset1.equals((java.lang.Object) color5);
        int int8 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) 10L);
        defaultCategoryDataset1.setValue((double) (-1), (java.lang.Comparable) (-12189689), (java.lang.Comparable) "Pie Plot");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        java.lang.Comparable comparable4 = null;
        try {
            defaultCategoryDataset1.incrementValue(0.14d, comparable4, (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        float float6 = piePlot1.getForegroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot1.setURLGenerator(pieURLGenerator7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        piePlot1.datasetChanged(datasetChangeEvent9);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.chart.util.Rotation rotation5 = piePlot1.getDirection();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.lang.String str25 = horizontalAlignment24.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment26, 0.0d, (double) 'a');
        columnArrangement29.clear();
        java.lang.Object obj31 = null;
        boolean boolean32 = columnArrangement29.equals(obj31);
        columnArrangement29.clear();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "HorizontalAlignment.CENTER" + "'", str25.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        int int3 = defaultCategoryDataset1.getRowCount();
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultCategoryDataset1.getGroup();
        java.util.List list5 = defaultCategoryDataset1.getRowKeys();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        java.awt.Image image17 = piePlot1.getBackgroundImage();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(image17);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        boolean boolean23 = pieSectionEntity20.equals((java.lang.Object) (byte) 1);
        java.lang.String str24 = pieSectionEntity20.toString();
        java.lang.String str25 = pieSectionEntity20.getURLText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PieSection: 1, -1( )" + "'", str24.equals("PieSection: 1, -1( )"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=-1]" + "'", str25.equals("org.jfree.chart.event.ChartChangeEvent[source=-1]"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        double double18 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart9.setBorderStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets12.calculateLeftOutset(10.0d);
        double double16 = rectangleInsets12.calculateRightOutset((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke10, rectangleInsets12);
        java.awt.Paint paint18 = lineBorder17.getPaint();
        java.awt.Stroke stroke19 = lineBorder17.getStroke();
        java.awt.Paint paint20 = lineBorder17.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        java.awt.Stroke stroke10 = jFreeChart8.getBorderStroke();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color17 = java.awt.Color.green;
        piePlot13.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        piePlot13.axisChanged(axisChangeEvent19);
        org.jfree.chart.title.LegendTitle legendTitle21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = legendTitle21.getVerticalAlignment();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = null;
        org.jfree.chart.util.Size2D size2D25 = legendTitle21.arrange(graphics2D23, rectangleConstraint24);
        java.awt.Font font26 = legendTitle21.getItemFont();
        try {
            jFreeChart8.addSubtitle((-1), (org.jfree.chart.title.Title) legendTitle21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(size2D25);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-32), 255, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.awt.Font font25 = textTitle23.getFont();
        java.lang.Object obj26 = textTitle23.clone();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        defaultKeyedValues2D1.setValue((java.lang.Number) 255, (java.lang.Comparable) 0L, (java.lang.Comparable) 100L);
        java.lang.Object obj8 = defaultKeyedValues2D1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.awt.Font font10 = textTitle9.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle9.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        java.lang.String str5 = projectInfo0.getLicenceText();
        java.lang.String str6 = projectInfo0.getLicenceText();
        java.lang.String str7 = projectInfo0.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str7.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot1.getInsets();
        piePlot1.setIgnoreZeroValues(false);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double4 = rectangleInsets2.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color10 = java.awt.Color.green;
        piePlot6.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        piePlot6.axisChanged(axisChangeEvent12);
        org.jfree.chart.title.LegendTitle legendTitle14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot6);
        double double15 = legendTitle14.getContentYOffset();
        legendTitle14.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D18 = legendTitle14.getBounds();
        rectangleInsets2.trim(rectangle2D18);
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D18, "Pie Plot");
        try {
            blockBorder0.draw(graphics2D1, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D18);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        int int5 = defaultCategoryDataset2.getRowIndex((java.lang.Comparable) "Multiple Pie Plot");
        int int6 = defaultCategoryDataset2.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        java.awt.Color color18 = java.awt.Color.lightGray;
        piePlot1.setOutlinePaint((java.awt.Paint) color18);
        java.awt.Color color20 = java.awt.Color.green;
        float[] floatArray27 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color18.getColorComponents(floatArray27);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str1 = tableOrder0.toString();
        java.lang.String str2 = tableOrder0.toString();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset3.getGroup();
        int int7 = defaultCategoryDataset3.getRowIndex((java.lang.Comparable) "HorizontalAlignment.CENTER");
        boolean boolean8 = tableOrder0.equals((java.lang.Object) int7);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_ROW" + "'", str1.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TableOrder.BY_ROW" + "'", str2.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        jFreeChart19.fireChartChanged();
        java.awt.Paint paint22 = null;
        jFreeChart19.setBackgroundPaint(paint22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart19);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.event.ChartChangeListener chartChangeListener26 = null;
        try {
            jFreeChart19.addChangeListener(chartChangeListener26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.String str14 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset12, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset15, (java.lang.Comparable) (-1L));
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        piePlot1.setCircular(false, false);
        java.awt.Paint paint23 = piePlot1.getSectionPaint((java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) '#', (double) (-1.0f), (double) 1.0f, (java.awt.Paint) color4);
        int int6 = color4.getRGB();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-8355712) + "'", int6 == (-8355712));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        java.lang.Object obj14 = null;
        boolean boolean15 = jFreeChart8.equals(obj14);
        org.jfree.chart.event.ChartChangeListener chartChangeListener16 = null;
        try {
            jFreeChart8.addChangeListener(chartChangeListener16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getInsets();
        piePlot1.setShadowYOffset(0.0d);
        piePlot1.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        java.awt.Paint paint24 = textTitle23.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNull(paint24);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        java.awt.Paint paint11 = textTitle9.getBackgroundPaint();
        textTitle9.setPadding(0.08d, 100.0d, (double) (short) 1, 1.0d);
        textTitle9.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        pieSectionEntity20.setPieIndex((int) ' ');
        java.lang.String str23 = pieSectionEntity20.toString();
        java.lang.Comparable comparable24 = pieSectionEntity20.getSectionKey();
        java.lang.String str25 = pieSectionEntity20.getShapeType();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PieSection: 32, -1( )" + "'", str23.equals("PieSection: 32, -1( )"));
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + ' ' + "'", comparable24.equals(' '));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "rect" + "'", str25.equals("rect"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16);
        java.lang.String str19 = chartEntity18.getToolTipText();
        java.lang.String str20 = chartEntity18.toString();
        chartEntity18.setToolTipText("PieLabelLinkStyle.STANDARD");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ChartEntity: tooltip = null" + "'", str20.equals("ChartEntity: tooltip = null"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot7.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint11 = piePlot7.getLabelPaint();
        boolean boolean12 = piePlot1.equals((java.lang.Object) piePlot7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot7.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator13);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart7.getLegend(0);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str11 = rectangleEdge10.toString();
        java.lang.String str12 = rectangleEdge10.toString();
        legendTitle9.setPosition(rectangleEdge10);
        org.junit.Assert.assertNotNull(legendTitle9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleEdge.LEFT" + "'", str11.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleEdge.LEFT" + "'", str12.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart19.addProgressListener(chartProgressListener22);
        boolean boolean24 = jFreeChart19.isNotify();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        projectInfo0.addOptionalLibrary("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle1.getMargin();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = piePlot17.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator19 = piePlot17.getToolTipGenerator();
        java.lang.Object obj20 = piePlot17.clone();
        boolean boolean21 = textTitle1.equals(obj20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = textTitle1.arrange(graphics2D22, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(drawingSupplier18);
        org.junit.Assert.assertNull(pieToolTipGenerator19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean10 = jFreeChart8.equals((java.lang.Object) color9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color11);
        boolean boolean13 = jFreeChart8.getAntiAlias();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        double double10 = piePlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.08d + "'", double10 == 0.08d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.getColor("VerticalAlignment.TOP", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = piePlot1.getDrawingSupplier();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot1.getLegendLabelURLGenerator();
        piePlot1.setForegroundAlpha(0.0f);
        double double16 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        piePlot1.zoom((double) 0L);
        java.lang.Object obj7 = piePlot1.clone();
        piePlot1.setSimpleLabels(false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        piePlot1.setShadowPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        java.awt.Paint paint11 = textTitle9.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        try {
            textTitle9.setTextAlignment(horizontalAlignment12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        int int4 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot0.getPieChart();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        piePlot8.notifyListeners(plotChangeEvent11);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot8);
        boolean boolean15 = jFreeChart13.equals((java.lang.Object) '4');
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        jFreeChart13.setBackgroundPaint((java.awt.Paint) color16);
        jFreeChart13.setTextAntiAlias(true);
        java.awt.RenderingHints renderingHints20 = jFreeChart13.getRenderingHints();
        jFreeChart5.setRenderingHints(renderingHints20);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(renderingHints20);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = piePlot1.getDrawingSupplier();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        java.awt.Font font20 = piePlot14.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot14);
        org.jfree.chart.plot.Plot plot22 = plotChangeEvent21.getPlot();
        piePlot1.notifyListeners(plotChangeEvent21);
        boolean boolean24 = piePlot1.isCircular();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(drawingSupplier12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        org.jfree.chart.title.LegendTitle legendTitle10 = jFreeChart8.getLegend();
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle10.setFrame((org.jfree.chart.block.BlockFrame) blockBorder11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle10.setLegendItemGraphicAnchor(rectangleAnchor13);
        java.awt.Font font15 = legendTitle10.getItemFont();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets19.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color27 = java.awt.Color.green;
        piePlot23.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color27);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = null;
        piePlot23.axisChanged(axisChangeEvent29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot23);
        double double32 = legendTitle31.getContentYOffset();
        legendTitle31.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D35 = legendTitle31.getBounds();
        rectangleInsets19.trim(rectangle2D35);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D35, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity42 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D35, "", "Other");
        lineBorder17.draw(graphics2D18, rectangle2D35);
        org.jfree.data.general.PieDataset pieDataset44 = null;
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot(pieDataset44);
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        piePlot45.addChangeListener(plotChangeListener46);
        java.awt.Color color48 = java.awt.Color.green;
        piePlot45.setBackgroundPaint((java.awt.Paint) color48);
        java.awt.Image image50 = piePlot45.getBackgroundImage();
        java.lang.Object obj51 = piePlot45.clone();
        java.awt.Color color53 = java.awt.Color.green;
        java.awt.Color color54 = java.awt.Color.getColor("hi!", color53);
        piePlot45.setLabelBackgroundPaint((java.awt.Paint) color53);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier56 = piePlot45.getDrawingSupplier();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator57 = piePlot45.getLegendLabelURLGenerator();
        try {
            java.lang.Object obj58 = legendTitle10.draw(graphics2D16, rectangle2D35, (java.lang.Object) piePlot45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(legendTitle10);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(image50);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(drawingSupplier56);
        org.junit.Assert.assertNull(pieURLGenerator57);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        java.awt.Image image17 = jFreeChart16.getBackgroundImage();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        jFreeChart16.setBorderStroke(stroke18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint8, stroke18, rectangleInsets20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        boolean boolean23 = pieSectionEntity20.equals((java.lang.Object) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        pieSectionEntity20.setDataset(pieDataset24);
        java.lang.String str26 = pieSectionEntity20.toString();
        int int27 = pieSectionEntity20.getSectionIndex();
        org.jfree.data.general.PieDataset pieDataset28 = pieSectionEntity20.getDataset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PieSection: 1, -1( )" + "'", str26.equals("PieSection: 1, -1( )"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(pieDataset28);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        textTitle1.setURLText("");
        textTitle1.setExpandToFitSpace(true);
        boolean boolean19 = textTitle1.getExpandToFitSpace();
        double double20 = textTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Image image11 = piePlot6.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot6);
        java.lang.Object obj13 = jFreeChart12.clone();
        jFreeChart12.fireChartChanged();
        java.awt.Paint paint15 = null;
        jFreeChart12.setBackgroundPaint(paint15);
        java.awt.Paint paint17 = jFreeChart12.getBackgroundPaint();
        java.lang.Object obj18 = null;
        boolean boolean19 = jFreeChart12.equals(obj18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart12.createBufferedImage(15, (int) (byte) 10, 3, chartRenderingInfo23);
        multiplePiePlot0.setPieChart(jFreeChart12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent26);
        double double28 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart8.getTitle();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = textTitle9.getPadding();
        java.lang.Object obj11 = textTitle9.clone();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        piePlot16.notifyListeners(plotChangeEvent19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot16);
        boolean boolean23 = jFreeChart21.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle24 = null;
        jFreeChart21.setTitle(textTitle24);
        jFreeChart21.setBackgroundImageAlignment((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot29.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color33);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = null;
        piePlot29.axisChanged(axisChangeEvent35);
        org.jfree.chart.title.LegendTitle legendTitle37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = legendTitle37.getVerticalAlignment();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = null;
        org.jfree.chart.util.Size2D size2D41 = legendTitle37.arrange(graphics2D39, rectangleConstraint40);
        double double42 = legendTitle37.getWidth();
        jFreeChart21.addSubtitle((org.jfree.chart.title.Title) legendTitle37);
        java.awt.Font font44 = legendTitle37.getItemFont();
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("hi!", font44);
        org.jfree.chart.title.TextTitle textTitle46 = new org.jfree.chart.title.TextTitle("UnitType.RELATIVE", font44);
        java.awt.Font font47 = textTitle46.getFont();
        textTitle9.setFont(font47);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(textTitle9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(font47);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj6 = objectList4.get(0);
        java.lang.Object obj7 = objectList4.clone();
        objectList4.clear();
        java.lang.Object obj9 = null;
        int int10 = objectList4.indexOf(obj9);
        java.lang.Object obj11 = objectList4.clone();
        boolean boolean12 = defaultCategoryDataset1.equals((java.lang.Object) objectList4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setInteriorGap(0.0d);
        java.awt.Paint paint10 = piePlot2.getLabelLinkPaint();
        java.awt.Color color12 = java.awt.Color.gray;
        piePlot2.setSectionOutlinePaint((java.lang.Comparable) 100L, (java.awt.Paint) color12);
        int int14 = piePlot2.getPieIndex();
        java.lang.Comparable comparable15 = null;
        try {
            double double16 = piePlot2.getExplodePercent(comparable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) "java.awt.Color[r=255,g=255,b=255]");
        strokeMap0.clear();
        java.lang.Object obj4 = strokeMap0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        boolean boolean8 = piePlot1.getSimpleLabels();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset11 = null;
        java.lang.String str13 = standardPieSectionLabelGenerator10.generateSectionLabel(pieDataset11, (java.lang.Comparable) (-1));
        boolean boolean15 = standardPieSectionLabelGenerator10.equals((java.lang.Object) (short) 100);
        java.text.AttributedString attributedString17 = null;
        standardPieSectionLabelGenerator10.setAttributedLabel((int) (short) 10, attributedString17);
        java.text.AttributedString attributedString20 = null;
        standardPieSectionLabelGenerator10.setAttributedLabel(0, attributedString20);
        java.lang.Object obj22 = standardPieSectionLabelGenerator10.clone();
        piePlot1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Rotation.ANTICLOCKWISE");
        java.text.NumberFormat numberFormat3 = standardPieSectionLabelGenerator2.getNumberFormat();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        piePlot5.setLabelLinksVisible(false);
        piePlot5.setMaximumLabelWidth((double) '4');
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        java.lang.Object obj19 = piePlot13.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        piePlot13.notifyListeners(plotChangeEvent20);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset24 = null;
        java.lang.String str26 = standardPieSectionLabelGenerator23.generateSectionLabel(pieDataset24, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset27 = null;
        java.lang.String str29 = standardPieSectionLabelGenerator23.generateSectionLabel(pieDataset27, (java.lang.Comparable) (-1L));
        piePlot13.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator23);
        java.awt.Color color31 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color31);
        boolean boolean33 = standardPieSectionLabelGenerator23.equals((java.lang.Object) color31);
        piePlot5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator23);
        java.text.NumberFormat numberFormat35 = standardPieSectionLabelGenerator23.getPercentFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("UnitType.ABSOLUTE", numberFormat3, numberFormat35);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(numberFormat35);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart9.setBorderStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets12.calculateLeftOutset(10.0d);
        double double16 = rectangleInsets12.calculateRightOutset((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke10, rectangleInsets12);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        piePlot19.setMaximumLabelWidth((double) 10.0f);
        piePlot19.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        piePlot27.addChangeListener(plotChangeListener28);
        piePlot27.setLabelLinksVisible(false);
        java.awt.Stroke stroke32 = piePlot27.getOutlineStroke();
        piePlot19.setOutlineStroke(stroke32);
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        boolean boolean35 = rectangleInsets12.equals((java.lang.Object) piePlot19);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        legendTitle9.setLegendItemGraphicPadding(rectangleInsets11);
        org.jfree.chart.block.BlockFrame blockFrame13 = legendTitle9.getFrame();
        java.awt.Color color16 = java.awt.Color.getColor("hi!", (int) '#');
        legendTitle9.setBackgroundPaint((java.awt.Paint) color16);
        double double18 = legendTitle9.getHeight();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle9.arrange(graphics2D19, rectangleConstraint20);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(blockFrame13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(size2D21);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        double double10 = piePlot1.getMaximumLabelWidth();
        java.awt.Color color14 = java.awt.Color.green;
        float[] floatArray21 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray22 = color14.getRGBColorComponents(floatArray21);
        float[] floatArray23 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (byte) 100, (int) (byte) 10, floatArray22);
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (byte) 100, dataset24);
        org.jfree.data.general.Dataset dataset26 = datasetChangeEvent25.getDataset();
        piePlot1.datasetChanged(datasetChangeEvent25);
        org.jfree.chart.plot.Plot plot28 = piePlot1.getParent();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14d + "'", double10 == 0.14d);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNull(dataset26);
        org.junit.Assert.assertNull(plot28);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        org.jfree.chart.ChartColor chartColor16 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean18 = chartColor16.equals((java.lang.Object) 0);
        piePlot4.setLabelPaint((java.awt.Paint) chartColor16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color24 = java.awt.Color.green;
        float[] floatArray31 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray32 = color24.getRGBColorComponents(floatArray31);
        float[] floatArray33 = java.awt.Color.RGBtoHSB((int) '#', (int) '4', 1, floatArray31);
        float[] floatArray34 = color20.getComponents(floatArray31);
        java.awt.Color color38 = java.awt.Color.green;
        float[] floatArray45 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray46 = color38.getRGBColorComponents(floatArray45);
        float[] floatArray47 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (byte) 100, (int) (byte) 10, floatArray46);
        float[] floatArray48 = color20.getColorComponents(floatArray46);
        float[] floatArray49 = chartColor16.getRGBComponents(floatArray48);
        float[] floatArray50 = java.awt.Color.RGBtoHSB((-5080454), (int) (byte) -1, 0, floatArray48);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) ' ');
        java.awt.Paint paint8 = piePlot1.getNoDataMessagePaint();
        piePlot1.setNoDataMessage("HorizontalAlignment.CENTER");
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        boolean boolean3 = jFreeChartResources0.containsKey("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray6 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strEnumeration4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Pie Plot", "java.awt.Color[r=255,g=255,b=255]", "PieSection: 32, -1( )", "Rotation.CLOCKWISE");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        basicProjectInfo4.setVersion("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        java.lang.String str22 = pieSectionEntity20.getToolTipText();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "NOID" + "'", str22.equals("NOID"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection6 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.util.TableOrder tableOrder7 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str8 = tableOrder7.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder7);
        java.lang.Object obj10 = null;
        boolean boolean11 = tableOrder7.equals(obj10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(tableOrder7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TableOrder.BY_ROW" + "'", str8.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        boolean boolean14 = jFreeChart8.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        piePlot16.setMaximumLabelWidth((double) 10.0f);
        piePlot16.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        piePlot24.addChangeListener(plotChangeListener25);
        piePlot24.setLabelLinksVisible(false);
        java.awt.Stroke stroke29 = piePlot24.getOutlineStroke();
        piePlot16.setOutlineStroke(stroke29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle31);
        legendTitle31.setID("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.clearSubtitles();
        boolean boolean11 = jFreeChart8.getAntiAlias();
        java.awt.Image image12 = jFreeChart8.getBackgroundImage();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = legendTitle22.getVerticalAlignment();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = null;
        org.jfree.chart.util.Size2D size2D26 = legendTitle22.arrange(graphics2D24, rectangleConstraint25);
        double double27 = legendTitle22.getWidth();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent28 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle22);
        jFreeChart8.titleChanged(titleChangeEvent28);
        org.jfree.chart.title.Title title30 = titleChangeEvent28.getTitle();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(image12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(title30);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        piePlot7.notifyListeners(plotChangeEvent10);
        double double12 = piePlot7.getInteriorGap();
        piePlot7.setIgnoreZeroValues(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = piePlot7.getDrawingSupplier();
        piePlot1.setDrawingSupplier(drawingSupplier15);
        java.awt.Color color18 = java.awt.Color.DARK_GRAY;
        int int19 = color18.getAlpha();
        piePlot1.setSectionPaint((java.lang.Comparable) (-1.0d), (java.awt.Paint) color18);
        double double21 = piePlot1.getShadowYOffset();
        java.lang.Object obj22 = piePlot1.clone();
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.08d + "'", double12 == 0.08d);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        java.lang.Object[][] objArray3 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        java.lang.String str2 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str2.equals("Rotation.ANTICLOCKWISE"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Other", "", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        int int3 = objectList1.indexOf((java.lang.Object) "ChartChangeEventType.DATASET_UPDATED");
        java.lang.Object obj5 = objectList1.get((-15));
        java.lang.Object obj7 = objectList1.get(255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.lang.String str25 = horizontalAlignment24.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement29 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment24, verticalAlignment26, 0.0d, (double) 'a');
        columnArrangement29.clear();
        java.lang.Object obj31 = null;
        boolean boolean32 = columnArrangement29.equals(obj31);
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        double double35 = textTitle34.getHeight();
        textTitle34.setText("");
        java.awt.Color color38 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        piePlot41.addChangeListener(plotChangeListener42);
        java.awt.Color color44 = java.awt.Color.green;
        piePlot41.setBackgroundPaint((java.awt.Paint) color44);
        java.awt.Image image46 = piePlot41.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot41);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart47.setBorderStroke(stroke48);
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double52 = rectangleInsets50.calculateLeftOutset(10.0d);
        double double54 = rectangleInsets50.calculateRightOutset((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder55 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color38, stroke48, rectangleInsets50);
        columnArrangement29.add((org.jfree.chart.block.Block) textTitle34, (java.lang.Object) stroke48);
        columnArrangement29.clear();
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "HorizontalAlignment.CENTER" + "'", str25.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(image46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Image image9 = piePlot4.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot4);
        java.lang.Object obj11 = jFreeChart10.clone();
        jFreeChart10.fireChartChanged();
        java.awt.Paint paint13 = null;
        jFreeChart10.setBackgroundPaint(paint13);
        java.awt.Paint paint15 = jFreeChart10.getBackgroundPaint();
        java.lang.Object obj16 = null;
        boolean boolean17 = jFreeChart10.equals(obj16);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        java.awt.image.BufferedImage bufferedImage22 = jFreeChart10.createBufferedImage(15, (int) (byte) 10, 3, chartRenderingInfo21);
        boolean boolean23 = chartChangeEventType0.equals((java.lang.Object) 3);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(bufferedImage22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.awt.Font font10 = textTitle9.getFont();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = piePlot12.getLabelLinkStyle();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        boolean boolean15 = pieLabelLinkStyle13.equals((java.lang.Object) paint14);
        textTitle9.setBackgroundPaint(paint14);
        textTitle9.setNotify(true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        double double10 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot1.setLabelLinkPaint(paint11);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke13);
        piePlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14d + "'", double10 == 0.14d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        legendTitle9.setMargin(0.0d, (double) (-1.0f), (double) 15, (double) (short) 0);
        org.jfree.chart.block.BlockContainer blockContainer20 = legendTitle9.getItemContainer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) 3, (double) (short) 0, (double) (short) 1);
        double double27 = rectangleInsets26.getLeft();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        piePlot32.addChangeListener(plotChangeListener33);
        java.awt.Color color36 = java.awt.Color.green;
        piePlot32.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color36);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent38 = null;
        piePlot32.axisChanged(axisChangeEvent38);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot32);
        double double41 = legendTitle40.getContentYOffset();
        legendTitle40.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D44 = legendTitle40.getBounds();
        rectangleInsets28.trim(rectangle2D44);
        org.jfree.chart.entity.ChartEntity chartEntity48 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D44, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity50 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D44, "{0}");
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets26.createInsetRectangle(rectangle2D44);
        try {
            blockContainer20.draw(graphics2D21, rectangle2D51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockContainer20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangle2D51);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent6 = null;
        piePlot3.notifyListeners(plotChangeEvent6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot3);
        boolean boolean10 = jFreeChart8.equals((java.lang.Object) '4');
        java.awt.Color color11 = java.awt.Color.DARK_GRAY;
        jFreeChart8.setBackgroundPaint((java.awt.Paint) color11);
        jFreeChart8.setTextAntiAlias(true);
        textTitle0.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset18 = null;
        java.lang.String str20 = standardPieSectionLabelGenerator17.generateSectionLabel(pieDataset18, (java.lang.Comparable) (-1));
        boolean boolean22 = standardPieSectionLabelGenerator17.equals((java.lang.Object) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets23.getTop();
        boolean boolean25 = standardPieSectionLabelGenerator17.equals((java.lang.Object) rectangleInsets23);
        jFreeChart8.setPadding(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16);
        java.lang.String str19 = chartEntity18.getURLText();
        java.lang.String str20 = chartEntity18.getShapeCoords();
        java.lang.String str21 = chartEntity18.getShapeCoords();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0,0,1,1" + "'", str20.equals("0,0,1,1"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0,0,1,1" + "'", str21.equals("0,0,1,1"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot1.getLegendLabelToolTipGenerator();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_RED;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Color color3 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = piePlot2.getToolTipGenerator();
        org.jfree.chart.JFreeChart jFreeChart6 = new org.jfree.chart.JFreeChart("org.jfree.chart.event.ChartChangeEvent[source=-1]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        piePlot2.setLabelOutlineStroke(stroke7);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(pieToolTipGenerator5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        boolean boolean14 = jFreeChart8.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color20 = java.awt.Color.green;
        piePlot16.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color20);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        piePlot16.axisChanged(axisChangeEvent22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        org.jfree.chart.util.VerticalAlignment verticalAlignment25 = legendTitle24.getVerticalAlignment();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = null;
        org.jfree.chart.util.Size2D size2D28 = legendTitle24.arrange(graphics2D26, rectangleConstraint27);
        double double29 = legendTitle24.getWidth();
        legendTitle24.setWidth((double) 0L);
        jFreeChart8.addSubtitle((org.jfree.chart.title.Title) legendTitle24);
        jFreeChart8.setBackgroundImageAlignment((int) (short) 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(verticalAlignment25);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.calculateLeftOutset(10.0d);
        piePlot2.setSimpleLabelOffset(rectangleInsets6);
        boolean boolean10 = flowArrangement0.equals((java.lang.Object) rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        blockContainer11.clear();
        blockContainer11.clear();
        java.lang.Object obj14 = blockContainer11.clone();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        int int3 = defaultCategoryDataset1.getRowCount();
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultCategoryDataset1.getGroup();
        java.lang.String str5 = datasetGroup4.getID();
        java.lang.Object obj6 = datasetGroup4.clone();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NOID" + "'", str5.equals("NOID"));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator20);
        java.lang.String str22 = piePlot1.getPlotType();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Pie Plot" + "'", str22.equals("Pie Plot"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener18 = null;
        jFreeChart16.addProgressListener(chartProgressListener18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        try {
            java.awt.image.BufferedImage bufferedImage24 = jFreeChart16.createBufferedImage((-1), (int) (byte) 100, 2, chartRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (100) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue(1, (-5080454));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.String str7 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset5, (java.lang.Comparable) (-1L));
        java.lang.Object obj8 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        java.lang.String str2 = projectInfo0.getLicenceText();
        java.lang.String str3 = projectInfo0.getCopyright();
        projectInfo0.setLicenceText("Pie Plot");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.event.ChartChangeEvent[source=-1]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) projectInfo0);
        java.lang.String str3 = projectInfo0.getInfo();
        projectInfo0.setLicenceName("PieSection: 1, -1( )");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Other" + "'", str3.equals("Other"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        multiplePiePlot7.setDataset(categoryDataset8);
        java.lang.Comparable comparable10 = multiplePiePlot7.getAggregatedItemsKey();
        int int11 = multiplePiePlot7.getBackgroundImageAlignment();
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot7.getPieChart();
        java.awt.Paint paint13 = jFreeChart12.getBorderPaint();
        piePlot1.setLabelPaint(paint13);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Font font14 = piePlot11.getLabelFont();
        piePlot4.setNoDataMessageFont(font14);
        boolean boolean16 = rotation0.equals((java.lang.Object) piePlot4);
        java.lang.String str17 = rotation0.toString();
        double double18 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str17.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        java.awt.Image image17 = piePlot1.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = piePlot1.getLabelDistributor();
        double double19 = piePlot1.getStartAngle();
        float float20 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle21 = piePlot1.getLabelLinkStyle();
        java.awt.Paint paint22 = null;
        piePlot1.setLabelBackgroundPaint(paint22);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 90.0d + "'", double19 == 90.0d);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.5f + "'", float20 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle21);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "", "Other");
        chartEntity23.setURLText("Other");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color11 = java.awt.Color.green;
        float[] floatArray18 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray19 = color11.getRGBColorComponents(floatArray18);
        float[] floatArray20 = color10.getRGBComponents(floatArray19);
        float[] floatArray21 = color6.getColorComponents(colorSpace9, floatArray20);
        java.awt.Color color25 = java.awt.Color.green;
        float[] floatArray32 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray33 = color25.getRGBColorComponents(floatArray32);
        float[] floatArray34 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (byte) 100, (int) (byte) 10, floatArray33);
        float[] floatArray35 = color0.getColorComponents(colorSpace9, floatArray34);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.awt.Font font10 = textTitle9.getFont();
        textTitle9.setExpandToFitSpace(true);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot13 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        multiplePiePlot13.setDataset(categoryDataset14);
        double double16 = multiplePiePlot13.getLimit();
        multiplePiePlot13.setLimit((double) '4');
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot13.getPieChart();
        textTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart19);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        piePlot1.notifyListeners(plotChangeEvent8);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        java.lang.String str14 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset12, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieSectionLabelGenerator11.generateSectionLabel(pieDataset15, (java.lang.Comparable) (-1L));
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator11);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        try {
            java.text.AttributedString attributedString21 = standardPieSectionLabelGenerator11.generateAttributedSectionLabel(pieDataset19, (java.lang.Comparable) "Multiple Pie Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        java.awt.Color color26 = java.awt.Color.MAGENTA;
        piePlot19.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot19);
        boolean boolean29 = rectangleInsets0.equals((java.lang.Object) jFreeChart28);
        java.util.List list30 = jFreeChart28.getSubtitles();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue((int) (short) -1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        int int3 = defaultCategoryDataset1.getRowCount();
        defaultCategoryDataset1.addValue((double) 0L, (java.lang.Comparable) "HorizontalAlignment.CENTER", (java.lang.Comparable) (byte) 0);
        try {
            defaultCategoryDataset1.removeRow((java.lang.Comparable) "RectangleEdge.LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        try {
            java.awt.image.BufferedImage bufferedImage29 = jFreeChart7.createBufferedImage((int) (short) 10, 0, (double) (short) 1, (double) '4', chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (10) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        int int4 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot0.getParent();
        java.lang.Comparable comparable6 = null;
        try {
            multiplePiePlot0.setAggregatedItemsKey(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(plot5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-254), 0.0f, (float) 1);
        int int4 = color3.getRGB();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot1.getLabelDistributor();
        piePlot1.setLabelGap((double) (byte) 100);
        piePlot1.setBackgroundAlpha((float) 0L);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
        org.junit.Assert.assertNull(pieSectionLabelGenerator25);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        legendTitle9.setVerticalAlignment(verticalAlignment15);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray17 = legendTitle9.getSources();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertNotNull(legendItemSourceArray17);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Color color9 = java.awt.Color.green;
        java.awt.Color color10 = java.awt.Color.getColor("hi!", color9);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color9);
        int int12 = piePlot1.getPieIndex();
        piePlot1.setSimpleLabels(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color10);
        jFreeChart7.setTextAntiAlias(true);
        boolean boolean14 = jFreeChart7.isNotify();
        org.jfree.chart.title.Title title16 = jFreeChart7.getSubtitle(0);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        piePlot19.notifyListeners(plotChangeEvent22);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot19);
        piePlot19.setInteriorGap(0.0d);
        java.awt.Paint paint27 = piePlot19.getLabelLinkPaint();
        java.awt.Color color28 = java.awt.Color.MAGENTA;
        piePlot19.setLabelShadowPaint((java.awt.Paint) color28);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = piePlot19.getLabelPadding();
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = blockBorder35.getInsets();
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double41 = rectangleInsets39.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        org.jfree.chart.event.PlotChangeListener plotChangeListener44 = null;
        piePlot43.addChangeListener(plotChangeListener44);
        java.awt.Color color47 = java.awt.Color.green;
        piePlot43.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color47);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = null;
        piePlot43.axisChanged(axisChangeEvent49);
        org.jfree.chart.title.LegendTitle legendTitle51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot43);
        double double52 = legendTitle51.getContentYOffset();
        legendTitle51.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D55 = legendTitle51.getBounds();
        rectangleInsets39.trim(rectangle2D55);
        textTitle38.setBounds(rectangle2D55);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets36.createOutsetRectangle(rectangle2D55);
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets30.createOutsetRectangle(rectangle2D55, false, true);
        title16.setMargin(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(title16);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean28 = chartColor26.equals((java.lang.Object) 0);
        piePlot14.setLabelPaint((java.awt.Paint) chartColor26);
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) chartColor26);
        org.jfree.data.general.PieDataset pieDataset31 = piePlot1.getDataset();
        java.lang.Comparable comparable32 = null;
        try {
            double double33 = piePlot1.getExplodePercent(comparable32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(pieDataset31);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent1.getChart();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1L) + "'", obj2.equals((-1L)));
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("rect");
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary("Other");
        projectInfo0.setCopyright("VerticalAlignment.CENTER");
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Image image11 = piePlot6.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot6);
        java.lang.Object obj13 = jFreeChart12.clone();
        jFreeChart12.fireChartChanged();
        java.awt.Paint paint15 = null;
        jFreeChart12.setBackgroundPaint(paint15);
        java.awt.Paint paint17 = jFreeChart12.getBackgroundPaint();
        java.lang.Object obj18 = null;
        boolean boolean19 = jFreeChart12.equals(obj18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart12.createBufferedImage(15, (int) (byte) 10, 3, chartRenderingInfo23);
        multiplePiePlot0.setPieChart(jFreeChart12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent26);
        java.lang.String str28 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Multiple Pie Plot" + "'", str28.equals("Multiple Pie Plot"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=255,g=255,b=255]", "hi!", "hi!", image3, "", "", "hi!");
        java.awt.Image image8 = projectInfo7.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str10 = projectInfo9.getInfo();
        projectInfo9.setName("");
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo9);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(projectInfo9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Other" + "'", str10.equals("Other"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        java.awt.Color color6 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 15);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color6);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block9 = null;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        piePlot12.notifyListeners(plotChangeEvent15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        piePlot19.axisChanged(axisChangeEvent25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = legendTitle27.getVerticalAlignment();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = null;
        org.jfree.chart.util.Size2D size2D31 = legendTitle27.arrange(graphics2D29, rectangleConstraint30);
        jFreeChart17.addSubtitle((org.jfree.chart.title.Title) legendTitle27);
        flowArrangement8.add(block9, (java.lang.Object) legendTitle27);
        org.jfree.chart.block.FlowArrangement flowArrangement34 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) multiplePiePlot0, (org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.chart.block.Arrangement) flowArrangement34);
        org.jfree.chart.block.FlowArrangement flowArrangement36 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot(pieDataset37);
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        piePlot38.addChangeListener(plotChangeListener39);
        java.awt.Font font41 = piePlot38.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double44 = rectangleInsets42.calculateLeftOutset(10.0d);
        piePlot38.setSimpleLabelOffset(rectangleInsets42);
        boolean boolean46 = flowArrangement36.equals((java.lang.Object) rectangleInsets42);
        org.jfree.chart.block.BlockContainer blockContainer47 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement36);
        blockContainer47.clear();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = null;
        try {
            org.jfree.chart.util.Size2D size2D51 = flowArrangement34.arrange(blockContainer47, graphics2D49, rectangleConstraint50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(size2D31);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        defaultKeyedValues2D1.setValue((java.lang.Number) (short) 100, (java.lang.Comparable) 0.08d, (java.lang.Comparable) "0,0,1,1");
        java.util.List list12 = defaultKeyedValues2D1.getRowKeys();
        int int13 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-254), 0.0f, (float) 1);
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getRGBComponents(floatArray4);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot2.axisChanged(axisChangeEvent8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.jfree.chart.ChartColor chartColor14 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean16 = chartColor14.equals((java.lang.Object) 0);
        piePlot2.setLabelPaint((java.awt.Paint) chartColor14);
        java.awt.Image image18 = piePlot2.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor19 = piePlot2.getLabelDistributor();
        double double20 = piePlot2.getStartAngle();
        float float21 = piePlot2.getBackgroundImageAlpha();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle22 = piePlot2.getLabelLinkStyle();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint24 = lineBorder23.getPaint();
        piePlot2.setLabelPaint(paint24);
        boolean boolean26 = multiplePiePlot0.equals((java.lang.Object) paint24);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 90.0d + "'", double20 == 90.0d);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Color color8 = java.awt.Color.green;
        float[] floatArray15 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray16 = color8.getRGBColorComponents(floatArray15);
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color18 = color8.darker();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(10.0d);
        double double4 = rectangleInsets0.calculateRightOutset((double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        double double2 = textTitle1.getHeight();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean8 = chartColor6.equals((java.lang.Object) 0);
        int int9 = chartColor6.getAlpha();
        textTitle1.setPaint((java.awt.Paint) chartColor6);
        java.lang.Object obj11 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) 1L);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot10);
        double double19 = legendTitle18.getContentYOffset();
        legendTitle18.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str24 = rectangleEdge23.toString();
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D22, rectangleEdge23);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        piePlot27.addChangeListener(plotChangeListener28);
        java.awt.Color color30 = java.awt.Color.green;
        piePlot27.setBackgroundPaint((java.awt.Paint) color30);
        java.awt.Stroke stroke33 = null;
        piePlot27.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = piePlot27.getLegendItems();
        boolean boolean36 = piePlot27.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot27);
        java.awt.Paint paint38 = piePlot27.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.PiePlotState piePlotState41 = piePlot1.initialise(graphics2D8, rectangle2D22, piePlot27, (java.lang.Integer) 8, plotRenderingInfo40);
        org.jfree.chart.block.LineBorder lineBorder42 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint43 = lineBorder42.getPaint();
        piePlot1.setLabelShadowPaint(paint43);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.LEFT" + "'", str24.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(piePlotState41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot1.getLabelGenerator();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator11);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        boolean boolean10 = legendTitle9.getNotify();
        legendTitle9.setID("VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        boolean boolean8 = piePlot1.isOutlineVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) "UnitType.ABSOLUTE", stroke11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator22 = piePlot14.getLegendLabelGenerator();
        double double23 = piePlot14.getMaximumLabelWidth();
        java.awt.Color color27 = java.awt.Color.green;
        float[] floatArray34 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray35 = color27.getRGBColorComponents(floatArray34);
        float[] floatArray36 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (byte) 100, (int) (byte) 10, floatArray35);
        org.jfree.data.general.Dataset dataset37 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (byte) 100, dataset37);
        org.jfree.data.general.Dataset dataset39 = datasetChangeEvent38.getDataset();
        piePlot14.datasetChanged(datasetChangeEvent38);
        piePlot1.datasetChanged(datasetChangeEvent38);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.14d + "'", double23 == 0.14d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNull(dataset39);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = piePlot2.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot2.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot2.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot7.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint11 = piePlot7.getLabelPaint();
        java.awt.Paint paint12 = piePlot7.getLabelOutlinePaint();
        piePlot2.setLabelOutlinePaint(paint12);
        boolean boolean14 = piePlot2.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color20 = java.awt.Color.green;
        piePlot16.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color20);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        piePlot16.axisChanged(axisChangeEvent22);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator24 = piePlot16.getLabelGenerator();
        piePlot2.setLegendLabelGenerator(pieSectionLabelGenerator24);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = piePlot2.getLegendItems();
        boolean boolean27 = color0.equals((java.lang.Object) legendItemCollection26);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(drawingSupplier3);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator24);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str15 = rectangleEdge14.toString();
        double double16 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D13, rectangleEdge14);
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge14);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.LEFT" + "'", str15.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.fireChartChanged();
        java.awt.Paint paint11 = null;
        jFreeChart8.setBackgroundPaint(paint11);
        java.awt.Paint paint13 = jFreeChart8.getBackgroundPaint();
        boolean boolean14 = jFreeChart8.getAntiAlias();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        piePlot16.setMaximumLabelWidth((double) 10.0f);
        piePlot16.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        piePlot24.addChangeListener(plotChangeListener25);
        piePlot24.setLabelLinksVisible(false);
        java.awt.Stroke stroke29 = piePlot24.getOutlineStroke();
        piePlot16.setOutlineStroke(stroke29);
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        jFreeChart8.removeSubtitle((org.jfree.chart.title.Title) legendTitle31);
        org.jfree.chart.event.ChartProgressListener chartProgressListener33 = null;
        jFreeChart8.addProgressListener(chartProgressListener33);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("NOID", "org.jfree.chart.ChartColor[r=100,g=0,b=10]", "", "PieSection: 1, 0( )");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        jFreeChart19.fireChartChanged();
        java.awt.Paint paint22 = null;
        jFreeChart19.setBackgroundPaint(paint22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart19);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot29.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color33);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot29);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean37 = jFreeChart35.equals((java.lang.Object) color36);
        piePlot1.setBaseSectionPaint((java.awt.Paint) color36);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean15 = chartColor13.equals((java.lang.Object) 0);
        piePlot1.setLabelPaint((java.awt.Paint) chartColor13);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        piePlot19.axisChanged(axisChangeEvent25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        piePlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot30.setBackgroundPaint((java.awt.Paint) color33);
        java.awt.Image image35 = piePlot30.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot30);
        java.lang.Object obj37 = jFreeChart36.clone();
        org.jfree.chart.title.LegendTitle legendTitle38 = jFreeChart36.getLegend();
        legendTitle27.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart36);
        jFreeChart36.setBackgroundImageAlpha(0.0f);
        boolean boolean42 = legendTitle17.equals((java.lang.Object) jFreeChart36);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator45 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset46 = null;
        java.lang.String str48 = standardPieSectionLabelGenerator45.generateSectionLabel(pieDataset46, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset49 = null;
        java.lang.String str51 = standardPieSectionLabelGenerator45.generateSectionLabel(pieDataset49, (java.lang.Comparable) (-1L));
        java.lang.Object obj52 = null;
        boolean boolean53 = standardPieSectionLabelGenerator45.equals(obj52);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double56 = rectangleInsets54.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.plot.PiePlot piePlot58 = new org.jfree.chart.plot.PiePlot(pieDataset57);
        org.jfree.chart.event.PlotChangeListener plotChangeListener59 = null;
        piePlot58.addChangeListener(plotChangeListener59);
        java.awt.Color color62 = java.awt.Color.green;
        piePlot58.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color62);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent64 = null;
        piePlot58.axisChanged(axisChangeEvent64);
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot58);
        double double67 = legendTitle66.getContentYOffset();
        legendTitle66.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D70 = legendTitle66.getBounds();
        rectangleInsets54.trim(rectangle2D70);
        org.jfree.chart.entity.ChartEntity chartEntity74 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D70, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity76 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D70, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity78 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D70, "Pie Plot");
        boolean boolean79 = standardPieSectionLabelGenerator45.equals((java.lang.Object) rectangle2D70);
        org.jfree.data.general.PieDataset pieDataset80 = null;
        org.jfree.chart.plot.PiePlot piePlot81 = new org.jfree.chart.plot.PiePlot(pieDataset80);
        org.jfree.chart.event.PlotChangeListener plotChangeListener82 = null;
        piePlot81.addChangeListener(plotChangeListener82);
        java.awt.Color color85 = java.awt.Color.green;
        piePlot81.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color85);
        java.awt.Font font87 = piePlot81.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent88 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot81);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType89 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent88.setType(chartChangeEventType89);
        try {
            java.lang.Object obj91 = legendTitle17.draw(graphics2D43, rectangle2D70, (java.lang.Object) plotChangeEvent88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(image35);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(legendTitle38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertNotNull(font87);
        org.junit.Assert.assertNotNull(chartChangeEventType89);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        boolean boolean6 = standardPieSectionLabelGenerator1.equals((java.lang.Object) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getTop();
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) rectangleInsets7);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets12.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color20 = java.awt.Color.green;
        piePlot16.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color20);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        piePlot16.axisChanged(axisChangeEvent22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        double double25 = legendTitle24.getContentYOffset();
        legendTitle24.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D28 = legendTitle24.getBounds();
        rectangleInsets12.trim(rectangle2D28);
        textTitle11.setBounds(rectangle2D28);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets7.createOutsetRectangle(rectangle2D28, false, false);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D28);
        java.lang.String str35 = chartEntity34.getToolTipText();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        piePlot1.zoom((double) 0L);
        java.lang.Object obj7 = piePlot1.clone();
        piePlot1.setSimpleLabels(false);
        piePlot1.setCircular(false, true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(2.0d, (double) 10, (double) 255, (double) 255);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent1.getType();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) rectangleInsets4);
        java.lang.String str6 = chartChangeEventType3.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1L) + "'", obj2.equals((-1L)));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str6.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        double double10 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        piePlot1.setLabelLinkPaint(paint11);
        piePlot1.setNoDataMessage("VerticalAlignment.TOP");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.14d + "'", double10 == 0.14d);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        int int4 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(categoryDataset5);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.CUBIC_CURVE" + "'", str1.equals("PieLabelLinkStyle.CUBIC_CURVE"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) ' ');
        java.awt.Paint paint8 = piePlot1.getNoDataMessagePaint();
        piePlot1.setNoDataMessage("HorizontalAlignment.CENTER");
        boolean boolean11 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        boolean boolean12 = piePlot1.getIgnoreNullValues();
        boolean boolean13 = piePlot1.isOutlineVisible();
        java.lang.Object obj14 = piePlot1.clone();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        piePlot16.setLabelLinksVisible(false);
        piePlot16.setMaximumLabelWidth((double) '4');
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        piePlot24.addChangeListener(plotChangeListener25);
        java.awt.Color color27 = java.awt.Color.green;
        piePlot24.setBackgroundPaint((java.awt.Paint) color27);
        java.awt.Image image29 = piePlot24.getBackgroundImage();
        java.lang.Object obj30 = piePlot24.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = null;
        piePlot24.notifyListeners(plotChangeEvent31);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator34 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset35 = null;
        java.lang.String str37 = standardPieSectionLabelGenerator34.generateSectionLabel(pieDataset35, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset38 = null;
        java.lang.String str40 = standardPieSectionLabelGenerator34.generateSectionLabel(pieDataset38, (java.lang.Comparable) (-1L));
        piePlot24.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator34);
        java.awt.Color color42 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color42);
        boolean boolean44 = standardPieSectionLabelGenerator34.equals((java.lang.Object) color42);
        piePlot16.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator34);
        org.jfree.chart.block.BlockBorder blockBorder50 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        boolean boolean51 = piePlot16.equals((java.lang.Object) (-1));
        java.awt.Font font52 = piePlot16.getLabelFont();
        piePlot1.setLabelFont(font52);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(image29);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(font52);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        multiplePiePlot11.setDataset(categoryDataset12);
        java.lang.Comparable comparable14 = multiplePiePlot11.getAggregatedItemsKey();
        java.awt.Color color17 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 15);
        multiplePiePlot11.setAggregatedItemsPaint((java.awt.Paint) color17);
        legendTitle9.setItemPaint((java.awt.Paint) color17);
        double double20 = legendTitle9.getHeight();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + "Other" + "'", comparable14.equals("Other"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        multiplePiePlot0.handleClick(8, (int) (byte) 1, plotRenderingInfo5);
        java.awt.Paint paint7 = multiplePiePlot0.getAggregatedItemsPaint();
        double double8 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Font font12 = piePlot9.getLabelFont();
        piePlot2.setNoDataMessageFont(font12);
        org.jfree.chart.util.Rotation rotation14 = piePlot2.getDirection();
        double double15 = rotation14.getFactor();
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(rotation14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        double double8 = piePlot1.getExplodePercent((java.lang.Comparable) 'a');
        piePlot1.setMaximumLabelWidth((double) 100.0f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        int int4 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot0.getParent();
        java.lang.String str6 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Multiple Pie Plot" + "'", str6.equals("Multiple Pie Plot"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.clearSubtitles();
        java.util.List list11 = jFreeChart8.getSubtitles();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = null;
        try {
            jFreeChart8.titleChanged(titleChangeEvent12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        java.awt.Image image2 = null;
        projectInfo0.setLogo(image2);
        java.lang.String str4 = projectInfo0.toString();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str4.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        piePlot1.handleClick(100, 0, plotRenderingInfo10);
        piePlot1.setBackgroundImageAlignment((int) (byte) 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        legendTitle9.setMargin(0.0d, (double) (-1.0f), (double) 15, (double) (short) 0);
        org.jfree.chart.block.BlockContainer blockContainer20 = legendTitle9.getItemContainer();
        blockContainer20.clear();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(blockContainer20);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle1.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle1.getTextAlignment();
        textTitle1.setNotify(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double21 = rectangleInsets19.calculateRightOutset((double) 0.5f);
        textTitle1.setMargin(rectangleInsets19);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        java.awt.Shape shape21 = chartEntity20.getArea();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        boolean boolean8 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke16 = null;
        piePlot10.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot10.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateLeftOutset(10.0d);
        double double25 = rectangleInsets21.calculateLeftInset((double) (short) 100);
        piePlot10.setInsets(rectangleInsets21, false);
        piePlot1.setInsets(rectangleInsets21, false);
        piePlot1.setForegroundAlpha((float) (short) 100);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "Rotation.ANTICLOCKWISE", (java.awt.Paint) color33);
        float float35 = piePlot1.getBackgroundAlpha();
        java.awt.Stroke stroke36 = piePlot1.getLabelLinkStroke();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str1 = tableOrder0.toString();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot5.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color9);
        java.awt.Font font11 = piePlot5.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("NOID", font11);
        java.awt.Font font13 = textTitle12.getFont();
        textTitle12.setExpandToFitSpace(true);
        blockContainer2.add((org.jfree.chart.block.Block) textTitle12);
        boolean boolean17 = tableOrder0.equals((java.lang.Object) textTitle12);
        java.lang.String str18 = tableOrder0.toString();
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TableOrder.BY_ROW" + "'", str1.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TableOrder.BY_ROW" + "'", str18.equals("TableOrder.BY_ROW"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.calculateLeftOutset(10.0d);
        piePlot2.setSimpleLabelOffset(rectangleInsets6);
        boolean boolean10 = flowArrangement0.equals((java.lang.Object) rectangleInsets6);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
        java.lang.Object obj12 = blockContainer11.clone();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Image image10 = piePlot5.getBackgroundImage();
        java.lang.Object obj11 = piePlot5.clone();
        boolean boolean12 = piePlot5.isOutlineVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextOutlineStroke();
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) "UnitType.ABSOLUTE", stroke15);
        multiplePiePlot3.setParent((org.jfree.chart.plot.Plot) piePlot5);
        piePlot5.setIgnoreZeroValues(true);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("UnitType.RELATIVE", font1, (org.jfree.chart.plot.Plot) piePlot5, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset1.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        defaultCategoryDataset1.addValue((java.lang.Number) (byte) -1, (java.lang.Comparable) (-254), (java.lang.Comparable) 100.0d);
        java.util.List list9 = defaultCategoryDataset1.getColumnKeys();
        java.util.List list10 = defaultCategoryDataset1.getRowKeys();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Image image8 = jFreeChart7.getBackgroundImage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart7.createBufferedImage((-16777216), (-5080454), chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-16777216) and height (-5080454) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(image8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        java.lang.Object obj11 = textTitle9.clone();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = piePlot1.getLabelLinkStyle();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = piePlot1.getDrawingSupplier();
        piePlot1.setMaximumLabelWidth(1.0E-5d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getInteriorGap();
        java.lang.Object obj7 = piePlot1.clone();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        piePlot1.handleClick(100, 0, plotRenderingInfo10);
        piePlot1.setCircular(true, true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        int int8 = defaultKeyedValues2D1.getRowCount();
        int int10 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100);
        defaultKeyedValues2D1.setValue((java.lang.Number) 0.0f, (java.lang.Comparable) 10L, (java.lang.Comparable) (-15));
        try {
            java.lang.Number number17 = defaultKeyedValues2D1.getValue((java.lang.Comparable) 0, (java.lang.Comparable) "rect");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: rect");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        int int8 = defaultKeyedValues2D1.getRowCount();
        int int10 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 100);
        defaultKeyedValues2D1.setValue((java.lang.Number) 0.0f, (java.lang.Comparable) 10L, (java.lang.Comparable) (-15));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot15 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot15.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = multiplePiePlot15.getLegendItems();
        boolean boolean19 = defaultKeyedValues2D1.equals((java.lang.Object) multiplePiePlot15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.lang.Object obj4 = piePlot1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        piePlot7.setMaximumLabelWidth((double) 10.0f);
        piePlot7.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        piePlot15.setLabelLinksVisible(false);
        java.awt.Stroke stroke20 = piePlot15.getOutlineStroke();
        piePlot7.setOutlineStroke(stroke20);
        piePlot1.setOutlineStroke(stroke20);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        boolean boolean4 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.lang.Object obj4 = piePlot1.clone();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle5 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.lang.String str4 = unitType3.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UnitType.ABSOLUTE" + "'", str4.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) 1L);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot10);
        double double19 = legendTitle18.getContentYOffset();
        legendTitle18.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str24 = rectangleEdge23.toString();
        double double25 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D22, rectangleEdge23);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        piePlot27.addChangeListener(plotChangeListener28);
        java.awt.Color color30 = java.awt.Color.green;
        piePlot27.setBackgroundPaint((java.awt.Paint) color30);
        java.awt.Stroke stroke33 = null;
        piePlot27.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke33);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = piePlot27.getLegendItems();
        boolean boolean36 = piePlot27.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot27);
        java.awt.Paint paint38 = piePlot27.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.plot.PiePlotState piePlotState41 = piePlot1.initialise(graphics2D8, rectangle2D22, piePlot27, (java.lang.Integer) 8, plotRenderingInfo40);
        java.awt.Paint paint42 = piePlot27.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "RectangleEdge.LEFT" + "'", str24.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(legendItemCollection35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(piePlotState41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "NOID", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "0,0,1,1", "HorizontalAlignment.CENTER");
        basicProjectInfo5.setCopyright("0,0,1,1");
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup("UnitType.ABSOLUTE");
        defaultCategoryDataset0.setGroup(datasetGroup3);
        java.lang.String str5 = datasetGroup3.getID();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UnitType.ABSOLUTE" + "'", str5.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        legendTitle9.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener22 = null;
        jFreeChart19.addProgressListener(chartProgressListener22);
        jFreeChart19.setNotify(false);
        java.lang.Object obj26 = jFreeChart19.getTextAntiAlias();
        java.lang.Object obj27 = jFreeChart19.getTextAntiAlias();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(obj27);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        piePlot9.setLabelLinksVisible(false);
        java.awt.Stroke stroke14 = piePlot9.getOutlineStroke();
        piePlot1.setOutlineStroke(stroke14);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray17 = legendTitle16.getSources();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(legendItemSourceArray17);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setBackgroundImageAlignment(255);
        java.lang.Comparable comparable6 = null;
        try {
            multiplePiePlot0.setAggregatedItemsKey(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendTitle9.getLegendItemGraphicPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle9.getPadding();
        java.lang.Object obj12 = null;
        boolean boolean13 = legendTitle9.equals(obj12);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setSimpleLabels(false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        jFreeChart7.setBackgroundPaint((java.awt.Paint) color10);
        jFreeChart7.setTextAntiAlias(true);
        boolean boolean14 = jFreeChart7.isNotify();
        org.jfree.chart.title.Title title16 = jFreeChart7.getSubtitle(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = title16.getPadding();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(title16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Font font7 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent8.setType(chartChangeEventType9);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot13.notifyListeners(plotChangeEvent16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot13);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart18.setBorderStroke(stroke19);
        java.lang.Object obj21 = jFreeChart18.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart18.getLegend();
        plotChangeEvent8.setChart(jFreeChart18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        java.awt.image.BufferedImage bufferedImage27 = jFreeChart18.createBufferedImage((int) 'a', 2, chartRenderingInfo26);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(bufferedImage27);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        defaultKeyedValues2D1.setValue((java.lang.Number) (short) 100, (java.lang.Comparable) 0.08d, (java.lang.Comparable) "0,0,1,1");
        java.util.List list12 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list13 = defaultKeyedValues2D1.getRowKeys();
        try {
            defaultKeyedValues2D1.removeRow(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart8.clearSubtitles();
        jFreeChart8.setNotify(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent3);
        multiplePiePlot0.setLimit((double) 0);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) ' ');
        org.jfree.chart.util.TableOrder tableOrder9 = org.jfree.chart.util.TableOrder.BY_ROW;
        java.lang.String str10 = tableOrder9.toString();
        java.lang.String str11 = tableOrder9.toString();
        multiplePiePlot0.setDataExtractOrder(tableOrder9);
        java.awt.Paint paint13 = multiplePiePlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(tableOrder9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TableOrder.BY_ROW" + "'", str10.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TableOrder.BY_ROW" + "'", str11.equals("TableOrder.BY_ROW"));
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = piePlot1.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        piePlot1.handleClick(100, 0, plotRenderingInfo10);
        java.lang.String str12 = piePlot1.getPlotType();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie Plot" + "'", str12.equals("Pie Plot"));
        org.junit.Assert.assertNull(pieSectionLabelGenerator13);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup3 = new org.jfree.data.general.DatasetGroup("UnitType.ABSOLUTE");
        defaultCategoryDataset0.setGroup(datasetGroup3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        piePlot6.notifyListeners(plotChangeEvent9);
        java.awt.Paint paint11 = piePlot6.getLabelLinkPaint();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot6);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        boolean boolean12 = piePlot1.getIgnoreNullValues();
        piePlot1.setSimpleLabels(false);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        piePlot16.setLabelLinksVisible(false);
        java.awt.Stroke stroke21 = piePlot16.getOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke21);
        piePlot1.setLabelLinkMargin((double) 15);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection6 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot7.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        defaultCategoryDataset8.addValue((java.lang.Number) 15, (java.lang.Comparable) "ChartEntity: tooltip = null", (java.lang.Comparable) (-1L));
        java.util.List list15 = defaultCategoryDataset8.getColumnKeys();
        try {
            defaultCategoryDataset8.removeRow((java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = multiplePiePlot1.getLegendItems();
        boolean boolean5 = paintMap0.equals((java.lang.Object) multiplePiePlot1);
        java.lang.Object obj6 = paintMap0.clone();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setInteriorGap(0.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot2.removeChangeListener(plotChangeListener10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 10);
        int int2 = pieLabelDistributor1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("rect", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        boolean boolean12 = piePlot3.isSubplot();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = null;
        piePlot15.notifyListeners(plotChangeEvent18);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart20.setNotify(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart20.addProgressListener(chartProgressListener23);
        org.jfree.chart.event.ChartProgressListener chartProgressListener25 = null;
        jFreeChart20.addProgressListener(chartProgressListener25);
        java.awt.Paint paint27 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        jFreeChart20.setBorderPaint(paint27);
        piePlot3.setLabelShadowPaint(paint27);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        boolean boolean13 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot15.getLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator23);
        int int25 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot1.getDatasetGroup();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean23 = chartColor21.equals((java.lang.Object) 0);
        piePlot9.setLabelPaint((java.awt.Paint) chartColor21);
        piePlot1.setLabelLinkPaint((java.awt.Paint) chartColor21);
        java.awt.Color color26 = chartColor21.darker();
        int int27 = chartColor21.getRed();
        int int28 = chartColor21.getGreen();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(pieURLGenerator7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        pieSectionEntity20.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        pieSectionEntity20.setSectionIndex(0);
        java.lang.String str26 = pieSectionEntity20.toString();
        pieSectionEntity20.setURLText("");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PieSection: 1, 0( )" + "'", str26.equals("PieSection: 1, 0( )"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.util.Set<java.lang.String> strSet4 = jFreeChartResources0.keySet();
        boolean boolean6 = jFreeChartResources0.containsKey("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.lang.Object obj1 = null;
        boolean boolean2 = lineBorder0.equals(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo2 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str3 = projectInfo2.getCopyright();
        java.awt.Image image4 = null;
        projectInfo2.setLogo(image4);
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo2);
        projectInfo2.setLicenceText("http://www.jfree.org/jfreechart/index.html");
        org.jfree.chart.ui.Library[] libraryArray9 = projectInfo2.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(libraryArray9);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 2, (float) (-246), (float) (-15));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        boolean boolean6 = standardPieSectionLabelGenerator1.equals((java.lang.Object) (short) 100);
        java.text.AttributedString attributedString8 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel((int) (short) 10, attributedString8);
        java.text.AttributedString attributedString11 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel(0, attributedString11);
        java.lang.Object obj13 = standardPieSectionLabelGenerator1.clone();
        java.lang.Object obj14 = null;
        boolean boolean15 = standardPieSectionLabelGenerator1.equals(obj14);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        java.awt.Color color18 = java.awt.Color.lightGray;
        piePlot1.setOutlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = piePlot1.getLabelShadowPaint();
        piePlot1.setMaximumLabelWidth((double) 'a');
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color9);
        java.awt.Image image11 = piePlot6.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot6);
        java.lang.Object obj13 = jFreeChart12.clone();
        jFreeChart12.fireChartChanged();
        java.awt.Paint paint15 = null;
        jFreeChart12.setBackgroundPaint(paint15);
        java.awt.Paint paint17 = jFreeChart12.getBackgroundPaint();
        java.lang.Object obj18 = null;
        boolean boolean19 = jFreeChart12.equals(obj18);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = null;
        java.awt.image.BufferedImage bufferedImage24 = jFreeChart12.createBufferedImage(15, (int) (byte) 10, 3, chartRenderingInfo23);
        multiplePiePlot0.setPieChart(jFreeChart12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        multiplePiePlot0.markerChanged(markerChangeEvent26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Font font32 = piePlot29.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateLeftOutset(10.0d);
        piePlot29.setSimpleLabelOffset(rectangleInsets33);
        java.lang.String str37 = rectangleInsets33.toString();
        double double39 = rectangleInsets33.calculateLeftOutset((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double42 = rectangleInsets40.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset43 = null;
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot(pieDataset43);
        org.jfree.chart.event.PlotChangeListener plotChangeListener45 = null;
        piePlot44.addChangeListener(plotChangeListener45);
        java.awt.Color color48 = java.awt.Color.green;
        piePlot44.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color48);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent50 = null;
        piePlot44.axisChanged(axisChangeEvent50);
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot44);
        double double53 = legendTitle52.getContentYOffset();
        legendTitle52.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D56 = legendTitle52.getBounds();
        rectangleInsets40.trim(rectangle2D56);
        org.jfree.chart.entity.ChartEntity chartEntity60 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D56, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity62 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D56, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity64 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D56, "Pie Plot");
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets33.createOutsetRectangle(rectangle2D56, false, true);
        multiplePiePlot0.setInsets(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(image11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(bufferedImage24);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str37.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = piePlot1.getLabelLinkStyle();
        org.jfree.chart.ChartColor chartColor6 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean8 = chartColor6.equals((java.lang.Object) 0);
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) chartColor6);
        java.awt.Paint paint10 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Font font7 = piePlot1.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent8.setType(chartChangeEventType9);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot13.notifyListeners(plotChangeEvent16);
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot13);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart18.setBorderStroke(stroke19);
        java.lang.Object obj21 = jFreeChart18.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle22 = jFreeChart18.getLegend();
        plotChangeEvent8.setChart(jFreeChart18);
        java.awt.Stroke stroke24 = jFreeChart18.getBorderStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(legendTitle22);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot2.axisChanged(axisChangeEvent8);
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot2);
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = legendTitle10.getVerticalAlignment();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = null;
        org.jfree.chart.util.Size2D size2D14 = legendTitle10.arrange(graphics2D12, rectangleConstraint13);
        double double15 = legendTitle10.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = legendTitle10.getLegendItemGraphicEdge();
        org.jfree.data.general.Dataset dataset17 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) legendTitle10, dataset17);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = legendTitle10.getHorizontalAlignment();
        java.awt.Font font20 = legendTitle10.getItemFont();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("PieSection: 1, -1( )", font20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = null;
        try {
            textTitle21.setMargin(rectangleInsets22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(verticalAlignment11);
        org.junit.Assert.assertNotNull(size2D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (-12189689), (double) (byte) 100, 0.0d, (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 100, (double) (byte) 10, (double) (byte) 100, (double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str15 = rectangleEdge14.toString();
        double double16 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D13, rectangleEdge14);
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge14);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "RectangleEdge.LEFT" + "'", str15.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        piePlot1.setBaseSectionPaint((java.awt.Paint) color13);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.awt.Color color20 = java.awt.Color.green;
        piePlot19.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color27 = java.awt.Color.green;
        piePlot23.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color27);
        java.awt.Font font29 = piePlot23.getLabelFont();
        piePlot19.setNoDataMessageFont(font29);
        piePlot1.setNoDataMessageFont(font29);
        java.awt.Font font32 = piePlot1.getNoDataMessageFont();
        org.jfree.chart.plot.Plot plot33 = null;
        piePlot1.setParent(plot33);
        int int35 = piePlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        textTitle1.setURLText("");
        textTitle1.setExpandToFitSpace(true);
        textTitle1.setHeight(0.14d);
        boolean boolean21 = textTitle1.getNotify();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        piePlot1.setPieIndex((-16777216));
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        multiplePiePlot6.setDataset(categoryDataset7);
        java.lang.Comparable comparable9 = multiplePiePlot6.getAggregatedItemsKey();
        int int10 = multiplePiePlot6.getBackgroundImageAlignment();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot6.getPieChart();
        java.awt.Paint paint12 = jFreeChart11.getBorderPaint();
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart11);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateBottomInset((double) (-1.0f));
        double double9 = rectangleInsets5.calculateTopOutset(0.0d);
        piePlot1.setInsets(rectangleInsets5, false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        java.lang.String str4 = multiplePiePlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Multiple Pie Plot" + "'", str4.equals("Multiple Pie Plot"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Font font14 = piePlot11.getLabelFont();
        piePlot4.setNoDataMessageFont(font14);
        boolean boolean16 = rotation0.equals((java.lang.Object) piePlot4);
        double double17 = rotation0.getFactor();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        boolean boolean19 = rotation0.equals((java.lang.Object) chartChangeEventType18);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) ' ');
        boolean boolean8 = piePlot1.getSectionOutlinesVisible();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle9 = piePlot1.getLabelLinkStyle();
        java.lang.String str10 = pieLabelLinkStyle9.toString();
        org.jfree.chart.ui.ProjectInfo projectInfo11 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo11.addOptionalLibrary("Other");
        projectInfo11.setLicenceName("");
        org.jfree.chart.ui.Library[] libraryArray16 = projectInfo11.getOptionalLibraries();
        boolean boolean17 = pieLabelLinkStyle9.equals((java.lang.Object) projectInfo11);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str10.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertNotNull(libraryArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity27 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D16, pieDataset21, (int) (short) 100, 8, (java.lang.Comparable) "hi!", "PieLabelLinkStyle.STANDARD", "VerticalAlignment.CENTER");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleEdge.TOP", "", "ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color7 = java.awt.Color.green;
        java.awt.Color color8 = java.awt.Color.getColor("hi!", color7);
        boolean boolean9 = projectInfo5.equals((java.lang.Object) "hi!");
        projectInfo5.setCopyright("");
        java.lang.String str12 = projectInfo5.getVersion();
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo5);
        java.awt.Image image14 = projectInfo5.getLogo();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(image14);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        textTitle1.setURLText("");
        textTitle1.setExpandToFitSpace(true);
        boolean boolean19 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        int int8 = defaultKeyedValues2D1.getRowCount();
        int int9 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        defaultKeyedValues2D1.setValue((java.lang.Number) (short) 100, (java.lang.Comparable) 0.08d, (java.lang.Comparable) "0,0,1,1");
        java.lang.Number number12 = null;
        defaultKeyedValues2D1.setValue(number12, (java.lang.Comparable) "NOID", (java.lang.Comparable) 10L);
        int int16 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        java.lang.String str21 = chartEntity20.getShapeType();
        java.awt.Shape shape22 = chartEntity20.getArea();
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity30 = new org.jfree.chart.entity.PieSectionEntity(shape22, pieDataset24, 255, 0, (java.lang.Comparable) 100, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "ChartChangeEventType.DATASET_UPDATED");
        pieSectionEntity30.setURLText("{0}");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "rect" + "'", str21.equals("rect"));
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary("Other");
        java.lang.String str3 = projectInfo0.getInfo();
        org.jfree.chart.ui.Library[] libraryArray4 = projectInfo0.getLibraries();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle9.getItemContainer();
        java.lang.Object obj15 = blockContainer14.clone();
        boolean boolean16 = blockContainer14.isEmpty();
        org.jfree.chart.block.Arrangement arrangement17 = blockContainer14.getArrangement();
        blockContainer14.clear();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(arrangement17);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        int int4 = multiplePiePlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.Plot plot5 = multiplePiePlot0.getParent();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        piePlot7.notifyListeners(plotChangeEvent10);
        java.awt.Stroke stroke13 = piePlot7.getSectionOutlineStroke((java.lang.Comparable) (byte) 10);
        int int14 = piePlot7.getPieIndex();
        java.awt.Paint paint15 = piePlot7.getShadowPaint();
        multiplePiePlot0.setAggregatedItemsPaint(paint15);
        double double17 = multiplePiePlot0.getLimit();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle10 = null;
        jFreeChart7.setTitle(textTitle10);
        jFreeChart7.setBackgroundImageAlignment((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = legendTitle23.getVerticalAlignment();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = null;
        org.jfree.chart.util.Size2D size2D27 = legendTitle23.arrange(graphics2D25, rectangleConstraint26);
        double double28 = legendTitle23.getWidth();
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle23);
        org.jfree.chart.plot.Plot plot30 = jFreeChart7.getPlot();
        boolean boolean31 = jFreeChart7.getAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle32 = jFreeChart7.getLegend();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(plot30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(legendTitle32);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = java.awt.Color.green;
        piePlot9.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Image image14 = piePlot9.getBackgroundImage();
        java.lang.Object obj15 = piePlot9.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot9.notifyListeners(plotChangeEvent16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset20 = null;
        java.lang.String str22 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset20, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset23 = null;
        java.lang.String str25 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset23, (java.lang.Comparable) (-1L));
        piePlot9.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color27);
        boolean boolean29 = standardPieSectionLabelGenerator19.equals((java.lang.Object) color27);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        boolean boolean36 = piePlot1.equals((java.lang.Object) (-1));
        java.awt.Font font37 = piePlot1.getLabelFont();
        piePlot1.setLabelGap((double) '#');
        boolean boolean40 = piePlot1.isSubplot();
        org.jfree.chart.util.Rotation rotation41 = piePlot1.getDirection();
        org.jfree.chart.LegendItemCollection legendItemCollection42 = piePlot1.getLegendItems();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rotation41);
        org.junit.Assert.assertNotNull(legendItemCollection42);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle10 = null;
        jFreeChart7.setTitle(textTitle10);
        jFreeChart7.setBackgroundImageAlignment((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = legendTitle23.getVerticalAlignment();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = null;
        org.jfree.chart.util.Size2D size2D27 = legendTitle23.arrange(graphics2D25, rectangleConstraint26);
        double double28 = legendTitle23.getWidth();
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle23);
        org.jfree.chart.plot.Plot plot30 = jFreeChart7.getPlot();
        jFreeChart7.setBackgroundImageAlpha(10.0f);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(plot30);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getMaximumLabelWidth();
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        piePlot12.notifyListeners(plotChangeEvent15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot12);
        jFreeChart17.setNotify(false);
        plot9.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        org.jfree.chart.plot.Plot plot21 = plot9.getParent();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNull(plot21);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        pieSectionEntity20.setPieIndex((int) ' ');
        java.lang.String str23 = pieSectionEntity20.getShapeCoords();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0,0,1,1" + "'", str23.equals("0,0,1,1"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        try {
            java.lang.Number number10 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (-246), (java.lang.Comparable) "Rotation.CLOCKWISE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: Rotation.CLOCKWISE");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setBackgroundImageAlignment(255);
        org.jfree.chart.util.TableOrder tableOrder6 = multiplePiePlot0.getDataExtractOrder();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertNotNull(tableOrder6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot1.markerChanged(markerChangeEvent8);
        float float10 = piePlot1.getBackgroundAlpha();
        double double11 = piePlot1.getInteriorGap();
        java.awt.Stroke stroke12 = piePlot1.getOutlineStroke();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle9.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle9.arrange(graphics2D14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = legendTitle9.getItemLabelPadding();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.awt.Color color4 = java.awt.Color.GRAY;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) '#', (double) (-1.0f), (double) 1.0f, (java.awt.Paint) color4);
        java.awt.Paint paint6 = blockBorder5.getPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setInteriorGap(0.0d);
        java.awt.Paint paint10 = piePlot2.getLabelLinkPaint();
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot2.getLabelPadding();
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        piePlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color30 = java.awt.Color.green;
        piePlot26.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color30);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent32 = null;
        piePlot26.axisChanged(axisChangeEvent32);
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot26);
        double double35 = legendTitle34.getContentYOffset();
        legendTitle34.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle34.getBounds();
        rectangleInsets22.trim(rectangle2D38);
        textTitle21.setBounds(rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets19.createOutsetRectangle(rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets13.createOutsetRectangle(rectangle2D38, false, true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.TOP;
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D44, rectangleAnchor45);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(point2D46);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("HorizontalAlignment.CENTER", "", "ChartEntity: tooltip = null", "PieLabelLinkStyle.STANDARD", "Rotation.ANTICLOCKWISE");
        basicProjectInfo5.setLicenceName("PieLabelLinkStyle.STANDARD");
        basicProjectInfo5.addOptionalLibrary("RectangleEdge.LEFT");
        java.lang.String str10 = basicProjectInfo5.getVersion();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle9.getItemContainer();
        java.lang.Object obj15 = blockContainer14.clone();
        org.jfree.chart.block.BlockFrame blockFrame16 = blockContainer14.getFrame();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = null;
        piePlot19.axisChanged(axisChangeEvent25);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot19);
        org.jfree.chart.ChartColor chartColor31 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean33 = chartColor31.equals((java.lang.Object) 0);
        piePlot19.setLabelPaint((java.awt.Paint) chartColor31);
        java.awt.Image image35 = piePlot19.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor36 = piePlot19.getLabelDistributor();
        double double37 = piePlot19.getStartAngle();
        float float38 = piePlot19.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        piePlot41.addChangeListener(plotChangeListener42);
        piePlot41.setMaximumLabelWidth((double) 10.0f);
        piePlot41.setShadowYOffset((double) 1L);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.data.general.PieDataset pieDataset49 = null;
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot(pieDataset49);
        org.jfree.chart.event.PlotChangeListener plotChangeListener51 = null;
        piePlot50.addChangeListener(plotChangeListener51);
        java.awt.Color color54 = java.awt.Color.green;
        piePlot50.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color54);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent56 = null;
        piePlot50.axisChanged(axisChangeEvent56);
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot50);
        double double59 = legendTitle58.getContentYOffset();
        legendTitle58.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D62 = legendTitle58.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str64 = rectangleEdge63.toString();
        double double65 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D62, rectangleEdge63);
        org.jfree.data.general.PieDataset pieDataset66 = null;
        org.jfree.chart.plot.PiePlot piePlot67 = new org.jfree.chart.plot.PiePlot(pieDataset66);
        org.jfree.chart.event.PlotChangeListener plotChangeListener68 = null;
        piePlot67.addChangeListener(plotChangeListener68);
        java.awt.Color color70 = java.awt.Color.green;
        piePlot67.setBackgroundPaint((java.awt.Paint) color70);
        java.awt.Stroke stroke73 = null;
        piePlot67.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke73);
        org.jfree.chart.LegendItemCollection legendItemCollection75 = piePlot67.getLegendItems();
        boolean boolean76 = piePlot67.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart77 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot67);
        java.awt.Paint paint78 = piePlot67.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.plot.PiePlotState piePlotState81 = piePlot41.initialise(graphics2D48, rectangle2D62, piePlot67, (java.lang.Integer) 8, plotRenderingInfo80);
        org.jfree.data.general.PieDataset pieDataset82 = null;
        org.jfree.chart.plot.PiePlot piePlot83 = new org.jfree.chart.plot.PiePlot(pieDataset82);
        java.awt.Color color84 = java.awt.Color.green;
        piePlot83.setBackgroundPaint((java.awt.Paint) color84);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator86 = piePlot83.getToolTipGenerator();
        java.awt.Paint paint87 = piePlot83.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset88 = null;
        org.jfree.chart.plot.PiePlot piePlot89 = new org.jfree.chart.plot.PiePlot(pieDataset88);
        java.awt.Color color90 = java.awt.Color.green;
        piePlot89.setBackgroundPaint((java.awt.Paint) color90);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator92 = piePlot89.getToolTipGenerator();
        java.awt.Paint paint93 = piePlot89.getLabelPaint();
        boolean boolean94 = piePlot83.equals((java.lang.Object) piePlot89);
        java.awt.Font font95 = piePlot83.getNoDataMessageFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo97 = null;
        org.jfree.chart.plot.PiePlotState piePlotState98 = piePlot19.initialise(graphics2D39, rectangle2D62, piePlot83, (java.lang.Integer) 100, plotRenderingInfo97);
        try {
            blockContainer14.draw(graphics2D17, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(blockFrame16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(image35);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 90.0d + "'", double37 == 90.0d);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.5f + "'", float38 == 0.5f);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "RectangleEdge.LEFT" + "'", str64.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(legendItemCollection75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(piePlotState81);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertNull(pieToolTipGenerator86);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertNull(pieToolTipGenerator92);
        org.junit.Assert.assertNotNull(paint93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertNotNull(font95);
        org.junit.Assert.assertNotNull(piePlotState98);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        piePlot9.setLabelLinksVisible(false);
        java.awt.Stroke stroke14 = piePlot9.getOutlineStroke();
        piePlot1.setOutlineStroke(stroke14);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendTitle16.getLegendItemGraphicAnchor();
        java.awt.Font font18 = legendTitle16.getItemFont();
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block20 = null;
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        piePlot23.addChangeListener(plotChangeListener24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = null;
        piePlot23.notifyListeners(plotChangeEvent26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot23);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        piePlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color34 = java.awt.Color.green;
        piePlot30.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color34);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = null;
        piePlot30.axisChanged(axisChangeEvent36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot30);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = legendTitle38.getVerticalAlignment();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = null;
        org.jfree.chart.util.Size2D size2D42 = legendTitle38.arrange(graphics2D40, rectangleConstraint41);
        jFreeChart28.addSubtitle((org.jfree.chart.title.Title) legendTitle38);
        flowArrangement19.add(block20, (java.lang.Object) legendTitle38);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray45 = legendTitle38.getSources();
        legendTitle38.setPadding(10.0d, (double) (byte) 10, (double) '4', (double) 2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray51 = legendTitle38.getSources();
        legendTitle16.setSources(legendItemSourceArray51);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(verticalAlignment39);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(legendItemSourceArray45);
        org.junit.Assert.assertNotNull(legendItemSourceArray51);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setInteriorGap(0.0d);
        java.awt.Paint paint10 = piePlot2.getLabelLinkPaint();
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot2.getLabelPadding();
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = blockBorder18.getInsets();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        piePlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color30 = java.awt.Color.green;
        piePlot26.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color30);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent32 = null;
        piePlot26.axisChanged(axisChangeEvent32);
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot26);
        double double35 = legendTitle34.getContentYOffset();
        legendTitle34.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D38 = legendTitle34.getBounds();
        rectangleInsets22.trim(rectangle2D38);
        textTitle21.setBounds(rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets19.createOutsetRectangle(rectangle2D38);
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets13.createOutsetRectangle(rectangle2D38, false, true);
        double double46 = rectangleInsets13.calculateRightOutset(4.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.0d + "'", double46 == 2.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean28 = chartColor26.equals((java.lang.Object) 0);
        piePlot14.setLabelPaint((java.awt.Paint) chartColor26);
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) chartColor26);
        double double32 = piePlot1.getExplodePercent((java.lang.Comparable) "NOID");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        java.lang.String str2 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.getLicenceText();
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = java.awt.Color.green;
        piePlot8.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Image image13 = piePlot8.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot8);
        java.lang.Object obj15 = jFreeChart14.clone();
        jFreeChart14.fireChartChanged();
        java.awt.Paint paint17 = null;
        jFreeChart14.setBackgroundPaint(paint17);
        java.awt.Paint paint19 = jFreeChart14.getBackgroundPaint();
        java.lang.Object obj20 = null;
        boolean boolean21 = jFreeChart14.equals(obj20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        java.awt.image.BufferedImage bufferedImage26 = jFreeChart14.createBufferedImage(15, (int) (byte) 10, 3, chartRenderingInfo25);
        projectInfo0.setLogo((java.awt.Image) bufferedImage26);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(image13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(bufferedImage26);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        boolean boolean3 = jFreeChartResources0.containsKey("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.util.Enumeration<java.lang.String> strEnumeration4 = jFreeChartResources0.getKeys();
        java.util.Set<java.lang.String> strSet5 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strEnumeration4);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Font font6 = piePlot1.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        piePlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = java.awt.Color.green;
        piePlot8.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke14 = null;
        piePlot8.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke14);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator16 = piePlot8.getLegendLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator16);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle18 = piePlot1.getLabelLinkStyle();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = piePlot20.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = piePlot20.getToolTipGenerator();
        java.lang.Object obj23 = piePlot20.clone();
        boolean boolean24 = pieLabelLinkStyle18.equals((java.lang.Object) piePlot20);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator25 = piePlot20.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle18);
        org.junit.Assert.assertNotNull(drawingSupplier21);
        org.junit.Assert.assertNull(pieToolTipGenerator22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(pieSectionLabelGenerator25);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Image image9 = piePlot4.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot4);
        java.lang.Object obj11 = jFreeChart10.clone();
        jFreeChart10.fireChartChanged();
        java.awt.Paint paint13 = null;
        jFreeChart10.setBackgroundPaint(paint13);
        java.lang.Object obj15 = jFreeChart10.clone();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        piePlot17.addChangeListener(plotChangeListener18);
        java.awt.Color color21 = java.awt.Color.green;
        piePlot17.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color21);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        piePlot17.axisChanged(axisChangeEvent23);
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17);
        double double26 = legendTitle25.getContentYOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets();
        legendTitle25.setLegendItemGraphicPadding(rectangleInsets27);
        jFreeChart10.addSubtitle((org.jfree.chart.title.Title) legendTitle25);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray30 = legendTitle25.getSources();
        boolean boolean31 = multiplePiePlot1.equals((java.lang.Object) legendItemSourceArray30);
        org.jfree.chart.LegendItemCollection legendItemCollection32 = multiplePiePlot1.getLegendItems();
        java.lang.Comparable comparable33 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(image9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemSourceArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(legendItemCollection32);
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + "Other" + "'", comparable33.equals("Other"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        jFreeChart19.fireChartChanged();
        java.awt.Paint paint22 = null;
        jFreeChart19.setBackgroundPaint(paint22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart19);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double27 = piePlot1.getLabelGap();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = piePlot1.getInsets();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.025d + "'", double27 == 0.025d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        java.util.List list4 = defaultCategoryDataset2.getColumnKeys();
        int int6 = defaultCategoryDataset2.getColumnIndex((java.lang.Comparable) 100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart9.setBorderStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets12.calculateLeftOutset(10.0d);
        double double16 = rectangleInsets12.calculateRightOutset((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke10, rectangleInsets12);
        double double19 = rectangleInsets12.calculateBottomInset(2.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(255);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        java.awt.Paint paint5 = blockBorder4.getPaint();
        java.awt.Paint paint6 = blockBorder4.getPaint();
        java.awt.Paint paint7 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        boolean boolean8 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot10.setBackgroundPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke16 = null;
        piePlot10.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot10.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateLeftOutset(10.0d);
        double double25 = rectangleInsets21.calculateLeftInset((double) (short) 100);
        piePlot10.setInsets(rectangleInsets21, false);
        piePlot1.setInsets(rectangleInsets21, false);
        double double30 = piePlot1.getMaximumExplodePercent();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        double double14 = legendTitle9.getWidth();
        legendTitle9.setWidth((double) 0L);
        java.awt.Font font17 = legendTitle9.getItemFont();
        java.awt.Paint paint18 = legendTitle9.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = piePlot1.getShadowYOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        piePlot1.markerChanged(markerChangeEvent11);
        java.awt.Image image13 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNull(image13);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.RenderingHints renderingHints9 = jFreeChart8.getRenderingHints();
        java.awt.Paint paint10 = jFreeChart8.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(renderingHints9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "{0}");
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "Pie Plot");
        java.awt.Shape shape25 = chartEntity24.getArea();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        boolean boolean23 = pieSectionEntity20.equals((java.lang.Object) (byte) 1);
        pieSectionEntity20.setSectionIndex(0);
        pieSectionEntity20.setToolTipText("PieSection: 1, -1( )");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle9.getLegendItemGraphicLocation();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle9);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Stroke stroke11 = null;
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke11);
        boolean boolean13 = defaultKeyedValues2D1.equals((java.lang.Object) piePlot5);
        int int14 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Comparable comparable16 = defaultKeyedValues2D1.getColumnKey((-1783));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot1.markerChanged(markerChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot1.getLegendItems();
        piePlot1.setSimpleLabels(true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = null;
        piePlot1.setURLGenerator(pieURLGenerator13);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = piePlot1.getShadowYOffset();
        org.jfree.chart.util.UnitType unitType12 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str13 = unitType12.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets(unitType12, (double) (-1783), (double) 1L, (double) 100.0f, (double) 10L);
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) 3, (float) (-1), (float) (short) 100);
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets18, (java.awt.Paint) color22);
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) 100.0d, (java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UnitType.ABSOLUTE" + "'", str13.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        boolean boolean12 = piePlot1.getIgnoreNullValues();
        boolean boolean13 = piePlot1.isOutlineVisible();
        java.lang.Object obj14 = piePlot1.clone();
        piePlot1.setStartAngle((double) 0.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke8);
        java.lang.Object obj10 = jFreeChart7.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend();
        jFreeChart7.clearSubtitles();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(legendTitle11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        double double11 = rectangleInsets5.extendHeight((double) 1L);
        double double13 = rectangleInsets5.calculateLeftOutset((double) 0);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot16.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.Image image21 = piePlot16.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot16);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart22.getTitle();
        java.awt.geom.Rectangle2D rectangle2D24 = textTitle23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets5.createOutsetRectangle(rectangle2D24, true, false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(image21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = piePlot1.getShadowYOffset();
        java.awt.Color color11 = java.awt.Color.red;
        piePlot1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        piePlot14.notifyListeners(plotChangeEvent17);
        double double19 = piePlot14.getInteriorGap();
        piePlot14.setIgnoreZeroValues(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = piePlot14.getDrawingSupplier();
        piePlot1.setDrawingSupplier(drawingSupplier22);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle24 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.08d + "'", double19 == 0.08d);
        org.junit.Assert.assertNotNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle24);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = null;
        piePlot2.setLabelGenerator(pieSectionLabelGenerator9);
        piePlot2.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = java.awt.Color.green;
        piePlot9.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Image image14 = piePlot9.getBackgroundImage();
        java.lang.Object obj15 = piePlot9.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot9.notifyListeners(plotChangeEvent16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset20 = null;
        java.lang.String str22 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset20, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset23 = null;
        java.lang.String str25 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset23, (java.lang.Comparable) (-1L));
        piePlot9.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color27);
        boolean boolean29 = standardPieSectionLabelGenerator19.equals((java.lang.Object) color27);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        java.text.NumberFormat numberFormat31 = standardPieSectionLabelGenerator19.getPercentFormat();
        java.lang.String str32 = standardPieSectionLabelGenerator19.getLabelFormat();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(numberFormat31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D2 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D2.getColumnCount();
        int int4 = defaultKeyedValues2D2.getRowCount();
        defaultKeyedValues2D2.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        int int9 = defaultKeyedValues2D2.getRowCount();
        int int11 = defaultKeyedValues2D2.getRowIndex((java.lang.Comparable) 100);
        defaultKeyedValues2D2.setValue((java.lang.Number) 0.0f, (java.lang.Comparable) 10L, (java.lang.Comparable) (-15));
        boolean boolean16 = horizontalAlignment0.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get(0);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        piePlot6.notifyListeners(plotChangeEvent9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Font font16 = piePlot13.getLabelFont();
        piePlot6.setNoDataMessageFont(font16);
        int int18 = objectList1.indexOf((java.lang.Object) piePlot6);
        java.awt.Paint paint20 = piePlot6.getSectionPaint((java.lang.Comparable) '4');
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator20 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = piePlot1.getLabelPadding();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) '4');
        org.jfree.chart.JFreeChart jFreeChart6 = multiplePiePlot0.getPieChart();
        jFreeChart6.fireChartChanged();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(jFreeChart6);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        java.awt.Paint paint11 = textTitle9.getBackgroundPaint();
        double double12 = textTitle9.getContentYOffset();
        java.lang.String str13 = textTitle9.getToolTipText();
        boolean boolean14 = textTitle9.getExpandToFitSpace();
        java.lang.String str15 = textTitle9.getURLText();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset1.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        defaultCategoryDataset1.addValue((java.lang.Number) (byte) -1, (java.lang.Comparable) (-254), (java.lang.Comparable) 100.0d);
        java.util.List list9 = defaultCategoryDataset1.getColumnKeys();
        try {
            java.lang.Number number12 = defaultCategoryDataset1.getValue((int) (byte) 100, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setInteriorGap(0.0d);
        java.awt.Paint paint10 = piePlot2.getLabelLinkPaint();
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        piePlot2.setLabelShadowPaint((java.awt.Paint) color11);
        java.awt.color.ColorSpace colorSpace13 = null;
        java.awt.Color color17 = java.awt.Color.green;
        float[] floatArray24 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray25 = color17.getRGBColorComponents(floatArray24);
        float[] floatArray26 = java.awt.Color.RGBtoHSB((int) '#', (int) '4', 1, floatArray24);
        try {
            float[] floatArray27 = color11.getColorComponents(colorSpace13, floatArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.TOP");
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset5 = null;
        java.lang.String str7 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset5, (java.lang.Comparable) (-1L));
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str9 = projectInfo8.getLicenceText();
        boolean boolean10 = standardPieSectionLabelGenerator1.equals((java.lang.Object) projectInfo8);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot12.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        java.awt.Font font18 = piePlot12.getLabelFont();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        plotChangeEvent19.setType(chartChangeEventType20);
        org.jfree.chart.plot.Plot plot22 = plotChangeEvent19.getPlot();
        org.jfree.chart.plot.Plot plot23 = plotChangeEvent19.getPlot();
        boolean boolean24 = standardPieSectionLabelGenerator1.equals((java.lang.Object) plotChangeEvent19);
        java.lang.Object obj25 = plotChangeEvent19.getSource();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNotNull(plot23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("VerticalAlignment.CENTER", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        int int3 = defaultCategoryDataset1.getRowCount();
        org.jfree.data.general.DatasetGroup datasetGroup4 = defaultCategoryDataset1.getGroup();
        java.lang.String str5 = datasetGroup4.getID();
        java.lang.String str6 = datasetGroup4.getID();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(datasetGroup4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "NOID" + "'", str5.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "NOID" + "'", str6.equals("NOID"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) 10);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (-12189689), (double) (byte) 100, 0.0d, (double) 100.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) (-1.0f), (double) 1.0f, 100.0d, (double) (-16777216));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelGenerator();
        org.jfree.data.general.DatasetGroup datasetGroup10 = piePlot1.getDatasetGroup();
        piePlot1.setPieIndex(1);
        java.awt.Font font13 = null;
        try {
            piePlot1.setNoDataMessageFont(font13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNull(datasetGroup10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        try {
            java.awt.image.BufferedImage bufferedImage27 = jFreeChart7.createBufferedImage((int) ' ', 0, chartRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (32) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot11.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot11.axisChanged(axisChangeEvent17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle19.getVerticalAlignment();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = null;
        org.jfree.chart.util.Size2D size2D23 = legendTitle19.arrange(graphics2D21, rectangleConstraint22);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle19);
        flowArrangement0.add(block1, (java.lang.Object) legendTitle19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle19.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendTitle19.getLegendItemGraphicPadding();
        double double29 = rectangleInsets27.calculateLeftInset(4.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.0d + "'", double29 == 2.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        boolean boolean4 = jFreeChartResources0.containsKey("PieSection: 1, -1( )");
        boolean boolean6 = jFreeChartResources0.containsKey("org.jfree.chart.event.ChartChangeEvent[source=Rotation.ANTICLOCKWISE]");
        java.lang.Object[][] objArray7 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color11 = java.awt.Color.green;
        piePlot7.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color11);
        boolean boolean13 = piePlot1.equals((java.lang.Object) 1);
        piePlot1.setOutlineVisible(true);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset18 = null;
        java.lang.String str20 = standardPieSectionLabelGenerator17.generateSectionLabel(pieDataset18, (java.lang.Comparable) (-1));
        boolean boolean22 = standardPieSectionLabelGenerator17.equals((java.lang.Object) (short) 100);
        java.text.AttributedString attributedString24 = null;
        standardPieSectionLabelGenerator17.setAttributedLabel((int) (short) 10, attributedString24);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        piePlot1.handleClick(0, (int) (short) 0, plotRenderingInfo6);
        boolean boolean8 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        double double3 = multiplePiePlot0.getLimit();
        multiplePiePlot0.setLimit((double) '4');
        org.jfree.chart.LegendItemCollection legendItemCollection6 = multiplePiePlot0.getLegendItems();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        multiplePiePlot7.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8);
        int int12 = defaultCategoryDataset8.getColumnIndex((java.lang.Comparable) 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot9.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color13);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = null;
        piePlot9.axisChanged(axisChangeEvent15);
        org.jfree.chart.title.LegendTitle legendTitle17 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = legendTitle17.getVerticalAlignment();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle17.arrange(graphics2D19, rectangleConstraint20);
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle17);
        org.jfree.chart.title.TextTitle textTitle23 = jFreeChart7.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textTitle23.getTextAlignment();
        java.awt.Font font25 = textTitle23.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle23.getTextAlignment();
        textTitle23.setText("org.jfree.chart.event.ChartChangeEvent[source=Rotation.ANTICLOCKWISE]");
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(verticalAlignment18);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(textTitle23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("TableOrder.BY_ROW");
        java.awt.Paint paint2 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("PieSection: 32, -1( )");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: PieSection: 32, -1( )" + "'", str2.equals("org.jfree.data.UnknownKeyException: PieSection: 32, -1( )"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLabelGenerator();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color16);
        java.awt.Image image18 = piePlot13.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot13);
        java.lang.Object obj20 = jFreeChart19.clone();
        jFreeChart19.fireChartChanged();
        java.awt.Paint paint22 = null;
        jFreeChart19.setBackgroundPaint(paint22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart19);
        piePlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart19);
        int int26 = jFreeChart19.getSubtitleCount();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.calculateRightOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        piePlot6.notifyListeners(plotChangeEvent9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot6);
        piePlot6.setInteriorGap(0.0d);
        java.awt.Paint paint14 = piePlot6.getLabelLinkPaint();
        java.awt.Color color15 = java.awt.Color.MAGENTA;
        piePlot6.setLabelShadowPaint((java.awt.Paint) color15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = piePlot6.getLabelPadding();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = blockBorder22.getInsets();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double28 = rectangleInsets26.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        piePlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color34 = java.awt.Color.green;
        piePlot30.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color34);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = null;
        piePlot30.axisChanged(axisChangeEvent36);
        org.jfree.chart.title.LegendTitle legendTitle38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot30);
        double double39 = legendTitle38.getContentYOffset();
        legendTitle38.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D42 = legendTitle38.getBounds();
        rectangleInsets26.trim(rectangle2D42);
        textTitle25.setBounds(rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets23.createOutsetRectangle(rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets17.createOutsetRectangle(rectangle2D42, false, true);
        org.jfree.chart.entity.ChartEntity chartEntity49 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets0.createOutsetRectangle(rectangle2D42, false, true);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int21 = pieSectionEntity20.getPieIndex();
        pieSectionEntity20.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        pieSectionEntity20.setSectionIndex(0);
        java.lang.String str26 = pieSectionEntity20.toString();
        pieSectionEntity20.setSectionKey((java.lang.Comparable) "rect");
        pieSectionEntity20.setPieIndex(15);
        int int31 = pieSectionEntity20.getSectionIndex();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "PieSection: 1, 0( )" + "'", str26.equals("PieSection: 1, 0( )"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary("");
        java.lang.String str3 = projectInfo0.getVersion();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        java.awt.Color color26 = java.awt.Color.MAGENTA;
        piePlot19.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot19);
        boolean boolean29 = rectangleInsets0.equals((java.lang.Object) jFreeChart28);
        org.jfree.chart.event.ChartProgressListener chartProgressListener30 = null;
        jFreeChart28.removeProgressListener(chartProgressListener30);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, 2.0d, (double) 8, (double) (short) -1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        piePlot1.setBackgroundAlpha((float) 8);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart7.setBorderStroke(stroke8);
        java.lang.Object obj10 = jFreeChart7.getTextAntiAlias();
        org.jfree.chart.title.LegendTitle legendTitle11 = jFreeChart7.getLegend();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = null;
        org.jfree.chart.util.Size2D size2D14 = legendTitle11.arrange(graphics2D12, rectangleConstraint13);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNotNull(legendTitle11);
        org.junit.Assert.assertNotNull(size2D14);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Font font5 = piePlot2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = piePlot7.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot7.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.awt.Color color13 = java.awt.Color.green;
        piePlot12.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator15 = piePlot12.getToolTipGenerator();
        java.awt.Paint paint16 = piePlot12.getLabelPaint();
        java.awt.Paint paint17 = piePlot12.getLabelOutlinePaint();
        piePlot7.setLabelOutlinePaint(paint17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        piePlot7.setBaseSectionPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = null;
        piePlot7.setToolTipGenerator(pieToolTipGenerator22);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.awt.Color color26 = java.awt.Color.green;
        piePlot25.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot29.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color33);
        java.awt.Font font35 = piePlot29.getLabelFont();
        piePlot25.setNoDataMessageFont(font35);
        piePlot7.setNoDataMessageFont(font35);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = null", font5, (org.jfree.chart.plot.Plot) piePlot7, true);
        piePlot7.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(pieToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.awt.Font font10 = textTitle9.getFont();
        boolean boolean11 = textTitle9.getNotify();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.green;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        boolean boolean4 = projectInfo0.equals((java.lang.Object) "hi!");
        java.lang.String str5 = projectInfo0.toString();
        java.lang.String str6 = projectInfo0.toString();
        projectInfo0.setLicenceText("PieSection: 32, -1( )");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str5.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str6.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleEdge.TOP", "", "ChartChangeEventType.DATASET_UPDATED");
        basicProjectInfo4.setInfo("Other");
        org.jfree.chart.ui.Library[] libraryArray7 = basicProjectInfo4.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle9.getItemContainer();
        java.lang.Object obj15 = blockContainer14.clone();
        boolean boolean16 = blockContainer14.isEmpty();
        org.jfree.chart.block.Arrangement arrangement17 = blockContainer14.getArrangement();
        boolean boolean18 = blockContainer14.isEmpty();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(arrangement17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        defaultCategoryDataset2.setValue((java.lang.Number) 1.0E-5d, (java.lang.Comparable) (-16777216), (java.lang.Comparable) "RectangleEdge.LEFT");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Paint paint20 = piePlot1.getLabelBackgroundPaint();
        piePlot1.setStartAngle(0.0d);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = piePlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(drawingSupplier23);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset1.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        defaultCategoryDataset1.addValue((java.lang.Number) (byte) -1, (java.lang.Comparable) (-254), (java.lang.Comparable) 100.0d);
        java.lang.Object obj9 = defaultCategoryDataset1.clone();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        piePlot1.setSectionOutlinesVisible(true);
        boolean boolean20 = piePlot1.isOutlineVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        java.util.List list4 = defaultCategoryDataset2.getColumnKeys();
        org.jfree.data.general.DatasetGroup datasetGroup5 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str6 = datasetGroup5.getID();
        java.lang.String str7 = datasetGroup5.getID();
        defaultCategoryDataset2.setGroup(datasetGroup5);
        defaultCategoryDataset2.addValue((java.lang.Number) 100.0f, (java.lang.Comparable) "Rotation.ANTICLOCKWISE", (java.lang.Comparable) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "NOID" + "'", str6.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "NOID" + "'", str7.equals("NOID"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str1 = rectangleEdge0.toString();
        java.lang.String str2 = rectangleEdge0.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.LEFT" + "'", str1.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.LEFT" + "'", str2.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot11.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot11.axisChanged(axisChangeEvent17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle19.getVerticalAlignment();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = null;
        org.jfree.chart.util.Size2D size2D23 = legendTitle19.arrange(graphics2D21, rectangleConstraint22);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle19);
        flowArrangement0.add(block1, (java.lang.Object) legendTitle19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle19.getSources();
        legendTitle19.setPadding(10.0d, (double) (byte) 10, (double) '4', (double) 2);
        java.awt.Color color35 = java.awt.Color.getHSBColor((float) (-254), 0.0f, (float) 1);
        legendTitle19.setBackgroundPaint((java.awt.Paint) color35);
        legendTitle19.setPadding(0.0d, 4.0d, (double) (byte) 0, (double) 2);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3.getToolTipGenerator();
        java.awt.Paint paint7 = piePlot3.getLabelPaint();
        java.awt.Paint paint8 = piePlot3.getLabelOutlinePaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor9 = piePlot3.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        piePlot3.handleClick(100, 0, plotRenderingInfo12);
        boolean boolean14 = textTitle1.equals((java.lang.Object) plotRenderingInfo12);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = textTitle1.getMargin();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle1.getTextAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle1.getHorizontalAlignment();
        double double18 = textTitle1.getHeight();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint5 = piePlot1.getLabelPaint();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot7.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot7.getToolTipGenerator();
        java.awt.Paint paint11 = piePlot7.getLabelPaint();
        boolean boolean12 = piePlot1.equals((java.lang.Object) piePlot7);
        double double13 = piePlot7.getMinimumArcAngleToDraw();
        boolean boolean14 = piePlot7.getIgnoreZeroValues();
        java.awt.Color color16 = java.awt.Color.DARK_GRAY;
        piePlot7.setSectionPaint((java.lang.Comparable) "RectangleInsets[t=2.0,l=2.0,b=2.0,r=2.0]", (java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(pieToolTipGenerator4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0E-5d + "'", double13 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary("Other");
        projectInfo0.setLicenceName("");
        java.lang.String str5 = projectInfo0.getLicenceName();
        projectInfo0.setLicenceName("");
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo8.addOptionalLibrary("Other");
        projectInfo8.setName("Other");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo8);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Font font6 = piePlot3.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = piePlot8.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = piePlot8.getToolTipGenerator();
        java.awt.Paint paint11 = piePlot8.getLabelShadowPaint();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot13.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = piePlot13.getToolTipGenerator();
        java.awt.Paint paint17 = piePlot13.getLabelPaint();
        java.awt.Paint paint18 = piePlot13.getLabelOutlinePaint();
        piePlot8.setLabelOutlinePaint(paint18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace21 = color20.getColorSpace();
        piePlot8.setBaseSectionPaint((java.awt.Paint) color20);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator23 = null;
        piePlot8.setToolTipGenerator(pieToolTipGenerator23);
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        java.awt.Color color27 = java.awt.Color.green;
        piePlot26.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        piePlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color34 = java.awt.Color.green;
        piePlot30.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color34);
        java.awt.Font font36 = piePlot30.getLabelFont();
        piePlot26.setNoDataMessageFont(font36);
        piePlot8.setNoDataMessageFont(font36);
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("ChartEntity: tooltip = null", font6, (org.jfree.chart.plot.Plot) piePlot8, true);
        boolean boolean41 = rectangleAnchor0.equals((java.lang.Object) piePlot8);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(pieToolTipGenerator16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(colorSpace21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        double double10 = legendTitle9.getContentYOffset();
        legendTitle9.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D13 = legendTitle9.getBounds();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D13, pieDataset14, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        pieSectionEntity20.setPieIndex((int) ' ');
        org.jfree.data.general.PieDataset pieDataset23 = null;
        pieSectionEntity20.setDataset(pieDataset23);
        org.jfree.data.general.PieDataset pieDataset25 = pieSectionEntity20.getDataset();
        pieSectionEntity20.setToolTipText("org.jfree.chart.event.ChartChangeEvent[source=Rotation.ANTICLOCKWISE]");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNull(pieDataset25);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        java.awt.Font font8 = piePlot2.getLabelFont();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("NOID", font8);
        java.lang.String str10 = textTitle9.getToolTipText();
        java.awt.Paint paint11 = textTitle9.getBackgroundPaint();
        textTitle9.setPadding(0.08d, 100.0d, (double) (short) 1, 1.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle9.getTextAlignment();
        java.lang.Object obj18 = textTitle9.clone();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle9.setTextAlignment(horizontalAlignment19);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) ' ');
        java.awt.Paint paint8 = piePlot1.getNoDataMessagePaint();
        piePlot1.setShadowXOffset(0.0d);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        double double23 = legendTitle22.getContentYOffset();
        legendTitle22.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D26 = legendTitle22.getBounds();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity33 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D26, pieDataset27, (int) (byte) 1, (int) (byte) -1, (java.lang.Comparable) ' ', "NOID", "org.jfree.chart.event.ChartChangeEvent[source=-1]");
        int int34 = pieSectionEntity33.getPieIndex();
        pieSectionEntity33.setURLText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        pieSectionEntity33.setSectionIndex(0);
        java.lang.String str39 = pieSectionEntity33.toString();
        pieSectionEntity33.setSectionKey((java.lang.Comparable) "rect");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator43 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean45 = standardPieSectionLabelGenerator43.equals((java.lang.Object) defaultCategoryDataset44);
        defaultCategoryDataset44.addValue(0.0d, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 3);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent50 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) "rect", (org.jfree.data.general.Dataset) defaultCategoryDataset44);
        piePlot1.datasetChanged(datasetChangeEvent50);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PieSection: 1, 0( )" + "'", str39.equals("PieSection: 1, 0( )"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        int int4 = defaultCategoryDataset2.getColumnCount();
        defaultCategoryDataset2.addValue((double) 0L, (java.lang.Comparable) 90.0d, (java.lang.Comparable) "");
        defaultCategoryDataset2.validateObject();
        java.lang.Object obj10 = defaultCategoryDataset2.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        piePlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot19.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color23);
        java.awt.Color color26 = java.awt.Color.MAGENTA;
        piePlot19.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color26);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot19);
        boolean boolean29 = rectangleInsets0.equals((java.lang.Object) jFreeChart28);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = null;
        try {
            jFreeChart28.handleClick((-8355712), (-8355712), chartRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }
}

