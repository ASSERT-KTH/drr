import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color5);
        java.awt.Image image7 = piePlot2.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.Object obj9 = jFreeChart8.clone();
        jFreeChart8.setBorderVisible(false);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart8.getLegend();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(legendTitle12);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = defaultCategoryDataset1.getGroup();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color0, (org.jfree.data.general.Dataset) defaultCategoryDataset1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        boolean boolean6 = defaultCategoryDataset1.equals((java.lang.Object) color5);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent12 = null;
        piePlot9.notifyListeners(plotChangeEvent12);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot9);
        boolean boolean16 = jFreeChart14.equals((java.lang.Object) '4');
        java.awt.Color color17 = java.awt.Color.DARK_GRAY;
        jFreeChart14.setBackgroundPaint((java.awt.Paint) color17);
        jFreeChart14.setTextAntiAlias(true);
        boolean boolean21 = jFreeChart14.isNotify();
        jFreeChart14.setAntiAlias(false);
        boolean boolean24 = defaultCategoryDataset1.hasListener((java.util.EventListener) jFreeChart14);
        defaultCategoryDataset1.addValue((java.lang.Number) 10, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "Rotation.ANTICLOCKWISE");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(datasetGroup3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        java.awt.Paint paint6 = piePlot1.getLabelLinkPaint();
        double double7 = piePlot1.getInteriorGap();
        try {
            piePlot1.setInteriorGap((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.awt.Color color0 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart9.setBorderStroke(stroke10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets12.calculateLeftOutset(10.0d);
        double double16 = rectangleInsets12.calculateRightOutset((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke10, rectangleInsets12);
        int int18 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        piePlot1.markerChanged(markerChangeEvent8);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = piePlot1.getLegendItems();
        piePlot1.setSimpleLabels(true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNull(pieURLGenerator13);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        boolean boolean3 = jFreeChartResources0.containsKey("Multiple Pie Plot");
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle2 = piePlot1.getLabelLinkStyle();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier3 = piePlot1.getDrawingSupplier();
        piePlot1.setPieIndex((-32));
        org.junit.Assert.assertNotNull(pieLabelLinkStyle2);
        org.junit.Assert.assertNotNull(drawingSupplier3);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        boolean boolean9 = jFreeChart7.equals((java.lang.Object) '4');
        org.jfree.chart.title.TextTitle textTitle10 = null;
        jFreeChart7.setTitle(textTitle10);
        jFreeChart7.setBackgroundImageAlignment((int) (byte) 0);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        piePlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color19 = java.awt.Color.green;
        piePlot15.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot15.axisChanged(axisChangeEvent21);
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment24 = legendTitle23.getVerticalAlignment();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = null;
        org.jfree.chart.util.Size2D size2D27 = legendTitle23.arrange(graphics2D25, rectangleConstraint26);
        double double28 = legendTitle23.getWidth();
        jFreeChart7.addSubtitle((org.jfree.chart.title.Title) legendTitle23);
        java.awt.Font font30 = legendTitle23.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = legendTitle23.getLegendItemGraphicAnchor();
        legendTitle23.setID("NOID");
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(verticalAlignment24);
        org.junit.Assert.assertNotNull(size2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        piePlot1.zoom((double) 0L);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator7);
        org.jfree.data.general.DatasetGroup datasetGroup9 = piePlot1.getDatasetGroup();
        boolean boolean10 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder4.getInsets();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets8.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot12.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = null;
        piePlot12.axisChanged(axisChangeEvent18);
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot12);
        double double21 = legendTitle20.getContentYOffset();
        legendTitle20.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D24 = legendTitle20.getBounds();
        rectangleInsets8.trim(rectangle2D24);
        textTitle7.setBounds(rectangle2D24);
        java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets5.createOutsetRectangle(rectangle2D24);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D27, "ChartChangeEventType.DATASET_UPDATED", "PieLabelLinkStyle.STANDARD");
        boolean boolean32 = chartEntity30.equals((java.lang.Object) (byte) -1);
        java.lang.String str33 = chartEntity30.toString();
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "ChartEntity: tooltip = ChartChangeEventType.DATASET_UPDATED" + "'", str33.equals("ChartEntity: tooltip = ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot3);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.fireChartChanged();
        java.awt.Paint paint12 = null;
        jFreeChart9.setBackgroundPaint(paint12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "RectangleEdge.TOP", jFreeChart9);
        java.awt.Paint paint15 = jFreeChart9.getBorderPaint();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        multiplePiePlot4.setDataset(categoryDataset5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        multiplePiePlot4.axisChanged(axisChangeEvent7);
        multiplePiePlot4.setAggregatedItemsKey((java.lang.Comparable) 3);
        java.awt.Color color11 = java.awt.Color.magenta;
        float[] floatArray12 = null;
        float[] floatArray13 = color11.getRGBComponents(floatArray12);
        multiplePiePlot4.setAggregatedItemsPaint((java.awt.Paint) color11);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 0.0f, 100.0d, (double) 0.0f, (double) 10L, (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = new java.awt.Paint[] {};
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.awt.Color color3 = java.awt.Color.green;
        piePlot2.setBackgroundPaint((java.awt.Paint) color3);
        boolean boolean5 = verticalAlignment0.equals((java.lang.Object) color3);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        java.lang.String str21 = chartEntity20.getShapeType();
        java.awt.Shape shape22 = chartEntity20.getArea();
        java.lang.Object obj23 = chartEntity20.clone();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "rect" + "'", str21.equals("rect"));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) "java.awt.Color[r=255,g=255,b=255]");
        strokeMap0.clear();
        boolean boolean5 = strokeMap0.containsKey((java.lang.Comparable) "0,0,1,1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        defaultKeyedValues2D1.setValue((java.lang.Number) (short) 100, (java.lang.Comparable) 0.08d, (java.lang.Comparable) "0,0,1,1");
        java.util.List list12 = defaultKeyedValues2D1.getRowKeys();
        java.util.List list13 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Comparable comparable15 = defaultKeyedValues2D1.getRowKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot7 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        multiplePiePlot7.setDataset(categoryDataset8);
        java.lang.Comparable comparable10 = multiplePiePlot7.getAggregatedItemsKey();
        java.awt.Color color13 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 15);
        multiplePiePlot7.setAggregatedItemsPaint((java.awt.Paint) color13);
        piePlot1.setLabelBackgroundPaint((java.awt.Paint) color13);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        piePlot18.addChangeListener(plotChangeListener19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        piePlot18.notifyListeners(plotChangeEvent21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot18);
        piePlot18.setInteriorGap(0.0d);
        java.awt.Paint paint26 = piePlot18.getLabelLinkPaint();
        java.awt.Color color27 = java.awt.Color.MAGENTA;
        piePlot18.setLabelShadowPaint((java.awt.Paint) color27);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = piePlot18.getLabelPadding();
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((-1.0d), 0.0d, (double) '4', (double) (-1));
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = blockBorder34.getInsets();
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double40 = rectangleInsets38.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        org.jfree.chart.event.PlotChangeListener plotChangeListener43 = null;
        piePlot42.addChangeListener(plotChangeListener43);
        java.awt.Color color46 = java.awt.Color.green;
        piePlot42.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color46);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = null;
        piePlot42.axisChanged(axisChangeEvent48);
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot42);
        double double51 = legendTitle50.getContentYOffset();
        legendTitle50.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D54 = legendTitle50.getBounds();
        rectangleInsets38.trim(rectangle2D54);
        textTitle37.setBounds(rectangle2D54);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets35.createOutsetRectangle(rectangle2D54);
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets29.createOutsetRectangle(rectangle2D54, false, true);
        piePlot1.setLabelPadding(rectangleInsets29);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "Other" + "'", comparable10.equals("Other"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D60);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot3.setBackgroundPaint((java.awt.Paint) color6);
        java.awt.Image image8 = piePlot3.getBackgroundImage();
        java.lang.Object obj9 = piePlot3.clone();
        boolean boolean10 = piePlot3.isOutlineVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        piePlot3.setSectionOutlineStroke((java.lang.Comparable) "UnitType.ABSOLUTE", stroke13);
        multiplePiePlot1.setParent((org.jfree.chart.plot.Plot) piePlot3);
        piePlot3.setIgnoreZeroValues(true);
        java.awt.Shape shape18 = null;
        try {
            piePlot3.setLegendItemShape(shape18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TableOrder.BY_ROW");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TableOrder.BY_ROW, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateLeftOutset(10.0d);
        piePlot1.setSimpleLabelOffset(rectangleInsets5);
        java.lang.String str9 = rectangleInsets5.toString();
        double double11 = rectangleInsets5.calculateLeftOutset((double) 8);
        double double13 = rectangleInsets5.trimHeight((double) (-1783));
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str9.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1783.0d) + "'", double13 == (-1783.0d));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator3 = piePlot1.getToolTipGenerator();
        java.awt.Paint paint4 = piePlot1.getLabelShadowPaint();
        java.awt.Paint paint5 = piePlot1.getLabelBackgroundPaint();
        org.jfree.chart.plot.Plot plot6 = piePlot1.getParent();
        piePlot1.setMaximumLabelWidth((double) (byte) 1);
        boolean boolean9 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNull(pieToolTipGenerator3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        piePlot11.notifyListeners(plotChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot11);
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart16);
        java.awt.Color color18 = java.awt.Color.lightGray;
        piePlot1.setOutlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = piePlot1.getLabelShadowPaint();
        java.awt.Paint paint21 = null;
        try {
            piePlot1.setLabelPaint(paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        defaultKeyedValues2D1.setValue((java.lang.Number) (short) 100, (java.lang.Comparable) 0.08d, (java.lang.Comparable) "0,0,1,1");
        java.util.List list12 = defaultKeyedValues2D1.getRowKeys();
        int int14 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 0.4d);
        java.util.List list15 = defaultKeyedValues2D1.getRowKeys();
        defaultKeyedValues2D1.setValue((java.lang.Number) 3.0d, (java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean3 = standardPieSectionLabelGenerator1.equals((java.lang.Object) defaultCategoryDataset2);
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        boolean boolean5 = standardPieSectionLabelGenerator1.equals((java.lang.Object) paint4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent5 = null;
        piePlot2.notifyListeners(plotChangeEvent5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot2);
        piePlot2.setInteriorGap(0.0d);
        java.awt.Paint paint10 = piePlot2.getLabelLinkPaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot2.setSectionPaint((java.lang.Comparable) "HorizontalAlignment.CENTER", (java.awt.Paint) color12);
        float float14 = piePlot2.getBackgroundImageAlpha();
        org.jfree.chart.util.Rotation rotation15 = null;
        try {
            piePlot2.setDirection(rotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        double double6 = piePlot1.getMaximumLabelWidth();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot8.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color16 = java.awt.Color.green;
        piePlot12.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color16);
        java.awt.Font font18 = piePlot12.getLabelFont();
        piePlot8.setNoDataMessageFont(font18);
        piePlot1.setLabelFont(font18);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get(0);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        piePlot6.addChangeListener(plotChangeListener7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        piePlot6.notifyListeners(plotChangeEvent9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        piePlot13.addChangeListener(plotChangeListener14);
        java.awt.Font font16 = piePlot13.getLabelFont();
        piePlot6.setNoDataMessageFont(font16);
        int int18 = objectList1.indexOf((java.lang.Object) piePlot6);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        piePlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = java.awt.Color.green;
        piePlot20.setBackgroundPaint((java.awt.Paint) color23);
        java.awt.Image image25 = piePlot20.getBackgroundImage();
        java.lang.Object obj26 = piePlot20.clone();
        java.awt.Paint paint27 = piePlot20.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        piePlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color33 = java.awt.Color.green;
        piePlot29.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color33);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = null;
        piePlot29.axisChanged(axisChangeEvent35);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator37 = piePlot29.getLegendLabelGenerator();
        piePlot20.setLabelGenerator(pieSectionLabelGenerator37);
        piePlot20.setMaximumLabelWidth((double) 'a');
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = piePlot20.getSimpleLabelOffset();
        java.awt.Paint paint42 = piePlot20.getBackgroundPaint();
        piePlot6.setLabelLinkPaint(paint42);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(image25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator37);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        java.awt.Paint paint9 = piePlot1.getOutlinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent4 = null;
        piePlot1.notifyListeners(plotChangeEvent4);
        double double6 = piePlot1.getMaximumLabelWidth();
        piePlot1.setSectionOutlinesVisible(false);
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        piePlot12.notifyListeners(plotChangeEvent15);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot12);
        jFreeChart17.setNotify(false);
        plot9.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart17);
        jFreeChart17.clearSubtitles();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.StrokeMap strokeMap0 = new org.jfree.chart.StrokeMap();
        boolean boolean2 = strokeMap0.containsKey((java.lang.Comparable) "java.awt.Color[r=255,g=255,b=255]");
        strokeMap0.clear();
        boolean boolean5 = strokeMap0.containsKey((java.lang.Comparable) "Pie Plot");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        java.lang.Comparable comparable3 = multiplePiePlot0.getAggregatedItemsKey();
        int int4 = multiplePiePlot0.getBackgroundImageAlignment();
        multiplePiePlot0.setNoDataMessage("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "Other" + "'", comparable3.equals("Other"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        piePlot1.axisChanged(axisChangeEvent7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle9.getVerticalAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.jfree.chart.block.BlockContainer blockContainer14 = legendTitle9.getItemContainer();
        java.lang.Object obj15 = blockContainer14.clone();
        boolean boolean16 = blockContainer14.isEmpty();
        org.jfree.chart.block.Arrangement arrangement17 = blockContainer14.getArrangement();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets19.calculateBottomInset((double) (-1.0f));
        double double23 = rectangleInsets19.calculateTopOutset(0.0d);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        piePlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = java.awt.Color.green;
        piePlot25.setBackgroundPaint((java.awt.Paint) color28);
        java.awt.Image image30 = piePlot25.getBackgroundImage();
        java.lang.Object obj31 = piePlot25.clone();
        boolean boolean32 = piePlot25.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot(pieDataset33);
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        piePlot34.addChangeListener(plotChangeListener35);
        java.awt.Color color37 = java.awt.Color.green;
        piePlot34.setBackgroundPaint((java.awt.Paint) color37);
        java.awt.Stroke stroke40 = null;
        piePlot34.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke40);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator42 = piePlot34.getLegendLabelGenerator();
        piePlot34.setLabelLinksVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double47 = rectangleInsets45.calculateLeftOutset(10.0d);
        double double49 = rectangleInsets45.calculateLeftInset((double) (short) 100);
        piePlot34.setInsets(rectangleInsets45, false);
        piePlot25.setInsets(rectangleInsets45, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double56 = rectangleInsets54.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset57 = null;
        org.jfree.chart.plot.PiePlot piePlot58 = new org.jfree.chart.plot.PiePlot(pieDataset57);
        org.jfree.chart.event.PlotChangeListener plotChangeListener59 = null;
        piePlot58.addChangeListener(plotChangeListener59);
        java.awt.Color color62 = java.awt.Color.green;
        piePlot58.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color62);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent64 = null;
        piePlot58.axisChanged(axisChangeEvent64);
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot58);
        double double67 = legendTitle66.getContentYOffset();
        legendTitle66.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D70 = legendTitle66.getBounds();
        rectangleInsets54.trim(rectangle2D70);
        org.jfree.chart.entity.ChartEntity chartEntity74 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D70, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity76 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D70, "{0}");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType77 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets45.createAdjustedRectangle(rectangle2D70, lengthAdjustmentType77, lengthAdjustmentType78);
        java.awt.geom.Rectangle2D rectangle2D82 = rectangleInsets19.createInsetRectangle(rectangle2D70, false, false);
        org.jfree.data.general.PieDataset pieDataset84 = null;
        org.jfree.chart.plot.PiePlot piePlot85 = new org.jfree.chart.plot.PiePlot(pieDataset84);
        org.jfree.chart.event.PlotChangeListener plotChangeListener86 = null;
        piePlot85.addChangeListener(plotChangeListener86);
        java.awt.Color color88 = java.awt.Color.green;
        piePlot85.setBackgroundPaint((java.awt.Paint) color88);
        java.awt.Image image90 = piePlot85.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart91 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot85);
        org.jfree.chart.title.TextTitle textTitle92 = jFreeChart91.getTitle();
        java.awt.Paint paint93 = textTitle92.getBackgroundPaint();
        try {
            java.lang.Object obj94 = blockContainer14.draw(graphics2D18, rectangle2D82, (java.lang.Object) textTitle92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(blockContainer14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(arrangement17);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNull(image30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertNull(image90);
        org.junit.Assert.assertNotNull(textTitle92);
        org.junit.Assert.assertNull(paint93);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        java.awt.Paint paint8 = piePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        piePlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color6 = java.awt.Color.green;
        piePlot2.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color6);
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("RectangleEdge.TOP", (org.jfree.chart.plot.Plot) piePlot2);
        jFreeChart8.setNotify(true);
        java.lang.Class<?> wildcardClass11 = jFreeChart8.getClass();
        org.jfree.chart.title.TextTitle textTitle12 = jFreeChart8.getTitle();
        java.lang.Object obj13 = textTitle12.clone();
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(textTitle12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        multiplePiePlot0.setDataset(categoryDataset1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        multiplePiePlot0.axisChanged(axisChangeEvent3);
        boolean boolean6 = multiplePiePlot0.equals((java.lang.Object) 2);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean10 = standardPieSectionLabelGenerator8.equals((java.lang.Object) defaultCategoryDataset9);
        java.util.List list11 = defaultCategoryDataset9.getColumnKeys();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 2, (org.jfree.data.general.Dataset) defaultCategoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        paintMap0.clear();
        java.lang.Object obj2 = paintMap0.clone();
        paintMap0.clear();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
        boolean boolean6 = standardPieSectionLabelGenerator1.equals((java.lang.Object) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets7.getTop();
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) rectangleInsets7);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets12.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        piePlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color20 = java.awt.Color.green;
        piePlot16.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color20);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        piePlot16.axisChanged(axisChangeEvent22);
        org.jfree.chart.title.LegendTitle legendTitle24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot16);
        double double25 = legendTitle24.getContentYOffset();
        legendTitle24.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D28 = legendTitle24.getBounds();
        rectangleInsets12.trim(rectangle2D28);
        textTitle11.setBounds(rectangle2D28);
        java.awt.geom.Rectangle2D rectangle2D33 = rectangleInsets7.createOutsetRectangle(rectangle2D28, false, false);
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D33, "RectangleEdge.TOP");
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot(pieDataset37);
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        piePlot38.addChangeListener(plotChangeListener39);
        java.awt.Color color41 = java.awt.Color.green;
        piePlot38.setBackgroundPaint((java.awt.Paint) color41);
        java.awt.Image image43 = piePlot38.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart44 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot38);
        java.lang.Object obj45 = jFreeChart44.clone();
        org.jfree.chart.title.LegendTitle legendTitle46 = jFreeChart44.getLegend();
        org.jfree.chart.block.BlockBorder blockBorder47 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle46.setFrame((org.jfree.chart.block.BlockFrame) blockBorder47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle46.setLegendItemGraphicAnchor(rectangleAnchor49);
        java.awt.geom.Point2D point2D51 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor49);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNull(image43);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(legendTitle46);
        org.junit.Assert.assertNotNull(blockBorder47);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(point2D51);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        paintMap0.clear();
        java.awt.Color color3 = java.awt.Color.GREEN;
        paintMap0.put((java.lang.Comparable) "ChartChangeEventType.GENERAL", (java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = null;
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke7);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = piePlot1.getLegendItems();
        boolean boolean10 = piePlot1.getLabelLinksVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        boolean boolean12 = piePlot1.getIgnoreNullValues();
        boolean boolean13 = piePlot1.isOutlineVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot1.getURLGenerator();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(pieURLGenerator14);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(15);
        pieLabelDistributor1.distributeLabels(0.0d, (double) '#');
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("http://www.jfree.org/jfreechart/index.html", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color15 = java.awt.Color.green;
        piePlot11.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        piePlot11.axisChanged(axisChangeEvent17);
        org.jfree.chart.title.LegendTitle legendTitle19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot11);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = legendTitle19.getVerticalAlignment();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = null;
        org.jfree.chart.util.Size2D size2D23 = legendTitle19.arrange(graphics2D21, rectangleConstraint22);
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) legendTitle19);
        flowArrangement0.add(block1, (java.lang.Object) legendTitle19);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray26 = legendTitle19.getSources();
        legendTitle19.setPadding(10.0d, (double) (byte) 10, (double) '4', (double) 2);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray32 = legendTitle19.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendTitle19.getItemLabelPadding();
        org.jfree.data.general.PieDataset pieDataset34 = null;
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot(pieDataset34);
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        piePlot35.addChangeListener(plotChangeListener36);
        java.awt.Color color38 = java.awt.Color.green;
        piePlot35.setBackgroundPaint((java.awt.Paint) color38);
        java.awt.Stroke stroke41 = null;
        piePlot35.setSectionOutlineStroke((java.lang.Comparable) 0L, stroke41);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator43 = piePlot35.getLegendLabelGenerator();
        piePlot35.setLabelLinksVisible(false);
        org.jfree.chart.ChartColor chartColor50 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        piePlot35.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) chartColor50);
        java.awt.Paint paint52 = piePlot35.getLabelShadowPaint();
        legendTitle19.setBackgroundPaint(paint52);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(legendItemSourceArray26);
        org.junit.Assert.assertNotNull(legendItemSourceArray32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator43);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        java.lang.Object obj2 = standardPieSectionLabelGenerator1.clone();
        java.lang.String str3 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setMaximumLabelWidth((double) '4');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = java.awt.Color.green;
        piePlot9.setBackgroundPaint((java.awt.Paint) color12);
        java.awt.Image image14 = piePlot9.getBackgroundImage();
        java.lang.Object obj15 = piePlot9.clone();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        piePlot9.notifyListeners(plotChangeEvent16);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
        org.jfree.data.general.PieDataset pieDataset20 = null;
        java.lang.String str22 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset20, (java.lang.Comparable) (-1));
        org.jfree.data.general.PieDataset pieDataset23 = null;
        java.lang.String str25 = standardPieSectionLabelGenerator19.generateSectionLabel(pieDataset23, (java.lang.Comparable) (-1L));
        piePlot9.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        java.awt.Color color27 = java.awt.Color.GRAY;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color27);
        boolean boolean29 = standardPieSectionLabelGenerator19.equals((java.lang.Object) color27);
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator19);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor31 = piePlot1.getLabelDistributor();
        java.awt.Paint paint33 = piePlot1.getSectionPaint((java.lang.Comparable) "Other");
        piePlot1.setMinimumArcAngleToDraw((double) (-32));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor31);
        org.junit.Assert.assertNull(paint33);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        piePlot4.notifyListeners(plotChangeEvent7);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot11.addChangeListener(plotChangeListener12);
        java.awt.Font font14 = piePlot11.getLabelFont();
        piePlot4.setNoDataMessageFont(font14);
        boolean boolean16 = rotation0.equals((java.lang.Object) piePlot4);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot(pieDataset17);
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        piePlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color22 = java.awt.Color.green;
        piePlot18.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color22);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        piePlot18.axisChanged(axisChangeEvent24);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot18);
        org.jfree.chart.ChartColor chartColor30 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean32 = chartColor30.equals((java.lang.Object) 0);
        piePlot18.setLabelPaint((java.awt.Paint) chartColor30);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color38 = java.awt.Color.green;
        float[] floatArray45 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray46 = color38.getRGBColorComponents(floatArray45);
        float[] floatArray47 = java.awt.Color.RGBtoHSB((int) '#', (int) '4', 1, floatArray45);
        float[] floatArray48 = color34.getComponents(floatArray45);
        java.awt.Color color52 = java.awt.Color.green;
        float[] floatArray59 = new float[] { (-1L), (short) -1, (short) -1, 100, (byte) -1, (byte) 0 };
        float[] floatArray60 = color52.getRGBColorComponents(floatArray59);
        float[] floatArray61 = java.awt.Color.RGBtoHSB((int) (byte) 100, (int) (byte) 100, (int) (byte) 10, floatArray60);
        float[] floatArray62 = color34.getColorComponents(floatArray60);
        float[] floatArray63 = chartColor30.getRGBComponents(floatArray62);
        piePlot4.setBaseSectionPaint((java.awt.Paint) chartColor30);
        java.awt.Font font65 = piePlot4.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.ANTICLOCKWISE" + "'", str1.equals("Rotation.ANTICLOCKWISE"));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(font65);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-1L));
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        chartChangeEvent1.setType(chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (-1L) + "'", obj4.equals((-1L)));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Color color2 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color2);
        int int4 = piePlot1.getBackgroundImageAlignment();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot6.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot6.getToolTipGenerator();
        java.awt.Paint paint10 = piePlot6.getLabelPaint();
        java.awt.Paint paint11 = piePlot6.getLabelOutlinePaint();
        piePlot1.setLabelOutlinePaint(paint11);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.ChartColor chartColor26 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean28 = chartColor26.equals((java.lang.Object) 0);
        piePlot14.setLabelPaint((java.awt.Paint) chartColor26);
        piePlot1.setBaseSectionOutlinePaint((java.awt.Paint) chartColor26);
        org.jfree.data.general.PieDataset pieDataset31 = piePlot1.getDataset();
        boolean boolean32 = piePlot1.isCircular();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(pieDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        java.lang.Object obj2 = null;
        boolean boolean3 = textTitle1.equals(obj2);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        piePlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color9 = java.awt.Color.green;
        piePlot5.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        piePlot5.axisChanged(axisChangeEvent11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot5);
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = legendTitle13.getVerticalAlignment();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = null;
        org.jfree.chart.util.Size2D size2D17 = legendTitle13.arrange(graphics2D15, rectangleConstraint16);
        double double18 = legendTitle13.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle13.getLegendItemGraphicEdge();
        org.jfree.data.general.Dataset dataset20 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) legendTitle13, dataset20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = legendTitle13.getHorizontalAlignment();
        textTitle1.setHorizontalAlignment(horizontalAlignment22);
        java.lang.Object obj24 = textTitle1.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        piePlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color7 = java.awt.Color.green;
        piePlot3.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3.axisChanged(axisChangeEvent9);
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot3);
        org.jfree.chart.ChartColor chartColor15 = new org.jfree.chart.ChartColor((int) (short) 100, 0, (int) (byte) 10);
        boolean boolean17 = chartColor15.equals((java.lang.Object) 0);
        piePlot3.setLabelPaint((java.awt.Paint) chartColor15);
        java.awt.Image image19 = piePlot3.getBackgroundImage();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot3.getLabelDistributor();
        boolean boolean21 = piePlot3.getSimpleLabels();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("", font1, (org.jfree.chart.plot.Plot) piePlot3, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color5 = java.awt.Color.green;
        piePlot1.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color5);
        java.awt.Color color8 = java.awt.Color.MAGENTA;
        piePlot1.setSectionOutlinePaint((java.lang.Comparable) "hi!", (java.awt.Paint) color8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        float float11 = jFreeChart10.getBackgroundImageAlpha();
        java.awt.Paint paint12 = jFreeChart10.getBackgroundPaint();
        int int13 = jFreeChart10.getSubtitleCount();
        java.awt.Paint paint14 = jFreeChart10.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("org.jfree.chart.event.ChartChangeEvent[source=-1]");
        java.util.Locale locale3 = jFreeChartResources0.getLocale();
        java.lang.Object[][] objArray4 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(locale3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.clear();
        java.util.List list4 = defaultKeyedValues2D1.getColumnKeys();
        java.lang.Comparable comparable5 = null;
        try {
            int int6 = defaultKeyedValues2D1.getRowIndex(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        piePlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color8 = java.awt.Color.green;
        piePlot4.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color8);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot4.axisChanged(axisChangeEvent10);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot4);
        double double13 = legendTitle12.getContentYOffset();
        legendTitle12.setNotify(true);
        java.awt.geom.Rectangle2D rectangle2D16 = legendTitle12.getBounds();
        rectangleInsets0.trim(rectangle2D16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D16, "RectangleEdge.TOP");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor23);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNotNull(point2D24);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        defaultKeyedValues2D1.setValue((java.lang.Number) 2, (java.lang.Comparable) "org.jfree.chart.ChartColor[r=100,g=0,b=10]", (java.lang.Comparable) (byte) 0);
        int int8 = defaultKeyedValues2D1.getRowCount();
        java.lang.Number number9 = null;
        defaultKeyedValues2D1.setValue(number9, (java.lang.Comparable) "RectangleAnchor.TOP_LEFT", (java.lang.Comparable) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("org.jfree.chart.ChartColor[r=100,g=0,b=10]");
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        java.lang.String str2 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str2.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        piePlot1.setMaximumLabelWidth((double) 10.0f);
        piePlot1.setShadowYOffset((double) ' ');
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot9.addChangeListener(plotChangeListener10);
        piePlot9.setLabelLinksVisible(false);
        java.awt.Stroke stroke14 = piePlot9.getOutlineStroke();
        piePlot1.setOutlineStroke(stroke14);
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font17 = legendTitle16.getItemFont();
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        java.lang.Object obj7 = piePlot1.clone();
        java.awt.Paint paint8 = piePlot1.getBackgroundPaint();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        piePlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color14 = java.awt.Color.green;
        piePlot10.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color14);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot10.axisChanged(axisChangeEvent16);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot10.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator18);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor20 = piePlot1.getLabelDistributor();
        java.awt.Paint paint21 = piePlot1.getBaseSectionOutlinePaint();
        piePlot1.setStartAngle((double) 10);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("HorizontalAlignment.CENTER");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("PieSection: 32, -1( )");
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("HorizontalAlignment.CENTER");
        java.lang.String str6 = unknownKeyException5.toString();
        unknownKeyException3.addSuppressed((java.lang.Throwable) unknownKeyException5);
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.UnknownKeyException: HorizontalAlignment.CENTER" + "'", str6.equals("org.jfree.data.UnknownKeyException: HorizontalAlignment.CENTER"));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        java.util.List list2 = projectInfo0.getContributors();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNull(list1);
        org.junit.Assert.assertNull(list2);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        piePlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = java.awt.Color.green;
        piePlot1.setBackgroundPaint((java.awt.Paint) color4);
        java.awt.Image image6 = piePlot1.getBackgroundImage();
        boolean boolean7 = piePlot1.getIgnoreNullValues();
        java.lang.String str8 = piePlot1.getNoDataMessage();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = piePlot1.getDrawingSupplier();
        piePlot1.zoom((double) 0L);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        piePlot7.addChangeListener(plotChangeListener8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = null;
        piePlot7.notifyListeners(plotChangeEvent10);
        org.jfree.chart.JFreeChart jFreeChart12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) piePlot7);
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        piePlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color18 = java.awt.Color.green;
        piePlot14.setSectionPaint((java.lang.Comparable) 1, (java.awt.Paint) color18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot14.axisChanged(axisChangeEvent20);
        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot14);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = legendTitle22.getVerticalAlignment();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = null;
        org.jfree.chart.util.Size2D size2D26 = legendTitle22.arrange(graphics2D24, rectangleConstraint25);
        jFreeChart12.addSubtitle((org.jfree.chart.title.Title) legendTitle22);
        org.jfree.chart.title.TextTitle textTitle28 = jFreeChart12.getTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = textTitle28.getTextAlignment();
        java.lang.String str30 = horizontalAlignment29.toString();
        org.jfree.chart.util.VerticalAlignment verticalAlignment31 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.ColumnArrangement columnArrangement34 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment29, verticalAlignment31, 0.0d, (double) 'a');
        columnArrangement34.clear();
        java.lang.Object obj36 = null;
        boolean boolean37 = columnArrangement34.equals(obj36);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        double double40 = textTitle39.getHeight();
        textTitle39.setText("");
        java.awt.Color color43 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot(pieDataset45);
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        piePlot46.addChangeListener(plotChangeListener47);
        java.awt.Color color49 = java.awt.Color.green;
        piePlot46.setBackgroundPaint((java.awt.Paint) color49);
        java.awt.Image image51 = piePlot46.getBackgroundImage();
        org.jfree.chart.JFreeChart jFreeChart52 = new org.jfree.chart.JFreeChart("java.awt.Color[r=255,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot46);
        java.awt.Stroke stroke53 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart52.setBorderStroke(stroke53);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double57 = rectangleInsets55.calculateLeftOutset(10.0d);
        double double59 = rectangleInsets55.calculateRightOutset((double) (short) 10);
        org.jfree.chart.block.LineBorder lineBorder60 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color43, stroke53, rectangleInsets55);
        columnArrangement34.add((org.jfree.chart.block.Block) textTitle39, (java.lang.Object) stroke53);
        org.jfree.chart.block.FlowArrangement flowArrangement62 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.general.PieDataset pieDataset63 = null;
        org.jfree.chart.plot.PiePlot piePlot64 = new org.jfree.chart.plot.PiePlot(pieDataset63);
        org.jfree.chart.event.PlotChangeListener plotChangeListener65 = null;
        piePlot64.addChangeListener(plotChangeListener65);
        java.awt.Font font67 = piePlot64.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double70 = rectangleInsets68.calculateLeftOutset(10.0d);
        piePlot64.setSimpleLabelOffset(rectangleInsets68);
        boolean boolean72 = flowArrangement62.equals((java.lang.Object) rectangleInsets68);
        org.jfree.chart.block.BlockContainer blockContainer73 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement62);
        org.jfree.chart.title.LegendTitle legendTitle74 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement34, (org.jfree.chart.block.Arrangement) flowArrangement62);
        org.junit.Assert.assertNotNull(drawingSupplier2);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(size2D26);
        org.junit.Assert.assertNotNull(textTitle28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "HorizontalAlignment.CENTER" + "'", str30.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertNotNull(verticalAlignment31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNull(image51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }
}

